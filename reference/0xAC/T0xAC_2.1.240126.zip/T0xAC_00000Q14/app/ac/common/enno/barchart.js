// { "framework": "Vue" }

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 1072);
/******/ })
/************************************************************************/
/******/ ({

/***/ 1072:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _barchart = __webpack_require__(1073);

var _barchart2 = _interopRequireDefault(_barchart);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

new Vue({
  el: '#root',
  render: function render(h) {
    return h(_barchart2.default);
  }
}); // 自动生成的入口文件

/***/ }),

/***/ 1073:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(1074)
)
__vue_styles__.push(__webpack_require__(1075)
)

/* script */
__vue_exports__ = __webpack_require__(1076)

/* template */
var __vue_template__ = __webpack_require__(1077)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/chenhx113/Documents/project/meijuobmweexapp/code/AC/src/T0xAC/app/ac/common/enno/barchart.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-e574a770"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 1074:
/***/ (function(module, exports) {

module.exports = {
  "content-wrapper": {
    "alignItems": "center",
    "width": 750
  },
  "chart-wrapper": {
    "paddingLeft": 15,
    "paddingRight": 15,
    "marginTop": 50,
    "paddingBottom": 5,
    "height": 434,
    "backgroundColor": "#198d59",
    "borderRadius": 16
  },
  "barchart1-wrapper": {
    "marginTop": 40,
    "paddingBottom": 40,
    "width": 750,
    "height": 434,
    "backgroundColor": "#ffffff",
    "borderRadius": 16
  },
  "barchart1": {
    "width": 700,
    "height": 366,
    "backgroundColor": "#f8f8f8",
    "marginTop": 32
  },
  "barchart2-wrapper": {
    "marginTop": 32,
    "width": 750,
    "height": 434,
    "backgroundColor": "#ffffff"
  },
  "barchart2": {
    "width": 750,
    "height": 366,
    "marginTop": 32
  }
}

/***/ }),

/***/ 1075:
/***/ (function(module, exports) {

module.exports = {
  "btn": {
    "width": 400,
    "height": 100,
    "lineHeight": 100,
    "textAlign": "center",
    "marginLeft": 100,
    "marginTop": 100,
    "border": "1px solid #eeeeee",
    "backgroundColor": "#dddddd"
  }
}

/***/ }),

/***/ 1076:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var modal = weex.requireModule('modal');
var msmartlifeModule = weex.requireModule('msmartlifeModule');
var routerModule = weex.requireModule('routerModule');
var bridgeModule = weex.requireModule('bridgeModule');

exports.default = {
  created: function created() {},
  data: function data() {
    return {
      chartData1: {
        marker: {
          //ChartMarkerView
          // extraInfo: {
          //   title: '行2',
          //   value: ['exv1', 'exv2', 'exv3']
          // },
          markerShow: true, //默认为false,不显示maker
          markerColor: '#ccccff', //默认为黑色000000，marker的背景色
          markerTextColor: '#ffffff', //默认白色，marker字体字颜色
          markerTextSize: '12', //默认12
          markerCornerRadius: '0', //圆角
          markerGraduationLabel: '℃', //显示单位 默认为空""
          markerOffsetY: 0, //垂直间距设置
          barSelectIndex: 1,
          markerType: 1, //需要为1，多曲线才能显示
          isMutipleLineMark: true,
          highLineDashAble: true,
          isVerticalHighlightIndicatorEnabled: true,
          isHorizontalHighlightIndicatorEnabled: false,
          highLightColor: '#aaaaaa'
        },
        x: {
          value: [1, 2, 3, 4, 5, 6, 7],
          label: ['11.6', '11.7', '11.8', '11.9', '11.10', '11.11', '11.12'],
          markerLabel: ['xm1', 'xm2', 'xm3', 'xm4', 'xm5', 'xm6', 'xm7', 'xm8', 'xmarkerLabel9111111']
        },
        y: [{
          //"maxValue": [4, 6, 8, 10, 2, 5, 8],
          value: [10.3, 4, 10, 2, 5.5, 2, 7],
          label: ['数据值10', '数据值4', '数据值10', '数据值2', '数据值5.5', '数据值自定义', '数据值自定义'],
          //"color": "#FF00FFFF", //柱子颜色ARGB格式
          //"maxColor": '#FFFF0000', //柱子上面颜色ARGB格式
          renderAttributes: [
          //renderAttributes设置后，maxValue，color，maxColor, maxHighLightColor,highLightColor 属性会被忽略
          //renderAttributes中的proportion加起来必须为1，且第一个颜色属性从柱状图顶部开始
          [{
            proportion: 0.45,
            color: '#77FF0000',
            highLightColor: '#FFFF0000',
            highLightContent: '百分之0.45百分之0.45百分之0'
          }, { proportion: 0.2, color: '#7700FF00', highLightColor: '#FF00FF00', highLightContent: '百分之0.2' }, { proportion: 0.1, color: '#770000FF', highLightColor: '#FF0000FF', highLightContent: '百分之0.1' }, { proportion: 0.25, color: '#77FF0000', highLightColor: '#FFFF0000', highLightContent: '百分之0.25' }], [{
            proportion: 1,
            color: '#FFFF0000',
            highLightColor: '#FF00FF00',
            highLightContent: '高亮自定义string1'
          }], [{
            proportion: 0.2,
            color: '#77FF0000',
            highLightColor: '#FFFF0000',
            highLightContent: '高亮自定义string2'
          }, {
            proportion: 0.2,
            color: '#77123456',
            highLightColor: '#FF123456',
            highLightContent: '高亮自定义string3'
          }, {
            proportion: 0.1,
            color: '#77882244',
            highLightColor: '#FF882244',
            highLightContent: '高亮自定义string4'
          }, {
            proportion: 0.1,
            color: '#77772211',
            highLightColor: '#FF772211',
            highLightContent: '高亮自定义string5'
          }, {
            proportion: 0.4,
            color: '#77990000',
            highLightColor: '#FF990000',
            highLightContent: '高亮自定义string6'
          }], [{
            proportion: 1,
            color: '#FF12FF55',
            highLightColor: '#FF5BD2FF',
            highLightContent: '高亮自定义string7'
          }], [{
            proportion: 1,
            color: '#FF1234FF',
            highLightColor: '#FF5BD2FF',
            highLightContent: '高亮自定义string8'
          }], [{
            proportion: 1,
            color: '#FF1234FF',
            highLightColor: '#FF5BD2FF',
            highLightContent: '高亮自定义string9'
          }], [{
            proportion: 0.2,
            color: '#FFFF0000',
            highLightColor: '#FF5BD2FF',
            highLightContent: '高亮自定义string10'
          }, {
            proportion: 0.2,
            color: '#FF123456',
            highLightColor: '#FF5BD2FF',
            highLightContent: '高亮自定义string11'
          }, {
            proportion: 0.1,
            color: '#FF007700',
            highLightColor: '#FF5BD2FF',
            highLightContent: '高亮自定义string12'
          }, {
            proportion: 0.1,
            color: '#FF0000AA',
            highLightColor: '#FF5BD2FF',
            highLightContent: '高亮自定义string13'
          }, {
            proportion: 0.4,
            color: '#FF00FF00',
            highLightColor: '#FF5BD2FF',
            highLightContent: '高亮自定义string14'
          }]],
          background: '#ffffff',
          //"maxHighLightColor": "#805BD2FF", //高亮颜色
          //"highLightColor": "#FF5BD2FF", //高亮颜色
          highLightEnable: true //点击高亮是否可用
        }],
        xAxisColor: '#000000', //x轴线的颜色，如果不设置，则默认是黑色线
        xAxisLabelColor: '#000000', //x label的字体颜色，如果不设置，则默认是黑色字体颜色
        yAxisColor: '#000000', //y轴线的颜色，如果不设置，则默认是黑色线
        yAxisLabelColor: '#000000', // label的字体颜色，如果不设置，则默认是黑色字体颜色
        background: '#ffffff', //不传，则默认使用透明背景
        borderRadius: '7.5', //柱子顶部的圆角，默认为0px
        bottomBorderRadius: '7.5', //底部的圆角值
        barWidth: '15', //设置柱状的宽度
        xAxisGridColor: '#ffffff', //x轴上分割线颜色
        xAxisGridAlpha: 0.5, //x轴上分割线透明度
        granularity: 1.2, //间距本身是自适应的，可以使用该值进行调整间距的比例，比如自适应间距是20px，granularity设置为2的时候，界面显示的间距为 40px

        yAxisLabelShow: true, //是否只显示最大最小值，true: 显示y轴值；false: 不显示y轴值；默认true

        description: '',
        legend: {
          position: 'TOP_RIGHT', //"TOP_LEFT"/"TOP_RIGHT"
          orientation: 'BOTTOM_RIGHT', //"HORIZONTAL"/"BOTTOM_RIGHT"
          show: false //控制每组数据标识的显示或隐藏
        },
        unit: {
          // "x": "x坐标",
          // "y": "y坐标"
        },
        signPost: {
          //底部界面  v5.8.0
          lineHeight: 1, //线条的高度
          lineColor: '#e5e5e8', //标签线的颜色 如果不设置，则默认是黑色线
          linePointRadius: 3, //标签线上圆点的半径, 默认10
          lineMarginTop: '5', //线条距离X轴的距离
          lineMarginBottom: '0',
          cursorColor: '#5BD2FF', //标签（三角形）的颜色 如果不设置，则默认是黑色线
          cursorMarginTop: '5', //标签（三角形）距离线条的距离
          cursorHigh: '20', //标签（三角形）本身高度
          cursorMarginBottom: '0',
          show: true, //默认是 false 是否显示底部界面
          showType: 'ends', //端点的显示样式，支持 all,ends,none 三种模式
          isSelectedDisappear: true //是否标签 滑动到的端点消失不见
        },
        yNumberOfDecimalConfig: true,
        yNumberOfDecimal: 3
      },
      chartData2: {
        marker: {
          //ChartMarkerView
          // extraInfo: {
          //   title: '行2',
          //   value: ['exv1', 'exv2', 'exv3']
          // },
          markerShow: true, //默认为false,不显示maker
          markerColor: '#cccccc', //默认为黑色，marker的背景色
          markerTextColor: '#ffffff', //默认白色，marker字体字颜色
          markerTextSize: '12', //默认12
          markerCornerRadius: '0', //圆角
          markerGraduationLabel: '℃', //显示单位 默认为空""
          markerOffsetY: 0, //垂直间距设置
          barSelectIndex: 1,
          markerType: 1, //需要为1，多曲线才能显示
          isMutipleLineMark: true,
          highLineDashAble: true,
          isVerticalHighlightIndicatorEnabled: true,
          isHorizontalHighlightIndicatorEnabled: false,
          highLightColor: '#aaaaaa',
          markermaximumFractionDigits: 4,
          trimSuffixFragction: false
        },
        x: {
          markerLabel: ['xm1', 'xm2', 'xm3', 'xm4', 'xm5', 'xm6', 'xm7', 'xm8', 'xmarkerLabel9111111'],
          label: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30']
        },
        y: [{
          maxValue: [10, 5, 3, 7, 1.8, 8.8, 9, 1, 1, 4, 3, 7, 4, 8.5, 7, 9, 8.6, 1.8, 3, 4, 10, 8, 7, 3, 3.8, 3.6, 4, 7, 4, 4],
          value: [3, 2, 1.5, 2.5, 0.3, 3.8, 2, 0.2, 1, 1, 1, 3, 1, 0.5, 3.2, 2, 2, 0.5, 1, 1, 3, 2, 2, 0.5, 0.8, 1.1, 1, 1, 1, 1],
          // "label": ["7L", "3L", "2.5L", "4.5L", "1.5L", "5L", "7L", "0.8L", "1L", "3L", "2L", "4L", "3L", "8L", "3.8L", "7L", "6.6L", "1.3L", "2L", "3L", "7L", "6L", "5L", "2.5L", "3L", "2.5L", "3L", "6L", "3L", "3L"],
          color: '#605BD2FF', //柱子颜色ARGB格式
          maxColor: '#205BD2FF', //柱子上面颜色ARGB格式
          maxHighLightColor: '#8000FF00', //高亮颜色
          highLightColor: '#FFFF0000', //高亮颜色
          background: '#ffffff',
          highLightEnable: true //点击高亮是否可用
        }],
        xAxisColor: '#e5e5e8', //x轴线的颜色，如果不设置，则默认是白色线
        xAxisLabelColor: '#8a8a8f', //x label的字体颜色，如果不设置，则默认是白色线
        yAxisColor: 'transparent', //y轴线的颜色，如果不设置，则默认是白色线
        yAxisLabelColor: '#8a8a8f', // label的字体颜色，如果不设置，则默认是白色线
        // "background": "#ffffff", //不传，则默认使用透明背景
        borderRadius: '3', //柱子顶部的圆角，默认为0px
        bottomBorderRadius: '3', //底部的圆角值
        barWidth: 10, //设置柱状的宽度
        description: '图标描叙',
        valueTextColor: '#4AD8CB', // 设置值显示文本颜色
        valueTextSize: 12, // 设置值显示文本字体大小
        barSpacing: 20,
        title: 't室1',
        legend: {
          position: 'TOP_RIGHT', //"TOP_LEFT"/"TOP_RIGHT"
          orientation: 'BOTTOM_RIGHT', //"HORIZONTAL"/"BOTTOM_RIGHT"
          show: false //是否显示标识
        },
        unit: {
          // "x": "x坐标",
          // "y": "y坐标"
        }
      },
      chartData3: {
        marker: {
          //ChartMarkerView
          // extraInfo: {
          //   title: '行2',
          //   value: ['exv1', 'exv2', 'exv3']
          // },
          markerShow: true, //默认为false,不显示maker
          markerColor: '#000000', //默认为黑色，marker的背景色
          markerTextColor: '#cccccc', //默认白色，marker字体字颜色
          markerTextSize: '12', //默认12
          markerCornerRadius: '0', //圆角
          markerGraduationLabel: '吨', //显示单位 默认为空""
          markerOffsetY: 0, //垂直间距设置
          barSelectIndex: 1,
          markerType: 1, //需要为1，多曲线才能显示
          isMutipleLineMark: true,
          highLineDashAble: true,
          isVerticalHighlightIndicatorEnabled: true,
          isHorizontalHighlightIndicatorEnabled: false,
          highLightColor: '#aaaaaa',
          markermaximumFractionDigits: 5,
          trimSuffixFragction: false
        },
        description: '图标描叙',
        unit: { y: 'kw·h' },
        yAxisLabelColor: '#8a8a8f',
        xAxisColor: '#e5e5e8',
        background: '#ffffff',
        x: {
          markerLabel: ['xmarkerLabel9111111', 'xm2', 'xm3', 'xm4', 'xm5', 'xm6', 'xm7', 'xm8', 'xmarkerLabel9111111'],
          label: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30]
        },
        yAxisColor: '#FF69ABFF',
        y: [{
          maxColor: '#FF69ABFF',
          color: '#FF69ABFF',
          highLightColor: '#FF5BD2FF',
          value: [1, 1, 2, 3.5, 1, 3, 3, 1, 1, 2, 1, 1, 2, 3.5, 1, 3, 3, 1, 1, 2, 1, 1, 2, 3.5, 1, 3, 3, 1, 1, 2],
          background: '#ffffff',
          highLightEnable: true,
          maxHighLightColor: '#805BD2FF',
          title: 'yTitle'
        }],
        barWidth: '6',
        barSpacing: '8',
        bottomBorderRadius: '3',
        yAxis: [{ position: 'RIGHT' }],

        legend: {
          show: false,
          position: 'TOP_LEFT',
          orientation: 'BOTTOM_RIGHT'
        },
        borderRadius: '3',
        xAxisLabelColor: '#8a8a8f'
      },
      chartData4: {
        marker: {
          //ChartMarkerView
          // extraInfo: {
          //   title: '行2',
          //   value: ['exv1', 'exv2', 'exv3']
          // },
          markerShow: true, //默认为false,不显示maker
          markerColor: '#cccccc', //默认为黑色，marker的背景色
          markerTextColor: '#ffffff', //默认白色，marker字体字颜色
          markerTextSize: '12', //默认12
          markerCornerRadius: '0', //圆角
          markerGraduationLabel: '℃', //显示单位 默认为空""
          markerOffsetY: 0, //垂直间距设置
          barSelectIndex: 1,
          markerType: 1, //需要为1，多曲线才能显示
          isMutipleLineMark: true
        },
        x: {
          //"value": [1, 2, 3, 4, 5, 6, 7],
          label: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30]
        },
        y: [{
          maxValue: [10, 5, 3, 7, 1.8, 8.8, 9, 1, 1, 4, 3, 7, 4, 8.5, 7, 9, 8.6, 1.8, 3, 4, 10, 8, 7, 3, 3.8, 3.6, 4, 7, 4, 4],
          value: [3, 2, 1.5, 2.5, 0.3, 3.8, 2, 0.2, 1, 1, 1, 3, 1, 0.5, 3.2, 2, 2, 0.5, 1, 1, 3, 2, 2, 0.5, 0.8, 1.1, 1, 1, 1, 1],
          // "label": ["7L", "3L", "2.5L", "4.5L", "1.5L", "5L", "7L", "0.8L", "1L", "3L", "2L", "4L", "3L", "8L", "3.8L", "7L", "6.6L", "1.3L", "2L", "3L", "7L", "6L", "5L", "2.5L", "3L", "2.5L", "3L", "6L", "3L", "3L"],
          color: '#605BD2FF', //柱子颜色ARGB格式
          maxColor: '#205BD2FF', //柱子上面颜色ARGB格式
          maxHighLightColor: '#8000FF00', //高亮颜色
          highLightColor: '#FFFF0000', //高亮颜色
          background: '#ffffff',
          highLightEnable: true //点击高亮是否可用
        }, {
          maxValue: [10, 9, 8, 7, 6, 5, 1.9, 0.1, 0.1, 4, 3, 7, 4, 8.5, 7, 9, 8.6, 1.8, 3, 4, 10, 8, 7, 3, 3.8, 3.6, 4, 7, 4, 4],
          value: [5, 4, 3, 2, 1, 0.5, 2, 0.2, 1, 1, 1, 3, 1, 0.5, 3.2, 2, 2, 0.5, 1, 1, 3, 2, 2, 0.5, 0.8, 1.1, 1, 1, 1, 1],
          // "label": ["7L", "3L", "2.5L", "4.5L", "1.5L", "5L", "7L", "0.8L", "1L", "3L", "2L", "4L", "3L", "8L", "3.8L", "7L", "6.6L", "1.3L", "2L", "3L", "7L", "6L", "5L", "2.5L", "3L", "2.5L", "3L", "6L", "3L", "3L"],
          color: '#605BD2FF', //柱子颜色ARGB格式
          maxColor: '#205BD2FF', //柱子上面颜色ARGB格式
          maxHighLightColor: '#8000FF00', //高亮颜色
          highLightColor: '#FFFF0000', //高亮颜色
          background: '#ffffff',
          highLightEnable: true //点击高亮是否可用
        }],
        xAxisColor: '#e5e5e8', //x轴线的颜色，如果不设置，则默认是白色线
        xAxisLabelColor: '#8a8a8f', //x label的字体颜色，如果不设置，则默认是白色线
        yAxisColor: 'transparent', //y轴线的颜色，如果不设置，则默认是白色线
        yAxisLabelColor: '#8a8a8f', // label的字体颜色，如果不设置，则默认是白色线
        // "background": "#ffffff", //不传，则默认使用透明背景
        borderRadius: '3', //柱子顶部的圆角，默认为0px
        bottomBorderRadius: '3', //底部的圆角值
        barWidth: '3', //设置柱状的宽度
        description: '图标描叙',
        valueTextColor: '#4AD8CB', // 设置值显示文本颜色
        valueTextSize: 12, // 设置值显示文本字体大小
        barSpacing: '18',
        title: 't室1',
        legend: {
          position: 'TOP_RIGHT', //"TOP_LEFT"/"TOP_RIGHT"
          orientation: 'BOTTOM_RIGHT', //"HORIZONTAL"/"BOTTOM_RIGHT"
          show: false //是否显示标识
        },
        unit: {
          // "x": "x坐标",
          // "y": "y坐标"
        }
      }
    };
  },

  methods: {
    goToMeijuPage: function goToMeijuPage() {
      var url = 'midea-overseas://com.midea.overseas/main?type=jumpNative&pageName=giftVideo&featuredId=a5b3326b-86c5-3c22-ba94-b0e5e86b40d1'; // 精选视频详情url

      routerModule.goToMeijuPageWithUrl({
        url: url
      });
    },
    showDialog: function showDialog() {
      var params = {
        show_type: '1'
      };
      msmartlifeModule.showGuideEvaluationDialog(JSON.stringify(params), function () {}, function () {});
    },
    choseVideo: function choseVideo() {
      bridgeModule.commandInterface({ operation: 'chooseVideo' }, function (data) {
        console.log(JSON.stringify(data));
        var tempFilePath = data.tempFilePath;
        // path, domain

        var params = { files: [tempath], path: '', domain: '' };
        bridgeModule.commandInterface({ operation: 'uploadLocalFile', params: params }, function (uploadData) {
          console.log(JSON.stringify(uploadData));
        });
      });
    },
    uploadVideo: function uploadVideo() {
      bridgeModule.commandInterface({ operation: 'chooseVideo' }, function (data) {
        console.log(JSON.stringify(data));
      });
    }
  }
};

/***/ }),

/***/ 1077:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('list', {
    staticClass: ["list"]
  }, [_c('cell', {
    staticClass: ["content-wrapper"],
    appendAsTree: true,
    attrs: {
      "append": "tree"
    }
  }, [_c('div', {
    staticClass: ["chart-wrapper"]
  }, [_c('midea-barchart-view', {
    staticClass: ["barchart1"],
    attrs: {
      "data": _vm.chartData1
    }
  })], 1), _c('div', {
    staticClass: ["chart-wrapper"]
  }, [_c('midea-barchart-view', {
    staticClass: ["barchart1"],
    attrs: {
      "data": _vm.chartData2
    }
  })], 1), _c('div', {
    staticClass: ["chart-wrapper"]
  }, [_c('midea-barchart-view', {
    staticClass: ["barchart1"],
    attrs: {
      "data": _vm.chartData3
    }
  })], 1), _c('div', {
    staticClass: ["chart-wrapper"]
  }, [_c('midea-barchart-view', {
    staticClass: ["barchart1"],
    attrs: {
      "data": _vm.chartData4
    }
  })], 1)])])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ })

/******/ });