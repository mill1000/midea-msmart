// { "framework": "Vue" }

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 1113);
/******/ })
/************************************************************************/
/******/ ({

/***/ 1:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _debugUtil = __webpack_require__(8);

var _debugUtil2 = _interopRequireDefault(_debugUtil);

var _util = __webpack_require__(13);

var _util2 = _interopRequireDefault(_util);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var mm = weex.requireModule('modal');
var navigator = weex.requireModule('navigator');
var stream = weex.requireModule('stream');
var storage = weex.requireModule('storage');
var bridgeModule = weex.requireModule('bridgeModule');
// const blueToothModule = weex.requireModule('blueToothModule');
var singleBlueToothModule = weex.requireModule('singleBlueToothModule'); // ^5.9.0
var blueToothMeshModule = weex.requireModule('blueToothMeshModule');
var globalEvent = weex.requireModule("globalEvent");
var aiSpeechModule = weex.requireModule("aiSpeechModule"); // ^5.9.0


var isIos = weex.config.env.platform == "iOS" ? true : false;


var isDummy = false;
// import Mock from './mock'  //正式场上线时注释掉

var debugLogSeperator = "**************************************\n";

var isDummy = _util2.default.getParameters(weex.config.bundleUrl, "isDummy") == "true";

var platform = weex.config.env.platform;
if (platform == 'Web') {
    isDummy = true;
}
console.log("isDummy:" + isDummy);
var isRemote = weex.config.bundleUrl.indexOf("http") > -1 ? true : false;

exports.default = {
    serviceList: {
        test: "commonservice"
    },
    Mock: {},
    isDummy: isDummy,
    //**********Util方法***************START
    convertToJson: function convertToJson(str) {
        var result = str;
        if (typeof str == 'string') {
            try {
                result = JSON.parse(str);
            } catch (error) {
                console.error(error);
            }
        }
        return result;
    },
    getParameters: function getParameters(key) {
        var theRequest = new Object();
        var bundleUrl = weex.config.bundleUrl;
        var queryString = '';
        if (bundleUrl.indexOf("?") != -1) {
            queryString = bundleUrl.substr(bundleUrl.indexOf("?") + 1);
            var strs = queryString.split("&");
            for (var i = 0; i < strs.length; i++) {
                theRequest[strs[i].split("=")[0]] = decodeURIComponent(strs[i].split("=")[1]);
            }
        }
        return key ? theRequest[key] : theRequest;
    },

    //**********Util方法***************END

    //**********页面跳转接口***************START
    /*
    params:
        path - 跳转页面路径（以插件文件夹为根目录的相对路径）
        options: {
            animated: true/false, - 是否需要跳转动画
            replace: true/false, - 跳转后是否在历史栈保留当前页面
            viewTag: string - 给跳转后的页面设置标识，可用于goBack时指定返回页面
            transparent: 'true/false', //新页面背景是否透明
            animatedType: 'slide_bottomToTop' //新页面出现动效类型
        }
     */
    goTo: function goTo(path, options, params, isCanSideBack) {
        var _this = this;

        var url;

        if (params) {
            path += (path.indexOf("?") == -1 ? '?' : "&") + Object.keys(params).map(function (k) {
                return encodeURIComponent(k) + '=' + encodeURIComponent(params[k] || '');
            }).join('&');
        }
        // mm.toast({ message: isRemote, duration: 2 })
        if (this.isDummy != true && !isRemote) {
            //手机本地页面跳转
            this.getPath(function (weexPath) {
                //weexPath为当前页面目录地址
                // url = weexPath + path;
                var weexPathArray = weexPath.split('/');
                var pathArray = path.split('/');
                if (weexPathArray[weexPathArray.length - 2] == pathArray[0]) {
                    pathArray.shift();
                    if (weexPathArray[weexPathArray.length - 3] == pathArray[0]) {
                        pathArray.shift();
                        if (weexPathArray[weexPathArray.length - 4] == pathArray[0]) {
                            pathArray.shift();
                        }
                    }
                    url = weexPathArray.join('/') + pathArray.join('/');
                } else {
                    url = weexPath + path;
                }
                // this.alert(path+'-------'+JSON.stringify(options))
                _this.runGo(url, options, isCanSideBack);
            });
        } else if (platform != 'Web') {
            //手机远程weex页面调试跳转
            this.getPath(function (weexPath) {
                //weexPath为当前页面目录地址
                var weexPathArray = weexPath.split('/');
                var pathArray = path.split('/');
                if (weexPathArray[weexPathArray.length - 2] == pathArray[0]) {
                    pathArray.shift();
                    if (weexPathArray[weexPathArray.length - 3] == pathArray[0]) {
                        pathArray.shift();
                        if (weexPathArray[weexPathArray.length - 4] == pathArray[0]) {
                            pathArray.shift();
                        }
                    }
                    url = weexPathArray.join('/') + pathArray.join('/');
                } else {
                    url = weexPath + path;
                }
                if (url.indexOf("?") != -1) {
                    url += '&isDummy=' + isDummy;
                } else {
                    url += '?isDummy=' + isDummy;
                }
                _this.runGo(url, options, isCanSideBack);
            });
        } else {
            //PC网页调试跳转
            location.href = location.origin + location.pathname + '?path=' + path.replace('?', '&');
        }
    },
    runGo: function runGo(url, options, isCanSideBack) {
        // mm.toast({ message: url, duration: 2 })
        // if (isCanSideBack !== undefined) {
        //     options.isCanSideBack = isCanSideBack
        // }
        if (!options) {
            options = {
                animated: 'true',
                replace: 'false'
            };
        } else {
            if (typeof options.animated == 'boolean') {
                options.animated = options.animated ? 'true' : 'false';
            }
            if (typeof options.replace == 'boolean') {
                options.replace = options.replace ? 'true' : 'false';
            }
        }
        // this.alert(isCanSideBack)
        if (isCanSideBack !== undefined) {
            options.isCanSideBack = isCanSideBack;
        }
        // this.alert('tt'+JSON.stringify(options))
        var params = Object.assign(options, {
            url: url
        });
        // this.alert(params)
        navigator.push(params, function (event) {});
    },

    /*
        取得当前weex页面的根路径
    */
    getPath: function getPath(callBack) {
        if (this.isDummy != true && !isRemote) {
            bridgeModule.getWeexPath(function (resData) {
                var jsonData = JSON.parse(resData);
                var weexPath = jsonData.weexPath;
                callBack(weexPath);
            });
        } else if (platform != 'Web') {
            //手机远程weex页面调试
            var rootPath = weex.config.bundleUrl.match(new RegExp("(.*/).*\.js", "i"));
            callBack(rootPath ? rootPath[1] : weex.config.bundleUrl);
        } else {
            //PC网页调试跳转
            location.href = location.origin + location.pathname + '?path=' + path;
        }
    },
    getWeexPath: function getWeexPath() {
        var _this2 = this;

        return new Promise(function (resolve, reject) {
            bridgeModule.getWeexPath(function (resData) {
                resolve(_this2.convertToJson(resData));
            });
        });
    },

    /*  
    options = {
            animated: 'true',
            animatedType: 'slide_topToBottom' //页面关闭时动效类型
    }*/
    goBack: function goBack() {
        var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        var params = Object.assign({
            animated: 'true'
        }, options);
        // this.toast(params)
        navigator.pop(params, function (event) {});
    },
    backToNative: function backToNative() {
        bridgeModule.backToNative();
    },

    //**********页面跳转接口***************END


    //**********非APP业务接口***************START
    generateUUID: function generateUUID() {
        var d = new Date().getTime();
        var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c == 'x' ? r : r & 0x3 | 0x8).toString(16);
        });
        return uuid;
    },
    genMessageId: function genMessageId() {
        var messageId = '';
        for (var i = 0; i < 8; i++) {
            messageId += Math.floor(Math.random() * 10).toString();
        }
        return messageId;
    },
    getItem: function getItem(key, callback) {
        storage.getItem(key, callback);
    },
    setItem: function setItem(key, value, callback) {
        var temp = void 0;
        if ((typeof value === 'undefined' ? 'undefined' : _typeof(value)) == 'object') {
            temp = JSON.stringify(value);
        }
        var defaultCallback = function defaultCallback(event) {
            console.log('set success');
        };
        storage.setItem(key, temp || value, callback || defaultCallback);
    },
    removeItem: function removeItem(key, callback) {
        storage.removeItem(key, function () {
            if (callback) callback();
        });
    },
    toast: function toast(message, duration, bgStyle) {
        if ((typeof message === 'undefined' ? 'undefined' : _typeof(message)) == 'object') {
            message = JSON.stringify(message);
        }
        if (platform == 'Web') {
            mm.toast({ message: message, duration: duration || 1.5 });
        } else {
            bridgeModule.toast({ message: message, duration: duration || 1.5, bgStyle: bgStyle });
        }
    },
    alert: function alert(message, callback, okTitle) {
        var callbackFunc = callback || function (value) {};

        if ((typeof message === 'undefined' ? 'undefined' : _typeof(message)) == 'object') {
            try {
                message = JSON.stringify(message);
            } catch (error) {}
        }
        mm.alert({
            message: message,
            okTitle: okTitle || "确定"
        }, function (value) {
            callbackFunc(value);
        });
    },
    confirm: function confirm(message, callback, okTitle, cancelTitle) {
        mm.confirm({
            message: message,
            okTitle: okTitle || '确定',
            cancelTitle: cancelTitle || '取消'
        }, function (result) {
            callback(result);
        });
    },
    showLoading: function showLoading() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        if (this.isDummy != true) {
            if (_util2.default.toNum(weex.config.env.appVersion) >= _util2.default.toNum("5.11.0")) {
                bridgeModule.showLoading(params);
            } else {
                bridgeModule.showLoading();
            }
        }
    },
    hideLoading: function hideLoading() {
        if (this.isDummy != true) {
            bridgeModule.hideLoading();
        }
    },
    showLoadingWithMsg: function showLoadingWithMsg(option) {
        if (this.isDummy != true) {
            var params = option;
            if (typeof option == 'string') {
                params = {
                    msg: option
                };
            }
            bridgeModule.showLoadingWithMsg(params);
        }
    },
    hideLoadingWithMsg: function hideLoadingWithMsg() {
        if (this.isDummy != true) {
            bridgeModule.hideLoadingWithMsg();
        }
    },

    //隐藏系统导航栏
    setNavBarHidden: function setNavBarHidden() {
        navigator.setNavBarHidden({
            hidden: '1',
            animated: "false"
        }, function (event) {});
    },

    //关闭键盘
    killKeyboard: function killKeyboard() {
        if (this.isDummy != true) {
            bridgeModule.killKeyboard();
        }
    },

    //**********非APP业务接口***************END

    //**********网络请求接口***************START
    //发送智慧云网络请求：此接口固定Post到智慧云https地址及端口
    sendMCloudRequest: function sendMCloudRequest(name, params) {
        var _this3 = this;

        var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : { isShowLoading: true, isValidate: true };

        return new Promise(function (resolve, reject) {
            var self = _this3;
            if (_this3.isDummy != true) {
                _this3.getItem("masterId", function (resdata) {
                    var msgid = self.genMessageId();
                    var masterId = resdata.data;
                    var sendData = {};
                    sendData.url = self.serviceList[name] ? self.serviceList[name] : name;
                    sendData.params = Object.assign({
                        applianceId: masterId + "",
                        msgid: msgid
                    }, params);
                    if (options.isShowLoading) {
                        _this3.showLoading();
                    }
                    bridgeModule.sendMCloudRequest(sendData, function (resData) {
                        _debugUtil2.default.debugLog(debugLogSeperator, 'request(' + msgid + '): ', sendData);
                        _debugUtil2.default.debugLog('response(' + msgid + '): ', resData, debugLogSeperator);
                        if (typeof resData == 'string') {
                            resData = JSON.parse(resData);
                        }
                        if (options.isShowLoading) {
                            _this3.hideLoading();
                        }

                        if (options.isValidate) {
                            //resData.status为5.0判断；resData.errorCode为4.判断
                            if (resData.errorCode == 0) {
                                resolve(resData);
                            } else if (resData.status === true) {
                                resolve(resData);
                            } else {
                                reject(resData);
                            }
                        } else {
                            resolve(resData);
                        }
                    }, function (error) {
                        _debugUtil2.default.debugLog(debugLogSeperator, 'request(' + msgid + '): ', sendData);
                        _debugUtil2.default.debugLog('=======> error(' + msgid + '): ', error, debugLogSeperator);
                        if (options.isShowLoading) {
                            _this3.hideLoading();
                        }
                        if (typeof error == 'string') {
                            error = JSON.parse(error);
                        }
                        reject(error);
                    });
                });
            } else {
                var resData = _this3.Mock.getMock(self.serviceList[name] ? self.serviceList[name] : name);
                if (options.isValidate) {
                    //resData.status为5.0判断；resData.errorCode为4.判断
                    if (resData.errorCode == 0) {
                        resolve(resData);
                    } else if (resData.status === true) {
                        resolve(resData);
                    } else {
                        reject(resData);
                    }
                } else {
                    resolve(resData);
                }
            }
        });
    },


    //^5.0.0发送中台网络请求：此接口固定Post到中台https地址及端口
    /* 
    name: 'gateway/subdevice/search', //请求接口路径url，或者serviceList的key,
    params(可选): {
        method: 'POST', //POST/GET, 默认POST
        headers: {}, //请求header
        data: {} //请求参数
        } 
    */
    sendCentralCloundRequest: function sendCentralCloundRequest(name, params) {
        var _this4 = this;

        var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : { isShowLoading: true };

        return new Promise(function (resolve, reject) {
            if (_this4.isDummy != true) {
                var msgid = _this4.genMessageId();
                var sendData = params || {};
                sendData.url = _this4.serviceList[name] ? _this4.serviceList[name] : name;
                if (options.isShowLoading) {
                    _this4.showLoading();
                }
                bridgeModule.sendCentralCloundRequest(sendData, function (resData) {
                    _debugUtil2.default.debugLog(debugLogSeperator, 'request(' + msgid + '): ', sendData);
                    _debugUtil2.default.debugLog('response(' + msgid + '): ', resData, debugLogSeperator);
                    if (typeof resData == 'string') {
                        try {
                            resData = JSON.parse(resData);
                        } catch (e) {}
                    }
                    if (options.isShowLoading) {
                        _this4.hideLoading();
                    }

                    resolve(resData);
                }, function (error) {
                    _debugUtil2.default.debugLog(debugLogSeperator, 'request(' + msgid + '): ', sendData);
                    _debugUtil2.default.debugLog('=======> error(' + msgid + '): ', error, debugLogSeperator);
                    if (options.isShowLoading) {
                        _this4.hideLoading();
                    }
                    if (typeof error == 'string') {
                        try {
                            error = JSON.parse(error);
                        } catch (e) {}
                    }
                    reject(error);
                });
            } else {
                var resData = _this4.Mock.getMock(_this4.serviceList[name] ? _this4.serviceList[name] : name);
                resolve(resData);
            }
        });
    },


    //AEM系统发送请求
    retransmissionCloundRequestSend: function retransmissionCloundRequestSend(url, params) {
        var _this5 = this;

        var method = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 'get';
        var options = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};

        var param = {
            url: url,
            method: method,
            data: _extends({}, params)
        };
        return new Promise(function (resolve, reject) {
            // nativeService.retransmissionCloundRequest(url, params, options).then((res) => {
            _this5.retransmissionCloundRequest(param, options).then(function (res) {
                if (parseInt(res.code, 10) === 200) {
                    resolve(res);
                } else {
                    reject(res);
                }
            }).catch(function (error) {
                reject(error);
            });
        });
    },
    retransmissionCloundRequest: function retransmissionCloundRequest(params) {
        var _this6 = this;

        var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : { isShowLoading: false };

        var param = Object.assign({
            operation: 'retransmissionCloundRequest',
            params: params
        });
        // return this.commandInterfaceWrapper(param);
        return new Promise(function (resolve, reject) {
            if (options.isShowLoading) {
                _this6.showLoading();
            }
            // this.alert(JSON.stringify(param))
            bridgeModule.commandInterface(JSON.stringify(param), function (resData) {
                if (options.isShowLoading) {
                    _this6.hideLoading();
                }
                resolve(_this6.convertToJson(resData));
            }, function (error) {
                if (options.isShowLoading) {
                    _this6.hideLoading();
                }
                reject(error);
            });
        });
    },

    //发送POST网络请求：URL自定义
    /* params: {
        url: url,
        type: 'text',
        method: "POST",
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: {
            'objectId': objectId,
            'format': 'base64'
        }
    } */
    sendHttpRequest: function sendHttpRequest(params) {
        var _this7 = this;

        var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : { isShowLoading: true, isValidate: true };

        return new Promise(function (resolve, reject) {
            var requestParams = JSON.parse(JSON.stringify(params));
            var self = _this7;
            if (_this7.isDummy != true) {
                var defaultParams = {
                    method: "POST",
                    type: 'json'
                };
                requestParams = Object.assign(defaultParams, requestParams);

                /* body 参数仅支持 string 类型的参数，请勿直接传递 JSON，必须先将其转为字符串。
                GET 请求不支持 body 方式传递参数，请使用 url 传参。 */
                if (requestParams.body && requestParams.method == "GET") {
                    var bodyStr = _this7.convertRequestBody(requestParams.body);
                    if (requestParams.url.indexOf("?") > -1) {
                        requestParams.url += "&" + bodyStr;
                    } else {
                        requestParams.url += "?" + bodyStr;
                    }
                    requestParams.body = "";
                } else if (requestParams.body && requestParams.method == "POST") {
                    requestParams.body = requestParams.body;
                }

                if (options.isShowLoading) {
                    _this7.showLoading();
                }
                var msgid = self.genMessageId();
                stream.fetch(requestParams, function (resData) {
                    _debugUtil2.default.debugLog(debugLogSeperator, 'request(' + msgid + '): ', requestParams);
                    _debugUtil2.default.debugLog('response(' + msgid + '): ', resData, debugLogSeperator);
                    if (options.isShowLoading) {
                        _this7.hideLoading();
                    }
                    if (!resData.ok) {
                        if (typeof resData == 'string') {
                            resData = JSON.parse(resData);
                        }
                        reject(resData);
                    } else {
                        var result = resData.data;
                        if (typeof result == 'string') {
                            result = JSON.parse(result);
                        }
                        resolve(result);
                    }
                });
            } else {
                var resData = _this7.Mock.getMock(params.url);
                resolve(resData);
            }
        });
    },
    convertRequestBody: function convertRequestBody(obj) {
        var param = "";
        for (var name in obj) {
            if (typeof obj[name] != 'function') {
                param += "&" + name + "=" + encodeURI(obj[name]);
            }
        }
        return param.substring(1);
    },

    //发送指令透传接口
    startCmdProcess: function startCmdProcess(name, messageBody, callback, callbackFail) {
        var commandId = Math.floor(Math.random() * 1000);
        var param = {
            commandId: commandId
        };
        if (messageBody != undefined) {
            param.messageBody = messageBody;
        }
        var finalCallBack = function finalCallBack(resData) {
            if (typeof resData == 'string') {
                resData = JSON.parse(resData);
            }
            if (resData.errorCode != 0) {
                callbackFail(resData);
            } else {
                callback(resData.messageBody);
            }
        };
        var finalCallbackFail = function finalCallbackFail(resData) {
            if (typeof resData == 'string') {
                resData = JSON.parse(resData);
            }
            callbackFail(resData);
        };
        if (this.isDummy != true) {
            if (isIos) {
                this.createCallbackFunctionListener();
                this.callbackFunctions[commandId] = finalCallBack;
                this.callbackFailFunctions[commandId] = finalCallbackFail;
            }
            bridgeModule.startCmdProcess(JSON.stringify(param), finalCallBack, finalCallbackFail);
        } else {
            callback(this.Mock.getMock(name).messageBody);
        }
    },


    //发送指令透传接口(套系)
    startCmdProcessTX: function startCmdProcessTX(name, messageBody, deviceId, callback, callbackFail) {
        var commandId = Math.floor(Math.random() * 1000);
        var param = {
            commandId: commandId
        };
        if (messageBody != undefined) {
            param.messageBody = messageBody;
        }
        if (deviceId != undefined) {
            param.deviceId = deviceId;
        }
        var finalCallBack = function finalCallBack(resData) {
            if (typeof resData == 'string') {
                resData = JSON.parse(resData);
            }
            if (resData.errorCode != 0) {
                callbackFail(resData);
            } else {
                callback(resData.messageBody);
            }
        };
        var finalCallbackFail = function finalCallbackFail(resData) {
            if (typeof resData == 'string') {
                resData = JSON.parse(resData);
            }
            callbackFail(resData);
        };
        if (this.isDummy != true) {
            if (isIos) {
                this.createCallbackFunctionListener();
                this.callbackFunctions[commandId] = finalCallBack;
                this.callbackFailFunctions[commandId] = finalCallbackFail;
            }
            bridgeModule.startCmdProcess(JSON.stringify(param), finalCallBack, finalCallbackFail);
        } else {
            callback(this.Mock.getMock(name).messageBody);
        }
    },

    /* 服务透传接口。提供给插件发送请求至事业部的品类服务器。此接口美居APP会将请求内容加密，然后发送给“云平台”进行中转发送至事业部品类服务器。
        params: {
            type:服务类型，如果weex没有传，或者传入类似""的空字节，则取当前插件类型作为该数值
            queryStrings:与H5内容一致
            transmitData:与H5内容一致
        }
    */
    requestDataTransmit: function requestDataTransmit(params) {
        var _this8 = this;

        return new Promise(function (resolve, reject) {
            bridgeModule.requestDataTransmit(JSON.stringify(params), function (resData) {
                resolve(_this8.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },


    /* *****即将删除, IOS已经做了改进，不在需要已callbackFunction回调callback ********/
    isCreateListener: false,
    createCallbackFunctionListener: function createCallbackFunctionListener() {
        var _this9 = this;

        if (!this.isCreateListener) {
            this.isCreateListener = true;
            globalEvent.addEventListener("callbackFunction", function (result) {
                //IOS消息返回处理
                var commandId = result.commandId;
                if (commandId) {
                    _this9.callbackFunction(commandId, result);
                }
            });
        }
    },

    callbackFunctions: {},
    callbackFailFunctions: {},
    callbackFunction: function callbackFunction(commandId, result) {
        var jsonResult = result;
        var cbf = this.callbackFunctions[commandId];
        var cbff = this.callbackFailFunctions[commandId];
        if (jsonResult.errorCode !== undefined && jsonResult.errMessage == 'TimeOut') {
            if (typeof cbff == "function") {
                cbff(-1); //表示指令超时 －1
            }
        } else {
            if (typeof cbf == "function") {
                cbf(jsonResult);
            }
        }
        delete this.callbackFunctions[commandId];
        delete this.callbackFailFunctions[commandId];
    },

    /* *****即将删除, IOS已经做了改进，不在需要已callbackFunction回调callback ********/

    //发送Lua指令接口
    sendLuaRequest: function sendLuaRequest(params) {
        var _this10 = this;

        var isShowLoading = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;

        return new Promise(function (resolve, reject) {
            if (!params.operation) {
                params.operation = "luaQuery"; //luaQuery or luaControl
            }
            if (!params.params) {
                params.params = {};
            }

            if (_this10.isDummy != true) {
                if (isShowLoading && params.operation == 'luaQuery') {
                    _this10.showLoading();
                }
                var msgid = _this10.genMessageId();
                bridgeModule.commandInterface(JSON.stringify(params), function (resData) {
                    _debugUtil2.default.debugLog(debugLogSeperator, 'Lua request(' + msgid + '): ', params);
                    _debugUtil2.default.debugLog('Lua response(' + msgid + '):', resData, debugLogSeperator);
                    if (typeof resData == 'string') {
                        resData = JSON.parse(resData);
                    }
                    if (isShowLoading) {
                        _this10.hideLoading();
                    }
                    if (resData.errorCode == 0) {
                        //成功
                        resolve(resData);
                    } else {
                        reject(resData);
                    }
                }, function (error) {
                    // this.alert(error)
                    _debugUtil2.default.debugLog(debugLogSeperator, 'Lua request(' + msgid + '): ', params);
                    _debugUtil2.default.debugLog('=======> Lua error(' + msgid + '): ', error, debugLogSeperator);
                    if (isShowLoading) {
                        _this10.hideLoading();
                    }
                    if (typeof error == 'string') {
                        error = JSON.parse(error);
                    }
                    reject(error);
                });
            } else {
                var resData = void 0;
                if (params['operation'] || params['name']) {
                    if (params['name']) {
                        resData = Mock.getMock(params['name']);
                    } else {
                        resData = Mock.getMock(params['operation']);
                    }
                }
                _debugUtil2.default.debugLog("Mock: ", resData);
                resolve(resData);
            }
        });
    },

    //**********网络请求接口***************END


    //**********APP业务接口***************START
    updateTitle: function updateTitle(title, showLeftBtn, showRightBtn) {
        var params = {
            title: title,
            showLeftBtn: showLeftBtn,
            showRightBtn: showRightBtn
        };
        if (this.isDummy != true) {
            bridgeModule.updateTitle(JSON.stringify(params));
        }
    },
    getAuthToken: function getAuthToken() {
        var _this11 = this;

        return new Promise(function (resolve, reject) {
            bridgeModule.getAuthToken({}, function (resData) {
                resolve(_this11.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },

    // 获取套系列表
    getTxList: function getTxList() {
        var _this12 = this;

        var isShowLoading = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;

        // if (this.isDummy != true) {
        return new Promise(function (resolve, reject) {
            if (isShowLoading) {
                _this12.showLoading();
            }
            bridgeModule.getTXList({}, function (resData) {
                if (typeof resData == 'string') {
                    // this.alert(resData)
                    var resDataObj = JSON.parse(resData);
                    if (isShowLoading) {
                        _this12.hideLoading();
                    }
                    if (resDataObj.errorCode && resDataObj.errorCode !== 0) {
                        //失败
                        reject(resDataObj);
                    } else {
                        //成功
                        resolve(resDataObj);
                    }
                } else {
                    //Android 可能直接传个对象
                    var resDataObj = resData;
                    if (isShowLoading) {
                        _this12.hideLoading();
                    }
                    if (resDataObj.errorCode && resDataObj.errorCode !== 0) {
                        //失败
                        reject(resDataObj);
                    } else {
                        //成功
                        resolve(resDataObj);
                    }
                }
            }, function (error) {
                if (typeof error == 'string') {
                    error = JSON.parse(error);
                    mm.modal({ "message": error }, 3);
                }
                reject(error);
            });
        });
        // }else{
        //     return new Promise((resolve, reject) => {
        //         let data = Mock.getMock('queryTXList');
        //         resolve(data)
        //     })
        // }
    },
    showSharePanel: function showSharePanel(params, callback, callbackFail) {
        return new Promise(function (resolve, reject) {
            bridgeModule.showSharePanel(params, function (resData) {
                resolve(resData);
            }, function (error) {
                reject(error);
            });
        });
    },


    /*
     * created by zhouhg 20180621 start
     */
    //根据设备信息获取插件信息
    getDevicePluginInfo: function getDevicePluginInfo(params) {
        var _this13 = this;

        return new Promise(function (resolve, reject) {
            if (_this13.isDummy != true) {
                bridgeModule.getDevicePluginInfo(params, function (resData) {
                    resolve(resData);
                }, function (error) {
                    reject(error);
                });
            } else {
                var data = Mock.getMock('getDevicePluginInfo');
                resolve(data);
            }
        });
    },

    //下载插件接口
    downLoadDevicePlugin: function downLoadDevicePlugin(params, callback, callbackFail) {
        var that = this;
        if (this.isDummy != true) {
            bridgeModule.downLoadDevicePlugin(params, function (resData) {
                callback(resData);
            }, function (error) {
                callbackFail(error);
            });
        } else {
            var data = Mock.getMock('downLoadDevicePlugin');
            setTimeout(function () {
                callback(data);
            }, 3000);
        }
    },
    getDeviceOnlineStatus: function getDeviceOnlineStatus(params, callback, callbackFail) {
        var _this14 = this;

        return new Promise(function (resolve, reject) {
            var that = _this14;
            bridgeModule.getDeviceOnlineStatus(params, function (resData) {
                resolve(resData);
            }, function (error) {
                reject(error);
            });
        });
    },

    //设备主动上报在线离线状态
    deviceOnlineStatus: function deviceOnlineStatus() {
        var params = {
            operation: 'deviceOnlineStatus'
        };
        return this.commandInterfaceWrapper(params);
    },

    //更新下载插件并解压后，需要替换加载新下载的插件
    loadingLatestPlugin: function loadingLatestPlugin(params, callback, callbackFail) {
        //  	let params = {};
        return new Promise(function (resolve, reject) {
            bridgeModule.loadingLatestPlugin(params, function (resData) {
                resolve(resData);
            }, function (error) {
                reject(error);
            });
        });
    },

    //重新加载当前页面
    reload: function reload(callback, callbackFail) {
        var params = {};
        bridgeModule.reload(params, function (resData) {
            if (callback) callback(resData);
        }, function (error) {
            if (callbackFail) callbackFail(error);
        });
    },

    /*
     * created by zhouhg 20180621 end
     */

    //统一JS->Native接口
    commandInterfaceWrapper: function commandInterfaceWrapper(param) {
        var _this15 = this;

        return new Promise(function (resolve, reject) {
            bridgeModule.commandInterface(JSON.stringify(param), function (resData) {
                resolve(_this15.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },

    //获取用户信息
    getUserInfo: function getUserInfo() {
        var param = {
            operation: 'getUserInfo'
        };
        return this.commandInterfaceWrapper(param);
    },

    //打电话
    /* param: {
        tel: '10086',
        title: '客户服务',
        desc: '拨打热线电话：'
    } */
    callTel: function callTel(params) {
        var param = Object.assign(params, {
            operation: 'callTel'
        });
        return this.commandInterfaceWrapper(param);
    },

    //弹出全局电话列表
    /* param: [{
        tel: '10086',
        title: '客户服务',
        desc: '拨打热线电话：'
    },{...}] */
    callTelList: function callTelList(params) {
        var param = {
            'operation': 'callTelList',
            'params': params
        };
        return this.commandInterfaceWrapper(param);
    },

    //触发手机震动  intensity 1：轻微震动 2：中等震动 3：强烈震动  intensity为空：猛烈♂震动
    hapticFeedback: function hapticFeedback(intensity) {
        var param = void 0;
        if (intensity && typeof intensity == 'number') {
            param = {
                operation: 'hapticFeedback',
                intensity: intensity
            };
        } else {
            param = {
                operation: 'hapticFeedback'
            };
        }
        return this.commandInterfaceWrapper(param);
    },

    //打开指定的系统设置，比如蓝牙
    openNativeSystemSetting: function openNativeSystemSetting(settingName) {
        var param = {
            operation: 'openNativeSystemSetting',
            setting: settingName || 'bluetooth'
        };
        return this.commandInterfaceWrapper(param);
    },
    shareMsg: function shareMsg(params) {
        /* params =  {
            "type": "wx", //分享类型，wx表示微信分享，qq表示qq分享，sms表示短信分享，weibo表示新浪微博，qzone表示QQ空间，wxTimeline表示微信朋友圈
            "title": "xxxxxx", //分享的标题
            "desc": "xxxxxx",//分享的文本内容
            "imgUrl": "xxxxxx",//分享的图片链接
            "link": "xxxxxx" //分享的跳转链接
        } */
        var param = {
            'operation': 'shareMsg',
            'params': params
        };
        return this.commandInterfaceWrapper(param);
    },

    //获取当前设备网络信息
    getNetworkStatus: function getNetworkStatus() {
        var param = {
            operation: 'getNetworkStatus'
        };
        return this.commandInterfaceWrapper(param);
    },

    //获取当前家庭信息
    getCurrentHomeInfo: function getCurrentHomeInfo() {
        var param = {
            operation: 'getCurrentHomeInfo'
        };
        return this.commandInterfaceWrapper(param);
    },

    //获取当前设备信息
    getDeviceInfo: function getDeviceInfo() {
        var param = {
            operation: 'getDeviceInfo'
        };
        if (this.isDummy == true) {
            return new Promise(function (resolve, reject) {
                try {
                    var resData = Mock.getMock(param.operation);
                    if (resData.errorCode == 0) {
                        resolve(resData);
                    } else {
                        reject(resData);
                    }
                } catch (error) {
                    reject("获取模拟数据出错");
                }
            });
        } else {
            return this.commandInterfaceWrapper(param);
        }
    },

    //更新当前设备信息
    updateDeviceInfo: function updateDeviceInfo(params) {
        var param = Object.assign(params, {
            operation: 'updateDeviceInfo'
        });
        return this.commandInterfaceWrapper(param);
    },

    //打开指定的原生页面
    jumpNativePage: function jumpNativePage(params) {
        /* params =  {
            "pageName": "xxxx", //跳转的目标页面
            "data": {xxxxxx}, //传参，为json格式字符串
        } */
        var param = Object.assign(params, {
            operation: 'jumpNativePage'
        });
        return this.commandInterfaceWrapper(param);
    },

    //跳转到h5页面
    weexBundleToWeb: function weexBundleToWeb(params) {
        /* params =  {
            url: "xxxx", //跳转的目标页面
            title: "h5标题"
        } */
        var param = Object.assign(params, {
            operation: 'weexBundleToWeb'
        });
        return this.commandInterfaceWrapper(param);
    },

    //设置是否监控安卓手机物理返回键功能, v4.4.0
    setBackHandle: function setBackHandle(status) {
        /* params =  {
            "pageName": "xxxx", //跳转的目标页面
            "isMonitor": on,  //on: 打开监控，off: 关闭监控
        } */
        var params = {
            operation: 'setBackHandle',
            isMonitor: status
        };
        return this.commandInterfaceWrapper(params);
    },

    //二维码/条形码扫码功能，用于读取二维码/条形码的内容
    scanCode: function scanCode() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        var param = Object.assign(params, {
            operation: 'scanCode'
        });
        return this.commandInterfaceWrapper(param);
    },

    //获取wifi列表
    getWifiList: function getWifiList() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        var param = Object.assign(params, {
            operation: 'getWifiList'
        });
        return this.commandInterfaceWrapper(param);
    },

    //开启麦克风录音，可以保存录音文件或者把声音转换成文字
    startRecordAudio: function startRecordAudio(params) {
        /* params =  {
            max:number, //最长录音时间, 单位为秒
            isSave:true/false, //是否保存语音录音文件
            isTransform:true/false, //是否需要转换语音成文字
        } */
        var param = Object.assign(params, {
            operation: 'startRecordAudio'
        });
        return this.commandInterfaceWrapper(param);
    },

    //开启麦克风录音后，自行控制结束录音
    stopRecordAudio: function stopRecordAudio() {
        var params = {
            operation: 'stopRecordAudio'
        };
        return this.commandInterfaceWrapper(params);
    },
    takePhoto: function takePhoto(params) {
        /* params =  {
            compressRage:60, , //number, 返回照片的压缩率，范围为0~100，数值越高保真率越高
            type:'jpg', //值为jpg或png，指定返回相片的格式
            isNeedBase64: true/false //是否需要返回相片base64数据
        } */
        var param = Object.assign(params, {
            operation: 'takePhoto'
        });
        return this.commandInterfaceWrapper(param);
    },

    /* 选择相册照片，并返回相片数据 */
    choosePhoto: function choosePhoto(params) {
        /* params =  {
            compressRage:60, , //number, 返回照片的压缩率，范围为0~100，数值越高保真率越高
            type:'jpg', //值为jpg或png，指定返回相片的格式
            isNeedBase64: true/false //是否需要返回相片base64数据
        } */
        var param = Object.assign(params, {
            operation: 'choosePhoto'
        });
        return this.commandInterfaceWrapper(param);
    },

    /* 选择多张相册照片，并返回相片数据，不支持base64的转换 */
    chooseMulPhoto: function chooseMulPhoto(params) {
        /* params =  {
            max:number, //一次最多可选择的数量，默认为9，最多9张。
        } */
        var param = Object.assign(params, {
            operation: 'chooseMulPhoto'
        });
        return this.commandInterfaceWrapper(param);
    },
    getGPSInfo: function getGPSInfo(params) {
        /* params =  {
            desiredAccuracy: "10",  //定位的精确度，单位：米
            alwaysAuthorization: "0",  //是否开启实时定位功能，0: 只返回一次GPS信息（默认），1:APP在前台时，每移动distanceFilter的距离返回一次回调。2:无论APP在前后台，每移动distanceFilter的距离返回一次回调（注意耗电）
            distanceFilter: "10", //alwaysAuthorization为1或2时有效，每移动多少米回调一次定位信息
        } */
        var param = Object.assign(params, {
            operation: 'getGPSInfo'
        });
        return this.commandInterfaceWrapper(param);
    },
    getCityInfo: function getCityInfo(params) {
        var param = Object.assign(params, {
            operation: 'getCityInfo'
        });
        return this.commandInterfaceWrapper(param);
    },

    /*  ^5.0.0 根据getCityInfo获得的城市对应的气象局ID获取城市天气信息， 比如温度， 风向等信息 */
    getWeatherInfo: function getWeatherInfo(params) {
        var param = Object.assign(params, {
            operation: 'getWeatherInfo'
        });
        return this.commandInterfaceWrapper(param);
    },

    /*  ^5.0.0  百度开放接口，通过经纬度返回对应的位置信息 */
    baiduGeocoder: function baiduGeocoder(params) {
        var param = Object.assign(params, {
            operation: 'baiduGeocoder'
        });
        return this.commandInterfaceWrapper(param);
    },

    //获取登录态信息
    getLoginInfo: function getLoginInfo() {
        var param = {
            operation: 'getLoginInfo'
        };
        return this.commandInterfaceWrapper(param);
    },

    /* ^5.0.0 打开用户手机地图软件，传入标记地点。（打开地图软件后，用户可以使用地图软件的功能，比如导航等）
    ios: 如果用户安装了百度地图，则跳转到百度地图app，没有安装，则跳转Safar，使用网页导航
    android: 如果用户安装了百度地图，则跳转到百度地图app，没有安装，则跳转使用外部浏览器，使用网页导航（用户选择合适的浏览器，原生toast引导，存在选择错误应用的风险） */
    launchMapApp: function launchMapApp(params) {
        /* params =  {
            from:{ //当前用户地点
                latitude: string, //纬度
                longitude: string //经度
            },
            to:{ //目的地地点
                latitude: string, //纬度
                longitude: string //经度
            }
        } */
        var param = Object.assign(params, {
            operation: 'launchMapApp'
        });
        return this.commandInterfaceWrapper(param);
    },

    /* 根据模糊地址，返回地图服务的查询结果数据。 */
    searchMapAddress: function searchMapAddress(params) {
        /* params =  {
            city: "", //需要查询的城市(范围)
            keyword: "美的" //需要查询的地址
        } */
        var param = Object.assign(params, {
            operation: 'searchMapAddress'
        });
        return this.commandInterfaceWrapper(param);
    },

    /* 选择通讯录的好友，可以获取电话号码，好友信息 */
    getAddressBookPerson: function getAddressBookPerson() {
        var param = {
            operation: 'getAddressBookPerson'
        };
        return this.commandInterfaceWrapper(param);
    },
    downloadImageWithCookie: function downloadImageWithCookie(params) {
        var param = Object.assign(params, {
            operation: 'downloadImageWithCookie'
        });
        return this.commandInterfaceWrapper(param);
    },


    //调用第三方SDK统一接口
    interfaceForThirdParty: function interfaceForThirdParty() {
        bridgeModule.interfaceForThirdParty.apply(bridgeModule, arguments);
    },

    //
    updateAutoList: function updateAutoList() {
        bridgeModule.updateAutoList();
    },

    /*发送埋点数据*/
    burialPoint: function burialPoint(params) {
        var param = Object.assign(params, {
            operation: 'burialPoint'
        });
        return this.commandInterfaceWrapper(param);
    },

    /* weex卡片页打开控制页页面接口 */
    showControlPanelPage: function showControlPanelPage() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        bridgeModule.showControlPanelPage(params);
    },

    /* 上传图片文件，调用一次，上传一份图片文件 */
    uploadImgFile: function uploadImgFile(params, callback, callbackFail) {
        /* params = {
            path: string, //值为 图片在手机中的路径
            url: string, //值为服务器上传图片的url
            maxWidth: number, //最大宽度，如果不设置，则使用图片宽度
            maxHeight: number, //最大高度，如果不设置，则使用图片高度
            compressRage: number, //图片的压缩率，范围为0~100，数值越高保真率越高。默认值：100，不压缩，直接上传图片 ps: 压缩后的图片文件格式，固定为jpg 格式
            netParam: {
                xxx: xxx, //weex需要原生填充给服务器的post 表单参数1
                xxx: xxx, //weex需要原生填充给服务器的post 表单参数2
            },
            fileKey: string, //值为原生在post表单中传输图片文件的key值，缺省默认值为“file”
        } */
        var param = Object.assign(params, {
            operation: 'uploadImgFile'
        });
        bridgeModule.commandInterface(param, callback, callbackFail);
    },
    uploadImgFileToMas: function uploadImgFileToMas(params, callback, callbackFail) {
        /* params = {
            path: string, //值为 图片在手机中的路径
            url: string, //值为服务器上传图片的url
            maxWidth: number, //最大宽度，如果不设置，则使用图片宽度
            maxHeight: number, //最大高度，如果不设置，则使用图片高度
            compressRage: number, //图片的压缩率，范围为0~100，数值越高保真率越高。默认值：100，不压缩，直接上传图片 ps: 压缩后的图片文件格式，固定为jpg 格式
            netParam: {
                xxx: xxx, //weex需要原生填充给服务器的post 表单参数1
                xxx: xxx, //weex需要原生填充给服务器的post 表单参数2
            },
            fileKey: string, //值为原生在post表单中传输图片文件的key值，缺省默认值为“file”
        } */
        var param = Object.assign(params, {
            operation: 'uploadImgFileToMas'
        });
        bridgeModule.commandInterface(param, callback, callbackFail);
    },

    //LottieView接口
    showLottieView: function showLottieView() {},

    /* setIdleTimerDisabled 设置屏幕常亮 ^5.7
        1.插件调用setIdleTimerDisabled,原生APP定时60秒后重新开启系统自动屏灭的操作。
        1.1 假如插件要长时间保持屏亮，需要调用setIdleTimerDisabled后，隔60秒后再次调用来维持一直屏亮。
        1.2 插件调用setIdleTimerDisabled，间隔不到60秒又调用setIdleTimerDisabled，原生app的定时时间，重新设置，60秒后再重新启动系统的自动灭屏操作！
    */
    setIdleTimerDisabled: function setIdleTimerDisabled() {
        var param = {
            operation: 'setIdleTimerDisabled'
        };
        bridgeModule.commandInterface(param, function () {}, function () {});
    },

    /*  
     * ^5.7.0 [subscribeMessage]-订阅设备状态推送
     * @params: { deviceId: []}  
     * deviceId是想订阅的设备id,空数组-清空订阅设备，['all']-订阅用户该家庭所有设备消息推送， [deviceId]订阅指定设备
    */
    subscribeMessage: function subscribeMessage(params) {
        var param = Object.assign(params, {
            operation: 'subscribeMessage'
        });
        return this.commandInterfaceWrapper(param);
    },

    /*  
     * ^5.11.0 [subscribeMessage]-订阅设备状态推送
     * @params: { data: xxxxx}  
     * xxxx是加密的SN
    */
    decrptySN: function decrptySN(params) {
        var param = Object.assign(params, {
            operation: 'decrptySN'
        });
        return this.commandInterfaceWrapper(param);
    },

    //**********APP业务接口***************END


    //**********蓝牙接口***************START ==》此接口为二进制传输接口，已经在5.9作废
    // blueToothModuleWrapper(apiName, param) {
    //     return new Promise((resolve, reject) => {
    //         blueToothModule[apiName](JSON.stringify(param),
    //             (resData) => {
    //                 resolve(this.convertToJson(resData))
    //             },
    //             (error) => {
    //                 reject(error)
    //             })
    //     })
    // },
    //获取蓝牙开启状态
    /* return:
        {status:1, //1表示蓝牙已打开，0：蓝牙关闭状态，2:：蓝牙正在重置，3：设备不支持蓝牙，4：蓝牙未授权}
    */
    // getBlueStatus(params = {}) {
    //     return this.blueToothModuleWrapper("getBlueStatus", params)
    // },
    //开始扫描蓝牙 
    /*  param:{duration: number //持续时间, 单位：秒}
        当扫描到的蓝牙设备（蓝牙信息），app-->插件:
        receiveMessageFromApp({messageType:"blueScanResult",messageBody:{name:"xxx", deviceKey:"xxxxx"}})
     */
    // startBlueScan(params = {}) {
    //     return this.blueToothModuleWrapper("startBlueScan", params)
    // },
    //停止蓝牙扫描
    /* 当扫描结束（停止或超时），app -> 插件:
    receiveMessageFromApp({ messageType: "blueScanStop", messageBody: {} })
    */
    // stopBlueScan(params = {}) {
    //     return this.blueToothModuleWrapper("stopBlueScan", params)
    // },
    //保存蓝牙信息
    /* param:{deviceType:品类码, name:"xxx", deviceKey:"xxxxx"} */
    // addDeviceBlueInfo(params = {}) {
    //     return this.blueToothModuleWrapper("addDeviceBlueInfo", params)
    // },
    //获取之前保存的蓝牙信息
    /* param:{ deviceType: 品类码 }
       result:{status：0, //0: 执行成功, 1:执行失败, name:"xxx", deviceKey:"xxxxx"}
    */
    // getDeviceBlueInfo(params = {}) {
    //     return this.blueToothModuleWrapper("getDeviceBlueInfo", params)
    // },
    //根据蓝牙信息建立蓝牙连接
    /* param:{name:"xxx", 
        deviceKey:"xxxxx",
        service:"uuid", //蓝牙服务特征，使用者根据设备信息传入
        writeCharacter:"uuid", //蓝牙写入通道特征，使用者根据设备信息传入
        readCharacter:"uuid" //蓝牙读取通道特征，使用者根据设备信息传入
    } */
    /* 当收到蓝牙数据，app -> 插件: 
    receiveMessageFromApp({ messageType: "receiveBlueInfo", messageBody: { deviceKey:"xxxxx", data: "xxx" } })
    */
    // setupBlueConnection(params = {}) {
    //     return this.blueToothModuleWrapper("setupBlueConnection", params)
    // },
    // 向蓝牙设备传输数据
    /* param:{
        deviceKey:"xxxxx", 
        data:"xxx" 
    } */
    // writeBlueInfo(params = {}) {
    //     return this.blueToothModuleWrapper("writeBlueInfo", params)
    // },
    //断开当前蓝牙连接
    /* 若是蓝牙意外断开, app -> 插件: 
       receiveMessageFromApp({ messageType: "blueConnectionBreak", messageBody: {} }) 
    */
    // disconnectBlueConnection(params = {}) {
    //     return this.blueToothModuleWrapper("disconnectBlueConnection", params)
    // },
    //**********蓝牙接口***************END


    //**********新蓝牙接口^5.9.0***************START
    singleBlueToothModuleWrapper: function singleBlueToothModuleWrapper(apiName, param) {
        var _this16 = this;

        return new Promise(function (resolve, reject) {
            if (_util2.default.toNum(weex.config.env.appVersion) >= _util2.default.toNum("5.9.0")) {
                singleBlueToothModule[apiName](JSON.stringify(param), function (resData) {
                    resolve(_this16.convertToJson(resData));
                }, function (error) {
                    reject(error);
                });
            } else {
                reject({ errorCode: -1, errorMsg: "version not support" });
            }
        });
    },

    //获取蓝牙开启状态
    /* return:
        当获取到蓝牙状态/蓝牙状态变更
        receiveMessageFromApp({messageType:"singleBlueStatus",messageBody:{status:1, //1表示蓝牙已打开，0：蓝牙关闭状态，2:：蓝牙正在重置，3：设备不支持蓝牙，4：蓝牙未授权}})
    */
    getBlueStatus: function getBlueStatus() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("getBlueStatus", params);
    },

    //开始扫描蓝牙
    /*  param:{
        name:"midea_xx_xxxx",//选填
        mac:"xxxxxxxxxxxx",//选填
        duration: number //持续时间, 单位：秒}
        当扫描到的蓝牙设备（蓝牙信息），app-->插件:
        receiveMessageFromApp({messageType:"singleBlueScanStop",messageBody:{}})
     */
    startBlueScan: function startBlueScan() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("startBlueScan", params);
    },

    //停止蓝牙扫描
    /* 当扫描结束（停止或超时），app -> 插件:
    receiveMessageFromApp({ messageType: "blueScanStop", messageBody: {} })
    */
    stopBlueScan: function stopBlueScan() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("stopBlueScan", params);
    },

    //根据蓝牙信息建立蓝牙连接
    /* param:{
        name:"midea_xx_xxxx", //蓝牙名称
        token:"xxxx",//鉴权 长度32
        mac:"xxxx"//蓝牙mac地址
        applianceId:"xxx"//设备id
    } 
     失败回调:errorCode:-1, //-1:连接失败, -2:发现服务失败, -3:密钥协商失败, -4:token校验失败, -5:10s超时
    */
    setupBlueConnection: function setupBlueConnection() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("setupBlueConnection", params);
    },


    //查询设备当前状态,连接之后立马查询

    /* param:{
        mac:"xxxx",//12位蓝牙Mac地址
        name:"midea_xx_xxxx",//蓝牙名称
        applianceId:"xxx"//设备id
    } 
    当收到蓝牙数据时，APP通知插件结果:
    receiveMessageFromApp({ messageType: "receiveSingleBlueLuaInfo", messageBody: { applianceId:"xxx", data: {luaKey1:"xxx",luaKey2:"xxx"}}})
    */
    queryBlueLuaStatus: function queryBlueLuaStatus() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("queryBlueLuaStatus", params);
    },


    //查询设备当前状态,连接之后立马查询

    /* param:{
        mac:"xxxx",//12位蓝牙Mac地址
        name:"midea_xx_xxxx",//蓝牙名称
        applianceId:"xxx"
        data:{
            luaKey1:"xxx",
            luaKey2:"xxx"
        } //期望控制
    } 
    当收到蓝牙数据时，APP通知插件结果:
    receiveMessageFromApp({ messageType: "receiveSingleBlueLuaInfo", messageBody: { applianceId:"xxx", data: {luaKey1:"xxx",luaKey2:"xxx"}}})
    */
    sendBlueLuaRequest: function sendBlueLuaRequest() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("sendBlueLuaRequest", params);
    },


    //断开当前蓝牙连接
    /* param:{
        mac:"xxxx",//12位蓝牙Mac地址
        name:"midea_xx_xxxx",//蓝牙名称
        } 
    若是蓝牙意外断开, app -> 插件: 
       receiveMessageFromApp({ messageType: "singleBlueConnectionBreak", messageBody: {mac:"xxxx", name:"midea_xx_xxxx"} }) 
    */
    disconnectBlueConnection: function disconnectBlueConnection() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("disconnectBlueConnection", params);
    },


    //下载文件
    /* param:{
        mac:"xxxx",//12位蓝牙Mac地址
        name:"midea_xx_xxxx",//蓝牙名称
        } 
        result: {
            path:"xxx"//,下载文件本地路径
        }
    */
    downFile: function downFile() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("downFile", params);
    },

    //查询当前固件指令
    /* param:{
            mac:"xxxx",//12位蓝牙Mac地址
            name:"midea_xx_xxxx",//蓝牙名称
        } 
    当收到蓝牙数据时，APP通知插件结果:
        receiveMessageFromApp({ messageType: "receiveSingleBlueFirmwareStatus", messageBody: {mac:"xxxx", name:"midea_xx_xxxx",data: {
            otaVersion:"xxx"//固件版本
            status:"",//固件状态
            revisonL:"xxx",//大版本号
            revisionS:""//小版本号
        }}}) 
    */
    readFirmwareStatus: function readFirmwareStatus() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("readFirmwareStatus", params);
    },

    //开始ota升级
    /* param:{
            mac:"xxxx",//12位蓝牙Mac地址
            name:"midea_xx_xxxx",//蓝牙名称
            source:"xxx"//bin文件路径
        } 
    当收到蓝牙数据时，APP通知插件结果:
        receiveMessageFromApp({ messageType: "receiveSingleBlueOtaProcess", messageBody: {mac:"xxxx", name:"midea_xx_xxxx",data: {
            status:0//0:成功, -1:失败
            process:1//1:擦拭空间, 2:请求写入, 3:写数据（写数据进度看progress）, 4:crc校验, 5:升级指令
            progress：0.5//写bin文件进度,当process=3时使用
        }}}) 
    */
    startFirmwareOta: function startFirmwareOta() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("startFirmwareOta", params);
    },

    //重启蓝牙模块
    /* param:{
        mac:"xxxx",//12位蓝牙Mac地址
        name:"midea_xx_xxxx",//蓝牙名称
        } 
    当收到蓝牙数据时，APP通知插件结果:
        receiveMessageFromApp({ messageType: "receiveSingleBlueRestart", messageBody: {mac:"xxxx", name:"midea_xx_xxxx",data: {
            status:0//0成功，-1失败,
        }}}) 
    */
    restartBlueDevice: function restartBlueDevice() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("restartBlueDevice", params);
    },

    //**********蓝牙接口新蓝牙接口^5.9.0***************END


    //**********蓝牙MESH接口***************START
    blueToothMeshModuleWrapper: function blueToothMeshModuleWrapper(apiName, param) {
        var _this17 = this;

        return new Promise(function (resolve, reject) {
            blueToothMeshModule[apiName](JSON.stringify(param), function (resData) {
                resolve(_this17.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },

    //根据蓝牙信息建立蓝牙连接
    /* param:{
        mac:"xxx", //设备mac地址，可通getDeviceBlueMeshInfo接口获取
        ssid:"xxxxx", //设备ssid，可通getDeviceBlueMeshInfo接口获取
    } */
    /* 当收到蓝牙数据，app -> 插件: 
    receiveMessageFromApp({ messageType: "receiveBlueInfo", messageBody: { deviceKey:"xxxxx", data: "xxx" } })
    */
    setupBlueMeshConnection: function setupBlueMeshConnection() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.blueToothMeshModuleWrapper("setupBlueMeshConnection", params);
    },

    //断开当前蓝牙连接
    /* 若是蓝牙意外断开, app -> 插件: 
       receiveMessageFromApp({ messageType: "blueConnectionBreak", messageBody: {} }) 
    */
    disconnectBlueMeshConnection: function disconnectBlueMeshConnection() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.blueToothMeshModuleWrapper("disconnectBlueMeshConnection", params);
    },

    //获取当前家庭的所有Mesh设备的信息
    /* param:{ deviceType: 品类码 }
       result:{status：0, //0: 执行成功, 1:执行失败, name:"xxx", deviceKey:"xxxxx"}
    */
    getDeviceBlueMeshListInfo: function getDeviceBlueMeshListInfo() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.blueToothModuleWrapper("getDeviceBlueMeshListInfo", params);
    },

    // 向蓝牙Mesh发送控制指令
    /* param:{
        destAddress: xxx  //目标控制地址  ，可为 单播地址，群播地址
        name:xxx //例如 GenericOnOff 、GenericLevel 、LightCtlTemperature
        params :{     // name字段的不同，params需要不同的数据，例如  ,
        onoff:  xxx // 0 或1 ,name 为 GenericOnOff 需要  0或者1
        level:    xxx // GenericLevel 需要 0~100 之类的数值
        temperature:  xxxx //  LightCtlTemperature 才会需要的温度数值
        deltaUV: xxxx // LightCtlTemperature 才会需要
    } */
    sendBlueMeshControlMessage: function sendBlueMeshControlMessage() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.blueToothModuleWrapper("sendBlueMeshControlMessage", params);
    },

    // 蓝牙Mesh增加群订阅
    /*  ps1:一个mesh node element 可以订阅多个群地址
        ps2:一个群地址可以配置多个modelNumberId，以响应不同的控制消息
    param:{
        groupAddress:xxx  // 组播地址  这个理论上是 事业部应用服务器从 iot服务器上申请分配，建议从0xD000开始分配
        deviceAddress: xxx  //mesh node 的 element 单播地址
        modelNumberId:xxx // 控制模式的id , 例如  GenericOnOff 组播，需要传入 0x1000 ,之后就可以通过 sendBlueMeshControlMessage {name : “GenericOnOff”  群控制设备开关 }
    } */
    addBlueMeshModelSubscription: function addBlueMeshModelSubscription() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.blueToothModuleWrapper("addBlueMeshModelSubscription", params);
    },

    // 蓝牙Mesh取消群订阅
    /* param:{
        groupAddress:xxx  // 组播地址  这个理论上是 事业部应用服务器从 iot服务器上申请分配，建议从0xD000开始分配
        deviceAddress: xxx  //mesh node 的 element 单播地址
        modelNumberId:xxx // 控制模式的id , 例如  GenericOnOff 组播，需要传入 0x1000 ,之后就可以通过 sendBlueMeshControlMessage {name : “GenericOnOff”  群控制设备开关 }
    } */
    deleteBlueMeshModelSubscription: function deleteBlueMeshModelSubscription() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.blueToothModuleWrapper("deleteBlueMeshModelSubscription", params);
    },

    //**********蓝牙接口***************END


    //**********思必驰语音识别接口***************START
    // 启动语音监听
    /*
    param为对象:
        {
        auto: true/false，是否启动后马上监听还是处于暂停状态，默认是true (^5.10.0)
        mode: local/online, //设置是APP本地词库识别还是网络在线识别，默认为local本地词库识别 (^5.10.0)
        deviceType: "xxxx", //设备类型，如0xAC，可选项，当需要控制指定设备时填写 (^5.10.0)
        deviceId: "xxxxx", //设备ID，可选项，可选项，当需要控制指定设备时填写 (^5.10.0)
        }
        当收到语音识别数据，app -> 插件: 
        receiveMessageFromApp({ messageType: "aiSpeechNotification", messageBody: {key:"xxxxxxxx"} }) //xxxxxx为匹配到的热词
         当收到语音执行结果，app -> 插件: 
        receiveMessageFromApp({ messageType: "aiSpeechAcyionResult", messageBody: {...} }) //messageBody为思必驰执行返回结果
    */
    startSpeechMonitor: function startSpeechMonitor() {
        var _this18 = this;

        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return new Promise(function (resolve, reject) {
            aiSpeechModule["startSpeechMonitor"](JSON.stringify(params), function (resData) {
                resolve(_this18.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },
    stopSpeechMonitor: function stopSpeechMonitor() {
        var _this19 = this;

        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return new Promise(function (resolve, reject) {
            aiSpeechModule["stopSpeechMonitor"](JSON.stringify(params), function (resData) {
                resolve(_this19.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },

    /* (^5.10.0) 恢复监听。在暂停状态下可以恢复。 */
    resumeSpeechMonitor: function resumeSpeechMonitor() {
        var _this20 = this;

        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return new Promise(function (resolve, reject) {
            aiSpeechModule["resumeSpeechMonitor"](JSON.stringify(params), function (resData) {
                resolve(_this20.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },

    /* (^5.10.0)暂停监听。在监听状态下可以停止。 */
    pauseSpeechMonitor: function pauseSpeechMonitor() {
        var _this21 = this;

        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return new Promise(function (resolve, reject) {
            aiSpeechModule["pauseSpeechMonitor"](JSON.stringify(params), function (resData) {
                resolve(_this21.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },

    /* (^5.10.0)播报文字。
        params为对象:
        {
            content: string，//需要语音播报的句子
        }
    */
    textToSpeech: function textToSpeech() {
        var _this22 = this;

        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return new Promise(function (resolve, reject) {
            aiSpeechModule["textToSpeech"](JSON.stringify(params), function (resData) {
                resolve(_this22.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },
    getLanguage: function getLanguage() {
        var params = {
            operation: 'getLanguage'
        };
        return this.commandInterfaceWrapper(params);
    }

    //**********思必驰语音识别接口***************START

};

/***/ }),

/***/ 11:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(14)
)

/* script */
__vue_exports__ = __webpack_require__(15)

/* template */
var __vue_template__ = __webpack_require__(16)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/chenhx113/Documents/project/meijuobmweexapp/code/AC/src/midea-component/header.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-5837942a"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 1113:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _demoCopy = __webpack_require__(1114);

var _demoCopy2 = _interopRequireDefault(_demoCopy);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

new Vue({
  el: '#root',
  render: function render(h) {
    return h(_demoCopy2.default);
  }
}); // 自动生成的入口文件

/***/ }),

/***/ 1114:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(1115)
)

/* script */
__vue_exports__ = __webpack_require__(1116)

/* template */
var __vue_template__ = __webpack_require__(1118)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/chenhx113/Documents/project/meijuobmweexapp/code/AC/src/T0xAC/app/ac/common/icheck/demo copy.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-2b475b9a"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 1115:
/***/ (function(module, exports) {

module.exports = {
  "wrapper": {
    "alignItems": "center",
    "backgroundColor": "#f5f5f5"
  },
  "list": {
    "width": 750,
    "height": 420,
    "backgroundColor": "#07c160"
  },
  "refresh": {
    "justifyContent": "center",
    "alignItems": "center"
  },
  "indicator": {
    "marginTop": 32,
    "width": 80,
    "height": 80,
    "color": "#ffffff"
  },
  "status-wrapper": {
    "justifyContent": "center",
    "alignItems": "center",
    "width": 750,
    "height": 420
  },
  "status": {
    "justifyContent": "center",
    "alignItems": "center",
    "marginTop": -32,
    "width": 750
  },
  "weight-wrapper": {
    "flexDirection": "row",
    "justifyContent": "center",
    "alignItems": "flex-end"
  },
  "weight": {
    "fontFamily": "PingFangSC-Regular",
    "fontSize": 180,
    "color": "#ffffff"
  },
  "unit": {
    "fontFamily": "PingFangSC-Regular",
    "paddingBottom": 36,
    "fontSize": 28,
    "color": "#ffffff"
  },
  "tip": {
    "fontFamily": "PingFangSC-Regular",
    "fontSize": 28,
    "color": "#ffffff"
  },
  "content-wrapper": {
    "marginTop": -60,
    "width": 686,
    "height": 626,
    "backgroundColor": "#ffffff",
    "borderRadius": 10
  },
  "footer": {
    "position": "fixed",
    "bottom": 0,
    "left": 0,
    "flexDirection": "row",
    "justifyContent": "space-around",
    "alignItems": "center",
    "paddingTop": 20,
    "width": 750,
    "backgroundColor": "#ffffff"
  },
  "ipx-b": {
    "paddingBottom": 68
  },
  "footer-item": {
    "flex": 1,
    "justifyContent": "center",
    "alignItems": "center"
  },
  "icon-wrapper": {
    "width": 72,
    "height": 72,
    "backgroundColor": "#e5e5e8",
    "borderRadius": 72
  },
  "item-title": {
    "paddingTop": 20,
    "paddingBottom": 20,
    "fontFamily": "PingFangSC-Regular",
    "fontSize": 28,
    "color": "#000000"
  },
  "collapse-icon": {
    "marginRight": 32,
    "width": 72,
    "height": 72,
    "backgroundColor": "#07c160",
    "borderRadius": 72
  },
  "collapse-content": {
    "paddingLeft": 104
  },
  "collapse-content-main": {
    "borderBottomWidth": 1,
    "borderBottomColor": "#e5e5e8"
  },
  "collapse-text": {
    "fontFamily": "PingFangSC-Regular",
    "fontSize": 28,
    "color": "#666666"
  },
  "desc1": {
    "fontFamily": "PingFangSC-Regular",
    "fontSize": 28,
    "color": "#ff5566"
  }
}

/***/ }),

/***/ 1116:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _base = __webpack_require__(1117);

var _base2 = _interopRequireDefault(_base);

var _collapse = __webpack_require__(859);

var _collapse2 = _interopRequireDefault(_collapse);

var _nativeService = __webpack_require__(1);

var _nativeService2 = _interopRequireDefault(_nativeService);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  mixins: [_base2.default],
  components: {
    MideaCollapse: _collapse2.default
  },
  data: function data() {
    return {
      refreshing: false,
      weight: 102
    };
  },


  computed: {
    isipx: function isipx() {
      return weex && (weex.config.env.deviceModel === 'iPhone10,3' || weex.config.env.deviceModel === 'iPhone10,6' //iphoneX
      || weex.config.env.deviceModel === 'iPhone11,8' //iPhone XR
      || weex.config.env.deviceModel === 'iPhone11,2' //iPhone XS
      || weex.config.env.deviceModel === 'iPhone11,4' || weex.config.env.deviceModel === 'iPhone11,6' //iPhone XS Max
      );
    }
  },

  methods: {
    onrefresh: function onrefresh() {
      var _this = this;

      this.refreshing = true;
      setTimeout(function () {
        _this.refreshing = false;
      }, 3000);
    },
    goToRecord: function goToRecord() {
      var path = "midea-pages/record.js";
      _nativeService2.default.goTo(path);
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),

/***/ 1117:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _nativeService = __webpack_require__(1);

var _nativeService2 = _interopRequireDefault(_nativeService);

var _debugUtil = __webpack_require__(8);

var _debugUtil2 = _interopRequireDefault(_debugUtil);

var _header = __webpack_require__(11);

var _header2 = _interopRequireDefault(_header);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var appDataTemplate = {};

var bundleUrl = weex.config.bundleUrl;
var match = /.*\/(T0x.*)\//g.exec(bundleUrl);
var plugin_name = match ? match[1] : 'common'; //appConfig.plugin_name
var srcFileName = bundleUrl.substring(bundleUrl.lastIndexOf('/') + 1, bundleUrl.lastIndexOf('.js'));

var globalEvent = weex.requireModule('globalEvent');
var storage = weex.requireModule('storage');

var appDataChannel = new BroadcastChannel(plugin_name + 'appData');
var pushDataChannel = new BroadcastChannel(plugin_name + 'pushData');

Vue.config.errorHandler = function (err, vm, info) {
    console.error(err);
};
exports.default = {
    components: {
        mideaHeader: _header2.default
    },
    data: function data() {
        return {
            title: '',
            isIos: weex.config.env.platform == 'iOS' ? true : false,
            srcFileName: srcFileName,
            pluginVersion: '1.0.0',
            pluginName: plugin_name,
            isMixinCreated: true,
            isNavigating: false,
            appDataKey: plugin_name + 'appData',
            appDataChannel: appDataChannel,
            pushKey: 'receiveMessage',
            pushDataChannel: pushDataChannel,

            appData: appDataTemplate
        };
    },
    computed: {
        pageHeight: function pageHeight() {
            return 750 / weex.config.env.deviceWidth * weex.config.env.deviceHeight;
        },

        isImmersion: function isImmersion() {
            var result = true;
            if (weex.config.env.isImmersion == "false") {
                result = false;
            }
            return result;
        }
    },
    methods: {
        viewappear: function viewappear() {},
        viewdisappear: function viewdisappear() {
            _debugUtil2.default.resetDebugLog();
        },

        getParameterByName: function getParameterByName(name) {
            var url = this.$getConfig().bundleUrl;
            name = name.replace(/[\[\]]/g, "\\$&");
            var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
                results = regex.exec(url);
            if (!results) return null;
            if (!results[2]) return '';
            return decodeURIComponent(results[2].replace(/\+/g, " "));
        },
        goTo: function goTo(pageName) {
            var _this = this;

            var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
            var params = arguments[2];

            if (!this.isNavigating) {
                this.isNavigating = true;
                // 离开时同步全局应用数据
                _nativeService2.default.setItem(this.appDataKey, this.appData, function () {
                    //跳转页面
                    var path = pageName + ".js";
                    if (params) {
                        path += '?' + Object.keys(params).map(function (k) {
                            return encodeURIComponent(k) + '=' + encodeURIComponent(params[k]);
                        }).join('&');
                    }
                    options.viewTag = pageName;
                    _nativeService2.default.goTo(path, options);
                    setTimeout(function () {
                        _this.isNavigating = false;
                    }, 500);
                });
            }
        },
        back: function back() {
            //返回上一页
            _nativeService2.default.goBack();
        },
        exit: function exit() {
            _nativeService2.default.backToNative();
        },
        getAppData: function getAppData() {
            var _this2 = this;

            //获取全局应用数据
            return new Promise(function (resolve, reject) {
                _nativeService2.default.getItem(_this2.appDataKey, function (resp) {
                    var data = void 0;
                    if (resp.result == 'success') {
                        data = resp.data;
                        if (typeof data == 'string') {
                            try {
                                data = JSON.parse(data);
                            } catch (error) {}
                        }
                    }
                    if (!data) {
                        data = _this2.appData;
                    }
                    resolve(data);
                });
            });
        },
        updateAppData: function updateAppData(data) {
            //更新全局应用数据
            this.appData = Object.assign(this.appData, data);
            appDataChannel.postMessage(this.appData);
        },
        resetAppData: function resetAppData() {
            var _this3 = this;

            //重置全局应用数据
            return new Promise(function (resolve, reject) {
                _nativeService2.default.removeItem(_this3.appDataKey, function (resp) {
                    _this3.appData = JSON.parse(JSON.stringify(appDataTemplate));
                    appDataChannel.postMessage(_this3.appData);
                    resolve();
                });
            });
        },
        handleNotification: function handleNotification(data) {
            //处理推送消息
            _debugUtil2.default.debugLog(srcFileName, this.pushKey, data);
        },
        reload: function reload() {
            _nativeService2.default.reload();
        }
    },
    created: function created() {
        var _this4 = this;

        console.log("created");
        //若isMixinCreated为false, 则不继承
        if (!this.isMixinCreated) return;

        //Debug Log相关信息
        _debugUtil2.default.isEnableDebugInfo = false; //开启关闭debuglog功能
        _debugUtil2.default.debugLog("@@@@@@ " + this.title + "(" + plugin_name + "-" + srcFileName + ") @@@@@@");

        //监听全局推送(native->weex)
        globalEvent.addEventListener(this.pushKey, function (data) {
            _debugUtil2.default.debugLog(_this4.title + "=>" + _this4.pushKey + ": " + data);
            //触发本页面处理事件
            _this4.handleNotification(data || {});
            //触发其他页面处理事件
            pushDataChannel.postMessage(data);
        });
        //监听全局推送通信渠道(weex->weex)
        pushDataChannel.onmessage = function (event) {
            _this4.handleNotification(event.data || {});
        };

        //监听全局应用数据通信渠道(weex->weex)
        appDataChannel.onmessage = function (event) {
            _this4.appData = event.data || {};
        };
        //页面创建时获取全局应用数据
        this.getAppData().then(function (data) {
            _this4.appData = data || {};
        });
    }
};

/***/ }),

/***/ 1118:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["wrapper"]
  }, [_c('midea-header', {
    attrs: {
      "bgColor": "#07c160",
      "titleText": "#ffffff",
      "title": "体脂秤",
      "isImmersion": _vm.isImmersion,
      "showRightImg": true,
      "leftImg": "./img/header/ic_back@3x.png",
      "rightImg": "../assets/img/smart_ic_reline@3x.png"
    },
    on: {
      "leftImgClick": _vm.back,
      "rightImgClick": _vm.reload
    }
  }), _c('list', {
    staticClass: ["list"],
    attrs: {
      "showScrollbar": false
    }
  }, [_c('refresh', {
    staticClass: ["refresh"],
    attrs: {
      "display": _vm.refreshing ? 'show' : 'hide'
    },
    on: {
      "refresh": _vm.onrefresh
    }
  }), _c('cell', {
    staticClass: ["status-wrapper"],
    appendAsTree: true,
    attrs: {
      "append": "tree"
    }
  }, [(!_vm.refreshing) ? _c('div', {
    staticClass: ["status"]
  }, [_c('div', {
    staticClass: ["weight-wrapper"]
  }, [_c('text', {
    staticClass: ["weight"]
  }, [_vm._v(_vm._s(_vm.weight))]), _c('text', {
    staticClass: ["unit"]
  }, [_vm._v("斤")])]), _c('text', {
    staticClass: ["tip"]
  }, [_vm._v("下拉链接体脂秤")])]) : _vm._e(), (_vm.refreshing) ? _c('div', {
    staticClass: ["status"]
  }, [_c('image', {
    staticClass: ["indicator"],
    attrs: {
      "src": "../assets/img/loading.gif",
      "resize": "container"
    }
  })]) : _vm._e()])]), _c('list', {
    staticClass: ["content-wrapper"],
    attrs: {
      "showScrollbar": false
    }
  }, [_c('cell', {
    staticClass: ["main-cell"],
    appendAsTree: true,
    attrs: {
      "append": "tree"
    }
  }, [_c('midea-collapse', {
    attrs: {
      "title": "BMI 19.1",
      "desc": "标准",
      "height": "108"
    }
  }, [_c('div', {
    staticClass: ["collapse-icon"],
    slot: "left-icon"
  }), _c('div', {
    staticClass: ["collapse-content"],
    slot: "content"
  }, [_c('div', {
    staticClass: ["collapse-content-main"]
  }, [_c('text', {
    staticClass: ["collapse-text"]
  }, [_vm._v("\n              身体质量指数, 等于体重(kg)除以身高(m)的平方.MBI越大, 身材距离超模和明星们就越远(专业运动员除外)\n            ")])])])]), _c('midea-collapse', {
    attrs: {
      "title": "体脂 22.8%",
      "height": "108"
    }
  }, [_c('div', {
    staticClass: ["collapse-icon"],
    slot: "left-icon"
  }), _c('text', {
    staticClass: ["desc1"],
    slot: "desc"
  }, [_vm._v("偏低")]), _c('div', {
    staticClass: ["collapse-content"],
    slot: "content"
  }, [_c('div', {
    staticClass: ["collapse-content-main"]
  }, [_c('text', {
    staticClass: ["collapse-text"]
  }, [_vm._v("\n              身体质量指数, 等于体重(kg)除以身高(m)的平方.MBI越大, 身材距离超模和明星们就越远(专业运动员除外)\n            ")])])])]), _c('midea-collapse', {
    attrs: {
      "title": "水分 52.1%",
      "desc": "正常",
      "height": "108"
    }
  }, [_c('div', {
    staticClass: ["collapse-icon"],
    slot: "left-icon"
  }), _c('div', {
    staticClass: ["collapse-content"],
    slot: "content"
  }, [_c('div', {
    staticClass: ["collapse-content-main"]
  }, [_c('text', {
    staticClass: ["collapse-text"]
  }, [_vm._v("\n              身体质量指数, 等于体重(kg)除以身高(m)的平方.MBI越大, 身材距离超模和明星们就越远(专业运动员除外)\n            ")])])])]), _c('midea-collapse', {
    attrs: {
      "title": "肌肉 75%",
      "desc": "正常",
      "height": "108"
    }
  }, [_c('div', {
    staticClass: ["collapse-icon"],
    slot: "left-icon"
  }), _c('div', {
    staticClass: ["collapse-content"],
    slot: "content"
  }, [_c('div', {
    staticClass: ["collapse-content-main"]
  }, [_c('text', {
    staticClass: ["collapse-text"]
  }, [_vm._v("\n              身体质量指数, 等于体重(kg)除以身高(m)的平方.MBI越大, 身材距离超模和明星们就越远(专业运动员除外)\n            ")])])])]), _c('midea-collapse', {
    attrs: {
      "title": "骨骼 10%",
      "desc": "正常",
      "height": "108"
    }
  }, [_c('div', {
    staticClass: ["collapse-icon"],
    slot: "left-icon"
  }), _c('div', {
    staticClass: ["collapse-content"],
    slot: "content"
  }, [_c('div', {
    staticClass: ["collapse-content-main"]
  }, [_c('text', {
    staticClass: ["collapse-text"]
  }, [_vm._v("\n              身体质量指数, 等于体重(kg)除以身高(m)的平方.MBI越大, 身材距离超模和明星们就越远(专业运动员除外)\n            ")])])])]), _c('midea-collapse', {
    attrs: {
      "title": "基础消耗 1140千卡",
      "height": "108"
    }
  }, [_c('div', {
    staticClass: ["collapse-icon"],
    slot: "left-icon"
  }), _c('text', {
    staticClass: ["desc1"],
    slot: "desc"
  }, [_vm._v("偏低")]), _c('div', {
    staticClass: ["collapse-content"],
    slot: "content"
  }, [_c('div', {
    staticClass: ["collapse-content-main"]
  }, [_c('text', {
    staticClass: ["collapse-text"]
  }, [_vm._v("\n              身体质量指数, 等于体重(kg)除以身高(m)的平方.MBI越大, 身材距离超模和明星们就越远(专业运动员除外)\n            ")])])])])], 1)]), _c('div', {
    class: ['footer', _vm.isipx && 'ipx-b']
  }, [_vm._m(0), _c('div', {
    staticClass: ["footer-item"],
    on: {
      "click": _vm.goToRecord
    }
  }, [_c('div', {
    staticClass: ["icon-wrapper"]
  }), _c('text', {
    staticClass: ["item-title"]
  }, [_vm._v("记录统计")])]), _vm._m(1)])], 1)
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["footer-item"]
  }, [_c('div', {
    staticClass: ["icon-wrapper"]
  }), _c('text', {
    staticClass: ["item-title"]
  }, [_vm._v("手动计体重")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["footer-item"]
  }, [_c('div', {
    staticClass: ["icon-wrapper"]
  }), _c('text', {
    staticClass: ["item-title"]
  }, [_vm._v("健康信息")])])
}]}
module.exports.render._withStripped = true

/***/ }),

/***/ 13:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
// ************ push 相关 *************
var util = {
    dateFormat: function dateFormat(dateTime, fmt) {
        // 对Date的扩展，将 Date 转化为指定格式的String
        // 月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符， 
        // 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字) 
        // 例子： 
        // dateFormat(new Date(), "yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423 
        // dateFormat(new Date(), "yyyy-M-d h:m:s.S")      ==> 2006-7-2 8:9:4.18 
        if (!dateTime) {
            return dateTime;
        }
        if (typeof dateTime == 'string' && !isNaN(dateTime)) {
            dateTime = +dateTime;
        }
        dateTime = new Date(dateTime);
        var o = {
            "M+": dateTime.getMonth() + 1, //月份 
            "d+": dateTime.getDate(), //日 
            "h+": dateTime.getHours(), //小时 
            "m+": dateTime.getMinutes(), //分 
            "s+": dateTime.getSeconds(), //秒 
            "q+": Math.floor((dateTime.getMonth() + 3) / 3), //季度 
            "S": dateTime.getMilliseconds() //毫秒 
        };
        if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (dateTime.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (var k in o) {
            if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
        }return fmt;
    },
    getParameters: function getParameters(url, key) {
        var theRequest = new Object();
        if (url.indexOf("?") != -1) {
            var queryString = url.substr(url.indexOf("?") + 1);
            var strs = queryString.split("&");
            for (var i = 0; i < strs.length; i++) {
                theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
            }
        }
        return key ? theRequest[key] : theRequest;
    },
    toNum: function toNum(a) {
        var a = a.toString();
        var c = a.split('.');
        var num_place = ["", "0", "00", "000", "0000"],
            r = num_place.reverse();
        for (var i = 0; i < c.length; i++) {
            var len = c[i].length;
            c[i] = r[len] + c[i];
        }
        var res = c.join('');
        return res;
    }
};

exports.default = util;

/***/ }),

/***/ 14:
/***/ (function(module, exports) {

module.exports = {
  "box": {
    "width": 750,
    "display": "inline-flex",
    "flexDirection": "row",
    "flexWrap": "nowrap",
    "justifyContent": "space-between",
    "alignItems": "center"
  },
  "immersion": {
    "paddingTop": 40,
    "height": 128
  },
  "immersion-ipx": {
    "paddingTop": 88,
    "height": 176
  },
  "header-title": {
    "flex": 1,
    "fontFamily": "PingFangSC-Medium",
    "fontWeight": "600",
    "width": 574,
    "lines": 1,
    "textOverflow": "ellipsis",
    "textAlign": "center"
  },
  "header-left-image-wrapper": {
    "width": 88,
    "height": 88,
    "display": "flex",
    "justifyContent": "center",
    "alignItems": "flex-start",
    "paddingLeft": 10
  },
  "header-left-image": {
    "height": 58,
    "width": 58
  },
  "header-right-image-wrapper": {
    "width": 88,
    "height": 88,
    "display": "flex",
    "justifyContent": "center",
    "alignItems": "flex-end",
    "paddingRight": 32
  },
  "header-right-image": {
    "height": 44,
    "width": 44
  },
  "header-right": {
    "position": "absolute",
    "right": 0,
    "height": 88,
    "display": "flex",
    "justifyContent": "center",
    "alignItems": "center"
  },
  "header-right-text": {
    "fontFamily": "PingFangSC-Regular",
    "fontSize": 28,
    "paddingLeft": 20,
    "paddingRight": 32,
    "textAlign": "right"
  }
}

/***/ }),

/***/ 15:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var _nativeService = __webpack_require__(1);

var _nativeService2 = _interopRequireDefault(_nativeService);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    props: {
        title: {
            type: String,
            default: ''
        },
        bgColor: {
            type: String,
            default: '#ffffff'
        },
        fontSize: {
            type: String,
            default: '32'
        },
        titleText: {
            type: String,
            default: '#000000'
        },
        isImmersion: {
            type: Boolean,
            default: null
        },
        leftImg: {
            type: String,
            default: './img/header/public_ic_back@3x.png'
        },
        rightImg: {
            type: String,
            default: './img/header/me_ic_set@3x.png'
        },
        showLeftImg: {
            type: Boolean,
            default: true
        },
        showRightImg: {
            type: Boolean,
            default: false
        },
        showRightText: {
            type: Boolean,
            default: false
        },
        rightText: {
            type: String,
            default: ''
        },
        rightColor: {
            type: String,
            default: '#666666'
        },
        custStyleObj: {
            type: Object,
            default: function _default() {
                return {};
            }
        }
    },
    computed: {
        isipx: function isipx() {
            return weex && (weex.config.env.deviceModel === 'iPhone10,3' || weex.config.env.deviceModel === 'iPhone10,6' //iphoneX
            || weex.config.env.deviceModel === 'iPhone11,8' //iPhone XR
            || weex.config.env.deviceModel === 'iPhone11,2' //iPhone XS
            || weex.config.env.deviceModel === 'iPhone11,4' || weex.config.env.deviceModel === 'iPhone11,6' //iPhone XS Max
            || weex.config.env.deviceModel === 'iPhone12,3' //iPhone11 pro
            );
        },
        statusBarHeight: function statusBarHeight() {
            var result = '20';
            if (weex.config.env.statusBarHeight) {
                if (weex.config.env.platform == 'iOS') {
                    //iOS使用pt为单位
                    result = weex.config.env.statusBarHeight;
                } else {
                    //安卓使用px为单位
                    result = weex.config.env.statusBarHeight / weex.config.env.scale;
                }
            }
            return result;
        },
        headerStyleObj: function headerStyleObj() {
            var result = void 0,
                isImmersion = void 0;
            if (this.isImmersion != null) {
                isImmersion = this.isImmersion;
            } else {
                isImmersion = weex.config.env.isImmersion == "false" ? false : true;
            }
            if (isImmersion) {
                //全屏显示，weex自行处理状态栏高度
                result = _extends({
                    backgroundColor: this.bgColor,
                    paddingTop: this.statusBarHeight + 'wx',
                    height: +this.statusBarHeight + 44 + 'wx'
                }, this.custStyleObj);
            } else {
                //非全屏显示，APP已经处理状态栏高度
                result = _extends({
                    backgroundColor: this.bgColor,
                    height: '44wx'
                }, this.custStyleObj);
            }

            return result;
        }
    },
    data: function data() {
        return {};
    },

    methods: {
        leftImgClick: function leftImgClick() {
            if (!this.showLeftImg) {
                return;
            }
            this.$emit('leftImgClick');
        },
        rightImgClick: function rightImgClick() {
            if (!this.showRightImg) {
                return;
            }
            this.$emit('rightImgClick');
        },
        rightTextClick: function rightTextClick() {
            if (!this.showRightText) {
                return;
            }
            this.$emit('rightTextClick');
        },
        headerClick: function headerClick() {
            this.$emit('headerClick');
        }
    }
};

/***/ }),

/***/ 16:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["wrapper"],
    staticStyle: {
      width: "750px"
    }
  }, [_c('div', {
    staticClass: ["box"],
    style: _vm.headerStyleObj
  }, [_c('div', {
    staticClass: ["header-left-image-wrapper"],
    on: {
      "click": _vm.leftImgClick
    }
  }, [(_vm.showLeftImg) ? _c('image', {
    staticClass: ["header-left-image"],
    attrs: {
      "src": _vm.leftImg
    }
  }) : _vm._e()]), _c('div', {
    on: {
      "click": _vm.headerClick
    }
  }, [_c('text', {
    staticClass: ["header-title"],
    style: {
      color: _vm.titleText,
      fontSize: _vm.fontSize + 'px'
    }
  }, [_vm._v(_vm._s(_vm.title))])]), _c('div', {
    staticClass: ["header-right-image-wrapper"],
    on: {
      "click": _vm.rightImgClick
    }
  }, [_vm._t("rightContent", [(_vm.showRightImg) ? _c('image', {
    staticClass: ["header-right-image"],
    attrs: {
      "src": _vm.rightImg
    }
  }) : _vm._e()])], 2), (_vm.showRightText) ? _c('div', {
    staticClass: ["header-right"],
    on: {
      "click": _vm.rightTextClick
    }
  }, [_c('text', {
    staticClass: ["header-right-text"],
    style: {
      color: _vm.rightColor
    }
  }, [_vm._v(_vm._s(_vm.rightText))])]) : _vm._e(), _vm._t("customerContent")], 2)])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),

/***/ 8:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

// ************ debug 相关 *************
var storage = weex.requireModule('storage');
var mm = weex.requireModule('modal');
var debugInfoDataChannel = new BroadcastChannel('debugInfoDataChannel');
var debugUtil = {
    isEnableDebugInfo: false,
    debugInfoKey: 'debugInfo',
    debugInfoDataChannel: debugInfoDataChannel,
    debugInfoExist: '',
    debugInfo: '',
    debugLogSizeLmite: 80000,
    debugLog: function debugLog() {
        var _this = this;

        for (var _len = arguments.length, messages = Array(_len), _key = 0; _key < _len; _key++) {
            messages[_key] = arguments[_key];
        }

        if (!this.isEnableDebugInfo) return;

        if (!this.debugInfoExist) {
            this.getDebugLog().then(function (data) {
                _this.debugInfoExist = data || ' ***>>> ';
                _this.debugLog.apply(_this, messages);
            });
        } else {
            var debugInfoArray = [];
            for (var index = 0; index < messages.length; index++) {
                var message = messages[index];
                if ((typeof message === 'undefined' ? 'undefined' : _typeof(message)) == 'object') {
                    try {
                        message = JSON.stringify(message, null, 2);
                    } catch (error) {
                        debugInfoArray.push(error);
                    }
                } else if (typeof message == 'string') {
                    try {
                        message = JSON.stringify(JSON.parse(message), null, 2);
                    } catch (error) {}
                }
                debugInfoArray = debugInfoArray.concat(this.strCut2Arr(message, 2000));
            }
            var newDebugInfo = new Date() + '\n' + debugInfoArray.join(", ") + '\n\n';
            this.debugInfo += newDebugInfo;
            this.setItem(this.debugInfoKey, this.debugInfoExist + this.debugInfo);
        }
    },
    getDebugLog: function getDebugLog() {
        var _this2 = this;

        return new Promise(function (resolve, reject) {
            _this2.getItem(_this2.debugInfoKey, function (resp) {
                var result = resp.data || '';
                resolve(result.substr(-_this2.debugLogSizeLmite));
            });
        });
    },
    resetDebugLog: function resetDebugLog() {
        this.debugInfoExist = '';
        this.debugInfo = '';
    },
    cleanDebugLog: function cleanDebugLog() {
        var _this3 = this;

        this.debugInfoExist = '***';
        this.debugInfo = '';
        return new Promise(function (resolve, reject) {
            _this3.removeItem(_this3.debugInfoKey, function () {
                _this3.debugInfoExist = '***';
                _this3.debugInfo = '';
                resolve();
            });
        });
    },
    getItem: function getItem(key, callback) {
        storage.getItem(key, callback);
    },
    setItem: function setItem(key, value, callback) {
        if ((typeof value === 'undefined' ? 'undefined' : _typeof(value)) == 'object') {
            value = JSON.stringify(value);
        }
        value = value.substr(-this.debugLogSizeLmite);
        storage.setItem(key, value, callback);
    },
    removeItem: function removeItem(key, callback) {
        storage.removeItem(key, callback);
    },
    strCut2Arr: function strCut2Arr(str, n) {
        var arr = [];
        var len = Math.ceil(str.length / n);
        for (var i = 0; i < len; i++) {
            if (str.length >= n) {
                var strCut = str.substring(0, n);
                arr.push(strCut + '&*&');
                str = str.substring(n);
            } else {
                str = str;
                arr.push(str);
            }
        }
        return arr;
    }
};

debugInfoDataChannel.onmessage = function (event) {
    debugUtil.cleanDebugLog();
};

exports.default = debugUtil;

/***/ }),

/***/ 859:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(860)
)

/* script */
__vue_exports__ = __webpack_require__(861)

/* template */
var __vue_template__ = __webpack_require__(862)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/chenhx113/Documents/project/meijuobmweexapp/code/AC/src/midea-component/collapse.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-5fc2f80a"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 860:
/***/ (function(module, exports) {

module.exports = {
  "flex_": {
    "display": "flex",
    "flexDirection": "row"
  },
  "bor_": {
    "borderStyle": "solid",
    "borderWidth": 1,
    "borderColor": "#FF0000"
  },
  "collapse-item-wrapper": {
    "paddingLeft": 32,
    "flexDirection": "row",
    "justifyContent": "space-between",
    "alignItems": "center"
  },
  "collapse-item": {
    "flex": 1,
    "alignItems": "center",
    "justifyContent": "space-between",
    "flexDirection": "row",
    "height": 92
  },
  "collapse-item-left": {
    "justifyContent": "center",
    "alignItems": "flex-start"
  },
  "bottom-line": {
    "borderBottomColor": "#eeeeee",
    "borderBottomStyle": "solid",
    "borderBottomWidth": 2
  },
  "collapse-title": {
    "flex": 1,
    "fontFamily": "PingFangSC-Regular",
    "fontSize": 32,
    "color": "#000000"
  },
  "collapse-desc": {
    "fontFamily": "PingFangSC-Regular",
    "fontSize": 28,
    "color": "#666666"
  },
  "collapse-icon": {
    "height": 40,
    "width": 40,
    "marginRight": 24
  }
}

/***/ }),

/***/ 861:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    props: {
        title: String,
        desc: String,
        isFolded: {
            type: Boolean,
            default: true
        },
        height: {
            type: [String, Number],
            default: 92
        }
    },
    computed: {
        collapseItemStyle: function collapseItemStyle() {
            var height = this.height;

            return {
                height: height + 'px'
            };
        }
    },
    watch: {
        isFolded: function isFolded(value) {
            this.isFoldedStatus = value;
        }
    },
    data: function data() {
        return {
            unfoldIcon: '../img/service_ic_show@3x.png',
            foldIcon: '../img/service_ic_hide@3x.png',
            isFoldedStatus: true
        };
    },

    methods: {
        makeSwitch: function makeSwitch(e) {
            this.isFoldedStatus = !this.isFoldedStatus;
        }
    }
};

/***/ }),

/***/ 862:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["collapse-wrapper"]
  }, [_c('div', {
    staticClass: ["collapse-item-wrapper"],
    class: [!_vm.isFoldedStatus ? 'bottom-line' : ''],
    on: {
      "click": _vm.makeSwitch
    }
  }, [_vm._t("left-icon"), _c('div', {
    staticClass: ["collapse-item"],
    style: _vm.collapseItemStyle
  }, [_c('div', {
    staticClass: ["collapse-item-left"]
  }, [(_vm.title) ? _c('text', {
    staticClass: ["collapse-title"]
  }, [_vm._v(_vm._s(_vm.title))]) : _vm._e(), _vm._t("desc", [(_vm.desc) ? _c('text', {
    staticClass: ["collapse-desc"]
  }, [_vm._v(_vm._s(_vm.desc))]) : _vm._e()])], 2), _c('div', {
    staticClass: ["flex_"]
  }, [_vm._t("rightNum"), _c('image', {
    staticClass: ["collapse-icon"],
    attrs: {
      "src": _vm.isFoldedStatus ? _vm.foldIcon : _vm.unfoldIcon
    }
  })], 2)])], 2), (!_vm.isFoldedStatus) ? _c('div', [_vm._t("content")], 2) : _vm._e()])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ })

/******/ });