// { "framework": "Vue" }

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 941);
/******/ })
/************************************************************************/
/******/ ({

/***/ 1:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _debugUtil = __webpack_require__(8);

var _debugUtil2 = _interopRequireDefault(_debugUtil);

var _util = __webpack_require__(13);

var _util2 = _interopRequireDefault(_util);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var mm = weex.requireModule('modal');
var navigator = weex.requireModule('navigator');
var stream = weex.requireModule('stream');
var storage = weex.requireModule('storage');
var bridgeModule = weex.requireModule('bridgeModule');
// const blueToothModule = weex.requireModule('blueToothModule');
var singleBlueToothModule = weex.requireModule('singleBlueToothModule'); // ^5.9.0
var blueToothMeshModule = weex.requireModule('blueToothMeshModule');
var globalEvent = weex.requireModule("globalEvent");
var aiSpeechModule = weex.requireModule("aiSpeechModule"); // ^5.9.0


var isIos = weex.config.env.platform == "iOS" ? true : false;


var isDummy = false;
// import Mock from './mock'  //正式场上线时注释掉

var debugLogSeperator = "**************************************\n";

var isDummy = _util2.default.getParameters(weex.config.bundleUrl, "isDummy") == "true";

var platform = weex.config.env.platform;
if (platform == 'Web') {
    isDummy = true;
}
console.log("isDummy:" + isDummy);
var isRemote = weex.config.bundleUrl.indexOf("http") > -1 ? true : false;

exports.default = {
    serviceList: {
        test: "commonservice"
    },
    Mock: {},
    isDummy: isDummy,
    //**********Util方法***************START
    convertToJson: function convertToJson(str) {
        var result = str;
        if (typeof str == 'string') {
            try {
                result = JSON.parse(str);
            } catch (error) {
                console.error(error);
            }
        }
        return result;
    },
    getParameters: function getParameters(key) {
        var theRequest = new Object();
        var bundleUrl = weex.config.bundleUrl;
        var queryString = '';
        if (bundleUrl.indexOf("?") != -1) {
            queryString = bundleUrl.substr(bundleUrl.indexOf("?") + 1);
            var strs = queryString.split("&");
            for (var i = 0; i < strs.length; i++) {
                theRequest[strs[i].split("=")[0]] = decodeURIComponent(strs[i].split("=")[1]);
            }
        }
        return key ? theRequest[key] : theRequest;
    },

    //**********Util方法***************END

    //**********页面跳转接口***************START
    /*
    params:
        path - 跳转页面路径（以插件文件夹为根目录的相对路径）
        options: {
            animated: true/false, - 是否需要跳转动画
            replace: true/false, - 跳转后是否在历史栈保留当前页面
            viewTag: string - 给跳转后的页面设置标识，可用于goBack时指定返回页面
            transparent: 'true/false', //新页面背景是否透明
            animatedType: 'slide_bottomToTop' //新页面出现动效类型
        }
     */
    goTo: function goTo(path, options, params, isCanSideBack) {
        var _this = this;

        var url;

        if (params) {
            path += (path.indexOf("?") == -1 ? '?' : "&") + Object.keys(params).map(function (k) {
                return encodeURIComponent(k) + '=' + encodeURIComponent(params[k] || '');
            }).join('&');
        }
        // mm.toast({ message: isRemote, duration: 2 })
        if (this.isDummy != true && !isRemote) {
            //手机本地页面跳转
            this.getPath(function (weexPath) {
                //weexPath为当前页面目录地址
                // url = weexPath + path;
                var weexPathArray = weexPath.split('/');
                var pathArray = path.split('/');
                if (weexPathArray[weexPathArray.length - 2] == pathArray[0]) {
                    pathArray.shift();
                    if (weexPathArray[weexPathArray.length - 3] == pathArray[0]) {
                        pathArray.shift();
                        if (weexPathArray[weexPathArray.length - 4] == pathArray[0]) {
                            pathArray.shift();
                        }
                    }
                    url = weexPathArray.join('/') + pathArray.join('/');
                } else {
                    url = weexPath + path;
                }
                // this.alert(path+'-------'+JSON.stringify(options))
                _this.runGo(url, options, isCanSideBack);
            });
        } else if (platform != 'Web') {
            //手机远程weex页面调试跳转
            this.getPath(function (weexPath) {
                //weexPath为当前页面目录地址
                var weexPathArray = weexPath.split('/');
                var pathArray = path.split('/');
                if (weexPathArray[weexPathArray.length - 2] == pathArray[0]) {
                    pathArray.shift();
                    if (weexPathArray[weexPathArray.length - 3] == pathArray[0]) {
                        pathArray.shift();
                        if (weexPathArray[weexPathArray.length - 4] == pathArray[0]) {
                            pathArray.shift();
                        }
                    }
                    url = weexPathArray.join('/') + pathArray.join('/');
                } else {
                    url = weexPath + path;
                }
                if (url.indexOf("?") != -1) {
                    url += '&isDummy=' + isDummy;
                } else {
                    url += '?isDummy=' + isDummy;
                }
                _this.runGo(url, options, isCanSideBack);
            });
        } else {
            //PC网页调试跳转
            location.href = location.origin + location.pathname + '?path=' + path.replace('?', '&');
        }
    },
    runGo: function runGo(url, options, isCanSideBack) {
        // mm.toast({ message: url, duration: 2 })
        // if (isCanSideBack !== undefined) {
        //     options.isCanSideBack = isCanSideBack
        // }
        if (!options) {
            options = {
                animated: 'true',
                replace: 'false'
            };
        } else {
            if (typeof options.animated == 'boolean') {
                options.animated = options.animated ? 'true' : 'false';
            }
            if (typeof options.replace == 'boolean') {
                options.replace = options.replace ? 'true' : 'false';
            }
        }
        // this.alert(isCanSideBack)
        if (isCanSideBack !== undefined) {
            options.isCanSideBack = isCanSideBack;
        }
        // this.alert('tt'+JSON.stringify(options))
        var params = Object.assign(options, {
            url: url
        });
        // this.alert(params)
        navigator.push(params, function (event) {});
    },

    /*
        取得当前weex页面的根路径
    */
    getPath: function getPath(callBack) {
        if (this.isDummy != true && !isRemote) {
            bridgeModule.getWeexPath(function (resData) {
                var jsonData = JSON.parse(resData);
                var weexPath = jsonData.weexPath;
                callBack(weexPath);
            });
        } else if (platform != 'Web') {
            //手机远程weex页面调试
            var rootPath = weex.config.bundleUrl.match(new RegExp("(.*/).*\.js", "i"));
            callBack(rootPath ? rootPath[1] : weex.config.bundleUrl);
        } else {
            //PC网页调试跳转
            location.href = location.origin + location.pathname + '?path=' + path;
        }
    },
    getWeexPath: function getWeexPath() {
        var _this2 = this;

        return new Promise(function (resolve, reject) {
            bridgeModule.getWeexPath(function (resData) {
                resolve(_this2.convertToJson(resData));
            });
        });
    },

    /*  
    options = {
            animated: 'true',
            animatedType: 'slide_topToBottom' //页面关闭时动效类型
    }*/
    goBack: function goBack() {
        var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        var params = Object.assign({
            animated: 'true'
        }, options);
        // this.toast(params)
        navigator.pop(params, function (event) {});
    },
    backToNative: function backToNative() {
        bridgeModule.backToNative();
    },

    //**********页面跳转接口***************END


    //**********非APP业务接口***************START
    generateUUID: function generateUUID() {
        var d = new Date().getTime();
        var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c == 'x' ? r : r & 0x3 | 0x8).toString(16);
        });
        return uuid;
    },
    genMessageId: function genMessageId() {
        var messageId = '';
        for (var i = 0; i < 8; i++) {
            messageId += Math.floor(Math.random() * 10).toString();
        }
        return messageId;
    },
    getItem: function getItem(key, callback) {
        storage.getItem(key, callback);
    },
    setItem: function setItem(key, value, callback) {
        var temp = void 0;
        if ((typeof value === 'undefined' ? 'undefined' : _typeof(value)) == 'object') {
            temp = JSON.stringify(value);
        }
        var defaultCallback = function defaultCallback(event) {
            console.log('set success');
        };
        storage.setItem(key, temp || value, callback || defaultCallback);
    },
    removeItem: function removeItem(key, callback) {
        storage.removeItem(key, function () {
            if (callback) callback();
        });
    },
    toast: function toast(message, duration, bgStyle) {
        if ((typeof message === 'undefined' ? 'undefined' : _typeof(message)) == 'object') {
            message = JSON.stringify(message);
        }
        if (platform == 'Web') {
            mm.toast({ message: message, duration: duration || 1.5 });
        } else {
            bridgeModule.toast({ message: message, duration: duration || 1.5, bgStyle: bgStyle });
        }
    },
    alert: function alert(message, callback, okTitle) {
        var callbackFunc = callback || function (value) {};

        if ((typeof message === 'undefined' ? 'undefined' : _typeof(message)) == 'object') {
            try {
                message = JSON.stringify(message);
            } catch (error) {}
        }
        mm.alert({
            message: message,
            okTitle: okTitle || "确定"
        }, function (value) {
            callbackFunc(value);
        });
    },
    confirm: function confirm(message, callback, okTitle, cancelTitle) {
        mm.confirm({
            message: message,
            okTitle: okTitle || '确定',
            cancelTitle: cancelTitle || '取消'
        }, function (result) {
            callback(result);
        });
    },
    showLoading: function showLoading() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        if (this.isDummy != true) {
            if (_util2.default.toNum(weex.config.env.appVersion) >= _util2.default.toNum("5.11.0")) {
                bridgeModule.showLoading(params);
            } else {
                bridgeModule.showLoading();
            }
        }
    },
    hideLoading: function hideLoading() {
        if (this.isDummy != true) {
            bridgeModule.hideLoading();
        }
    },
    showLoadingWithMsg: function showLoadingWithMsg(option) {
        if (this.isDummy != true) {
            var params = option;
            if (typeof option == 'string') {
                params = {
                    msg: option
                };
            }
            bridgeModule.showLoadingWithMsg(params);
        }
    },
    hideLoadingWithMsg: function hideLoadingWithMsg() {
        if (this.isDummy != true) {
            bridgeModule.hideLoadingWithMsg();
        }
    },

    //隐藏系统导航栏
    setNavBarHidden: function setNavBarHidden() {
        navigator.setNavBarHidden({
            hidden: '1',
            animated: "false"
        }, function (event) {});
    },

    //关闭键盘
    killKeyboard: function killKeyboard() {
        if (this.isDummy != true) {
            bridgeModule.killKeyboard();
        }
    },

    //**********非APP业务接口***************END

    //**********网络请求接口***************START
    //发送智慧云网络请求：此接口固定Post到智慧云https地址及端口
    sendMCloudRequest: function sendMCloudRequest(name, params) {
        var _this3 = this;

        var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : { isShowLoading: true, isValidate: true };

        return new Promise(function (resolve, reject) {
            var self = _this3;
            if (_this3.isDummy != true) {
                _this3.getItem("masterId", function (resdata) {
                    var msgid = self.genMessageId();
                    var masterId = resdata.data;
                    var sendData = {};
                    sendData.url = self.serviceList[name] ? self.serviceList[name] : name;
                    sendData.params = Object.assign({
                        applianceId: masterId + "",
                        msgid: msgid
                    }, params);
                    if (options.isShowLoading) {
                        _this3.showLoading();
                    }
                    bridgeModule.sendMCloudRequest(sendData, function (resData) {
                        _debugUtil2.default.debugLog(debugLogSeperator, 'request(' + msgid + '): ', sendData);
                        _debugUtil2.default.debugLog('response(' + msgid + '): ', resData, debugLogSeperator);
                        if (typeof resData == 'string') {
                            resData = JSON.parse(resData);
                        }
                        if (options.isShowLoading) {
                            _this3.hideLoading();
                        }

                        if (options.isValidate) {
                            //resData.status为5.0判断；resData.errorCode为4.判断
                            if (resData.errorCode == 0) {
                                resolve(resData);
                            } else if (resData.status === true) {
                                resolve(resData);
                            } else {
                                reject(resData);
                            }
                        } else {
                            resolve(resData);
                        }
                    }, function (error) {
                        _debugUtil2.default.debugLog(debugLogSeperator, 'request(' + msgid + '): ', sendData);
                        _debugUtil2.default.debugLog('=======> error(' + msgid + '): ', error, debugLogSeperator);
                        if (options.isShowLoading) {
                            _this3.hideLoading();
                        }
                        if (typeof error == 'string') {
                            error = JSON.parse(error);
                        }
                        reject(error);
                    });
                });
            } else {
                var resData = _this3.Mock.getMock(self.serviceList[name] ? self.serviceList[name] : name);
                if (options.isValidate) {
                    //resData.status为5.0判断；resData.errorCode为4.判断
                    if (resData.errorCode == 0) {
                        resolve(resData);
                    } else if (resData.status === true) {
                        resolve(resData);
                    } else {
                        reject(resData);
                    }
                } else {
                    resolve(resData);
                }
            }
        });
    },


    //^5.0.0发送中台网络请求：此接口固定Post到中台https地址及端口
    /* 
    name: 'gateway/subdevice/search', //请求接口路径url，或者serviceList的key,
    params(可选): {
        method: 'POST', //POST/GET, 默认POST
        headers: {}, //请求header
        data: {} //请求参数
        } 
    */
    sendCentralCloundRequest: function sendCentralCloundRequest(name, params) {
        var _this4 = this;

        var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : { isShowLoading: true };

        return new Promise(function (resolve, reject) {
            if (_this4.isDummy != true) {
                var msgid = _this4.genMessageId();
                var sendData = params || {};
                sendData.url = _this4.serviceList[name] ? _this4.serviceList[name] : name;
                if (options.isShowLoading) {
                    _this4.showLoading();
                }
                bridgeModule.sendCentralCloundRequest(sendData, function (resData) {
                    _debugUtil2.default.debugLog(debugLogSeperator, 'request(' + msgid + '): ', sendData);
                    _debugUtil2.default.debugLog('response(' + msgid + '): ', resData, debugLogSeperator);
                    if (typeof resData == 'string') {
                        try {
                            resData = JSON.parse(resData);
                        } catch (e) {}
                    }
                    if (options.isShowLoading) {
                        _this4.hideLoading();
                    }

                    resolve(resData);
                }, function (error) {
                    _debugUtil2.default.debugLog(debugLogSeperator, 'request(' + msgid + '): ', sendData);
                    _debugUtil2.default.debugLog('=======> error(' + msgid + '): ', error, debugLogSeperator);
                    if (options.isShowLoading) {
                        _this4.hideLoading();
                    }
                    if (typeof error == 'string') {
                        try {
                            error = JSON.parse(error);
                        } catch (e) {}
                    }
                    reject(error);
                });
            } else {
                var resData = _this4.Mock.getMock(_this4.serviceList[name] ? _this4.serviceList[name] : name);
                resolve(resData);
            }
        });
    },


    //AEM系统发送请求
    retransmissionCloundRequestSend: function retransmissionCloundRequestSend(url, params) {
        var _this5 = this;

        var method = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 'get';
        var options = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};

        var param = {
            url: url,
            method: method,
            data: _extends({}, params)
        };
        return new Promise(function (resolve, reject) {
            // nativeService.retransmissionCloundRequest(url, params, options).then((res) => {
            _this5.retransmissionCloundRequest(param, options).then(function (res) {
                if (parseInt(res.code, 10) === 200) {
                    resolve(res);
                } else {
                    reject(res);
                }
            }).catch(function (error) {
                reject(error);
            });
        });
    },
    retransmissionCloundRequest: function retransmissionCloundRequest(params) {
        var _this6 = this;

        var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : { isShowLoading: false };

        var param = Object.assign({
            operation: 'retransmissionCloundRequest',
            params: params
        });
        // return this.commandInterfaceWrapper(param);
        return new Promise(function (resolve, reject) {
            if (options.isShowLoading) {
                _this6.showLoading();
            }
            // this.alert(JSON.stringify(param))
            bridgeModule.commandInterface(JSON.stringify(param), function (resData) {
                if (options.isShowLoading) {
                    _this6.hideLoading();
                }
                resolve(_this6.convertToJson(resData));
            }, function (error) {
                if (options.isShowLoading) {
                    _this6.hideLoading();
                }
                reject(error);
            });
        });
    },

    //发送POST网络请求：URL自定义
    /* params: {
        url: url,
        type: 'text',
        method: "POST",
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: {
            'objectId': objectId,
            'format': 'base64'
        }
    } */
    sendHttpRequest: function sendHttpRequest(params) {
        var _this7 = this;

        var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : { isShowLoading: true, isValidate: true };

        return new Promise(function (resolve, reject) {
            var requestParams = JSON.parse(JSON.stringify(params));
            var self = _this7;
            if (_this7.isDummy != true) {
                var defaultParams = {
                    method: "POST",
                    type: 'json'
                };
                requestParams = Object.assign(defaultParams, requestParams);

                /* body 参数仅支持 string 类型的参数，请勿直接传递 JSON，必须先将其转为字符串。
                GET 请求不支持 body 方式传递参数，请使用 url 传参。 */
                if (requestParams.body && requestParams.method == "GET") {
                    var bodyStr = _this7.convertRequestBody(requestParams.body);
                    if (requestParams.url.indexOf("?") > -1) {
                        requestParams.url += "&" + bodyStr;
                    } else {
                        requestParams.url += "?" + bodyStr;
                    }
                    requestParams.body = "";
                } else if (requestParams.body && requestParams.method == "POST") {
                    requestParams.body = requestParams.body;
                }

                if (options.isShowLoading) {
                    _this7.showLoading();
                }
                var msgid = self.genMessageId();
                stream.fetch(requestParams, function (resData) {
                    _debugUtil2.default.debugLog(debugLogSeperator, 'request(' + msgid + '): ', requestParams);
                    _debugUtil2.default.debugLog('response(' + msgid + '): ', resData, debugLogSeperator);
                    if (options.isShowLoading) {
                        _this7.hideLoading();
                    }
                    if (!resData.ok) {
                        if (typeof resData == 'string') {
                            resData = JSON.parse(resData);
                        }
                        reject(resData);
                    } else {
                        var result = resData.data;
                        if (typeof result == 'string') {
                            result = JSON.parse(result);
                        }
                        resolve(result);
                    }
                });
            } else {
                var resData = _this7.Mock.getMock(params.url);
                resolve(resData);
            }
        });
    },
    convertRequestBody: function convertRequestBody(obj) {
        var param = "";
        for (var name in obj) {
            if (typeof obj[name] != 'function') {
                param += "&" + name + "=" + encodeURI(obj[name]);
            }
        }
        return param.substring(1);
    },

    //发送指令透传接口
    startCmdProcess: function startCmdProcess(name, messageBody, callback, callbackFail) {
        var commandId = Math.floor(Math.random() * 1000);
        var param = {
            commandId: commandId
        };
        if (messageBody != undefined) {
            param.messageBody = messageBody;
        }
        var finalCallBack = function finalCallBack(resData) {
            if (typeof resData == 'string') {
                resData = JSON.parse(resData);
            }
            if (resData.errorCode != 0) {
                callbackFail(resData);
            } else {
                callback(resData.messageBody);
            }
        };
        var finalCallbackFail = function finalCallbackFail(resData) {
            if (typeof resData == 'string') {
                resData = JSON.parse(resData);
            }
            callbackFail(resData);
        };
        if (this.isDummy != true) {
            if (isIos) {
                this.createCallbackFunctionListener();
                this.callbackFunctions[commandId] = finalCallBack;
                this.callbackFailFunctions[commandId] = finalCallbackFail;
            }
            bridgeModule.startCmdProcess(JSON.stringify(param), finalCallBack, finalCallbackFail);
        } else {
            callback(this.Mock.getMock(name).messageBody);
        }
    },


    //发送指令透传接口(套系)
    startCmdProcessTX: function startCmdProcessTX(name, messageBody, deviceId, callback, callbackFail) {
        var commandId = Math.floor(Math.random() * 1000);
        var param = {
            commandId: commandId
        };
        if (messageBody != undefined) {
            param.messageBody = messageBody;
        }
        if (deviceId != undefined) {
            param.deviceId = deviceId;
        }
        var finalCallBack = function finalCallBack(resData) {
            if (typeof resData == 'string') {
                resData = JSON.parse(resData);
            }
            if (resData.errorCode != 0) {
                callbackFail(resData);
            } else {
                callback(resData.messageBody);
            }
        };
        var finalCallbackFail = function finalCallbackFail(resData) {
            if (typeof resData == 'string') {
                resData = JSON.parse(resData);
            }
            callbackFail(resData);
        };
        if (this.isDummy != true) {
            if (isIos) {
                this.createCallbackFunctionListener();
                this.callbackFunctions[commandId] = finalCallBack;
                this.callbackFailFunctions[commandId] = finalCallbackFail;
            }
            bridgeModule.startCmdProcess(JSON.stringify(param), finalCallBack, finalCallbackFail);
        } else {
            callback(this.Mock.getMock(name).messageBody);
        }
    },

    /* 服务透传接口。提供给插件发送请求至事业部的品类服务器。此接口美居APP会将请求内容加密，然后发送给“云平台”进行中转发送至事业部品类服务器。
        params: {
            type:服务类型，如果weex没有传，或者传入类似""的空字节，则取当前插件类型作为该数值
            queryStrings:与H5内容一致
            transmitData:与H5内容一致
        }
    */
    requestDataTransmit: function requestDataTransmit(params) {
        var _this8 = this;

        return new Promise(function (resolve, reject) {
            bridgeModule.requestDataTransmit(JSON.stringify(params), function (resData) {
                resolve(_this8.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },


    /* *****即将删除, IOS已经做了改进，不在需要已callbackFunction回调callback ********/
    isCreateListener: false,
    createCallbackFunctionListener: function createCallbackFunctionListener() {
        var _this9 = this;

        if (!this.isCreateListener) {
            this.isCreateListener = true;
            globalEvent.addEventListener("callbackFunction", function (result) {
                //IOS消息返回处理
                var commandId = result.commandId;
                if (commandId) {
                    _this9.callbackFunction(commandId, result);
                }
            });
        }
    },

    callbackFunctions: {},
    callbackFailFunctions: {},
    callbackFunction: function callbackFunction(commandId, result) {
        var jsonResult = result;
        var cbf = this.callbackFunctions[commandId];
        var cbff = this.callbackFailFunctions[commandId];
        if (jsonResult.errorCode !== undefined && jsonResult.errMessage == 'TimeOut') {
            if (typeof cbff == "function") {
                cbff(-1); //表示指令超时 －1
            }
        } else {
            if (typeof cbf == "function") {
                cbf(jsonResult);
            }
        }
        delete this.callbackFunctions[commandId];
        delete this.callbackFailFunctions[commandId];
    },

    /* *****即将删除, IOS已经做了改进，不在需要已callbackFunction回调callback ********/

    //发送Lua指令接口
    sendLuaRequest: function sendLuaRequest(params) {
        var _this10 = this;

        var isShowLoading = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;

        return new Promise(function (resolve, reject) {
            if (!params.operation) {
                params.operation = "luaQuery"; //luaQuery or luaControl
            }
            if (!params.params) {
                params.params = {};
            }

            if (_this10.isDummy != true) {
                if (isShowLoading && params.operation == 'luaQuery') {
                    _this10.showLoading();
                }
                var msgid = _this10.genMessageId();
                bridgeModule.commandInterface(JSON.stringify(params), function (resData) {
                    _debugUtil2.default.debugLog(debugLogSeperator, 'Lua request(' + msgid + '): ', params);
                    _debugUtil2.default.debugLog('Lua response(' + msgid + '):', resData, debugLogSeperator);
                    if (typeof resData == 'string') {
                        resData = JSON.parse(resData);
                    }
                    if (isShowLoading) {
                        _this10.hideLoading();
                    }
                    if (resData.errorCode == 0) {
                        //成功
                        resolve(resData);
                    } else {
                        reject(resData);
                    }
                }, function (error) {
                    // this.alert(error)
                    _debugUtil2.default.debugLog(debugLogSeperator, 'Lua request(' + msgid + '): ', params);
                    _debugUtil2.default.debugLog('=======> Lua error(' + msgid + '): ', error, debugLogSeperator);
                    if (isShowLoading) {
                        _this10.hideLoading();
                    }
                    if (typeof error == 'string') {
                        error = JSON.parse(error);
                    }
                    reject(error);
                });
            } else {
                var resData = void 0;
                if (params['operation'] || params['name']) {
                    if (params['name']) {
                        resData = Mock.getMock(params['name']);
                    } else {
                        resData = Mock.getMock(params['operation']);
                    }
                }
                _debugUtil2.default.debugLog("Mock: ", resData);
                resolve(resData);
            }
        });
    },

    //**********网络请求接口***************END


    //**********APP业务接口***************START
    updateTitle: function updateTitle(title, showLeftBtn, showRightBtn) {
        var params = {
            title: title,
            showLeftBtn: showLeftBtn,
            showRightBtn: showRightBtn
        };
        if (this.isDummy != true) {
            bridgeModule.updateTitle(JSON.stringify(params));
        }
    },
    getAuthToken: function getAuthToken() {
        var _this11 = this;

        return new Promise(function (resolve, reject) {
            bridgeModule.getAuthToken({}, function (resData) {
                resolve(_this11.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },

    // 获取套系列表
    getTxList: function getTxList() {
        var _this12 = this;

        var isShowLoading = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;

        // if (this.isDummy != true) {
        return new Promise(function (resolve, reject) {
            if (isShowLoading) {
                _this12.showLoading();
            }
            bridgeModule.getTXList({}, function (resData) {
                if (typeof resData == 'string') {
                    // this.alert(resData)
                    var resDataObj = JSON.parse(resData);
                    if (isShowLoading) {
                        _this12.hideLoading();
                    }
                    if (resDataObj.errorCode && resDataObj.errorCode !== 0) {
                        //失败
                        reject(resDataObj);
                    } else {
                        //成功
                        resolve(resDataObj);
                    }
                } else {
                    //Android 可能直接传个对象
                    var resDataObj = resData;
                    if (isShowLoading) {
                        _this12.hideLoading();
                    }
                    if (resDataObj.errorCode && resDataObj.errorCode !== 0) {
                        //失败
                        reject(resDataObj);
                    } else {
                        //成功
                        resolve(resDataObj);
                    }
                }
            }, function (error) {
                if (typeof error == 'string') {
                    error = JSON.parse(error);
                    mm.modal({ "message": error }, 3);
                }
                reject(error);
            });
        });
        // }else{
        //     return new Promise((resolve, reject) => {
        //         let data = Mock.getMock('queryTXList');
        //         resolve(data)
        //     })
        // }
    },
    showSharePanel: function showSharePanel(params, callback, callbackFail) {
        return new Promise(function (resolve, reject) {
            bridgeModule.showSharePanel(params, function (resData) {
                resolve(resData);
            }, function (error) {
                reject(error);
            });
        });
    },


    /*
     * created by zhouhg 20180621 start
     */
    //根据设备信息获取插件信息
    getDevicePluginInfo: function getDevicePluginInfo(params) {
        var _this13 = this;

        return new Promise(function (resolve, reject) {
            if (_this13.isDummy != true) {
                bridgeModule.getDevicePluginInfo(params, function (resData) {
                    resolve(resData);
                }, function (error) {
                    reject(error);
                });
            } else {
                var data = Mock.getMock('getDevicePluginInfo');
                resolve(data);
            }
        });
    },

    //下载插件接口
    downLoadDevicePlugin: function downLoadDevicePlugin(params, callback, callbackFail) {
        var that = this;
        if (this.isDummy != true) {
            bridgeModule.downLoadDevicePlugin(params, function (resData) {
                callback(resData);
            }, function (error) {
                callbackFail(error);
            });
        } else {
            var data = Mock.getMock('downLoadDevicePlugin');
            setTimeout(function () {
                callback(data);
            }, 3000);
        }
    },
    getDeviceOnlineStatus: function getDeviceOnlineStatus(params, callback, callbackFail) {
        var _this14 = this;

        return new Promise(function (resolve, reject) {
            var that = _this14;
            bridgeModule.getDeviceOnlineStatus(params, function (resData) {
                resolve(resData);
            }, function (error) {
                reject(error);
            });
        });
    },

    //设备主动上报在线离线状态
    deviceOnlineStatus: function deviceOnlineStatus() {
        var params = {
            operation: 'deviceOnlineStatus'
        };
        return this.commandInterfaceWrapper(params);
    },

    //更新下载插件并解压后，需要替换加载新下载的插件
    loadingLatestPlugin: function loadingLatestPlugin(params, callback, callbackFail) {
        //  	let params = {};
        return new Promise(function (resolve, reject) {
            bridgeModule.loadingLatestPlugin(params, function (resData) {
                resolve(resData);
            }, function (error) {
                reject(error);
            });
        });
    },

    //重新加载当前页面
    reload: function reload(callback, callbackFail) {
        var params = {};
        bridgeModule.reload(params, function (resData) {
            if (callback) callback(resData);
        }, function (error) {
            if (callbackFail) callbackFail(error);
        });
    },

    /*
     * created by zhouhg 20180621 end
     */

    //统一JS->Native接口
    commandInterfaceWrapper: function commandInterfaceWrapper(param) {
        var _this15 = this;

        return new Promise(function (resolve, reject) {
            bridgeModule.commandInterface(JSON.stringify(param), function (resData) {
                resolve(_this15.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },

    //获取用户信息
    getUserInfo: function getUserInfo() {
        var param = {
            operation: 'getUserInfo'
        };
        return this.commandInterfaceWrapper(param);
    },

    //打电话
    /* param: {
        tel: '10086',
        title: '客户服务',
        desc: '拨打热线电话：'
    } */
    callTel: function callTel(params) {
        var param = Object.assign(params, {
            operation: 'callTel'
        });
        return this.commandInterfaceWrapper(param);
    },

    //弹出全局电话列表
    /* param: [{
        tel: '10086',
        title: '客户服务',
        desc: '拨打热线电话：'
    },{...}] */
    callTelList: function callTelList(params) {
        var param = {
            'operation': 'callTelList',
            'params': params
        };
        return this.commandInterfaceWrapper(param);
    },

    //触发手机震动  intensity 1：轻微震动 2：中等震动 3：强烈震动  intensity为空：猛烈♂震动
    hapticFeedback: function hapticFeedback(intensity) {
        var param = void 0;
        if (intensity && typeof intensity == 'number') {
            param = {
                operation: 'hapticFeedback',
                intensity: intensity
            };
        } else {
            param = {
                operation: 'hapticFeedback'
            };
        }
        return this.commandInterfaceWrapper(param);
    },

    //打开指定的系统设置，比如蓝牙
    openNativeSystemSetting: function openNativeSystemSetting(settingName) {
        var param = {
            operation: 'openNativeSystemSetting',
            setting: settingName || 'bluetooth'
        };
        return this.commandInterfaceWrapper(param);
    },
    shareMsg: function shareMsg(params) {
        /* params =  {
            "type": "wx", //分享类型，wx表示微信分享，qq表示qq分享，sms表示短信分享，weibo表示新浪微博，qzone表示QQ空间，wxTimeline表示微信朋友圈
            "title": "xxxxxx", //分享的标题
            "desc": "xxxxxx",//分享的文本内容
            "imgUrl": "xxxxxx",//分享的图片链接
            "link": "xxxxxx" //分享的跳转链接
        } */
        var param = {
            'operation': 'shareMsg',
            'params': params
        };
        return this.commandInterfaceWrapper(param);
    },

    //获取当前设备网络信息
    getNetworkStatus: function getNetworkStatus() {
        var param = {
            operation: 'getNetworkStatus'
        };
        return this.commandInterfaceWrapper(param);
    },

    //获取当前家庭信息
    getCurrentHomeInfo: function getCurrentHomeInfo() {
        var param = {
            operation: 'getCurrentHomeInfo'
        };
        return this.commandInterfaceWrapper(param);
    },

    //获取当前设备信息
    getDeviceInfo: function getDeviceInfo() {
        var param = {
            operation: 'getDeviceInfo'
        };
        if (this.isDummy == true) {
            return new Promise(function (resolve, reject) {
                try {
                    var resData = Mock.getMock(param.operation);
                    if (resData.errorCode == 0) {
                        resolve(resData);
                    } else {
                        reject(resData);
                    }
                } catch (error) {
                    reject("获取模拟数据出错");
                }
            });
        } else {
            return this.commandInterfaceWrapper(param);
        }
    },

    //更新当前设备信息
    updateDeviceInfo: function updateDeviceInfo(params) {
        var param = Object.assign(params, {
            operation: 'updateDeviceInfo'
        });
        return this.commandInterfaceWrapper(param);
    },

    //打开指定的原生页面
    jumpNativePage: function jumpNativePage(params) {
        /* params =  {
            "pageName": "xxxx", //跳转的目标页面
            "data": {xxxxxx}, //传参，为json格式字符串
        } */
        var param = Object.assign(params, {
            operation: 'jumpNativePage'
        });
        return this.commandInterfaceWrapper(param);
    },

    //跳转到h5页面
    weexBundleToWeb: function weexBundleToWeb(params) {
        /* params =  {
            url: "xxxx", //跳转的目标页面
            title: "h5标题"
        } */
        var param = Object.assign(params, {
            operation: 'weexBundleToWeb'
        });
        return this.commandInterfaceWrapper(param);
    },

    //设置是否监控安卓手机物理返回键功能, v4.4.0
    setBackHandle: function setBackHandle(status) {
        /* params =  {
            "pageName": "xxxx", //跳转的目标页面
            "isMonitor": on,  //on: 打开监控，off: 关闭监控
        } */
        var params = {
            operation: 'setBackHandle',
            isMonitor: status
        };
        return this.commandInterfaceWrapper(params);
    },

    //二维码/条形码扫码功能，用于读取二维码/条形码的内容
    scanCode: function scanCode() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        var param = Object.assign(params, {
            operation: 'scanCode'
        });
        return this.commandInterfaceWrapper(param);
    },

    //获取wifi列表
    getWifiList: function getWifiList() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        var param = Object.assign(params, {
            operation: 'getWifiList'
        });
        return this.commandInterfaceWrapper(param);
    },

    //开启麦克风录音，可以保存录音文件或者把声音转换成文字
    startRecordAudio: function startRecordAudio(params) {
        /* params =  {
            max:number, //最长录音时间, 单位为秒
            isSave:true/false, //是否保存语音录音文件
            isTransform:true/false, //是否需要转换语音成文字
        } */
        var param = Object.assign(params, {
            operation: 'startRecordAudio'
        });
        return this.commandInterfaceWrapper(param);
    },

    //开启麦克风录音后，自行控制结束录音
    stopRecordAudio: function stopRecordAudio() {
        var params = {
            operation: 'stopRecordAudio'
        };
        return this.commandInterfaceWrapper(params);
    },
    takePhoto: function takePhoto(params) {
        /* params =  {
            compressRage:60, , //number, 返回照片的压缩率，范围为0~100，数值越高保真率越高
            type:'jpg', //值为jpg或png，指定返回相片的格式
            isNeedBase64: true/false //是否需要返回相片base64数据
        } */
        var param = Object.assign(params, {
            operation: 'takePhoto'
        });
        return this.commandInterfaceWrapper(param);
    },

    /* 选择相册照片，并返回相片数据 */
    choosePhoto: function choosePhoto(params) {
        /* params =  {
            compressRage:60, , //number, 返回照片的压缩率，范围为0~100，数值越高保真率越高
            type:'jpg', //值为jpg或png，指定返回相片的格式
            isNeedBase64: true/false //是否需要返回相片base64数据
        } */
        var param = Object.assign(params, {
            operation: 'choosePhoto'
        });
        return this.commandInterfaceWrapper(param);
    },

    /* 选择多张相册照片，并返回相片数据，不支持base64的转换 */
    chooseMulPhoto: function chooseMulPhoto(params) {
        /* params =  {
            max:number, //一次最多可选择的数量，默认为9，最多9张。
        } */
        var param = Object.assign(params, {
            operation: 'chooseMulPhoto'
        });
        return this.commandInterfaceWrapper(param);
    },
    getGPSInfo: function getGPSInfo(params) {
        /* params =  {
            desiredAccuracy: "10",  //定位的精确度，单位：米
            alwaysAuthorization: "0",  //是否开启实时定位功能，0: 只返回一次GPS信息（默认），1:APP在前台时，每移动distanceFilter的距离返回一次回调。2:无论APP在前后台，每移动distanceFilter的距离返回一次回调（注意耗电）
            distanceFilter: "10", //alwaysAuthorization为1或2时有效，每移动多少米回调一次定位信息
        } */
        var param = Object.assign(params, {
            operation: 'getGPSInfo'
        });
        return this.commandInterfaceWrapper(param);
    },
    getCityInfo: function getCityInfo(params) {
        var param = Object.assign(params, {
            operation: 'getCityInfo'
        });
        return this.commandInterfaceWrapper(param);
    },

    /*  ^5.0.0 根据getCityInfo获得的城市对应的气象局ID获取城市天气信息， 比如温度， 风向等信息 */
    getWeatherInfo: function getWeatherInfo(params) {
        var param = Object.assign(params, {
            operation: 'getWeatherInfo'
        });
        return this.commandInterfaceWrapper(param);
    },

    /*  ^5.0.0  百度开放接口，通过经纬度返回对应的位置信息 */
    baiduGeocoder: function baiduGeocoder(params) {
        var param = Object.assign(params, {
            operation: 'baiduGeocoder'
        });
        return this.commandInterfaceWrapper(param);
    },

    //获取登录态信息
    getLoginInfo: function getLoginInfo() {
        var param = {
            operation: 'getLoginInfo'
        };
        return this.commandInterfaceWrapper(param);
    },

    /* ^5.0.0 打开用户手机地图软件，传入标记地点。（打开地图软件后，用户可以使用地图软件的功能，比如导航等）
    ios: 如果用户安装了百度地图，则跳转到百度地图app，没有安装，则跳转Safar，使用网页导航
    android: 如果用户安装了百度地图，则跳转到百度地图app，没有安装，则跳转使用外部浏览器，使用网页导航（用户选择合适的浏览器，原生toast引导，存在选择错误应用的风险） */
    launchMapApp: function launchMapApp(params) {
        /* params =  {
            from:{ //当前用户地点
                latitude: string, //纬度
                longitude: string //经度
            },
            to:{ //目的地地点
                latitude: string, //纬度
                longitude: string //经度
            }
        } */
        var param = Object.assign(params, {
            operation: 'launchMapApp'
        });
        return this.commandInterfaceWrapper(param);
    },

    /* 根据模糊地址，返回地图服务的查询结果数据。 */
    searchMapAddress: function searchMapAddress(params) {
        /* params =  {
            city: "", //需要查询的城市(范围)
            keyword: "美的" //需要查询的地址
        } */
        var param = Object.assign(params, {
            operation: 'searchMapAddress'
        });
        return this.commandInterfaceWrapper(param);
    },

    /* 选择通讯录的好友，可以获取电话号码，好友信息 */
    getAddressBookPerson: function getAddressBookPerson() {
        var param = {
            operation: 'getAddressBookPerson'
        };
        return this.commandInterfaceWrapper(param);
    },
    downloadImageWithCookie: function downloadImageWithCookie(params) {
        var param = Object.assign(params, {
            operation: 'downloadImageWithCookie'
        });
        return this.commandInterfaceWrapper(param);
    },


    //调用第三方SDK统一接口
    interfaceForThirdParty: function interfaceForThirdParty() {
        bridgeModule.interfaceForThirdParty.apply(bridgeModule, arguments);
    },

    //
    updateAutoList: function updateAutoList() {
        bridgeModule.updateAutoList();
    },

    /*发送埋点数据*/
    burialPoint: function burialPoint(params) {
        var param = Object.assign(params, {
            operation: 'burialPoint'
        });
        return this.commandInterfaceWrapper(param);
    },

    /* weex卡片页打开控制页页面接口 */
    showControlPanelPage: function showControlPanelPage() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        bridgeModule.showControlPanelPage(params);
    },

    /* 上传图片文件，调用一次，上传一份图片文件 */
    uploadImgFile: function uploadImgFile(params, callback, callbackFail) {
        /* params = {
            path: string, //值为 图片在手机中的路径
            url: string, //值为服务器上传图片的url
            maxWidth: number, //最大宽度，如果不设置，则使用图片宽度
            maxHeight: number, //最大高度，如果不设置，则使用图片高度
            compressRage: number, //图片的压缩率，范围为0~100，数值越高保真率越高。默认值：100，不压缩，直接上传图片 ps: 压缩后的图片文件格式，固定为jpg 格式
            netParam: {
                xxx: xxx, //weex需要原生填充给服务器的post 表单参数1
                xxx: xxx, //weex需要原生填充给服务器的post 表单参数2
            },
            fileKey: string, //值为原生在post表单中传输图片文件的key值，缺省默认值为“file”
        } */
        var param = Object.assign(params, {
            operation: 'uploadImgFile'
        });
        bridgeModule.commandInterface(param, callback, callbackFail);
    },
    uploadImgFileToMas: function uploadImgFileToMas(params, callback, callbackFail) {
        /* params = {
            path: string, //值为 图片在手机中的路径
            url: string, //值为服务器上传图片的url
            maxWidth: number, //最大宽度，如果不设置，则使用图片宽度
            maxHeight: number, //最大高度，如果不设置，则使用图片高度
            compressRage: number, //图片的压缩率，范围为0~100，数值越高保真率越高。默认值：100，不压缩，直接上传图片 ps: 压缩后的图片文件格式，固定为jpg 格式
            netParam: {
                xxx: xxx, //weex需要原生填充给服务器的post 表单参数1
                xxx: xxx, //weex需要原生填充给服务器的post 表单参数2
            },
            fileKey: string, //值为原生在post表单中传输图片文件的key值，缺省默认值为“file”
        } */
        var param = Object.assign(params, {
            operation: 'uploadImgFileToMas'
        });
        bridgeModule.commandInterface(param, callback, callbackFail);
    },

    //LottieView接口
    showLottieView: function showLottieView() {},

    /* setIdleTimerDisabled 设置屏幕常亮 ^5.7
        1.插件调用setIdleTimerDisabled,原生APP定时60秒后重新开启系统自动屏灭的操作。
        1.1 假如插件要长时间保持屏亮，需要调用setIdleTimerDisabled后，隔60秒后再次调用来维持一直屏亮。
        1.2 插件调用setIdleTimerDisabled，间隔不到60秒又调用setIdleTimerDisabled，原生app的定时时间，重新设置，60秒后再重新启动系统的自动灭屏操作！
    */
    setIdleTimerDisabled: function setIdleTimerDisabled() {
        var param = {
            operation: 'setIdleTimerDisabled'
        };
        bridgeModule.commandInterface(param, function () {}, function () {});
    },

    /*  
     * ^5.7.0 [subscribeMessage]-订阅设备状态推送
     * @params: { deviceId: []}  
     * deviceId是想订阅的设备id,空数组-清空订阅设备，['all']-订阅用户该家庭所有设备消息推送， [deviceId]订阅指定设备
    */
    subscribeMessage: function subscribeMessage(params) {
        var param = Object.assign(params, {
            operation: 'subscribeMessage'
        });
        return this.commandInterfaceWrapper(param);
    },

    /*  
     * ^5.11.0 [subscribeMessage]-订阅设备状态推送
     * @params: { data: xxxxx}  
     * xxxx是加密的SN
    */
    decrptySN: function decrptySN(params) {
        var param = Object.assign(params, {
            operation: 'decrptySN'
        });
        return this.commandInterfaceWrapper(param);
    },

    //**********APP业务接口***************END


    //**********蓝牙接口***************START ==》此接口为二进制传输接口，已经在5.9作废
    // blueToothModuleWrapper(apiName, param) {
    //     return new Promise((resolve, reject) => {
    //         blueToothModule[apiName](JSON.stringify(param),
    //             (resData) => {
    //                 resolve(this.convertToJson(resData))
    //             },
    //             (error) => {
    //                 reject(error)
    //             })
    //     })
    // },
    //获取蓝牙开启状态
    /* return:
        {status:1, //1表示蓝牙已打开，0：蓝牙关闭状态，2:：蓝牙正在重置，3：设备不支持蓝牙，4：蓝牙未授权}
    */
    // getBlueStatus(params = {}) {
    //     return this.blueToothModuleWrapper("getBlueStatus", params)
    // },
    //开始扫描蓝牙 
    /*  param:{duration: number //持续时间, 单位：秒}
        当扫描到的蓝牙设备（蓝牙信息），app-->插件:
        receiveMessageFromApp({messageType:"blueScanResult",messageBody:{name:"xxx", deviceKey:"xxxxx"}})
     */
    // startBlueScan(params = {}) {
    //     return this.blueToothModuleWrapper("startBlueScan", params)
    // },
    //停止蓝牙扫描
    /* 当扫描结束（停止或超时），app -> 插件:
    receiveMessageFromApp({ messageType: "blueScanStop", messageBody: {} })
    */
    // stopBlueScan(params = {}) {
    //     return this.blueToothModuleWrapper("stopBlueScan", params)
    // },
    //保存蓝牙信息
    /* param:{deviceType:品类码, name:"xxx", deviceKey:"xxxxx"} */
    // addDeviceBlueInfo(params = {}) {
    //     return this.blueToothModuleWrapper("addDeviceBlueInfo", params)
    // },
    //获取之前保存的蓝牙信息
    /* param:{ deviceType: 品类码 }
       result:{status：0, //0: 执行成功, 1:执行失败, name:"xxx", deviceKey:"xxxxx"}
    */
    // getDeviceBlueInfo(params = {}) {
    //     return this.blueToothModuleWrapper("getDeviceBlueInfo", params)
    // },
    //根据蓝牙信息建立蓝牙连接
    /* param:{name:"xxx", 
        deviceKey:"xxxxx",
        service:"uuid", //蓝牙服务特征，使用者根据设备信息传入
        writeCharacter:"uuid", //蓝牙写入通道特征，使用者根据设备信息传入
        readCharacter:"uuid" //蓝牙读取通道特征，使用者根据设备信息传入
    } */
    /* 当收到蓝牙数据，app -> 插件: 
    receiveMessageFromApp({ messageType: "receiveBlueInfo", messageBody: { deviceKey:"xxxxx", data: "xxx" } })
    */
    // setupBlueConnection(params = {}) {
    //     return this.blueToothModuleWrapper("setupBlueConnection", params)
    // },
    // 向蓝牙设备传输数据
    /* param:{
        deviceKey:"xxxxx", 
        data:"xxx" 
    } */
    // writeBlueInfo(params = {}) {
    //     return this.blueToothModuleWrapper("writeBlueInfo", params)
    // },
    //断开当前蓝牙连接
    /* 若是蓝牙意外断开, app -> 插件: 
       receiveMessageFromApp({ messageType: "blueConnectionBreak", messageBody: {} }) 
    */
    // disconnectBlueConnection(params = {}) {
    //     return this.blueToothModuleWrapper("disconnectBlueConnection", params)
    // },
    //**********蓝牙接口***************END


    //**********新蓝牙接口^5.9.0***************START
    singleBlueToothModuleWrapper: function singleBlueToothModuleWrapper(apiName, param) {
        var _this16 = this;

        return new Promise(function (resolve, reject) {
            if (_util2.default.toNum(weex.config.env.appVersion) >= _util2.default.toNum("5.9.0")) {
                singleBlueToothModule[apiName](JSON.stringify(param), function (resData) {
                    resolve(_this16.convertToJson(resData));
                }, function (error) {
                    reject(error);
                });
            } else {
                reject({ errorCode: -1, errorMsg: "version not support" });
            }
        });
    },

    //获取蓝牙开启状态
    /* return:
        当获取到蓝牙状态/蓝牙状态变更
        receiveMessageFromApp({messageType:"singleBlueStatus",messageBody:{status:1, //1表示蓝牙已打开，0：蓝牙关闭状态，2:：蓝牙正在重置，3：设备不支持蓝牙，4：蓝牙未授权}})
    */
    getBlueStatus: function getBlueStatus() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("getBlueStatus", params);
    },

    //开始扫描蓝牙
    /*  param:{
        name:"midea_xx_xxxx",//选填
        mac:"xxxxxxxxxxxx",//选填
        duration: number //持续时间, 单位：秒}
        当扫描到的蓝牙设备（蓝牙信息），app-->插件:
        receiveMessageFromApp({messageType:"singleBlueScanStop",messageBody:{}})
     */
    startBlueScan: function startBlueScan() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("startBlueScan", params);
    },

    //停止蓝牙扫描
    /* 当扫描结束（停止或超时），app -> 插件:
    receiveMessageFromApp({ messageType: "blueScanStop", messageBody: {} })
    */
    stopBlueScan: function stopBlueScan() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("stopBlueScan", params);
    },

    //根据蓝牙信息建立蓝牙连接
    /* param:{
        name:"midea_xx_xxxx", //蓝牙名称
        token:"xxxx",//鉴权 长度32
        mac:"xxxx"//蓝牙mac地址
        applianceId:"xxx"//设备id
    } 
     失败回调:errorCode:-1, //-1:连接失败, -2:发现服务失败, -3:密钥协商失败, -4:token校验失败, -5:10s超时
    */
    setupBlueConnection: function setupBlueConnection() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("setupBlueConnection", params);
    },


    //查询设备当前状态,连接之后立马查询

    /* param:{
        mac:"xxxx",//12位蓝牙Mac地址
        name:"midea_xx_xxxx",//蓝牙名称
        applianceId:"xxx"//设备id
    } 
    当收到蓝牙数据时，APP通知插件结果:
    receiveMessageFromApp({ messageType: "receiveSingleBlueLuaInfo", messageBody: { applianceId:"xxx", data: {luaKey1:"xxx",luaKey2:"xxx"}}})
    */
    queryBlueLuaStatus: function queryBlueLuaStatus() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("queryBlueLuaStatus", params);
    },


    //查询设备当前状态,连接之后立马查询

    /* param:{
        mac:"xxxx",//12位蓝牙Mac地址
        name:"midea_xx_xxxx",//蓝牙名称
        applianceId:"xxx"
        data:{
            luaKey1:"xxx",
            luaKey2:"xxx"
        } //期望控制
    } 
    当收到蓝牙数据时，APP通知插件结果:
    receiveMessageFromApp({ messageType: "receiveSingleBlueLuaInfo", messageBody: { applianceId:"xxx", data: {luaKey1:"xxx",luaKey2:"xxx"}}})
    */
    sendBlueLuaRequest: function sendBlueLuaRequest() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("sendBlueLuaRequest", params);
    },


    //断开当前蓝牙连接
    /* param:{
        mac:"xxxx",//12位蓝牙Mac地址
        name:"midea_xx_xxxx",//蓝牙名称
        } 
    若是蓝牙意外断开, app -> 插件: 
       receiveMessageFromApp({ messageType: "singleBlueConnectionBreak", messageBody: {mac:"xxxx", name:"midea_xx_xxxx"} }) 
    */
    disconnectBlueConnection: function disconnectBlueConnection() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("disconnectBlueConnection", params);
    },


    //下载文件
    /* param:{
        mac:"xxxx",//12位蓝牙Mac地址
        name:"midea_xx_xxxx",//蓝牙名称
        } 
        result: {
            path:"xxx"//,下载文件本地路径
        }
    */
    downFile: function downFile() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("downFile", params);
    },

    //查询当前固件指令
    /* param:{
            mac:"xxxx",//12位蓝牙Mac地址
            name:"midea_xx_xxxx",//蓝牙名称
        } 
    当收到蓝牙数据时，APP通知插件结果:
        receiveMessageFromApp({ messageType: "receiveSingleBlueFirmwareStatus", messageBody: {mac:"xxxx", name:"midea_xx_xxxx",data: {
            otaVersion:"xxx"//固件版本
            status:"",//固件状态
            revisonL:"xxx",//大版本号
            revisionS:""//小版本号
        }}}) 
    */
    readFirmwareStatus: function readFirmwareStatus() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("readFirmwareStatus", params);
    },

    //开始ota升级
    /* param:{
            mac:"xxxx",//12位蓝牙Mac地址
            name:"midea_xx_xxxx",//蓝牙名称
            source:"xxx"//bin文件路径
        } 
    当收到蓝牙数据时，APP通知插件结果:
        receiveMessageFromApp({ messageType: "receiveSingleBlueOtaProcess", messageBody: {mac:"xxxx", name:"midea_xx_xxxx",data: {
            status:0//0:成功, -1:失败
            process:1//1:擦拭空间, 2:请求写入, 3:写数据（写数据进度看progress）, 4:crc校验, 5:升级指令
            progress：0.5//写bin文件进度,当process=3时使用
        }}}) 
    */
    startFirmwareOta: function startFirmwareOta() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("startFirmwareOta", params);
    },

    //重启蓝牙模块
    /* param:{
        mac:"xxxx",//12位蓝牙Mac地址
        name:"midea_xx_xxxx",//蓝牙名称
        } 
    当收到蓝牙数据时，APP通知插件结果:
        receiveMessageFromApp({ messageType: "receiveSingleBlueRestart", messageBody: {mac:"xxxx", name:"midea_xx_xxxx",data: {
            status:0//0成功，-1失败,
        }}}) 
    */
    restartBlueDevice: function restartBlueDevice() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.singleBlueToothModuleWrapper("restartBlueDevice", params);
    },

    //**********蓝牙接口新蓝牙接口^5.9.0***************END


    //**********蓝牙MESH接口***************START
    blueToothMeshModuleWrapper: function blueToothMeshModuleWrapper(apiName, param) {
        var _this17 = this;

        return new Promise(function (resolve, reject) {
            blueToothMeshModule[apiName](JSON.stringify(param), function (resData) {
                resolve(_this17.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },

    //根据蓝牙信息建立蓝牙连接
    /* param:{
        mac:"xxx", //设备mac地址，可通getDeviceBlueMeshInfo接口获取
        ssid:"xxxxx", //设备ssid，可通getDeviceBlueMeshInfo接口获取
    } */
    /* 当收到蓝牙数据，app -> 插件: 
    receiveMessageFromApp({ messageType: "receiveBlueInfo", messageBody: { deviceKey:"xxxxx", data: "xxx" } })
    */
    setupBlueMeshConnection: function setupBlueMeshConnection() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.blueToothMeshModuleWrapper("setupBlueMeshConnection", params);
    },

    //断开当前蓝牙连接
    /* 若是蓝牙意外断开, app -> 插件: 
       receiveMessageFromApp({ messageType: "blueConnectionBreak", messageBody: {} }) 
    */
    disconnectBlueMeshConnection: function disconnectBlueMeshConnection() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.blueToothMeshModuleWrapper("disconnectBlueMeshConnection", params);
    },

    //获取当前家庭的所有Mesh设备的信息
    /* param:{ deviceType: 品类码 }
       result:{status：0, //0: 执行成功, 1:执行失败, name:"xxx", deviceKey:"xxxxx"}
    */
    getDeviceBlueMeshListInfo: function getDeviceBlueMeshListInfo() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.blueToothModuleWrapper("getDeviceBlueMeshListInfo", params);
    },

    // 向蓝牙Mesh发送控制指令
    /* param:{
        destAddress: xxx  //目标控制地址  ，可为 单播地址，群播地址
        name:xxx //例如 GenericOnOff 、GenericLevel 、LightCtlTemperature
        params :{     // name字段的不同，params需要不同的数据，例如  ,
        onoff:  xxx // 0 或1 ,name 为 GenericOnOff 需要  0或者1
        level:    xxx // GenericLevel 需要 0~100 之类的数值
        temperature:  xxxx //  LightCtlTemperature 才会需要的温度数值
        deltaUV: xxxx // LightCtlTemperature 才会需要
    } */
    sendBlueMeshControlMessage: function sendBlueMeshControlMessage() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.blueToothModuleWrapper("sendBlueMeshControlMessage", params);
    },

    // 蓝牙Mesh增加群订阅
    /*  ps1:一个mesh node element 可以订阅多个群地址
        ps2:一个群地址可以配置多个modelNumberId，以响应不同的控制消息
    param:{
        groupAddress:xxx  // 组播地址  这个理论上是 事业部应用服务器从 iot服务器上申请分配，建议从0xD000开始分配
        deviceAddress: xxx  //mesh node 的 element 单播地址
        modelNumberId:xxx // 控制模式的id , 例如  GenericOnOff 组播，需要传入 0x1000 ,之后就可以通过 sendBlueMeshControlMessage {name : “GenericOnOff”  群控制设备开关 }
    } */
    addBlueMeshModelSubscription: function addBlueMeshModelSubscription() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.blueToothModuleWrapper("addBlueMeshModelSubscription", params);
    },

    // 蓝牙Mesh取消群订阅
    /* param:{
        groupAddress:xxx  // 组播地址  这个理论上是 事业部应用服务器从 iot服务器上申请分配，建议从0xD000开始分配
        deviceAddress: xxx  //mesh node 的 element 单播地址
        modelNumberId:xxx // 控制模式的id , 例如  GenericOnOff 组播，需要传入 0x1000 ,之后就可以通过 sendBlueMeshControlMessage {name : “GenericOnOff”  群控制设备开关 }
    } */
    deleteBlueMeshModelSubscription: function deleteBlueMeshModelSubscription() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return this.blueToothModuleWrapper("deleteBlueMeshModelSubscription", params);
    },

    //**********蓝牙接口***************END


    //**********思必驰语音识别接口***************START
    // 启动语音监听
    /*
    param为对象:
        {
        auto: true/false，是否启动后马上监听还是处于暂停状态，默认是true (^5.10.0)
        mode: local/online, //设置是APP本地词库识别还是网络在线识别，默认为local本地词库识别 (^5.10.0)
        deviceType: "xxxx", //设备类型，如0xAC，可选项，当需要控制指定设备时填写 (^5.10.0)
        deviceId: "xxxxx", //设备ID，可选项，可选项，当需要控制指定设备时填写 (^5.10.0)
        }
        当收到语音识别数据，app -> 插件: 
        receiveMessageFromApp({ messageType: "aiSpeechNotification", messageBody: {key:"xxxxxxxx"} }) //xxxxxx为匹配到的热词
         当收到语音执行结果，app -> 插件: 
        receiveMessageFromApp({ messageType: "aiSpeechAcyionResult", messageBody: {...} }) //messageBody为思必驰执行返回结果
    */
    startSpeechMonitor: function startSpeechMonitor() {
        var _this18 = this;

        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return new Promise(function (resolve, reject) {
            aiSpeechModule["startSpeechMonitor"](JSON.stringify(params), function (resData) {
                resolve(_this18.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },
    stopSpeechMonitor: function stopSpeechMonitor() {
        var _this19 = this;

        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return new Promise(function (resolve, reject) {
            aiSpeechModule["stopSpeechMonitor"](JSON.stringify(params), function (resData) {
                resolve(_this19.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },

    /* (^5.10.0) 恢复监听。在暂停状态下可以恢复。 */
    resumeSpeechMonitor: function resumeSpeechMonitor() {
        var _this20 = this;

        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return new Promise(function (resolve, reject) {
            aiSpeechModule["resumeSpeechMonitor"](JSON.stringify(params), function (resData) {
                resolve(_this20.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },

    /* (^5.10.0)暂停监听。在监听状态下可以停止。 */
    pauseSpeechMonitor: function pauseSpeechMonitor() {
        var _this21 = this;

        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return new Promise(function (resolve, reject) {
            aiSpeechModule["pauseSpeechMonitor"](JSON.stringify(params), function (resData) {
                resolve(_this21.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },

    /* (^5.10.0)播报文字。
        params为对象:
        {
            content: string，//需要语音播报的句子
        }
    */
    textToSpeech: function textToSpeech() {
        var _this22 = this;

        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

        return new Promise(function (resolve, reject) {
            aiSpeechModule["textToSpeech"](JSON.stringify(params), function (resData) {
                resolve(_this22.convertToJson(resData));
            }, function (error) {
                reject(error);
            });
        });
    },
    getLanguage: function getLanguage() {
        var params = {
            operation: 'getLanguage'
        };
        return this.commandInterfaceWrapper(params);
    }

    //**********思必驰语音识别接口***************START

};

/***/ }),

/***/ 11:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(14)
)

/* script */
__vue_exports__ = __webpack_require__(15)

/* template */
var __vue_template__ = __webpack_require__(16)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/chenhx113/Documents/project/meijuobmweexapp/code/AC/src/midea-component/header.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-5837942a"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 12:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _nativeService = __webpack_require__(1);

var _nativeService2 = _interopRequireDefault(_nativeService);

var _debugUtil = __webpack_require__(8);

var _debugUtil2 = _interopRequireDefault(_debugUtil);

var _header = __webpack_require__(11);

var _header2 = _interopRequireDefault(_header);

var _Process = __webpack_require__(5);

var _Process2 = _interopRequireDefault(_Process);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var appDataTemplate = {};

var bundleUrl = weex.config.bundleUrl;
var match = /.*\/(T0x.*)\//g.exec(bundleUrl);
var plugin_name = match ? match[1] : 'common'; //appConfig.plugin_name
var srcFileName = bundleUrl.substring(bundleUrl.lastIndexOf('/') + 1, bundleUrl.lastIndexOf('.js'));

var globalEvent = weex.requireModule('globalEvent');
var storage = weex.requireModule('storage');

var appDataChannel = new BroadcastChannel(plugin_name + 'appData');
var pushDataChannel = new BroadcastChannel(plugin_name + 'pushData');

// Vue.config.errorHandler = function (err, vm, info) {
//     console.error(err)
// }

Vue.config.errorHandler = function (err, vm, info) {
    var errObj = {
        path: weex.config.bundleUrl,
        errDesc: err,
        errDetail: JSON.stringify(err),
        info: info
    };
    var errMsg = '\u6267\u884C\u65F6\u9519\u8BEF\u4FE1\u606F:\xA0\n' + JSON.stringify(errObj, null, 4);
    console.log(errMsg);
    // (weex.config.bundleUrl.indexOf('http') !== -1) && (nativeService.alert(errMsg));
    // nativeService.alert(errMsg)
};

exports.default = {
    components: {
        mideaHeader: _header2.default
    },
    data: function data() {
        return {
            title: '',
            isIos: weex.config.env.platform == 'iOS' ? true : false,
            srcFileName: srcFileName,
            pluginVersion: '1.0.0',
            pluginName: plugin_name,
            isMixinCreated: true,
            isNavigating: false,
            appDataKey: plugin_name + 'appData',
            appDataChannel: appDataChannel,
            pushKey: 'receiveMessage',
            pushDataChannel: pushDataChannel,

            appData: appDataTemplate,
            langCode: 'en'
        };
    },
    computed: {
        pageHeight: function pageHeight() {
            return 750 / weex.config.env.deviceWidth * weex.config.env.deviceHeight;
        },

        isImmersion: function isImmersion() {
            var result = true;
            if (weex.config.env.isImmersion == "false") {
                result = false;
            }
            return result;
        },
        isipx: function isipx() {
            return weex && (weex.config.env.deviceModel === 'iPhone10,3' || weex.config.env.deviceModel === 'iPhone10,6' //iphoneX
            || weex.config.env.deviceModel === 'iPhone11,8' //iPhone XR
            || weex.config.env.deviceModel === 'iPhone11,2' //iPhone XS
            || weex.config.env.deviceModel === 'iPhone11,4' || weex.config.env.deviceModel === 'iPhone11,6' //iPhone XS Max
            || weex.config.env.deviceModel === 'iPhone12,3' //iPhone11 pro
            );
        },
        statusBarHeight: function statusBarHeight() {
            var result = '20';
            if (weex.config.env.statusBarHeight) {
                if (weex.config.env.platform == 'iOS') {
                    //iOS使用pt为单位
                    result = weex.config.env.statusBarHeight;
                } else {
                    //安卓使用px为单位
                    result = weex.config.env.statusBarHeight / weex.config.env.scale;
                }
            }
            return result;
        },
        headerStyleObj: function headerStyleObj() {
            var result = void 0,
                isImmersion = void 0;
            if (this.isImmersion != null) {
                isImmersion = this.isImmersion;
            } else {
                isImmersion = weex.config.env.isImmersion == "false" ? false : true;
            }
            if (isImmersion) {
                //全屏显示，weex自行处理状态栏高度
                result = _extends({
                    backgroundColor: 'rgba(255,255,255,' + this.titleOpacity + ')',
                    paddingTop: this.statusBarHeight + 'wx',
                    height: this.titleOpacity !== 0 && this.name.length > 4 ? +this.statusBarHeight + 54 + 'wx' : +this.statusBarHeight + 44 + 'wx'
                }, this.custStyleObj);
            } else {
                //非全屏显示，APP已经处理状态栏高度
                result = _extends({
                    backgroundColor: 'rgba(255,255,255,' + this.titleOpacity + ')',
                    height: '44wx'
                }, this.custStyleObj);
            }

            return result;
        }
    },
    methods: {
        viewappear: function viewappear() {},
        viewdisappear: function viewdisappear() {
            _debugUtil2.default.resetDebugLog();
        },

        getParameterByName: function getParameterByName(name) {
            var url = this.$getConfig().bundleUrl;
            name = name.replace(/[\[\]]/g, "\\$&");
            var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
                results = regex.exec(url);
            if (!results) return null;
            if (!results[2]) return '';
            return decodeURIComponent(results[2].replace(/\+/g, " "));
        },
        goTo: function goTo(pageName) {
            var _this = this;

            var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
            var params = arguments[2];

            if (!this.isNavigating) {
                this.isNavigating = true;
                // 离开时同步全局应用数据
                _nativeService2.default.setItem(this.appDataKey, this.appData, function () {
                    //跳转页面
                    var path = pageName + ".js";
                    if (params) {
                        path += '?' + Object.keys(params).map(function (k) {
                            return encodeURIComponent(k) + '=' + encodeURIComponent(params[k]);
                        }).join('&');
                    }
                    options.viewTag = pageName;
                    _nativeService2.default.goTo(path, options);
                    setTimeout(function () {
                        _this.isNavigating = false;
                    }, 500);
                });
            }
        },
        back: function back() {
            //返回上一页
            _nativeService2.default.goBack();
        },
        exit: function exit() {
            _nativeService2.default.backToNative();
        },
        getAppData: function getAppData() {
            var _this2 = this;

            //获取全局应用数据
            return new Promise(function (resolve, reject) {
                _nativeService2.default.getItem(_this2.appDataKey, function (resp) {
                    var data = void 0;
                    if (resp.result == 'success') {
                        data = resp.data;
                        if (typeof data == 'string') {
                            try {
                                data = JSON.parse(data);
                            } catch (error) {}
                        }
                    }
                    if (!data) {
                        data = _this2.appData;
                    }
                    resolve(data);
                });
            });
        },
        updateAppData: function updateAppData(data) {
            //更新全局应用数据
            this.appData = Object.assign(this.appData, data);
            appDataChannel.postMessage(this.appData);
        },
        resetAppData: function resetAppData() {
            var _this3 = this;

            //重置全局应用数据
            return new Promise(function (resolve, reject) {
                _nativeService2.default.removeItem(_this3.appDataKey, function (resp) {
                    _this3.appData = JSON.parse(JSON.stringify(appDataTemplate));
                    appDataChannel.postMessage(_this3.appData);
                    resolve();
                });
            });
        },
        handleNotification: function handleNotification(data) {
            //处理推送消息
            _debugUtil2.default.debugLog(srcFileName, this.pushKey, data);
        },
        reload: function reload() {
            weex.config.bundleUrl.indexOf('http') !== -1 && _nativeService2.default.reload();
        }
    },
    created: function created() {
        var _this4 = this;

        // nativeService.alert(weex.config.bundleUrl.indexOf('http') !== -1);

        _Process2.default.initLangEnv(function (langCode) {
            _this4.langCode = langCode;
        });

        console.log("created");
        //若isMixinCreated为false, 则不继承
        if (!this.isMixinCreated) return;

        //Debug Log相关信息
        _debugUtil2.default.isEnableDebugInfo = false; //开启关闭debuglog功能
        _debugUtil2.default.debugLog("@@@@@@ " + this.title + "(" + plugin_name + "-" + srcFileName + ") @@@@@@");

        //监听全局推送(native->weex)
        globalEvent.addEventListener(this.pushKey, function (data) {
            _debugUtil2.default.debugLog(_this4.title + "=>" + _this4.pushKey + ": " + data);
            //触发本页面处理事件
            _this4.handleNotification(data || {});
            //触发其他页面处理事件
            pushDataChannel.postMessage(data);
        });
        //监听全局推送通信渠道(weex->weex)
        pushDataChannel.onmessage = function (event) {
            _this4.handleNotification(event.data || {});
        };

        //监听全局应用数据通信渠道(weex->weex)
        appDataChannel.onmessage = function (event) {
            _this4.appData = event.data || {};
        };
        //页面创建时获取全局应用数据
        this.getAppData().then(function (data) {
            _this4.appData = data || {};
        });
    }
};

/***/ }),

/***/ 13:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
// ************ push 相关 *************
var util = {
    dateFormat: function dateFormat(dateTime, fmt) {
        // 对Date的扩展，将 Date 转化为指定格式的String
        // 月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符， 
        // 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字) 
        // 例子： 
        // dateFormat(new Date(), "yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423 
        // dateFormat(new Date(), "yyyy-M-d h:m:s.S")      ==> 2006-7-2 8:9:4.18 
        if (!dateTime) {
            return dateTime;
        }
        if (typeof dateTime == 'string' && !isNaN(dateTime)) {
            dateTime = +dateTime;
        }
        dateTime = new Date(dateTime);
        var o = {
            "M+": dateTime.getMonth() + 1, //月份 
            "d+": dateTime.getDate(), //日 
            "h+": dateTime.getHours(), //小时 
            "m+": dateTime.getMinutes(), //分 
            "s+": dateTime.getSeconds(), //秒 
            "q+": Math.floor((dateTime.getMonth() + 3) / 3), //季度 
            "S": dateTime.getMilliseconds() //毫秒 
        };
        if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (dateTime.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (var k in o) {
            if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
        }return fmt;
    },
    getParameters: function getParameters(url, key) {
        var theRequest = new Object();
        if (url.indexOf("?") != -1) {
            var queryString = url.substr(url.indexOf("?") + 1);
            var strs = queryString.split("&");
            for (var i = 0; i < strs.length; i++) {
                theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
            }
        }
        return key ? theRequest[key] : theRequest;
    },
    toNum: function toNum(a) {
        var a = a.toString();
        var c = a.split('.');
        var num_place = ["", "0", "00", "000", "0000"],
            r = num_place.reverse();
        for (var i = 0; i < c.length; i++) {
            var len = c[i].length;
            c[i] = r[len] + c[i];
        }
        var res = c.join('');
        return res;
    }
};

exports.default = util;

/***/ }),

/***/ 14:
/***/ (function(module, exports) {

module.exports = {
  "box": {
    "width": 750,
    "display": "inline-flex",
    "flexDirection": "row",
    "flexWrap": "nowrap",
    "justifyContent": "space-between",
    "alignItems": "center"
  },
  "immersion": {
    "paddingTop": 40,
    "height": 128
  },
  "immersion-ipx": {
    "paddingTop": 88,
    "height": 176
  },
  "header-title": {
    "flex": 1,
    "fontFamily": "PingFangSC-Medium",
    "fontWeight": "600",
    "width": 574,
    "lines": 1,
    "textOverflow": "ellipsis",
    "textAlign": "center"
  },
  "header-left-image-wrapper": {
    "width": 88,
    "height": 88,
    "display": "flex",
    "justifyContent": "center",
    "alignItems": "flex-start",
    "paddingLeft": 10
  },
  "header-left-image": {
    "height": 58,
    "width": 58
  },
  "header-right-image-wrapper": {
    "width": 88,
    "height": 88,
    "display": "flex",
    "justifyContent": "center",
    "alignItems": "flex-end",
    "paddingRight": 32
  },
  "header-right-image": {
    "height": 44,
    "width": 44
  },
  "header-right": {
    "position": "absolute",
    "right": 0,
    "height": 88,
    "display": "flex",
    "justifyContent": "center",
    "alignItems": "center"
  },
  "header-right-text": {
    "fontFamily": "PingFangSC-Regular",
    "fontSize": 28,
    "paddingLeft": 20,
    "paddingRight": 32,
    "textAlign": "right"
  }
}

/***/ }),

/***/ 15:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var _nativeService = __webpack_require__(1);

var _nativeService2 = _interopRequireDefault(_nativeService);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    props: {
        title: {
            type: String,
            default: ''
        },
        bgColor: {
            type: String,
            default: '#ffffff'
        },
        fontSize: {
            type: String,
            default: '32'
        },
        titleText: {
            type: String,
            default: '#000000'
        },
        isImmersion: {
            type: Boolean,
            default: null
        },
        leftImg: {
            type: String,
            default: './img/header/public_ic_back@3x.png'
        },
        rightImg: {
            type: String,
            default: './img/header/me_ic_set@3x.png'
        },
        showLeftImg: {
            type: Boolean,
            default: true
        },
        showRightImg: {
            type: Boolean,
            default: false
        },
        showRightText: {
            type: Boolean,
            default: false
        },
        rightText: {
            type: String,
            default: ''
        },
        rightColor: {
            type: String,
            default: '#666666'
        },
        custStyleObj: {
            type: Object,
            default: function _default() {
                return {};
            }
        }
    },
    computed: {
        isipx: function isipx() {
            return weex && (weex.config.env.deviceModel === 'iPhone10,3' || weex.config.env.deviceModel === 'iPhone10,6' //iphoneX
            || weex.config.env.deviceModel === 'iPhone11,8' //iPhone XR
            || weex.config.env.deviceModel === 'iPhone11,2' //iPhone XS
            || weex.config.env.deviceModel === 'iPhone11,4' || weex.config.env.deviceModel === 'iPhone11,6' //iPhone XS Max
            || weex.config.env.deviceModel === 'iPhone12,3' //iPhone11 pro
            );
        },
        statusBarHeight: function statusBarHeight() {
            var result = '20';
            if (weex.config.env.statusBarHeight) {
                if (weex.config.env.platform == 'iOS') {
                    //iOS使用pt为单位
                    result = weex.config.env.statusBarHeight;
                } else {
                    //安卓使用px为单位
                    result = weex.config.env.statusBarHeight / weex.config.env.scale;
                }
            }
            return result;
        },
        headerStyleObj: function headerStyleObj() {
            var result = void 0,
                isImmersion = void 0;
            if (this.isImmersion != null) {
                isImmersion = this.isImmersion;
            } else {
                isImmersion = weex.config.env.isImmersion == "false" ? false : true;
            }
            if (isImmersion) {
                //全屏显示，weex自行处理状态栏高度
                result = _extends({
                    backgroundColor: this.bgColor,
                    paddingTop: this.statusBarHeight + 'wx',
                    height: +this.statusBarHeight + 44 + 'wx'
                }, this.custStyleObj);
            } else {
                //非全屏显示，APP已经处理状态栏高度
                result = _extends({
                    backgroundColor: this.bgColor,
                    height: '44wx'
                }, this.custStyleObj);
            }

            return result;
        }
    },
    data: function data() {
        return {};
    },

    methods: {
        leftImgClick: function leftImgClick() {
            if (!this.showLeftImg) {
                return;
            }
            this.$emit('leftImgClick');
        },
        rightImgClick: function rightImgClick() {
            if (!this.showRightImg) {
                return;
            }
            this.$emit('rightImgClick');
        },
        rightTextClick: function rightTextClick() {
            if (!this.showRightText) {
                return;
            }
            this.$emit('rightTextClick');
        },
        headerClick: function headerClick() {
            this.$emit('headerClick');
        }
    }
};

/***/ }),

/***/ 16:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["wrapper"],
    staticStyle: {
      width: "750px"
    }
  }, [_c('div', {
    staticClass: ["box"],
    style: _vm.headerStyleObj
  }, [_c('div', {
    staticClass: ["header-left-image-wrapper"],
    on: {
      "click": _vm.leftImgClick
    }
  }, [(_vm.showLeftImg) ? _c('image', {
    staticClass: ["header-left-image"],
    attrs: {
      "src": _vm.leftImg
    }
  }) : _vm._e()]), _c('div', {
    on: {
      "click": _vm.headerClick
    }
  }, [_c('text', {
    staticClass: ["header-title"],
    style: {
      color: _vm.titleText,
      fontSize: _vm.fontSize + 'px'
    }
  }, [_vm._v(_vm._s(_vm.title))])]), _c('div', {
    staticClass: ["header-right-image-wrapper"],
    on: {
      "click": _vm.rightImgClick
    }
  }, [_vm._t("rightContent", [(_vm.showRightImg) ? _c('image', {
    staticClass: ["header-right-image"],
    attrs: {
      "src": _vm.rightImg
    }
  }) : _vm._e()])], 2), (_vm.showRightText) ? _c('div', {
    staticClass: ["header-right"],
    on: {
      "click": _vm.rightTextClick
    }
  }, [_c('text', {
    staticClass: ["header-right-text"],
    style: {
      color: _vm.rightColor
    }
  }, [_vm._v(_vm._s(_vm.rightText))])]) : _vm._e(), _vm._t("customerContent")], 2)])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),

/***/ 17:
/***/ (function(module, exports) {

module.exports = {"login":{"en":"Login","zh-Hans":"登录","fr":"Connexion","ja":"ログイン","it":"Accesso","es":"iniciar sesión","pt":"Conectar","de":"Anmeldung","ru":"войти","vi":"Đăng nhập","th":"ล็อกอิน","id":"Masuk","zh-Hant":"登入","zh-TW":"登入","ar":"تسجيل الدخول","hu":"Bejelentkezés","el":"Σύνδεση","nl":"Inloggen","pl":"Logowanie","fi":"Kirjaudu sisään","sv":"Inloggning","km":"ចូល"},"device_is_power_off":{"en":"Device is power off","zh-Hans":"设备已关机","fr":"L'appareil est éteint","ja":"デバイスの電源が切れています。","it":"L'impianto è spento","es":"El dispositivo está apagado","pt":"Dispositivo desligado","de":"Gerät ist ausgeschaltet","ru":"Устройство выключено","vi":"Thiết bị đã bị tắt","th":"อุปกรณ์ปิดอยู่","id":"Perangkat dimatikan","zh-Hant":"設備已關機","zh-TW":"設備已關機","ar":"تسجيل الدخول","hu":"A készülék kikapcsolt állapotban van","el":"Η συσκευή είναι απενεργοποιημένη","nl":"Apparaat is uitgeschakeld","pl":"Urządzenie jest wyłączone","fi":"Laitteen virta on katkaistu","sv":"Enheten är avstängd","km":"ឧបករណ៍ គឺ ជា ថាមពល ចេញ"},"ECO_can_not_be_used_under_current_mode":{"en":"ECO is not available in current mode","zh-Hans":"ECO无法在当前模式下使用","fr":"Eco ne peut pas être utilisé en mode actuel","ja":"現在のモードではECO は使用できません。","it":"Eco non può essere utilizzato nella modalità corrente","es":"Eco no se puede utilizar en el modo actual","pt":"Eco indisponível no modo atual","de":"Eco kann im aktuellen Modus nicht benutzt werden","ru":"ЭКО нельзя использовать в текущем режиме","vi":"Không thể sử dụng ECO ở chế độ hiện tại","th":"ไม่สามารถใช้ ECO ได้ในโหมดปัจจุบัน","id":"ECO tidak bisa digunakan dalam mode ini","zh-Hant":"ECO無法在當前模式下使用","zh-TW":"ECO無法在當前模式下使用","ar":"لا يمكن استخدام وظيفة ايكو تحت الوضع الحالي","hu":"Az ECO nem elérhető az aktuális üzemmódban","el":"Το ECO δεν είναι διαθέσιμο στην τρέχουσα λειτουργία","nl":"ECO is niet beschikbaar in de huidige modus","pl":"Tryb ECO nie jest dostępny w bieżącym trybie","fi":"ECO ei ole käytettävissä nykyisessä tilassa","sv":"ECO är inte tillgängligt i det aktuella läget","km":"ECO មិន មាន ក្នុង របៀប បច្ចុប្បន្ន"},"Turbo_can_not_be_used_under_current_mode":{"en":"Boost is not available in current mode","zh-Hans":"强劲无法在当前模式下使用","fr":"Boost n'est pas pris en charge dans ce mode","ja":"このモードではターボはサポートされていません。","it":"Boost non è supportato in questa modalità.","es":"Boost no es soportado en este modo","pt":"Boost indisponível no modo atual","de":"Boost ist in diesem Modus nicht unterstützt.","ru":"стимулировать нельзя использовать в текущем режиме","vi":"Chế độ Tăng cường không được hỗ trợ","th":"ไม่รองรับเทอร์โบในโหมดนี้","id":"Boost tidak didukung dalam mode ini","zh-Hant":"強勁無法在當前模式下使用","zh-TW":"強勁無法在當前模式下使用","ar":"وظيفة تيربو غير مدعومة في هذا الوضع","hu":"A Boost nem elérhető az aktuális üzemmódban","el":"Η λειτουργία Boost δεν είναι διαθέσιμη στην τρέχουσα λειτουργία","nl":"Boost is niet beschikbaar in de huidige modus","pl":"Funkcja Boost nie jest dostępna w bieżącym trybie","fi":"Boost ei ole käytettävissä nykyisessä tilassa","sv":"Boost är inte tillgängligt i det aktuella läget","km":"Boost មិន អាច ប្រើ បាន ក្នុង របៀប បច្ចុប្បន្ន"},"ElecHeat_can_not_be_used_under_current_mode":{"en":"ElecHeat is not available in current mode","zh-Hans":"电辅热无法在当前模式下使用","fr":"ElecHeat ne peut pas être utilisé sous le mode actuel","ja":"現在のモードでは、ElecHeat は使用できません。","it":"ElecHeat non può esssere usato nella modalità corrente","es":"La calefacción eléctrica no se puede utilizar en el modo actual","pt":"ElecHeat indisponível no modo atual","de":"ElecHeat is not available in current mode","ru":"ЭлекОбогрев нельзя использовать в текущем режиме","vi":"Không thể sử dụng ElecHeat ở chế độ hiện tại","th":"ไม่สามารถใช้ ElecHeat ได้ในโหมดปัจจุบัน","id":"ElecHeat tidak bisa digunakan dalam mode ini","zh-Hant":"電輔熱無法在當前模式下使用","zh-TW":"電輔熱無法在當前模式下使用","ar":"لا يمكن استخدام وظيفة التدفئة الكهربائية تحت الوضع الحالي","hu":"ElecHeat nem elérhető az aktuális üzemmódban","el":"Η λειτουργία ElecHeat δεν είναι διαθέσιμη στην τρέχουσα λειτουργία","nl":"ElecHeat is niet beschikbaar in de huidige modus","pl":"Funkcja ElecHeat nie jest dostępna w bieżącym trybie","fi":"ElecHeat ei ole käytettävissä nykyisessä tilassa.","sv":"ElecHeat är inte tillgängligt i det aktuella läget","km":"ElecHeat មិន មាន ក្នុង របៀប បច្ចុប្បន្ន"},"Dry_can_not_be_used_under_current_mode":{"en":"This function is not available in current mode","zh-Hans":"此功能无法在当前模式下使用","fr":"Cette fonction ne peut pas être utilisée sous le mode actuel","ja":"現在のモードでは、ドライは使用できません。","it":"Questa funzione non può essere utilizzata nella modalità corrente","es":"Esta función no se puede usar en el modo actual","pt":"Função indisponível no modo atual","de":"Diese Funktion kann im aktuellen Modus nicht verwendet werden","ru":"Данная функция нельзя использовать в текущем режиме","vi":"Không thể sử dụng chức năng này trong chế độ hiện tại","th":"ไม่สามารถใช้ฟังก์ชันนี้ได้ในโหมดปัจจุบัน","id":"Fungsi ini tidak bisa digunakan dalam mode ini","zh-Hant":"此功能無法在當前模式下使用","zh-TW":"此功能無法在當前模式下使用","ar":"لا يمكن استخدام هذه الوظيفة تحت الوضع الحالي","hu":"Ez a funkció nem elérhető az aktuális üzemmódban","el":"Αυτή η λειτουργία δεν είναι διαθέσιμη στην τρέχουσα λειτουργία","nl":"Deze functie is niet beschikbaar in de huidige modus","pl":"Ta funkcja nie jest dostępna w bieżącym trybie","fi":"Tämä toiminto ei ole käytettävissä nykyisessä tilassa","sv":"Denna funktion är inte tillgänglig i aktuellt läge","km":"មុខងារ នេះ មិន មាន ក្នុង របៀប បច្ចុប្បន្ន ទេ"},"SetTemperature_can_not_be_used_under_current_mode":{"en":"Temperature can't be changed under Fan mode","zh-Hans":"温度设置无法在当前模式下使用","fr":"La température ne peut pas être modifiée en mode ventilateur","ja":"SetTemperature は、現在のモードでは使用できません。","it":"La temperatura non può essere cambiata in modalità Ventilatore","es":"La temperatura no se puede cambiar en el modo Ventilador","pt":"Temperatura não pode ser alterada no modo Ventilador","de":"Temperatur kann im Lüfter-Modus nicht geändert werden","ru":"Температура нельзя использовать в текущем режиме","vi":"Không thể thay đổi nhiệt độ trong chế độ hiện tại","th":"ไม่สามารถเปลี่ยนอุณหภูมิได้หากอยู่ในโหมดพัดลม","id":"Suhu tidak bisa diganti dalam mode Kipas","zh-Hant":"溫度設定無法在當前模式下使用","zh-TW":"溫度設定無法在當前模式下使用","ar":"لا يمكن تغيير درجة الحرارة تحت وضع المروحة","hu":"A hőmérséklet nem változtatható ventilátor üzemmódban","el":"Η θερμοκρασία δεν μπορεί να αλλάξει στη λειτουργία ανεμιστήρα","nl":"Temperatuur kan niet worden gewijzigd in de ventilatormodus","pl":"Nie można zmienić temperatury w trybie wentylatora","fi":"Lämpötilaa ei voi muuttaa tuuletintilassa.","sv":"Temperaturen kan inte ändras i fläktläget","km":"សីតុណ្ហភាព មិន អាច ផ្លាស់ ប្តូរ ក្រោម របៀប Fan បាន ទេ"},"Fan Speed_can_not_be_used_under_current_mode":{"en":"Fan Speed is not available in current mode","zh-Hans":"风扇设置无法在当前模式下使用","fr":"La vitesse du ventilateur ne peut pas être utilisée en mode actuel","ja":"現在のモードでは、ファンスピードは使用できません。","it":"La velocità della ventola non può essere utilizzata nella modalità corrente","es":"La velocidad del ventilador no se puede usar en el modo actual","pt":"A velocidade do ventilador não pode ser usada no modo atual","de":"Die Lüftergeschwindigkeit kann im aktuellen Modus nicht verwendet werden","ru":"Скорость вентилятора нельзя использовать в текущем режиме","vi":"Không thể sử dụng Tốc độ Quạt trong chế độ hiện tại","th":"ไม่สามารถใช้ความเร็วพัดลมได้ในโหมดปัจจุบัน","id":"Kecepatan Kipas tidak bisa digunakan dalam mode ini","zh-Hant":"風速設置無法在當前模式下使用","zh-TW":"風速設置無法在當前模式下使用","ar":"لا يمكن استخدام سرعة المروحة تحت الوضع الحالي","hu":"A ventilátor sebessége nem elérhető az aktuális üzemmódban","el":"Η ταχύτητα ανεμιστήρα δεν είναι διαθέσιμη στην τρέχουσα λειτουργία","nl":"Ventilatorsnelheid is niet beschikbaar in de huidige modus","pl":"Prędkość wentylatora nie jest dostępna w bieżącym trybie","fi":"Tuulettimen nopeus ei ole käytettävissä nykyisessä tilassa","sv":"Fläkthastighet är inte tillgänglig i aktuellt läge","km":"Fan Speed មិន អាច ប្រើ បាន ក្នុង របៀប បច្ចុប្បន្ន"},"Please_clean_the_filter":{"en":"Please clean the filter","zh-Hans":"请清洗滤网","fr":"Veuillez nettoyer le filtre","ja":"フィルターを清掃してください。","it":"Pulire il filtro","es":"Por favor, limpie el filtro","pt":"Limpe o filtro","de":"Bitte den Filter reinigen","ru":"Очистите фильтр","vi":"Hãy vệ sinh bộ lọc","th":"โปรดทำความสะอาดไส้กรอง","id":"Mohon bersihkan filter","zh-Hant":"請清洗濾網","zh-TW":"請清洗濾網","ar":"يرجى تنظيف الفلتر","hu":"Kérjük, tisztítsa meg a szűrőt","el":"Καθαρίστε το φίλτρο","nl":"Maak het filter schoon","pl":"Wyczyść filtr","fi":"Puhdista suodatin","sv":"Vänligen rengör filtret","km":"សូម សម្អាត តម្រង"},"Please_replace_the_filter":{"en":"Please replace the filter","zh-Hans":"请替换滤网","fr":"Veuillez remplacer le filter","ja":"フィルターを交換してください","it":"Si prega di sostituire il filtro","es":"Por favor, sustituya el filtro","pt":"Favor substituir o filtro","de":"Bitte ersetzen Sie den Filter","ru":"Пожалуйста, замените фильтр","vi":"Vui lòng thay bộ lọc","th":"กรุณาเปลี่ยนตัวกรอง","id":"Sila tukar penapis","zh-Hant":"請替換濾網","zh-TW":"請替換濾網","ar":"يرجى استبدال المرشح","hu":"Kérjük, cserélje ki a szűrőt","el":"Αντικαταστήστε το φίλτρο","nl":"Vervang het filter","pl":"Wymień filtr","fi":"Vaihda suodatin","sv":"Vänligen byt ut filtret","km":"សូម ជំនួស តម្រង"},"Outdoor":{"en":"Outdoor","zh-Hans":"室外","fr":"Extérieur","ja":"屋外","it":"Esterna","es":"Exterior","pt":"Exterior","de":"Außen","ru":"На улице","vi":"Ngoài trời","th":"กลางแจ้ง","id":"Luar Ruangan","zh-Hant":"室外","zh-TW":"室外","ar":"خارجي","hu":"Kültéri","el":"Εξωτερικός χώρος","nl":"Buiten","pl":"Na zewnątrz","fi":"Ulkona","sv":"Utomhus","km":"ខាងក្រៅ"},"Indoor":{"en":"Indoor","zh-Hans":"室内","fr":"Intérieur","ja":"室内","it":"Interno","es":"Interior","pt":"Interior","de":"Innen","ru":"В помещении","vi":"Trong nhà","th":"ในร่ม","id":"Dalam Ruangan","zh-Hant":"室內","zh-TW":"室內","ar":"داخلي","hu":"Beltéri","el":"Εσωτερικός χώρος","nl":"Binnen","pl":"Wewnętrzny","fi":"Sisätila","sv":"Inomhus","km":"Indoor"},"Air Conditioner":{"en":"Air Conditioner","zh-Hans":"空调","fr":"Climatisation","ja":"クーラー","it":"Condizionatore d'aria","es":"Aire acondicionado","pt":"Ar Condicionado","de":"Klimaanlage","ru":"Бытовой кондиционер","vi":"Máy lạnh","th":"เครื่องปรับอากาศ","id":"Pengkondisi Udara","zh-Hant":"空調","zh-TW":"空調","ar":"تكييف الهوا","hu":"Légkondicionáló","el":"Κλιματιστικό","nl":"Airconditioner","pl":"Klimatyzator","fi":"Ilmastointilaite","sv":"Luftkonditionering","km":"ម៉ាស៊ីន ត្រជាក់"},"Fan_Speed":{"en":"Fan Speed","zh-Hans":"风速设置","fr":"Vitesse du ventilateur","ja":"ファンの速度","it":"Vel. Ventola","es":"Veloc. Vent.","pt":"Velocidade","de":"Lüfterdrehzahl","ru":"Скорость вентилятора","vi":"Tốc độ Quạt","th":"ความเร็วพัดลม","id":"Kecepatan Kipas","zh-Hant":"風速設置","zh-TW":"風速設置","ar":"سرعة المروحة","hu":"Ventilátor fordulatszám","el":"Ταχύτητα ανεμιστήρα","nl":"Ventilatorsnelheid","pl":"Prędkość wentylatora","fi":"Puhaltimen nopeus","sv":"Fläkthastighet","km":"ល្បឿន Fan"},"Refresh successed":{"en":"Refresh successed","zh-Hans":"刷新成功","fr":"Actualisation réussie","ja":"リフレッシュに成功","it":"Aggiornamento riuscito","es":"Actualización exitosa","pt":"Atualização bem-sucedida","de":"Aktualisierung erfolgreich","ru":"Обновление успешно выполнено","vi":"Làm sạch thành công","th":"รีเฟรชเรียบร้อยแล้ว","id":"Berhasil Menyegarkan","zh-Hant":"整理成功","zh-TW":"整理成功","ar":"نجح التحديث","hu":"Sikeres frissítés","el":"Επιτυχής ανανέωση","nl":"Vernieuwen gelukt","pl":"Odświeżanie powiodło się","fi":"Päivitys onnistui","sv":"Uppdatering lyckades","km":"ភាពជោគជ័យស្រស់"},"Function":{"en":"More","zh-Hans":"功能","fr":"Fonction","ja":"機能","it":"Funzione","es":"Función","pt":"Função","de":"Funktion","ru":"Функция","vi":"Chức năng","th":"ฟังก์ชัน","id":"Fungsi","zh-Hant":"功能","zh-TW":"功能","ar":"الوظيفة","hu":"Funkció","el":"Περισσότερα","nl":"Meer","pl":"Więcej","fi":"Lisää","sv":"Mer om","km":"ច្រើនទៀត"},"Units":{"en":"Units","zh-Hans":"单位","fr":"Unités","ja":"ユニット","it":"Unità","es":"Unidades","pt":"Unidades","de":"Einheiten","ru":"Единицы","vi":"Đơn vị","th":"หน่วย","id":"Unit","zh-Hant":"單位","zh-TW":"單位","ar":"الوحدات","hu":"Egységek","el":"Μονάδες","nl":"Eenheden","pl":"Jednostki","fi":"Yksiköt","sv":"Enheter","km":"ឯកតា"},"Schedule":{"en":"Schedule","zh-Hans":"周定时","fr":"l'horaire","ja":"スケジュール","it":"Orari","es":"Horarios","pt":"Agenda","de":"Zeitpläne","ru":"График","vi":"Lịch","th":"กำหนดการ","id":"Jadwal","zh-Hant":"周定時","zh-TW":"周定時","ar":"الجدول الزمني","hu":"Ütemezés","el":"Πρόγραμμα","nl":"Plan","pl":"Harmonogram","fi":"Aikataulu","sv":"Schema","km":"កាលវិភាគ"},"Check":{"en":"Check","zh-Hans":"故障检测","fr":"Vérifier","ja":"チェック","it":"Verifica","es":"Verificar","pt":"Autodiagnóstico","de":"Prüfen","ru":"Проверить","vi":"Kiểm tra","th":"ตรวจสอบ","id":"Periksa","zh-Hant":"故障檢測","zh-TW":"故障檢測","ar":"الفحص","hu":"Ellenőrizze","el":"Ελέγξτε το","nl":"Controleer","pl":"Sprawdź","fi":"Tarkista","sv":"Kontrollera","km":"ពិនិត្យ"},"About device":{"en":"About device","zh-Hans":"设备信息","fr":"A propos de l'appareil","ja":"デバイスについて","it":"Informazioni sul dispositivo","es":"Acerca del dispositivo","pt":"Sobre o dispositivo","de":"Über das Gerät","ru":"Об устройстве","vi":"Thông tin thiết bị","th":"เกี่ยวกับอุปกรณ์","id":"Mengenai Perangkat","zh-Hant":"裝置訊息","zh-TW":"裝置訊息","ar":"حول الجهاز","hu":"A készülékről","el":"Σχετικά με τη συσκευή","nl":"Over apparaat","pl":"Informacje o urządzeniu","fi":"Tietoja laitteesta","sv":"Om enheten","km":"អំពីឧបករណ៍"},"Cool":{"en":"Cool","zh-Hans":"制冷","fr":"Cool","ja":"クール","it":"Freddo","es":"Enfriar","pt":"Frio","de":"Kühlen","ru":"Охлаждение","vi":"Làm lạnh","th":"ทำความเย็น","id":"Sejuk","zh-Hant":"製冷","zh-TW":"製冷","ar":"تبريد","hu":"hűtés","el":"ψύξη","nl":"Koel","pl":"Chłodzenie","fi":"Cool","sv":"Kall","km":"ត្រជាក់"},"Dry":{"en":"Dry","zh-Hans":"干燥","fr":"Sec","ja":"ドライ","it":"Asciutto","es":"Seco","pt":"Seco","de":"Entfeuchtung","ru":"Осушение","vi":"Hút ẩm","th":"เป่าแห้ง","id":"Kering","zh-Hant":"乾燥","zh-TW":"乾燥","ar":"تجفيف","hu":"Szárítás","el":"Ξήρανση","nl":"Droog","pl":"Suche","fi":"Kuiva","sv":"Torr","km":"ស្ងោរ"},"Heat":{"en":"Heat","zh-Hans":"加热","fr":"Chaleur","ja":"ヒート","it":"Calore","es":"Calefacción","pt":"Calor","de":"Heizen","ru":"Обогрев","vi":"Sưởi","th":"ทำความร้อน","id":"Panas","zh-Hant":"加熱","zh-TW":"加熱","ar":"تدفئة","hu":"Fűtés","el":"Θέρμανση","nl":"Warmte","pl":"Ciepło","fi":"Heat","sv":"Värme","km":"កំដៅ"},"Fan":{"en":"Fan","zh-Hans":"送风","fr":"Ventilateur","ja":"ファン","it":"Ventola","es":"Ventilador","pt":"Ventilador","de":"Ventilation","ru":"Скорость","vi":"Quạt","th":"พัดลม","id":"Kipas","zh-Hant":"送風","zh-TW":"送風","ar":"المروحة","hu":"Levegőszállítás","el":"Αποστολή","nl":"Ventilator","pl":"Wentylator","fi":"Fan","sv":"Fläkt","km":"Fan"},"Cool, Dry & Heat Mode":{"en":"Cooling & Heating","zh-Hans":"制冷和制热","fr":"Refroidissement et Chauffage","ja":"クール、ドライ、ヒートモード","it":"Raffreddamento e riscaldamento","es":"Refrigeración y Calefacción","pt":"Resfriação e Aquecimento","de":"Kühlen und Heizen","ru":"Режим охлаждения, осушения и обогрева","vi":"Làm mát và Sưởi","th":"ทำความเย็นและทำความร้อน","id":"Pendinginan & Pemanasan","zh-Hant":"製冷和制熱","zh-TW":"製冷和制熱","ar":"التبريد والتدفئة","hu":"Hűtés és fűtés","el":"Ψύξη & Θέρμανση","nl":"Koelen & Verwarmen","pl":"Chłodzenie i ogrzewanie","fi":"Jäähdytys & lämmitys","sv":"Kylning och uppvärmning","km":"ម៉ាស៊ីនត្រជាក់ & កំដៅ"},"Auto,Cool,Dry,Heat,Fan":{"en":"Auto,Cool,Dry,Heat,Fan","zh-Hans":"自动、制冷、干燥、制热、送风","fr":"Auto, Cool, Sec, Chaleur, Ventilateur","ja":"オート、クール、ドライ、ヒート、ファン","it":"Automatico, Raffreddamento, Essiccazione, Riscaldamento, Ventilatore","es":"Auto, Frío, Seco, Calor, Ventilador","pt":"Auto, Frio, Seco, Calor, Ventilador","de":"Auto,Kühlen,Entfeuchtung,Heizen,Ventilation","ru":"Авто,Охлаждение,Осушение,Обогрев,Вентиляция","vi":"Tự động, Làm mát, Sấy khô, Sưởi, Quạt","th":"อัตโนมัติ ทำความเย็น เป่าแห้ง ทำความร้อน พัดลม","id":"Auto, Sejuk, Kering, Panas, Kipas","zh-Hant":"自動、製冷、乾燥、制熱、送風","zh-TW":"自動、製冷、乾燥、制熱、送風","ar":"تلقائي، تبريد، تجفيف، تدفئة، مروحة","hu":"Auto,Hűtés,Száraz,Hő,Ventilátor","el":"Αυτόματη, ψύξη, ξήρανση, θέρμανση, παροχή αέρα","nl":"Auto,Koel,Droog,Warmte,Ventilator","pl":"Auto, chłodzenie, osuszanie, ogrzewanie, wentylator","fi":"Auto,Jäähdytys,Kuiva,Lämpö,Tuuletin","sv":"Auto,Kyl,Torr,Värme,Fläkt","km":"Auto,Cool,Dry,Heat,Fan"},"Cool & Dry Mode":{"en":"Cooling Only","zh-Hans":"单冷","fr":"Refroidissement Uniquement","ja":"冷却のみ","it":"Solo raffreddamento","es":"Solo Enfriamiento","pt":"Apenas Resfriamento","de":"Nur kühlen","ru":"Режим охлаждения и осушения","vi":"Chỉ làm mát","th":"ทำความเย็นเท่านั้น","id":"Pendinginan Saja","zh-Hant":"單冷","zh-TW":"單冷","ar":"تبريد فقط","el":"Μόνο ψύξη","nl":"Alleen koelen","pl":"Tylko chłodzenie","fi":"Vain jäähdytys","sv":"Endast kylning","km":"ការ ត្រជាក់ តែ ប៉ុណ្ណោះ"},"Auto,Cool,Dry,Fan":{"en":"Auto,Cool,Dry,Fan","zh-Hans":"自动、制冷、干燥、送风","fr":"Auto, Cool, Sec, Ventilateur","ja":"オート、クール、ドライ、ヒート、ファン","it":"Automatico, Raffreddamento, Essiccazione, Ventilatore","es":"Auto, Frío, Seco, Ventilador","pt":"Auto, Frio, Seco, Ventilador","de":"Auto,Kühlen,Entfeuchtung,,Ventilation","ru":"Авто,Охлаждение,Осушение,Вентиляция","vi":"Tự động, Làm mát, Sấy khô, Quạt","th":"อัตโนมัติ ทำความเย็น เป่าแห้ง พัดลม","id":"Auto, Sejuk, Kering, Kipas","zh-Hant":"自動、製冷、乾燥、送風","zh-TW":"自動、製冷、乾燥、送風","ar":"تلقائي، تبريد، تجفيف، مروحة","hu":"Automatikus,hűtés,száraz,ventilátor","el":"Auto,Cool,Dry,Fan","nl":"Auto,Koel,Droog,Ventilator","pl":"Automatyczny, chłodny, suchy, wentylator","fi":"Auto,Cool,Dry,Fan","sv":"Auto,Kyla,Torr,Fläkt","km":"Auto,Cool,Dry,Fan"},"Cool Mode":{"en":"Cooling Special","zh-Hans":"制冷专用","fr":"Spécial Refroidissement","ja":"クールモード","it":"Speciale raffreddamento","es":"Enfriamiento Especia","pt":"Resfriamento Especial","de":"Sonderkühlung","ru":"Режим охлаждения","vi":"Làm mát Đặc biệt","th":"ทำความเย็นเป็นพิเศษ","id":"Khusus Pendinginan","zh-Hant":"製冷專用","zh-TW":"製冷專用","ar":"تبريد خاص","hu":"Hűtés Speciális","el":"Ειδική ψύξη","nl":"Koelen speciaal","pl":"Specjalne chłodzenie","fi":"Jäähdytys Special","sv":"Särskild kylning","km":"ម៉ាស៊ីនត្រជាក់ពិសេស"},"Cool,Fan":{"en":"Cool,Fan","zh-Hans":"制冷、送风","fr":"Cool,Ventilateur","ja":"クール、ファン","it":"Raffreddamento, Ventilatore","es":"Frío,Ventilador","pt":"Frio, Ventilador","de":"Kühlen,Ventilation","ru":"Охлаждение,Вентиляция","vi":"Làm mát, Quạt","th":"ทำความเย็น พัดลม","id":"Sejuk, Kipas","zh-Hant":"製冷、送風","zh-TW":"製冷、送風","ar":"تبريد، مروحة","hu":"Hűtés,ventilátor","el":"Ψύξη,ανεμιστήρας","nl":"Koelen,Ventilator","pl":"Chłodzenie, Wentylator","fi":"Jäähdytys,tuuletin","sv":"Kyla,Fläkt","km":"ម៉ាស៊ីនត្រជាក់,Fan"},"Heat Mode":{"en":"Heating Only","zh-Hans":"单热","fr":"Chauffage Seulement","ja":"ヒートモード","it":"Solo riscaldamento","es":"Sólo Calefacción","pt":"Apenas Aquecimento","de":"Nur Heizen","ru":"Режим обогрева","vi":"Chỉ sưởi","th":"ทำความร้อนเท่านั้น","id":"Hanya Pemanasan","zh-Hant":"單熱","zh-TW":"單熱","ar":"تدفئة فقط","hu":"Hő üzemmód","el":"Μόνο θέρμανση","nl":"Verwarming","pl":"Tylko ogrzewanie","fi":"Vain lämmitys","sv":"Endast uppvärmning","km":"កំដៅ តែ ប៉ុណ្ណោះ"},"Auto,Heat,Fan":{"en":"Auto,Heat,Fan","zh-Hans":"自动、制热、送风","fr":"Auto, Chaleur, Ventilateur","ja":"オート、ヒート、ファン","it":"Automatico, Riscaldamento, Ventilatore","es":"Auto, Calor, Ventilador","pt":"Auto, Calor, Ventilador","de":"Auto,Heizen,Ventilation","ru":"Авто,Обогрев,Вентиляция","vi":"Tự động, Sưởi, Quạt","th":"อัตโนมัติ ทำความร้อน พัดลม","id":"Auto, Panas, Kipas","zh-Hant":"自動、制熱、送風","zh-TW":"自動、制熱、送風","ar":"تلقائي، تدفئة، مروحة","hu":"Automatikus, fűtés, ventilátor","el":"Auto,Heat,Fan","nl":"Auto,Warmte,Ventilator","pl":"Auto, Ogrzewanie, Wentylator","fi":"Auto,Lämmitys,Tuuletin","sv":"Auto,Värme,Fläkt","km":"Auto,Heat,Fan"},"Medium":{"en":"Medium","zh-Hans":"中等","fr":"Médium","ja":"中","it":"Medio","es":"Medio","pt":"Médio","de":"Mittel","ru":"Средний","vi":"Trung bình","th":"ปานกลาง","id":"Medium","zh-Hant":"中等","zh-TW":"中等","ar":"متوسط","hu":"Közepes","el":"Μεσαίο","nl":"Medium","pl":"Średni","fi":"Medium","sv":"Medium","km":"មធ្យម"},"Fan Speed can not be used under current mode":{"en":"Fan Speed is not available in current mode","zh-Hans":"风速设置无法在当前模式下使用","fr":"La vitesse du ventilateur ne peut pas être utilisée en mode actuel","ja":"現在のモードではファンスピードは使用できません。","it":"La velocità della ventola non può essere utilizzata nella modalità corrente","es":"La velocidad del ventilador no se puede usar en el modo actual","pt":"Velocidade do ventilador indisponível no modo atual","de":"Die Lüftergeschwindigkeit kann im aktuellen Modus nicht verwendet werden","ru":"Скорость вентилятора нельзя использовать в текущем режиме","vi":"Không thể sử dụng Tốc độ Quạt ở chế độ hiện tại","th":"ไม่สามารถใช้ความเร็วพัดลมได้ในโหมดปัจจุบัน","id":"Kecepatan Kipas tidak bisa digunakan dalam mode ini","zh-Hant":"風速設置無法在當前模式下使用","zh-TW":"風速設置無法在當前模式下使用","ar":"لا يمكن استخدام سرعة المروحة تحت الوضع الحالي","hu":"A ventilátor sebesség nem használható a jelenlegi üzemmódban","el":"Η ταχύτητα ανεμιστήρα δεν είναι διαθέσιμη στην τρέχουσα λειτουργία","nl":"Ventilatorsnelheid is niet beschikbaar in de huidige modus","pl":"Prędkość wentylatora nie jest dostępna w bieżącym trybie","fi":"Tuulettimen nopeus ei ole käytettävissä nykyisessä tilassa","sv":"Fläkthastighet är inte tillgänglig i aktuellt läge","km":"Fan Speed មិន អាច ប្រើ បាន ក្នុង របៀប បច្ចុប្បន្ន"},"Device is power off":{"en":"The device cannot be operated when it is turned off.","zh-Hans":"设备已关机","fr":"L'appareil est éteint","ja":"デバイスの電源が切れています。","it":"L'impianto è spento","es":"El dispositivo está apagado","pt":"Dispositivo desligado","de":"Gerät ist ausgeschaltet","ru":"Устройство выключено","vi":"Thiết bị bị tắt nguồn","th":"อุปกรณ์ปิดอยู่","id":"Perangkat dimatikan","zh-Hant":"裝置已關機","zh-TW":"裝置已關機","ar":"الجهاز متوقف عن التشغيل","hu":"A készülék ki van kapcsolva","el":"Η συσκευή δεν μπορεί να λειτουργήσει όταν είναι απενεργοποιημένη.","nl":"Het apparaat kan niet worden bediend als het is uitgeschakeld.","pl":"Urządzenie nie może być obsługiwane, gdy jest wyłączone.","fi":"Laitetta ei voi käyttää, kun se on kytketty pois päältä.","sv":"Enheten kan inte användas när den är avstängd.","km":"ឧបករណ៍ មិន អាច ដំណើរ ការ បាន ទេ នៅ ពេល ដែល វា ត្រូវ បាន បិទ & # 160; ។"},"Turbo can not be used under current mode":{"en":"Boost is not available in current mode","zh-Hans":"强劲无法在当前模式下使用","fr":"Boost n'est pas pris en charge dans ce mode","ja":"ターボは現在のモードでは使用できません。","it":"Boost non è supportato in questa modalità.","es":"Boost no es soportado en este modo","pt":"Boost indisponível no modo atual","de":"Boost ist in diesem Modus nicht unterstützt.","ru":"стимулировать нельзя использовать в текущем режиме","vi":"Chế độ tăng cường không được hỗ trợ","th":"ไม่รองรับเทอร์โบในโหมดนี้","id":"Boost tidak didukung dalam mode ini","zh-Hant":"強勁無法在當前模式下使用","zh-TW":"強勁無法在當前模式下使用","ar":"وظيفة تيربو غير مدعومة في هذا الوضع","hu":"Turbo nem használható az aktuális üzemmódban","el":"Η λειτουργία Boost δεν είναι διαθέσιμη στην τρέχουσα λειτουργία","nl":"Boost is niet beschikbaar in de huidige modus","pl":"Funkcja Boost nie jest dostępna w bieżącym trybie","fi":"Boost ei ole käytettävissä nykyisessä tilassa","sv":"Boost är inte tillgängligt i aktuellt läge","km":"Boost មិន អាច ប្រើ បាន ក្នុង របៀប បច្ចុប្បន្ន"},"ECO can not be used under current mode":{"en":"ECO is not available in current mode","zh-Hans":"ECO无法在当前模式下使用","fr":"Eco ne peut pas être utilisé en mode actuel","ja":"現在のモードではECOは使用できません。","it":"Eco non può essere utilizzato nella modalità corrente","es":"Eco no se puede utilizar en el modo actual","pt":"Eco indisponível no modo atual","de":"Eco kann im aktuellen Modus nicht benutzt werden","ru":"ЭКО нельзя использовать в текущем режиме","vi":"Không thể sử dụng ECO ở chế độ hiện tại","th":"ไม่สามารถใช้ ECO ได้ในโหมดปัจจุบัน","id":"ECO tidak bisa digunakan dalam mode ini","zh-Hant":"ECO無法在當前模式下使用","zh-TW":"ECO無法在當前模式下使用","ar":"لا يمكن استخدام وظيفة ايكو تحت الوضع الحالي","hu":"ECO nem használható az aktuális üzemmódban","el":"Το ECO δεν είναι διαθέσιμο στην τρέχουσα λειτουργία","nl":"ECO is niet beschikbaar in de huidige modus","pl":"Funkcja ECO nie jest dostępna w bieżącym trybie","fi":"ECO ei ole käytettävissä nykyisessä tilassa","sv":"ECO är inte tillgängligt i aktuellt läge","km":"ECO មិន មាន ក្នុង របៀប បច្ចុប្បន្ន"},"Dry can not be used under current mode":{"en":"This function is not available in current mode","zh-Hans":"干燥无法在当前模式下使用","fr":"Cette fonction ne peut pas être utilisée sous le mode actuel","ja":"ドライは現在のモードでは使用できません。","it":"Questa funzione non può essere utilizzata nella modalità corrente","es":"Esta función no se puede usar en el modo actual","pt":"Função indisponível no modo atual","de":"Diese Funktion kann im aktuellen Modus nicht verwendet werden","ru":"Осушение нельзя использовать в текущем режиме","vi":"Không thể sử dụng chức năng Hút ẩm ở chế độ hiện tại","th":"ไม่สามารถใช้ฟังก์ชันนี้ได้ในโหมดปัจจุบัน","id":"Fungsi ini tidak bisa digunakan dalam mode ini","zh-Hant":"乾燥無法在當前模式下使用","zh-TW":"乾燥無法在當前模式下使用","ar":"لا يمكن استخدام هذه الوظيفة تحت الوضع الحالي","hu":"Száraz nem használható a jelenlegi üzemmódban","el":"Αυτή η λειτουργία δεν είναι διαθέσιμη στην τρέχουσα λειτουργία","nl":"Deze functie is niet beschikbaar in de huidige modus","pl":"Ta funkcja nie jest dostępna w bieżącym trybie","fi":"Tämä toiminto ei ole käytettävissä nykyisessä tilassa","sv":"Denna funktion är inte tillgänglig i aktuellt läge","km":"មុខងារ នេះ មិន មាន ក្នុង របៀប បច្ចុប្បន្ន ទេ"},"ElecHeat can not be used under current mode":{"en":"ElecHeat is not available in current mode","zh-Hans":"电辅热无法在当前模式下使用","fr":"ElecHeat ne peut pas être utilisé sous le mode actuel","ja":"現在のモードではElecHeat は使用できません。","it":"ElecHeat non può essere usato nella modalità corrente","es":"La calefacción eléctrica no se puede utilizar en el modo actual","pt":"ElecHeat indisponível no modo atual","de":"Gerät ist ausgeschaltet","ru":"ЭлекОбогрев нельзя использовать в текущем режиме","vi":"Không thể sử dụng ElecHeat ở chế độ hiện tại","th":"ไม่สามารถใช้ ElecHeat ได้ในโหมดปัจจุบัน","id":"ElecHeat tidak bisa digunakan dalam mode ini","zh-Hant":"電輔熱無法在當前模式下使用","zh-TW":"電輔熱無法在當前模式下使用","ar":"لا يمكن استخدام وظيفة التدفئة الكهربائية تحت الوضع الحالي","hu":"ElecHeat nem használható az aktuális üzemmódban","el":"Η λειτουργία ElecHeat δεν είναι διαθέσιμη στην τρέχουσα λειτουργία.","nl":"ElecHeat is niet beschikbaar in de huidige modus","pl":"Funkcja ElecHeat nie jest dostępna w bieżącym trybie","fi":"ElecHeat ei ole käytettävissä nykyisessä tilassa.","sv":"ElecHeat är inte tillgänglig i aktuellt läge","km":"ElecHeat មិន មាន ក្នុង របៀប បច្ចុប្បន្ន"},"Temperature can't be changed under Fan mode":{"en":"Temperature can't be changed under Fan mode","zh-Hans":"温度设置无法在当前模式下使用","fr":"La température ne peut pas être modifiée en mode ventilateur","ja":"SetTemperature は現在のモードでは使用できません。","it":"La temperatura non può essere cambiata in modalità Ventilatore","es":"La temperatura no se puede cambiar en el modo Ventilador","pt":"Temperatura não pode ser alterada no modo Ventilador","de":"Temperatur kann im Ventilation-Modus nicht geändert werden","ru":"Нельзя изменить температуру в режиме вентилятора","vi":"Không thể thay đổi nhiệt độ ở chế độ Quạt","th":"ไม่สามารถเปลี่ยนอุณหภูมิได้หากอยู่ในโหมดพัดลม","id":"Suhu tidak bisa diganti dalam mode Kipas","zh-Hant":"溫度設定無法在當前模式下使用","zh-TW":"溫度設定無法在當前模式下使用","ar":"لا يمكن تغيير درجة الحرارة تحت وضع المروحة","hu":"A hőmérséklet nem változtatható ventilátor üzemmódban.","el":"Η θερμοκρασία δεν μπορεί να αλλάξει στη λειτουργία ανεμιστήρα","nl":"Temperatuur kan niet worden gewijzigd in de ventilatormodus","pl":"Nie można zmienić temperatury w trybie wentylatora","fi":"Lämpötilaa ei voi muuttaa tuuletustilassa","sv":"Temperaturen kan inte ändras i fläktläget","km":"សីតុណ្ហភាព មិន អាច ផ្លាស់ ប្តូរ ក្រោម របៀប Fan បាន ទេ"},"device is power off":{"en":"The device cannot be operated when it is turned off.","zh-Hans":"设备已关机","fr":"L'appareil est éteint","ja":"デバイスの電源がきれています。","it":"L'impianto è spento","es":"El dispositivo está apagado","pt":"Dispositivo desligado","de":"Gerät ist ausgeschaltet","ru":"устройство выключено","vi":"Thiết bị bị tắt nguồn","th":"อุปกรณ์ปิดอยู่","id":"Perangkat dimatikan","zh-Hant":"裝置已關機","zh-TW":"裝置已關機","ar":"الجهاز متوقف عن التشغيل","hu":"a készülék ki van kapcsolva","el":"Η συσκευή δεν μπορεί να λειτουργήσει όταν είναι απενεργοποιημένη.","nl":"Het apparaat kan niet worden bediend wanneer het is uitgeschakeld.","pl":"Urządzenia nie można obsługiwać, gdy jest wyłączone.","fi":"Laitetta ei voi käyttää, kun se on sammutettu.","sv":"Enheten kan inte användas när den är avstängd.","km":"ឧបករណ៍ មិន អាច ដំណើរ ការ បាន ទេ នៅ ពេល ដែល វា ត្រូវ បាន បិទ & # 160; ។"},"8°Heat is not supported at this mode":{"en":"8°Heat is not available in current mode","zh-Hans":"该模式下，不支持8°加热","fr":"8 °C Heat n'est pas pris en charge dans ce mode","ja":"8°このモードではHeat に対応していません。","it":"8 ° C Il calore non è supportato in questa modalità","es":"Temperatura de 8 °C no es soportado en este modo","pt":"8 °C Calor não é suportado neste modo","de":"8 ° C Wärme wird in diesem Modus nicht unterstützt","ru":"8°Обогрев не поддерживается в этом режиме","vi":"8°Heat không được hỗ trợ ở chế độ này","th":"ไม่รองรับการทำความร้อนที่ 8° ในโหมดนี้","id":"Kipas \"8\" tidak didukung dalam mode ini","zh-Hant":"該模式下，不支持8°加熱","zh-TW":"該模式下，不支持8°加熱","ar":"وظيفة 8°تدفئة غير مدعومة في هذا الوضع","hu":"8°Heat nem támogatott ebben az üzemmódban","el":"8°Heat δεν είναι διαθέσιμη στην τρέχουσα λειτουργία","nl":"8°Warmte is niet beschikbaar in de huidige modus","pl":"8°Heat nie jest dostępne w bieżącym trybie","fi":"8°Heat ei ole käytettävissä nykyisessä tilassa","sv":"8°Heat är inte tillgängligt i det aktuella läget","km":"8°កំដៅមិនអាចប្រើបានក្នុងរបៀបបច្ចុប្បន្ន"},"Breezeless can not be used under current mode":{"en":"Breezeless is not available in current mode","zh-Hans":"无风设置无法在当前模式下使用","fr":"Breezeless ne peut pas être utilisé en mode actuel","ja":"現在のモードでは、Breezeless は使用できません。","it":"Breezeless non può essere utilizzato nella modalità corrente","es":"Breezeless no se puede utilizar en el modo actual","pt":"Breezeless indisponível no modo atual","de":"Breezeless kann im aktuellen Modus nicht verwendet werden","ru":"Breezeless нельзя использовать в текущем режиме","vi":"Không thể sử dụng Breezeless ở chế độ hiện tại","th":"ไม่สามารถใช้โหมดไม่มีลมอ่อนได้ในโหมดปัจจุบัน","id":"Breezeless (Tanpa Angin) tidak bisa digunakan dalam mode ini","zh-Hant":"無風設定無法在當前模式下使用","zh-TW":"無風設定無法在當前模式下使用","ar":"لا يمكن استخدام وظيفة بدون نسيم  تحت الوضع الحالي","hu":"Szellőmentes nem használható az aktuális üzemmódban","el":"Η λειτουργία Breezeless δεν είναι διαθέσιμη στην τρέχουσα λειτουργία","nl":"Breezeless is niet beschikbaar in de huidige modus","pl":"Tryb Breezeless nie jest dostępny w bieżącym trybie","fi":"Breezeless ei ole käytettävissä nykyisessä tilassa","sv":"Breezeless är inte tillgängligt i aktuellt läge","km":"Breezeless មិន អាច ប្រើ បាន ក្នុង របៀប បច្ចុប្បន្ន"},"CoolFlash can not be used under current mode":{"en":"CoolFlash is not available in current mode","zh-Hans":"无风设置无法在当前模式下使用","fr":"CoolFlash ne peut pas être utilisé en mode actuel","ja":"現在のモードでは、CoolFlash は使用できません。","it":"CoolFlash non può essere utilizzato nella modalità corrente","es":"CoolFlash no se puede utilizar en el modo actual","pt":"CoolFlash indisponível no modo atual","de":"CoolFlash kann im aktuellen Modus nicht verwendet werden","ru":"CoolFlash нельзя использовать в текущем режиме","vi":"Không thể sử dụng CoolFlash ở chế độ hiện tại","th":"ไม่สามารถใช้การไม่มีลมอ่อนได้ในโหมดปัจจุบัน","id":"CoolFlash (Tanpa Angin) tidak bisa digunakan dalam mode ini","zh-Hant":"無風設定無法在當前模式下使用","zh-TW":"無風設定無法在當前模式下使用","ar":"لا يمكن استخدام وظيفة بدون نسيم  تحت الوضع الحالي","hu":"A CoolFlash nem használható a jelenlegi üzemmódban.","el":"Το CoolFlash δεν είναι διαθέσιμο στην τρέχουσα λειτουργία","nl":"CoolFlash is niet beschikbaar in de huidige modus","pl":"Funkcja CoolFlash nie jest dostępna w bieżącym trybie","fi":"CoolFlash ei ole käytettävissä nykyisessä tilassa","sv":"CoolFlash är inte tillgängligt i aktuellt läge","km":"CoolFlash មិន អាច ប្រើ បាន ក្នុង របៀប បច្ចុប្បន្ន"},"HeatFlash can not be used under current mode":{"en":"HeatFlash is not available in current mode","zh-Hans":"无风设置无法在当前模式下使用","fr":"HeatFlash ne peut pas être utilisé en mode actuel","ja":"現在のモードでは、HeatFlash は使用できません。","it":"HeatFlash non può essere utilizzato nella modalità corrente","es":"HeatFlash no se puede utilizar en el modo actual","pt":"HeatFlash indisponível no modo atual","de":"HeatFlash kann im aktuellen Modus nicht verwendet werden","ru":"HeatFlash нельзя использовать в текущем режиме","vi":"Không thể sử dụng HeatFlash ở chế độ hiện tại","th":"ไม่สามารถใช้การไม่มีลมอ่อนได้ในโหมดปัจจุบัน","id":"HeatFlash (Tanpa Angin) tidak bisa digunakan dalam mode ini","zh-Hant":"無風設定無法在當前模式下使用","zh-TW":"無風設定無法在當前模式下使用","ar":"لا يمكن استخدام وظيفة بدون نسيم  تحت الوضع الحالي","hu":"A HeatFlash nem használható a jelenlegi üzemmódban.","el":"Το HeatFlash δεν είναι διαθέσιμο στην τρέχουσα λειτουργία","nl":"HeatFlash is niet beschikbaar in de huidige modus","pl":"HeatFlash nie jest dostępny w bieżącym trybie","fi":"HeatFlash ei ole käytettävissä nykyisessä tilassa","sv":"HeatFlash är inte tillgängligt i aktuellt läge","km":"HeatFlash មិន អាច ប្រើ បាន ក្នុង របៀប បច្ចុប្បន្ន"},"Wind ON me can not be used under current mode":{"en":"Wind ON me is not available in current mode","zh-Hans":"风吹人无法在当前模式下使用","fr":"Wind ON me ne peut pas être utilisé en mode actuel","ja":"現在のモードでは、「風ON」は使用できません。","it":"Wind ON me non può essere utilizzato in modalità corrente","es":"Wind ON me no se puede utilizar en el modo actual","pt":"Wind ON indisponível no modo atual","de":"Wind ON me kann im aktuellen Modus nicht verwendet werden","ru":"Прямой обдув нельзя использовать в текущем режиме","vi":"Không thể sử dụng Wind ON me ở chế độ hiện tại","th":"ไม่สามารถเปิดลมมาทางฉันได้ในโหมดปัจจุบัน","id":"Angin ON tidak bisa digunakan dalam mode ini","zh-Hant":"風吹人無法在當前模式下使用","zh-TW":"風吹人無法在當前模式下使用","ar":"لا يمكن استخدام وظيفة تشغيل نفخ الهواء تحت الوضع الحالي","hu":"A Wind ON me nem használható a jelenlegi üzemmódban.","el":"Το Wind ON me δεν είναι διαθέσιμο στην τρέχουσα λειτουργία","nl":"Wind AAN is niet beschikbaar in de huidige modus","pl":"Funkcja Wind ON me nie jest dostępna w bieżącym trybie","fi":"Wind ON me ei ole käytettävissä nykyisessä tilassa","sv":"Wind ON me är inte tillgängligt i det aktuella läget","km":"ខ្យល់ ON ខ្ញុំ មិន អាច ប្រើ បាន ក្នុង របៀប បច្ចុប្បន្ន"},"Wind OFF me can not be used under current mode":{"en":"Wind OFF me is not available in current mode","zh-Hans":"风避人无法在当前模式下使用","fr":"Wind OFF me ne peut pas être utilisé en mode actuel","ja":"現在のモードでは、「風OFF」は使用できません。","it":"Wind OFF me non può essere utilizzato in modalità corrente","es":"Wind OFF me no se puede utilizar en el modo actual","pt":"Wind OFF indisponível no modo atual","de":"Wind OFF me kann im aktuellen Modus nicht verwendet werden","ru":"Предотвращение прямого обдува нельзя использовать в текущем режиме","vi":"Không thể sử dụng Wind OFF me ở chế độ hiện tại","th":"ไม่สามารถปิดลมมาทางฉันได้ในโหมดปัจจุบัน","id":"Angin OFF tidak bisa digunakan dalam mode ini","zh-Hant":"風避人無法在當前模式下使用","zh-TW":"風避人無法在當前模式下使用","ar":"لا يمكن استخدام وظيفة إيقاف تشغيل نفخ الهواء تحت الوضع الحالي","hu":"A Wind OFF me nem használható a jelenlegi üzemmódban.","el":"Το Wind OFF me δεν είναι διαθέσιμο στην τρέχουσα λειτουργία","nl":"Wind UIT is niet beschikbaar in de huidige modus","pl":"Opcja Wind OFF me nie jest dostępna w bieżącym trybie","fi":"Wind OFF me ei ole käytettävissä nykyisessä tilassa","sv":"Wind OFF me är inte tillgängligt i det aktuella läget","km":"Wind OFF ខ្ញុំ មិន អាច ប្រើ បាន ក្នុង របៀប បច្ចុប្បន្ន"},"Breeze Away can not be used under current mode":{"en":"Breeze Away is not available in current mode","zh-Hans":"风避人无法在当前模式下使用","fr":"Breeze Away ne peut pas être utilisé en mode actuel","ja":"現在のモードでは、「ブリーズアウェイ」は使用できません。","it":"Breeze Away non può essere utilizzato nella modalità corrente","es":"Breeze Away no se puede utilizar en el modo actual","pt":"Breeze Away indisponível no modo atual","de":"Breeze Away kann im aktuellen Modus nicht verwendet werden","ru":"Breeze Away нельзя использовать в текущем режиме","vi":"Không thể sử dụng Breeze Away me ở chế độ hiện tại","th":"ไม่สามารถใช้ไม่ต้องการลมอ่อนได้ในโหมดปัจจุบัน","id":"Angin Semilir tidak bisa digunakan dalam mode ini","zh-Hant":"風避人無法在當前模式下使用","zh-TW":"風避人無法在當前模式下使用","ar":"لا يمكن استخدام وظيفة نسيم بعيد تحت الوضع الحالي","hu":"A Breeze Away nem használható az aktuális üzemmódban.","el":"Το Breeze Away δεν είναι διαθέσιμο στην τρέχουσα λειτουργία","nl":"Breeze Away is niet beschikbaar in de huidige modus","pl":"Funkcja Breeze Away nie jest dostępna w bieżącym trybie","fi":"Breeze Away ei ole käytettävissä nykyisessä tilassa","sv":"Breeze Away är inte tillgängligt i detta läge","km":"Breeze Away មិន អាច ប្រើ បាន ក្នុង របៀប បច្ចុប្បន្ន"},"Breeze Mild can not be used under current mode":{"en":"Breeze Mild is not available in current mode","zh-Hans":"柔风感无法在当前模式下使用","fr":"Breeze Mild ne peut pas être utilisé en mode actuel","ja":"現在のモードでは、「ブリーズマイルド」は使用できません。","it":"Breeze Mild non può essere utilizzato nella modalità corrente","es":"Breeze Mild no se puede utilizar en el modo actual","pt":"Breeze Mild indisponível no modo atual","de":"Breeze Mild kann im aktuellen Modus nicht verwendet werden","ru":"Breeze Mild нельзя использовать в текущем режиме","vi":"Không thể sử dụng Breeze Mild me ở chế độ hiện tại","th":"ไม่สามารถใช้ลมอ่อนได้ในโหมดปัจจุบัน","id":"Angin Lembut tidak bisa digunakan dalam mode ini","zh-Hant":"柔風感無法在當前模式下使用","zh-TW":"柔風感無法在當前模式下使用","ar":"لا يمكن استخدام وظيفة Breeze Mild تحت الوضع الحالي","hu":"A Breeze Mild nem használható az aktuális üzemmódban.","el":"Το Breeze Mild δεν είναι διαθέσιμο στην τρέχουσα λειτουργία","nl":"Breeze Mild is niet beschikbaar in de huidige modus","pl":"Funkcja Breeze Mild nie jest dostępna w bieżącym trybie","fi":"Breeze Mild ei ole käytettävissä nykyisessä tilassa.","sv":"Breeze Mild är inte tillgängligt i det aktuella läget","km":"Breeze Mild មិន អាច ប្រើ បាន ក្នុង របៀប បច្ចុប្បន្ន"},"Equipment communication failure, Please retry later":{"en":"Control failed, please try again","zh-Hans":"控制失败，请再次尝试","fr":"Le contrôle a échoué, veuillez réessayer","ja":"機器の通信障害、後で再試行してください。","it":"Controllo fallito, riprovare.","es":"Falla de control, intente de nuevo.","pt":"Falha no controlo. Tente novamente.","de":"Steuerung fehlgeschlagen, bitte erneut versuchen.","ru":"Ошибка связи с оборудованием, Повторите попытку позже","vi":"Điều khiển không thành công, vui lòng thử lại","th":"การควบคุมล้มเหลว โปรดลองอีกครั้ง","id":"Kontrol gagal, mohon coba lagi","zh-Hant":"控制失敗，請再次嘗試","zh-TW":"控制失敗，請再次嘗試","ar":"فشل التحكم، يرجى المحاولة مرة أخرى","hu":"A berendezés kommunikációs hibája, kérjük, próbálja meg később újra.","el":"Ο έλεγχος απέτυχε, δοκιμάστε ξανά","nl":"Besturing mislukt, probeer het opnieuw","pl":"Sterowanie nie powiodło się, spróbuj ponownie","fi":"Ohjaus epäonnistui, yritä uudelleen","sv":"Kontroll misslyckades, försök igen","km":"បញ្ជា បរាជ័យ, សូម សាក ល្បង ម្ដង ទៀត"},"week_everyday":{"en":"Everyday","zh-Hans":"每天","fr":"Tous les jours","ja":"日常","it":"Ogni giorno","es":"Todos los días","pt":"Todos os dias","de":"Täglich","ru":"Каждый день","vi":"Mỗi ngày","th":"ทุกวัน","id":"Setiap hari","zh-Hant":"每天","zh-TW":"每天","ar":"كل يوم","hu":"week_everyday","el":"Everyday","nl":"Dagelijks","pl":"Codziennie","fi":"Everyday","sv":"Varje dag","km":"រៀងរាល់ថ្ងៃ"},"Copy Successful":{"en":"Copy Successful","zh-Hans":"复制成功","fr":"Copie réussie","ja":"コピー成功","it":"Copia riuscita","es":"Copia exitosa","pt":"Copiado com Sucesso","de":"Kopieren erfolgreich","ru":"Копировать успешно","vi":"Sao chép thành công","th":"คัดลอกสำเร็จ","id":"Salin berhasil","zh-Hant":"複製成功","zh-TW":"複製成功","ar":"نسخة ناجحة","hu":"Másolás sikeres","el":"Αντιγραφή επιτυχής","nl":"Kopiëren gelukt","pl":"Kopiowanie powiodło się","fi":"Kopiointi onnistui","sv":"Kopiering lyckades","km":"ចម្លងបានជោគជ័យ"},"Network Timeout, Please retry later":{"en":"Control failed, please try again.","zh-Hans":"控制失败，请再次尝试","fr":"Le contrôle a échoué, veuillez réessayer","ja":"ネットワークタイムアウト、後で再試行してください。","it":"Controllo fallito, riprovare.","es":"Falla de control, intente de nuevo.","pt":"Falha no controlo. Tente novamente.","de":"Steuerung fehlgeschlagen, bitte erneut versuchen.","ru":"Ошибка управления, повторите попытку позже","vi":"Hết thời gian kết nối, vui lòng thử lại","th":"การควบคุมล้มเหลว โปรดลองอีกครั้ง","id":"Kontrol gagal, mohon coba lagi","zh-Hant":"控制失敗，請再次嘗試","zh-TW":"控制失敗，請再次嘗試","ar":"فشل التحكم، يرجى المحاولة مرة أخرى.","hu":"Hálózati időkiesés, Kérjük, próbálja meg később","el":"Ο έλεγχος απέτυχε, παρακαλώ δοκιμάστε ξανά.","nl":"Controle mislukt, probeer opnieuw.","pl":"Kontrola nie powiodła się, spróbuj ponownie.","fi":"Ohjaus epäonnistui, yritä uudelleen.","sv":"Kontrollen misslyckades, försök igen.","km":"បញ្ជា បរាជ័យ, សូម សាក ល្បង ម្តង ទៀត."},"Please select device type":{"en":"Choose Device Type","zh-Hans":"选择设备类型","fr":"Choisissez le type de périphérique","ja":"デバイスタイプの選択","it":"Scegli il tipo di impianto","es":"Elija el Tipo de Dispositivo","pt":"Escolha o Tipo de Dispositivo","de":"Wählen Sie den Gerätetyp aus","ru":"Выберите тип устройства","vi":"Chọn Loại Thiết bị","th":"เลือกประเภทของอุปกรณ์","id":"Pilih Jenis Perangkat","zh-Hant":"選擇裝置類別","zh-TW":"選擇裝置類別","ar":"اختر نوع الجهاز","hu":"Kérjük, válassza ki a készülék típusát","el":"Επιλέξτε τύπο συσκευής","nl":"Kies type apparaat","pl":"Wybierz typ urządzenia","fi":"Valitse laitetyyppi","sv":"Välj typ av enhet","km":"ជ្រើស ប្រភេទ ឧបករណ៍"},"Custom Dry":{"en":"Custom Dry","zh-Hans":"自定义干燥模式","fr":"Mode de séchage personnalisé","ja":"カスタム乾燥モード","it":"Asciugatura personalizzata","es":"Modo de secado personalizado","pt":"Modo de secagem personalizado","de":"Benutzerdefinierter Trocknungsmodus","ru":"Пользовательский режим сушки","vi":"Chế độ Hút ẩm tùy chỉnh","th":"โหมดการอบแห้งแบบกำหนดเอง","id":"Mod pengeringan tersuai","zh-Hant":"自定義乾燥模式","zh-TW":"自定義乾燥模式","ar":"وضع التجفيف المخصص","hu":"Testreszabott száraz","el":"Προσαρμοσμένο στεγνό","nl":"Aangepast droog","pl":"Niestandardowe suche","fi":"Mukautettu kuiva","sv":"Anpassad torr","km":"ស្ងោរផ្ទាល់"},"Vertical S":{"en":"Horizontal Swing","zh-Hans":"左右风","fr":"vent gauche et droit","ja":"左右の風","it":"vento sinistro e destro","es":"viento izquierdo y derecho","pt":"Ventilação Vertical","de":"Links- und Rechtswind","ru":"Жалюзи влево-вправо","vi":"Đảo cánh dọc","th":"ลมซ้ายและขวา","id":"angin kiri dan kanan","zh-Hant":"左右風","zh-TW":"左右風","ar":"الريح اليمنى واليسرى","hu":"Függőleges hinta","el":"Κατακόρυφη ταλάντευση","nl":"Verticaal zwenken","pl":"Swing pionowy","fi":"Pystysuora keinu","sv":"Vertikal svängning","km":"ស្វ៊ីង ផ្តេក"},"Horizontal S":{"en":"Vertical Swing","zh-Hans":"上下风","fr":"haut et bas","ja":"上下の風","it":"su e giù","es":"arriba y abajo","pt":"Ventilação Horizontal","de":"auf und ab","ru":"Жалюзи вверх-вниз","vi":"Đảo cánh ngang","th":"ขึ้นและลง","id":"atas dan bawah","zh-Hant":"上下風","zh-TW":"上下風","ar":"اعلى واسفل","hu":"Vízszintes hinta","el":"Οριζόντια ταλάντευση","nl":"Horizontaal zwenken","pl":"Poziomy Swing","fi":"Vaakasuora keinu","sv":"Horisontell svängning","km":"ស្វ៊ីង បញ្ឈរ"},"ECO":{"en":"ECO","zh-Hans":"ECO","fr":"ECO","ja":"ECO","it":"ECO","es":"ECO","pt":"ECO","de":"ECO","ru":"ECO","vi":"ECO","th":"ECO","id":"ECO","zh-Hant":"ECO","zh-TW":"ECO","ar":"ECO","hu":"ECO","el":"ECO","nl":"ECO","pl":"ECO","fi":"ECO","sv":"ECO","km":"ECO"},"Temp Unit":{"en":"Temp Unit","zh-Hans":"温度单位","fr":"Temp Unit","ja":"温度ユニット","it":"Temp Unità","es":"Unidad de temp.","pt":"Unidade de Tempo","de":"Temp Unit","ru":"Единица Темп","vi":"Đơn vị Nhiệt độ","th":"หน่วยของอุณหภูมิ","id":"Unit Suhu","zh-Hant":"溫度單位","zh-TW":"溫度單位","ar":"وحدة درجة الحرارة","hu":"Temp egység","el":"Μονάδα θερμοκρασίας","nl":"Temp-eenheid","pl":"Jednostka temperatury","fi":"Lämpötilayksikkö","sv":"Temp enhet","km":"ឯកតា Temp"},"Elec Heat":{"en":"Elec Heat","zh-Hans":"电热","fr":"chauffage électrique","ja":"電気暖房","it":"Risc Elet","es":"Calefacción eléctrica","pt":"Aquecimento elétrico","de":"Elec Heat","ru":"электрическое отопление","vi":"nhiệt điện","th":"เครื่องทำความร้อนไฟฟ้า","id":"pemanasan elektrik","zh-Hant":"電熱","zh-TW":"電熱","ar":"تدفئة كهربائية","hu":"Elec Heat","el":"Θέρμανση Elec","nl":"Elektrische warmte","pl":"Ogrzewanie elektryczne","fi":"Sähkölämmitys","sv":"Elvärme","km":"កំដៅ Elec"},"FP":{"en":"Freeze Protection","zh-Hans":"防冻","fr":"Antigel","ja":"フロスト保護","it":"Antigelo","es":"Anticongelante","pt":"Anticongelante","de":"Frostschutzmittel","ru":"Дежурный обогрев","vi":"chất chống đông","th":"สารป้องกันการแข็งตัว","id":"antibeku","zh-Hant":"防凍","zh-TW":"防凍","ar":"مضاد للتجمد","hu":"Fagyvédelem","el":"Προστασία από πάγωμα","nl":"Vorstbeveiliging","pl":"Ochrona przed zamarzaniem","fi":"Jäätymissuojaus","sv":"Skydd mot frysning","km":"ការ ពារ កក"},"Wind ON me":{"en":"Wind ON me","zh-Hans":"风吹人","fr":"le vent souffle les gens","ja":"風が吹く","it":"il vento soffia le persone","es":"el viento sopla a la gente","pt":"Vento Siga me","de":"Wind weht Menschen","ru":"ветер дует людей","vi":"Gió thổi lên người","th":"ลมพัด","id":"angin meniup orang","zh-Hant":"風吹人","zh-TW":"風吹人","ar":"تهب الرياح الناس","hu":"Szél nekem","el":"Άνεμος ON me","nl":"Wind AAN","pl":"Wiatr włączony","fi":"Tuuli ON me","sv":"Vind PÅ mig","km":"ខ្យល់ ON ខ្ញុំ"},"Wind OFF me":{"en":"Wind OFF me","zh-Hans":"风避人","fr":"éviter les gens","ja":"人を避ける","it":"evitare le persone","es":"evitar a la gente","pt":"Vento não Siga me","de":"Menschen meiden","ru":"избегать людей","vi":"Tránh gió lên người","th":"เลี่ยงคน","id":"elakkan orang","zh-Hant":"風避人","zh-TW":"風避人","ar":"تجنب الناس","hu":"Szél lefelé","el":"Άνεμος OFF me","nl":"Wind UIT","pl":"Wiatr wyłączony","fi":"Tuuli pois päältä","sv":"Vind AV mig","km":"ខ្យល់ OFF ខ្ញុំ"},"LED":{"en":"LED","zh-Hans":"LED","fr":"LED","ja":"LED","it":"LED","es":"LED","pt":"LED","de":"LED","ru":"LED","vi":"LED","th":"LED","id":"LED","zh-Hant":"LED","zh-TW":"LED","ar":"LED","hu":"LED","el":"LED","nl":"LED","pl":"LED","fi":"LED","sv":"LED","km":"LED"},"Breezeless":{"en":"Breezeless","zh-Hans":"无风","fr":"Sans vent","ja":"風のない","it":"Senza vento","es":"Sin brisa","pt":"Sem Brisa","de":"Atemlos","ru":"Безветренный","vi":"Không có gió","th":"ไม่มีลมอ่อน","id":"Breezeless (Tanpa Angin)","zh-Hant":"無風","zh-TW":"無風","ar":"بدون نسيم","hu":"Szellőmentes","el":"Χωρίς αέρα","nl":"Windstil","pl":"Bezwietrznie","fi":"Tuuleton","sv":"Vindstilla","km":"Breezeless"},"Elec":{"en":"Elec","zh-Hans":"Elec","fr":"Elec","ja":"Elec","it":"Elec","es":"Elec","pt":"Elec","de":"Elec","ru":"Элек","vi":"Elec","th":"Elec","id":"Elec","zh-Hant":"Elec","zh-TW":"Elec","ar":"Elec","hu":"Elec","el":"Elec","nl":"Elec","pl":"Elektryczny","fi":"Elec","sv":"Elektrisk","km":"អេឡិច"},"Active Clean":{"en":"Active Clean","zh-Hans":"自清洁","fr":"autonettoyant","ja":"セルフクリーニング","it":"autopulente","es":"autolimpiante","pt":"Autolimpante","de":"selbstreinigend","ru":"Самоочистка","vi":"tự làm sạch","th":"ทำความสะอาดตัวเอง","id":"pembersihan diri","zh-Hant":"自清潔","zh-TW":"自清潔","ar":"التنظيف الذاتي","hu":"Aktív Clean","el":"Ενεργό Καθαρό","nl":"Actief Schoon","pl":"Aktywne czyszczenie","fi":"Aktiivinen Clean","sv":"Aktiv Ren","km":"ស្រីស្អាតសកម្ម"},"Breeze Away":{"en":"Breeze Away","zh-Hans":"防直吹","fr":"Empêcher le soufflage direct","ja":"直接吹き付けを防ぐ","it":"Prevenire il soffiaggio diretto","es":"Prevenir el soplado directo","pt":"Brisa Distante","de":"Direktes Anblasen verhindern","ru":"Мягкое охлаждение","vi":"Phân phối luồng gió","th":"ป้องกันการเป่าโดยตรง","id":"Elakkan tiupan langsung","zh-Hant":"防直接吹風","zh-TW":"防直接吹風","ar":"منع النفخ المباشر","hu":"Megakadályozza a szélbe fújást","el":"Αντι άμεσο χτύπημα","nl":"Windje Weg","pl":"Breeze Away","fi":"Breeze Away","sv":"Breeze Borta","km":"Breeze Away"},"Breeze Mild":{"en":"Breeze Mild","zh-Hans":"柔风","fr":"vent doux","ja":"やわらかい風","it":"vento morbido","es":"viento suave","pt":"Vento suave","de":"weicher wind","ru":"мягкий ветер","vi":"Gió nhẹ","th":"ลมอ่อนๆ","id":"angin lembut","zh-Hant":"柔風","zh-TW":"柔風","ar":"الرياح لينة","hu":"enyhe szél","el":"Μαλακός αέρας","nl":"Milde bries","pl":"Breeze Mild","fi":"Breeze Mild","sv":"Breeze Mild","km":"Breeze Mild"},"AvoidMe":{"en":"Avoid Me","zh-Hans":"上下防直吹","fr":"Avoid Me","ja":"私を避けて","it":"Evitami","es":"Recuérdame","pt":"Evitar me","de":"Vermeide mich","ru":"Избегайте меня","vi":"Tránh xa tôi ra","th":"หลีกเลี่ยงฉัน","id":"Menghindari Aku","zh-Hant":"上下防直吹","zh-TW":"上下防直吹","ar":"أعلى وأسفل تهب مباشرة","hu":"felső és alsó védelem","el":"Αντι-άμεσο φύσημα προς τα πάνω και προς τα κάτω","nl":"Mij vermijden","pl":"Unikaj mnie","fi":"Vältä minua","sv":"Undvik mig","km":"ជៀសវាងខ្ញុំ"},"Upper":{"en":"Upper","zh-Hans":"更高","fr":"Supérieur","ja":"上段","it":"Superiore","es":"Superior","pt":"Superior","de":"Obere","ru":"Верхний","vi":"Phía trên","th":"ด้านบน","id":"Atas","zh-Hant":"更高","zh-TW":"更高","ar":"العلوي","hu":"magasabb","el":"Άνω","nl":"Boven","pl":"Górny","fi":"Upper","sv":"Högre","km":"ខាងលើ"},"Lower":{"en":"Lower","zh-Hans":"更低","fr":"Inférieure","ja":"下","it":"Inferiore","es":"Inferior","pt":"Inferior","de":"Untere","ru":"Нижний","vi":"Thấp hơn","th":"ต่ำกว่า","id":"Lebih rendah","zh-Hant":"更低","zh-TW":"更低","ar":"أدنى","hu":"Alacsonyabb","el":"Κάτω","nl":"Lager","pl":"Niższy","fi":"Alempi","sv":"Lägre","km":"ទាបជាង"},"Upper and lower ambient wind":{"en":"Upper and lower ambient wind","zh-Hans":"上下环境风","fr":"Vent ambiant supérieur et inférieur","ja":"上下の環境風","it":"Vento ambientale superiore e inferiore","es":"Viento ambiente superior e inferior","pt":"Vento ambiente superior e inferior","de":"Oberer und unterer Umgebungswind","ru":"Верхний и нижний окружающий ветер","vi":"Gió xung quanh trên và dưới","th":"ลมบนและล่าง","id":"Angin sekitar atas dan bawah","zh-Hant":"上下環境風","zh-TW":"上下環境風","ar":"لرياح المحيطة العلوية والسفلية","hu":"Felső és alsó Környezeti szél","el":"Ανώτερος και κατώτερος άνεμος περιβάλλοντος","nl":"Bovenste en onderste omgevingswind","pl":"Górny i dolny wiatr otoczenia","fi":"Ylempi ja alempi tuuli","sv":"Övre och undre omgivande vind","km":"ខ្យល់ អាប់អុប ខាង លើ និង ខាង ក្រោម"},"Eco Sensoric":{"en":"ECO Smart Eye","zh-Hans":"智慧眼","fr":"ECO Intelligent Eye","ja":"エコ・センソリック","it":"ECO Intelligent Eye","es":"ECO Intelligent Eye","pt":"ECO Intelligent Eye","de":"ECO Intelligent Eye","ru":"Эко Сенсорик","vi":"Eco Sensoric","th":"ระบบเซ็นเซอร์แบบ Eco","id":"ECO Intelligent Eye","zh-Hant":"智慧眼","zh-TW":"智慧眼","ar":"ايكو سينسوريك","hu":"ECO Smart Eye","el":"ECO Smart Eye","nl":"ECO Smart Eye","pl":"ECO Smart Eye","fi":"ECO Smart Eye","sv":"ECO Smart Eye","km":"ECO Smart ភ្នែក"},"update success":{"en":"update success","zh-Hans":"更新成功","fr":"succès de la mise à jour","ja":"アップデート成功","it":"aggiornamento avvenuto","es":"actualización exitosa","pt":"Atualização Bem Sucedida","de":"Aktualisierung erfolgreich","ru":"обновление выполнено успешно","vi":"cập nhật thành công","th":"อัปเดตเรียบร้อยแล้ว","id":"pembaruan berhasil","zh-Hant":"更新成功","zh-TW":"更新成功","ar":"نجح التحديث","hu":"frissítés sikere","el":"επιτυχία ενημέρωσης","nl":"update succes","pl":"aktualizacja powiodła się","fi":"päivityksen onnistuminen","sv":"uppdatering lyckas","km":"ភាពជោគជ័យ update"},"update fail":{"en":"update fail","zh-Hans":"更新失败","fr":"échec de la mise à jour","ja":"アップデート失敗","it":"aggiornamento fallito","es":"actualización fallida","pt":"Falha de Atualização","de":"Aktualisierung fehlgeschlagen","ru":"ошибка обновления","vi":"cập nhật không thành công","th":"การอัปเดตล้มเหว","id":"pembaruan gagal","zh-Hant":"更新失敗","zh-TW":"更新失敗","ar":"تعذر التحديث","hu":"frissítés sikertelen","el":"αποτυχία ενημέρωσης","nl":"update mislukt","pl":"aktualizacja nie powiodła się","fi":"päivitys epäonnistui","sv":"uppdatering misslyckad","km":"ការ បរាជ័យ នៃ ការ ធ្វើ បច្ចុប្បន្ន ភាព"},"Detail":{"en":"Detail","zh-Hans":"详情","fr":"Détail","ja":"詳細","it":"Dettagli","es":"Detalle","pt":"Detalhe","de":"Einzelheit","ru":"Подробно","vi":"Chi tiết","th":"รายละเอียด","id":"Rincian","zh-Hant":"詳情","zh-TW":"詳情","ar":"التفاصيل","hu":"Részlet","el":"Λεπτομέρεια","nl":"Detail","pl":"Szczegół","fi":"Yksityiskohta","sv":"Detalj","km":"លំអិត"},"Scanning":{"en":"Scanning","zh-Hans":"扫描","fr":"Scanne","ja":"スキャン","it":"Scansione","es":"Exploración","pt":"Pesquisando","de":"Scannen","ru":"Сканирование","vi":"Đang quét","th":"กำลังสแกน","id":"Pemindaian","zh-Hant":"掃瞄","zh-TW":"掃瞄","ar":"المسح","hu":"Szkennelés","el":"Σάρωση","nl":"Scannen","pl":"Skanowanie","fi":"Skannaus","sv":"Skanning","km":"ការស្កេន"},"Testing":{"en":"Testing","zh-Hans":"测试","fr":"Essai","ja":"テスト","it":"Test","es":"Probando","pt":"Testando","de":"Testen","ru":"Тест","vi":"Đang kiểm tra","th":"กำลังทดสอบ","id":"Pengujian","zh-Hant":"測試","zh-TW":"測試","ar":"الاختبار","hu":"Tesztelés","el":"Δοκιμή","nl":"Testen","pl":"Testowanie","fi":"Testaus","sv":"Testning","km":"ការធ្វើតេស្ត"},"Normal":{"en":"Normal","zh-Hans":"正常","fr":"Ordinaire","ja":"正常","it":"Normale","es":"Normal","pt":"Normal","de":"Normal","ru":"Норма","vi":"Bình thường","th":"ปกติ","id":"Normal","zh-Hant":"正常","zh-TW":"正常","ar":"طبيعي","hu":"Normál","el":"Κανονική","nl":"Normaal","pl":"Normalny","fi":"Normaali","sv":"Normal","km":"ធម្មតា"},"Abnormal":{"en":"Abnormal","zh-Hans":"异常","fr":"Anormal","ja":"異常","it":"Anomalo","es":"Anormal","pt":"Anormal","de":"Anormal","ru":"Ошибка","vi":"Bất thường","th":"ผิดปกติ","id":"Tidak Normal","zh-Hant":"異常","zh-TW":"異常","ar":"غير طبيعي","hu":"Rendellenes","el":"Ανώμαλη","nl":"Abnormaal","pl":"Nienormalny","fi":"Epänormaali","sv":"Onormal","km":"មិនធម្មតា"},"Done":{"en":"Done","zh-Hans":"完成","fr":"Terminé","ja":"完了","it":"Fatto","es":"Hecho","pt":"Concluído","de":"Fertig","ru":"Готово","vi":"Xong","th":"เรียบร้อย","id":"Selesai","zh-Hant":"完成","zh-TW":"完成","ar":"تم","hu":"Kész","el":"Έγινε","nl":"Gedaan","pl":"Gotowe","fi":"Tehty","sv":"Gjort","km":"បាន ធ្វើ រួច"},"Save changes":{"en":"Save changes?","zh-Hans":"保存更改?","fr":"Sauvegarder les modifications?","ja":"変更の保存?","it":"Salvo le modifiche?","es":"Guardar cambios?","pt":"Salvar alterações?","de":"Änderungen speichern?","ru":"Сохранить изменения","vi":"Lưu thay đổi?","th":"บันทึกการเปลี่ยนแปลง?","id":"Simpan perubahan?","zh-Hant":"保存更改?","zh-TW":"保存更改?","ar":"حفظ التغييرات؟","hu":"Változások mentése?","el":"Αποθήκευση αλλαγών;","nl":"Wijzigingen opslaan?","pl":"Zapisać zmiany?","fi":"Tallenna muutokset?","sv":"Spara ändringar?","km":"រក្សាទុកការផ្លាស់ប្តូរ?"},"Ok":{"en":"Ok","zh-Hans":"确定","fr":"D'accord","ja":"OK","it":"Ok","es":"Okay","pt":"Ok","de":"Ok","ru":"Да","vi":"Được","th":"ตกลง","id":"Oke","zh-Hant":"確定","zh-TW":"確定","ar":"موافق","hu":"Ok","el":"Ok","nl":"Ok","pl":"Ok","fi":"Ok","sv":"Ok","km":"យល់ព្រម"},"OK":{"en":"Ok","zh-Hans":"确定","fr":"D'accord","ja":"OK","it":"Ok","es":"Okay","pt":"Ok","de":"Ok","ru":"Да","vi":"Được","th":"ตกลง","id":"Oke","zh-Hant":"確定","zh-TW":"確定","ar":"موافق","hu":"Ok","el":"Ok","nl":"Ok","pl":"Ok","fi":"Ok","sv":"Ok","km":"យល់ព្រម"},"Repeat":{"en":"Repeat","zh-Hans":"重复","fr":"Répéter","ja":"繰り返し","it":"Ripeti","es":"Repetir","pt":"Repetir","de":"Wiederholen","ru":"Повторить","vi":"Lặp lại","th":"ทำซ้ำ","id":"Ulangi","zh-Hant":"重複","zh-TW":"重複","ar":"التكرار","hu":"Ismételje meg a","el":"Επαναλάβετε","nl":"Herhaal","pl":"Powtórz","fi":"Toista","sv":"Upprepa","km":"ដដែលៗ"},"Label":{"en":"Label","zh-Hans":"标签","fr":"Étiquette","ja":"ラベル","it":"Etichette","es":"Etiqueta","pt":"Rótulo","de":"Etikett","ru":"Ярлык","vi":"Nhãn","th":"ฉลาก","id":"Label","zh-Hant":"標識","zh-TW":"標識","ar":"التسمية","hu":"Címke","el":"Ετικέτα","nl":"Label","pl":"Etykieta","fi":"Tarra","sv":"Etikett","km":"ស្លាក"},"Unnamed":{"en":"Unnamed","zh-Hans":"未命名","fr":"Sans nom","ja":"名称未設定","it":"Senza nome","es":"Sin nombre","pt":"Sem nome","de":"Unbenannt","ru":"Без имени","vi":"Chưa được đặt tên","th":"ไม่มีชื่อ","id":"Tidak Bernama","zh-Hant":"未命名","zh-TW":"未命名","ar":"بدون اسم","hu":"Névtelen","el":"Unnamed","nl":"Naamloos","pl":"Bez nazwy","fi":"Nimetön","sv":"Namnlös","km":"មិន បញ្ចេញ ឈ្មោះ"},"Delete":{"en":"Delete","zh-Hans":"删除","fr":"Supprimer","ja":"削除","it":"Cancella","es":"Eliminar","pt":"Apagar","de":"Löschen","ru":"Удалить","vi":"Xóa","th":"ลบ","id":"Hapus","zh-Hant":"移除","zh-TW":"移除","ar":"حذف","hu":"Delete","el":"Διαγραφή","nl":"Verwijderen","pl":"Usuń","fi":"Delete","sv":"Radera","km":"លុប"},"Maximum temperature":{"en":"Maximum temperature","zh-Hans":"最高温度","fr":"Température maximale","ja":"最高温度","it":"Temperatura massima","es":"Temperatura máxima","pt":"Temperatura máxima","de":"Max. Temperatur","ru":"Максимальная температура","vi":"Nhiệt độ tối đa","th":"อุณหภูมิสูงสุด","id":"Suhu Maksimal","zh-Hant":"最高溫度","zh-TW":"最高溫度","ar":"درجة الحارة القصوى","hu":"Maximális hőmérséklet","el":"Μέγιστη θερμοκρασία","nl":"Maximale temperatuur","pl":"Maksymalna temperatura","fi":"Maksimilämpötila","sv":"Högsta temperatur","km":"សីតុណ្ហភាពអតិបរមា"},"Minimum temperature":{"en":"Minimum temperature","zh-Hans":"最低温度","fr":"Température minimum","ja":"最低温度","it":"Temperatura minima","es":"Temperatura mínima","pt":"Temperatura mínima","de":"Min. Temperatur","ru":"Минимальная температура","vi":"Nhiệt độ tối thiểu","th":"อุณหภูมิต่ำสุด","id":"Suhu Minimal","zh-Hant":"最低溫度","zh-TW":"最低溫度","ar":"درجة الحرارة الدنيا","hu":"Minimális hőmérséklet","el":"Ελάχιστη θερμοκρασία","nl":"Minimum temperatuur","pl":"Minimalna temperatura","fi":"Minimilämpötila","sv":"Minsta temperatur","km":"សីតុណ្ហភាពអប្បបរមា"},"Delete schedule":{"en":"Delete schedule","zh-Hans":"删除周定时","fr":"Certain d’effacer","ja":"スケジュールの削除","it":"Cancella piano","es":"Seguro para eliminar","pt":"Deletar progromação","de":"Zeitplan löschen","ru":"Удалить график","vi":"Xóa lịch trình","th":"ลบกำหนดการ","id":"Hapus jadwal","zh-Hant":"移除周定時","zh-TW":"移除周定時","ar":"مسح الجدول الزمني","hu":"Ütemterv törlése","el":"Διαγραφή προγράμματος","nl":"Schema verwijderen","pl":"Usuń harmonogram","fi":"Poista aikataulu","sv":"Radera schema","km":"លុបកាលវិភាគ"},"Please add a schedule":{"en":"Please add a schedule…","zh-Hans":"请添加周定时…","fr":"Veuillez ajouter un horaire…","ja":"スケジュールを追加してください...","it":"Aggiungi un piano...","es":"Añade un horario …","pt":"Adicione uma programação...","de":"Bitte einen Zeitplan hinzufügen","ru":"Добавьте график","vi":"Vui lòng thêm lịch trình","th":"โปรดเพิ่มกำหนดการ","id":"Mohon tambah sebuah jadwal","zh-Hant":"請新增周定時…","zh-TW":"請新增周定時…","ar":"يرجى إضافة جدول زمني...","hu":"Kérjük, adjon hozzá egy ütemtervet...","el":"Παρακαλώ προσθέστε ένα πρόγραμμα...","nl":"Voeg een schema toe...","pl":"Dodaj harmonogram...","fi":"Lisää aikataulu...","sv":"Lägg till ett schema...","km":"សូមបន្ថែមកាលវិភាគ..."},"Every day":{"en":"Every day","zh-Hans":"每天","fr":"Tous les jours","ja":"毎日","it":"Ogni giorno","es":"Todos los días","pt":"Todos os dias","de":"Täglich","ru":"Каждый день","vi":"Mỗi ngày","th":"ทุกวัน","id":"Setiap hari","zh-Hant":"每天","zh-TW":"每天","ar":"كل يوم","hu":"Minden nap","el":"Κάθε μέρα","nl":"Elke dag","pl":"Codziennie","fi":"Joka päivä","sv":"Varje dag","km":"ជា​រៀងរាល់ថ្ងៃ"},"Weekdays":{"en":"Weekdays","zh-Hans":"工作日","fr":"Jour de travail","ja":"平日","it":"Fine settimana","es":"Dia de trabajo","pt":"Dias úteis","de":"Wochentags","ru":"Будние дни","vi":"Các ngày trong tuần","th":"วันธรรมดา","id":"Hari kerja","zh-Hant":"工作日","zh-TW":"工作日","ar":"أيام الأسبوع","hu":"Hétköznapokon","el":"Καθημερινές","nl":"Weekdagen","pl":"Dni powszednie","fi":"Arkipäivät","sv":"Veckodagar","km":"ថ្ងៃសប្តាហ៏"},"Only once":{"en":"Only once","zh-Hans":"仅一次","fr":"Juste une fois","ja":"一度だけ","it":"Solo 1 volta","es":"Sólo una vez","pt":"Apenas uma vez","de":"Nur einmal","ru":"Только один раз","vi":"Chỉ một lần","th":"แค่ครั้งเดียว","id":"Hanya sekali","zh-Hant":"僅一次","zh-TW":"僅一次","ar":"مرة واحدة فقط","hu":"Csak egyszer","el":"Μόνο μία φορά","nl":"Slechts één keer","pl":"Tylko raz","fi":"Vain kerran","sv":"Endast en gång","km":"តែ ម្តង"},"Monday":{"en":"Monday","zh-Hans":"星期一","fr":"Lundi","ja":"月曜日","it":"Lunedì","es":"Lunes","pt":"Segunda","de":"Montag","ru":"Понедельник","vi":"Thứ Hai","th":"วันจันทร์","id":"Senin","zh-Hant":"星期一","zh-TW":"星期一","ar":"الاثنين","hu":"Hétfő","el":"Δευτέρα","nl":"Maandag","pl":"Poniedziałek","fi":"Maanantai","sv":"Måndag","km":"ថ្ងៃចន្ទ"},"Mon.":{"en":"Mon.","zh-Hans":"星期一","fr":"Lun.","ja":"月曜.","it":"Lun.","es":"Lun.","pt":"Seg.","de":"Mon.","ru":"Пн.","vi":"T2","th":"จ.","id":"Sen.","zh-Hant":"星期一","zh-TW":"星期一","ar":"الاثنين","hu":"Hétfőn.","el":"Δευτέρα.","nl":"Maandag","pl":"Poniedziałek","fi":"Ma.","sv":"Mån.","km":"ម៉ន."},"Tuesday":{"en":"Tuesday","zh-Hans":"星期二","fr":"Mardi","ja":"火曜日","it":"Martedì","es":"Martes","pt":"Terça","de":"Dienstag","ru":"Вторник","vi":"Thứ Ba","th":"วันอังคาร","id":"Selasa","zh-Hant":"星期二","zh-TW":"星期二","ar":"الثلاثاء","hu":"Kedd","el":"Τρίτη","nl":"Dinsdag","pl":"Wtorek","fi":"Tiistai","sv":"Tisdag","km":"ថ្ងៃអង្គារ"},"Tue.":{"en":"Tue.","zh-Hans":"星期二","fr":"Mar.","ja":"火曜.","it":"Mar.","es":"Mar.","pt":"Ter.","de":"Die.","ru":"Вт.","vi":"T3","th":"อ.","id":"Sel.","zh-Hant":"星期二","zh-TW":"星期二","ar":"الثلاثاء","hu":"kedd.","el":"Τρίτη","nl":"dins.","pl":"Wt.","fi":"Ti.","sv":"Tis.","km":"ធូ។"},"Wednesday":{"en":"Wednesday","zh-Hans":"星期三","fr":"Mercredi","ja":"水曜日","it":"Mercoledì","es":"Miércoles","pt":"Quarta","de":"Mittwoch","ru":"Среда","vi":"Thứ Tư","th":"วันพุธ","id":"Rabu","zh-Hant":"星期三","zh-TW":"星期三","ar":"الأربعاء","hu":"Szerda","el":"Τετάρτη","nl":"Woensdag","pl":"Środa","fi":"Keskiviikko","sv":"Onsdag","km":"ថ្ងៃពុធ"},"Wed.":{"en":"Wed.","zh-Hans":"星期三","fr":"Merc.","ja":"水曜.","it":"Mer.","es":"Mie.","pt":"Qua.","de":"Mit.","ru":"Ср.","vi":"T4","th":"พ.","id":"Rab.","zh-Hant":"星期三","zh-TW":"星期三","ar":"الأربعاء","hu":"Hétfő","el":"Τετ.","nl":"woensdag","pl":"Środa.","fi":"Ke.","sv":"Ons.","km":"Wed."},"Thursday":{"en":"Thursday","zh-Hans":"星期四","fr":"Jeudi","ja":"木曜日","it":"Giovedì","es":"Jueves","pt":"Quinta","de":"Donnerstag","ru":"Четверг","vi":"Thứ Năm","th":"วันพฤหัสบดี","id":"Kamis","zh-Hant":"星期四","zh-TW":"星期四","ar":"الخميس","hu":"Csütörtök","el":"Πέμπτη","nl":"Donderdag","pl":"Czwartek","fi":"Torstai","sv":"Torsdag","km":"ថ្ងៃព្រស្បតិ៍"},"Thur.":{"en":"Thur.","zh-Hans":"星期四","fr":"Jeu.","ja":"木曜.","it":"Gio.","es":"Jue.","pt":"Qui.","de":"Don.","ru":"Чт.","vi":"T5","th":"พฤ.","id":"Kam.","zh-Hant":"星期四","zh-TW":"星期四","ar":"الخميس","hu":"Csütörtök","el":"Πέμπτη","nl":"Donderdag","pl":"Czwartek","fi":"Torstai","sv":"Tors.","km":"ធើ។"},"Friday":{"en":"Friday","zh-Hans":"星期五","fr":"Vendredi","ja":"金曜日","it":"Venerdì","es":"Viernes","pt":"Sexta","de":"Freitag","ru":"Пятница","vi":"Thứ Sáu","th":"วันศุกร์","id":"Jumat","zh-Hant":"星期五","zh-TW":"星期五","ar":"الجمعة","hu":"Péntek","el":"Παρασκευή","nl":"Vrijdag","pl":"Piątek","fi":"Perjantai","sv":"fredag","km":"ថ្ងៃសុក្រ"},"Fri.":{"en":"Fri.","zh-Hans":"星期五","fr":"Ven.","ja":"金曜","it":"Ven.","es":"Vie.","pt":"Sex.","de":"Fre.","ru":"Пт.","vi":"T6","th":"ศ.","id":"Jum.","zh-Hant":"星期五","zh-TW":"星期五","ar":"الجمعة","hu":"Péntek","el":"Παρ.","nl":"Vr.","pl":"Piątek.","fi":"Perjantai","sv":"Fredag","km":"Fri."},"Saturday":{"en":"Saturday","zh-Hans":"星期六","fr":"Samedi","ja":"土曜日","it":"Sabato","es":"Sábado","pt":"Sábado","de":"Samstag","ru":"Суббота","vi":"Thứ Bảy","th":"วันเสาร์","id":"Sabtu","zh-Hant":"星期六","zh-TW":"星期六","ar":"السبت","hu":"Szombat","el":"Σάββατο","nl":"Zaterdag","pl":"Sobota","fi":"Lauantai","sv":"Lördag","km":"ថ្ងៃសៅរ៍"},"Sat.":{"en":"Sat.","zh-Hans":"星期六","fr":"Sam.","ja":"土曜.","it":"Sab.","es":"Sáb.","pt":"Sáb.","de":"Sam.","ru":"Сб.","vi":"T7","th":"ส.","id":"Sab.","zh-Hant":"星期六","zh-TW":"星期六","ar":"السبت","hu":"Sat.","el":"Σάββατο","nl":"Zat.","pl":"sobota.","fi":"La.","sv":"Lör.","km":"អង្គុយ។"},"Sunday":{"en":"Sunday","zh-Hans":"星期日","fr":"Dimanche","ja":"日曜日","it":"Domenica","es":"Domingo","pt":"Domingo","de":"Sonntag","ru":"Воскресенье","vi":"Chủ Nhật","th":"วันอาทิตย์","id":"Minggu","zh-Hant":"星期日","zh-TW":"星期日","ar":"الأحد","hu":"Vasárnap","el":"Κυριακή","nl":"Zondag","pl":"Niedziela","fi":"Sunnuntai","sv":"Söndag","km":"ថ្ងៃអាទិត្យ"},"Sun.":{"en":"Sun.","zh-Hans":"星期日","fr":"Soleil.","ja":"日曜","it":"Dom.","es":"Dom.","pt":"Dom.","de":"Son.","ru":"Вс.","vi":"CN","th":"อา.","id":"Ahad","zh-Hant":"星期日","zh-TW":"星期日","ar":"الأحد","hu":"Sun.","el":"Κυρ.","nl":"Zon.","pl":"Niedziela.","fi":"Sun.","sv":"Söndag.","km":"ព្រះអាទិត្យ។"},"The label cannot exceed 15 characters!":{"en":"The label cannot exceed 15 characters!","zh-Hans":"标签不得超过15个字符!","fr":"L'étiquette ne peut pas dépasser 15 caractères!","ja":"ラベルの文字数は15文字までです。","it":"L'etichetta non può superare 15 caratteri!","es":"¡La etiqueta no puede superar los 15 caracteres!","pt":"O rótulo não pode exceder 15 caracteres!","de":"Das Bezeichnung darf 15 Zeichen nicht überschreiten!","ru":"Ярлык не может превышать 15 символов!","vi":"Nhãn không thể dài quá 15 ký tự!","th":"ฉลากต้องไม่เกิน 15 อักขระ","id":"Label tidak boleh melebihi 15 karakter!","zh-Hant":"標識不得超過15個字元!","zh-TW":"標識不得超過15個字元!","ar":"لا يمكن ان يتجاوز الاسم 15 حرفاً!","hu":"A címke nem haladhatja meg a 15 karaktert!","el":"Η ετικέτα δεν μπορεί να υπερβαίνει τους 15 χαρακτήρες!","nl":"Het label mag niet langer zijn dan 15 tekens!","pl":"Etykieta nie może zawierać więcej niż 15 znaków!","fi":"Merkintä voi olla enintään 15 merkkiä!","sv":"Etiketten får inte innehålla mer än 15 tecken!","km":"ស្លាក មិនអាច លើស ១៥ តួ បាន ទេ !"},"Current_humidity":{"en":"Room Humidity","zh-Hans":"室内湿度","fr":"Humidité de la pièce","ja":"部屋の湿度","it":"Umidità della stanza","es":"Humedad de la Habitación","pt":"Humidade do Quarto","de":"Zimmerfeuchtigkeit","ru":"Текущая_влажность","vi":"Độ ẩm Phòng","th":"ความชื้นของห้อง","id":"Kelembaban Ruangan","zh-Hant":"室內濕度","zh-TW":"室內濕度","ar":"رطوبة الغرفة","hu":"Szobai páratartalom","el":"Υγρασία δωματίου","nl":"Vochtigheid kamer","pl":"Wilgotność w pomieszczeniu","fi":"Huoneen kosteus","sv":"Luftfuktighet i rummet","km":"សំណើមបន្ទប់"},"Humidity":{"en":"Humidity","zh-Hans":"湿度","fr":"Humidité","ja":"湿度","it":"Umidità","es":"Humedad","pt":"Humidade","de":"Feuchtigkeit","ru":"Влажность","vi":"Độ ẩm","th":"ความชื้น","id":"Kelembaban","zh-Hant":"濕度","zh-TW":"濕度","ar":"الرطوبة","hu":"Páratartalom","el":"Υγρασία","nl":"Vochtigheid","pl":"Wilgotność","fi":"Kosteus","sv":"Luftfuktighet","km":"សំណើម"},"Full water time":{"en":"Water full time","zh-Hans":"水满时间","fr":"Eau à plein temps","ja":"フルタイムの水","it":"Acqua a tempo pieno","es":"Agua a tiempo completo","pt":"Água em tempo integral","de":"Wasser ganztägig","ru":"Время наполнения водой","vi":"Thời gian đầy nước","th":"เวลาที่น้ำจะเต็ม","id":"Air sepanjang hari","zh-Hant":"水滿時間","zh-TW":"水滿時間","ar":"وقت ملئ الماء","hu":"Teljes idejű víz","el":"Πλήρης χρόνος νερού","nl":"Water voltijd","pl":"Woda przez cały czas","fi":"Vesi koko ajan","sv":"Vatten full tid","km":"ទឹក ពេញ ម៉ោង"},"Hour":{"en":"Hours","zh-Hans":"小时","fr":"Heures","ja":"時間","it":"Ore","es":"Horas","pt":"Horas","de":"Stunde","ru":"Час","vi":"Giờ","th":"ชั่วโมง","id":"Jam","zh-Hant":"小時","zh-TW":"小時","ar":"ساعات","hu":"Órák","el":"Ώρες","nl":"Uren","pl":"Godziny","fi":"Tunnit","sv":"Timmar","km":"ម៉ោង"},"Hours":{"en":"Hours","zh-Hans":"小时","fr":"Heures","ja":"時間","it":"Ore","es":"Horas","pt":"Horas","de":"Stunde","ru":"Час","vi":"Giờ","th":"ชั่วโมง","id":"Jam","zh-Hant":"小時","zh-TW":"小時","ar":"ساعات","hu":"Órák","el":"Ώρες","nl":"Uren","pl":"Godziny","fi":"Tunnit","sv":"Timmar","km":"ម៉ោង"},"Tank full":{"en":"Water tank full","zh-Hans":"水箱水满","fr":"Réservoir d'eau plein","ja":"水タンクがいっぱい","it":"Serbatoio dell'acqua pieno","es":"Tanque de agua lleno","pt":"Tanque de água cheio","de":"Wassertank voll","ru":"Полный бак","vi":"Bình đầy nước","th":"ถังเก็บน้ำเต็ม","id":"Tangki air penuh","zh-Hant":"水箱水滿","zh-TW":"水箱水滿","ar":"خزان الماء ممتلئ","hu":"A víztartály megtelt","el":"Δεξαμενή νερού γεμάτη","nl":"Watertank vol","pl":"Zbiornik wody pełny","fi":"Vesisäiliö täynnä","sv":"Vattentanken full","km":"ធុងទឹកពេញ"},"anion":{"en":"anion","zh-Hans":"负离子","fr":"anion","ja":"アニオン","it":"anione","es":"anión","pt":"ânion","de":"Anion","ru":"анион","vi":"anion","th":"ประจุลบ","id":"anion","zh-Hant":"負離子","zh-TW":"負離子","ar":"أنيون","hu":"anion","el":"ανιόντα","nl":"anion","pl":"anion","fi":"anioni","sv":"Anjon","km":"anion"},"Low":{"en":"Low","zh-Hans":"低风","fr":"Faible","ja":"低","it":"Basso","es":"Bajo","pt":"Baixa","de":"Niedrig","ru":"Низкий","vi":"Thấp","th":"ต่ำ","id":"Rendah","zh-Hant":"低風","zh-TW":"低風","ar":"منخفض","hu":"Alacsony","el":"Χαμηλή","nl":"Laag","pl":"Niski","fi":"Matala","sv":"Låg","km":"ទាប"},"Mid":{"en":"Mid","zh-Hans":"中风","fr":"Médium","ja":"中","it":"Medio","es":"Medio","pt":"Média","de":"Mittel","ru":"Средний","vi":"Trung bình","th":"กลาง","id":"Sedang","zh-Hant":"中風","zh-TW":"中風","ar":"متوسط","hu":"Közép","el":"Μέση","nl":"Midden","pl":"Średni","fi":"Keskimmäinen","sv":"Medel","km":"កណ្តាល"},"High":{"en":"High","zh-Hans":"高风","fr":"Haut","ja":"高","it":"Alto","es":"Alto","pt":"Alta","de":"Hoch","ru":"Высокий","vi":"Cao","th":"สูง","id":"Tinggi","zh-Hant":"高風","zh-TW":"高風","ar":"مرتفع","hu":"Magas","el":"Υψηλή","nl":"Hoog","pl":"Wysoki","fi":"Korkea","sv":"Hög","km":"ខ្ពស់"},"Auto":{"en":"Auto","zh-Hans":"自动","fr":"Auto","ja":"オート","it":"Automatico","es":"Auto","pt":"Auto","de":"Auto","ru":"Авто","vi":"Tự động","th":"อัตโนมัติ","id":"Auto","zh-Hant":"自動","zh-TW":"自動","ar":"تلقائي","hu":"Automatikus","el":"Αυτόματο","nl":"Auto","pl":"Automatyczny","fi":"Auto","sv":"Auto","km":"ស្វ័យ ប្រវត្តិ"},"Turbo":{"en":"Boost","zh-Hans":"增压","fr":"Turbo","ja":"ブースト","it":"Turbo","es":"Aumento","pt":"Boost","de":"Turbo","ru":"Tурбо","vi":"Tăng cường","th":"กระตุ้น","id":"Turbo (Dorongan)","zh-Hant":"增壓","zh-TW":"增壓","ar":"تعزيز","hu":"Turbo","el":"Ενίσχυση","nl":"Boost","pl":"Wzmocnienie","fi":"Boost","sv":"Förstärkning","km":"ជំរុញ"},"water_level":{"en":"Water level","zh-Hans":"水位","fr":"Niveau d'eau","ja":"水位","it":"Livello dell'acqua","es":"Nivel de agua","pt":"Nível de água","de":"Wasserstand","ru":"Уровень воды","vi":"Mức nước","th":"ระดับน้ำ","id":"Tingkat air","zh-Hant":"水位","zh-TW":"水位","ar":"مستوى الماء","hu":"Vízszint","el":"Στάθμη νερού","nl":"Waterniveau","pl":"Poziom wody","fi":"Vedenpinnan taso","sv":"Vattennivå","km":"កម្រិត ទឹក"},"1st gear":{"en":"1st gear","zh-Hans":"1档","fr":"1ère vitesse","ja":"1速","it":"1a marcia","es":"1ra marcha","pt":"1ª marcha","de":"1. Gang","ru":"1-я скорость","vi":"Mức thứ nhất","th":"เกียร์ 1","id":"Gigi 1","zh-Hant":"1檔","zh-TW":"1檔","ar":"ملف","hu":"1. fokozat","el":"1η ταχύτητα","nl":"1e versnelling","pl":"1. bieg","fi":"1. vaihde","sv":"1:a växeln","km":"១. ១ សម្លៀកបំពាក់"},"2nd gear":{"en":"2nd gear","zh-Hans":"2档","fr":"2ème vitesse","ja":"2速","it":"2a marcia","es":"2da marcha","pt":"2ª marcha","de":"2. Gang","ru":"2-я скорость","vi":"Mức thứ hai","th":"เกียร์ 2","id":"Gigi 2","zh-Hant":"2檔","zh-TW":"2檔","ar":"السرعة الثانية","hu":"2. fokozat","el":"2η ταχύτητα","nl":"2e versnelling","pl":"2. bieg","fi":"2. vaihde","sv":"2:a växeln","km":"១."},"3rd gear":{"en":"3rd gear","zh-Hans":"3档","fr":"3e vitesse","ja":"3速","it":"3a marcia","es":"3ra marcha","pt":"3ª marcha","de":"3. Gang","ru":"3-я скорость","vi":"Mức thứ ba","th":"เกียร์ 3","id":"Gigi 3","zh-Hant":"3檔","zh-TW":"3檔","ar":"السرعة الثالثة","hu":"3. fokozat","el":"3η ταχύτητα","nl":"3e versnelling","pl":"3. bieg","fi":"3. vaihde","sv":"3:e växel","km":"3 ជំនាន់ទី 3"},"4th gear":{"en":"4th gear","zh-Hans":"4档","fr":"4e vitesse","ja":"4速","it":"4a marcia","es":"4ta marcha","pt":"4ª marcha","de":"4. Gang","ru":"4-я скорость","vi":"Mức thứ tư","th":"เกียร์ 4","id":"Gigi 4","zh-Hant":"4檔","zh-TW":"4檔","ar":"السرعة الرابعة","hu":"4. fokozat","el":"4η ταχύτητα","nl":"4e versnelling","pl":"4 bieg","fi":"4. vaihde","sv":"4:e växeln","km":"៤ ធុង"},"Mode":{"en":"Mode","zh-Hans":"模式","fr":"maquette","ja":"モデル","it":"modello","es":"Modo","pt":"Modo","de":"Modus","ru":"Режим","vi":"Chế độ","th":"แบบอย่าง","id":"model","zh-Hant":"模式","zh-TW":"模式","ar":"نمط","hu":"Üzemmód","el":"Λειτουργία","nl":"Modus","pl":"Tryb","fi":"Mode","sv":"Läge","km":"របៀប"},"Fan Speed":{"en":"Fan Speed","zh-Hans":"风速","fr":"vitesse du vent","ja":"風速","it":"velocità del vento","es":"velocidad del viento","pt":"Velocidade","de":"Lüfterdrehzahl","ru":"Скорость вентилятора","vi":"Tốc độ quạt","th":"ความเร็วลม","id":"kelajuan angin","zh-Hant":"風速","zh-TW":"風速","ar":"سرعة الرياح","hu":"Ventilátor fordulatszám","el":"Ταχύτητα ανεμιστήρα","nl":"Ventilatorsnelheid","pl":"Prędkość wentylatora","fi":"Puhaltimen nopeus","sv":"Fläkthastighet","km":"ល្បឿន Fan"},"Power off after sleep":{"en":"Power off after sleep","zh-Hans":"执行完睡眠曲线后自动关机","fr":"Mise hors tension après la mise en veille","ja":"スリープカーブ実行後の自動シャットダウン","it":"Spegnimento automatico dopo l'esecuzione della curva di riposo","es":"Apagado automático tras ejecutar la curva de reposo","pt":"Desligamento automático após a execução da curva de suspensão","de":"Automatische Abschaltung nach Ausführung der Schlafkurve","ru":"Автоматическое выключение после выполнения кривой сна","vi":"Tắt nguồn sau khi ngủ","th":"ปิดเครื่องหลังการนอนหลับ","id":"Matikan setelah tidur","zh-Hant":"完成睡眠後自動關機","zh-TW":"完成睡眠後自動關機","ar":"إيقاف التشغيل بعد النوم","hu":"Kikapcsolás alvás után","el":"Απενεργοποίηση μετά τον ύπνο","nl":"Uitschakelen na slaapstand","pl":"Wyłączanie po uśpieniu","fi":"Virta pois päältä lepotilan jälkeen","sv":"Avstängning efter viloläge","km":"ថាមពល ចេញ បន្ទាប់ ពី ដេក"},"No":{"en":"No","zh-Hans":"不","fr":"Non","ja":"いいえ","it":"No","es":"No","pt":"Não","de":"Nein","ru":"Нет","vi":"Không","th":"ไม่","id":"Tidak","zh-Hant":"不","zh-TW":"不","ar":"نمط","hu":"Nincs","el":"Όχι","nl":"Geen","pl":"Nie","fi":"Ei","sv":"Nej","km":"ទេ"},"Setting Successful":{"en":"Setting Successful","zh-Hans":"设置成功","fr":"Configurer avec succès","ja":"設定に成功しました","it":"Impostazione riuscita","es":"Configuración exitosa","pt":"Configurado com Sucesso","de":"Einstellung erfolgreich","ru":"Изменения приняты","vi":"Thiết lập thành công","th":"ตั้งค่าสำเร็จ","id":"Menetapkan Sukses","zh-Hant":"設定成功","zh-TW":"設定成功","ar":"مجموعة ناجحة","hu":"Sikeres beállítás","el":"Ρύθμιση Επιτυχής","nl":"Succesvol instellen","pl":"Pomyślne ustawienie","fi":"Asetus Onnistunut","sv":"Inställning framgångsrik","km":"ការកំណត់ជោគជ័យ"},"Yes, Run":{"en":"Yes, Run","zh-Hans":"是的，运行","fr":"Oui, courir","ja":"はい、実行","it":"Sì, corri","es":"Sí, correr","pt":"Sim, ligar","de":"Ja, lauf","ru":"Да","vi":"Ừ, chạy đi","th":"ใช่ วิ่ง","id":"Yes, run","zh-Hant":"是的，運行","zh-TW":"是的，運行","ar":"نعم ، تشغيل","hu":"Igen, működik","el":"Ναι, Εκτέλεση","nl":"Ja, Uitvoeren","pl":"Tak, uruchom","fi":"Kyllä, suorita","sv":"Ja, kör","km":"បាទ, រត់"},"Future temperature will be updated.":{"en":"Future temperature will be updated.","zh-Hans":"未来温度将更新","fr":"Les températures futures seront mises à jour","ja":"将来的には温度が更新されます","it":"La temperatura futura sarà aggiornata","es":"La temperatura se actualizará en el futuro","pt":"A temperatura futura será atualizada","de":"Zukünftige Temperatur wird aktualisiert","ru":"В будущем температура будет обновляться","vi":"Nhiệt độ sẽ được cập nhật trong tương lai","th":"จะมีการปรับปรุงอุณหภูมิในอนาคต","id":"Future temperature will be updated","zh-Hant":"未來溫度將更新","zh-TW":"未來溫度將更新","ar":"سيتم تحديث درجة الحرارة في المستقبل","hu":"A jövőben a hőmérséklet frissítésre kerül.","el":"Η μελλοντική θερμοκρασία θα ενημερωθεί.","nl":"Toekomstige temperatuur wordt bijgewerkt.","pl":"Przyszła temperatura zostanie zaktualizowana.","fi":"Tuleva lämpötila päivitetään.","sv":"Framtida temperatur kommer att uppdateras.","km":"សីតុណ្ហភាព នា ពេល អនាគត នឹង ត្រូវ បាន ធ្វើ ឲ្យ ទាន់ សម័យ ។"},"Run the new sleep curve now ?":{"en":"Run the new sleep curve now ?","zh-Hans":"现在运行新的睡眠曲线？","fr":"Exécuter une nouvelle courbe de sommeil maintenant?","ja":"新しい睡眠曲線を実行しますか？","it":"Fai la nuova curva del sonno ora?","es":"¿¿ ahora se ejecuta una nueva curva de sueño?","pt":"Iniciar nova curva de sono agora?","de":"Jetzt die Schlafkurve aktivieren?","ru":"Запустить режим сна прямо сейчас?","vi":"Bây giờ chạy một đường cong giấc ngủ mới?","th":"ตอนนี้เปิดเส้นโค้งการนอนหลับใหม่?","id":"Jalankan kurva tidur baru sekarang?","zh-Hant":"現在運行新的睡眠曲線？","zh-TW":"現在運行新的睡眠曲線？","ar":"الآن تشغيل منحنى النوم الجديد ؟","hu":"Az új alvási görbe futtatása most ?","el":"Τρέξτε τη νέα καμπύλη ύπνου τώρα ?","nl":"De nieuwe slaapcurve nu uitvoeren?","pl":"Uruchomić teraz nową krzywą uśpienia?","fi":"Aja uusi unikäyrä nyt ?","sv":"Kör den nya sömnkurvan nu?","km":"រត់ ខ្សែកោង ដេក ថ្មី ឥឡូវ នេះ ?"},"On/Off":{"en":"On/Off","zh-Hans":"开/关","fr":"Allumé éteint","ja":"オンオフ","it":"Acceso spento","es":"Encendido apagado","pt":"Ligado/desligado","de":"On/Off","ru":"Вкл выкл","vi":"Bật / Tắt","th":"เปิดปิด","id":"Hidup/Mati","zh-Hant":"開/關","zh-TW":"開/關","ar":"تشغيل / إيقاف","hu":"Be/Ki","el":"On/Off","nl":"Aan/Uit","pl":"Wł.","fi":"On/Off","sv":"På/Av","km":"On/Off"},"Power":{"en":"Power","zh-Hans":"开关机","fr":"Allumé éteint","ja":"スイッチング","it":"Acceso spento","es":"Encendido apagado","pt":"Ligado/desligado","de":"On/Off","ru":"Вкл выкл","vi":"Nguồn","th":"เปิดปิด","id":"Power","zh-Hant":"開關機","zh-TW":"開關機","ar":"تشغيل / إيقاف","hu":"Power","el":"Ισχύς","nl":"Stroom","pl":"Zasilanie","fi":"Power","sv":"Ström","km":"អំណាច"},"Setting":{"en":"Setting","zh-Hans":"设置","fr":"Paramètre","ja":"設定","it":"Impostazione","es":"Configuración","pt":"Configuração","de":"Einstellung","ru":"Параметры","vi":"Cài đặt","th":"การตั้งค่า","id":"Pengaturan","zh-Hant":"設定","zh-TW":"設定","ar":"الضبط","hu":"Beállítás","el":"Ρύθμιση","nl":"Instelling","pl":"Ustawienie","fi":"Asetus","sv":"Inställning","km":"ការ កំណត់"},"Set":{"en":"Setting","zh-Hans":"设置","fr":"Paramètre","ja":"設定","it":"Impostazione","es":"Configuración","pt":"Configuração","de":"Einstellung","ru":"Установить","vi":"Cài đặt","th":"การตั้งค่า","id":"Pengaturan","zh-Hant":"設定","zh-TW":"設定","ar":"الضبط","hu":"Beállítás","el":"Ρύθμιση","nl":"Instellen","pl":"Ustawienie","fi":"Asetus","sv":"Inställning","km":"ការ កំណត់"},"Smart":{"en":"Smart","zh-Hans":"智能","fr":"Smart","ja":"スマート","it":"Smart","es":"Inteligente","pt":"Smart","de":"Smart","ru":"Умный","vi":"Thông minh","th":"อัจฉริยะ","id":"Cerdas","zh-Hant":"智能","zh-TW":"智能","ar":"ذكي","hu":"Smart","el":"Smart","nl":"Smart","pl":"Inteligentny","fi":"Smart","sv":"Smart","km":"Smart"},"Drying Clothes":{"en":"Dryer","zh-Hans":"烘干机","fr":"Séchoir","ja":"ドライヤー","it":"Essiccatore","es":"Secador","pt":"Secador","de":"Dryer","ru":"Осушитель","vi":"Hút ẩm quần áo","th":"เครื่องเป่าแห้ง","id":"Pengering","zh-Hant":"烘乾機","zh-TW":"烘乾機","ar":"المجفف","hu":"Szárító","el":"Στεγνωτήριο","nl":"Droger","pl":"Suszarka","fi":"Kuivausrumpu","sv":"Torktumlare","km":"ទួលគោក"},"Drying Shoes":{"en":"Drying Shoes","zh-Hans":"干鞋","fr":"Séchage de chaussures","ja":"靴の乾燥","it":"Pattini essiccatore","es":"Secando calzado","pt":"Secar Sapatos","de":"Drying Shoes","ru":"Сушка обуви","vi":"Hút ẩm giày","th":"การเป่าแห้งรองเท้า","id":"Sepatu Pengering","zh-Hant":"幹鞋","zh-TW":"幹鞋","ar":"تجفيف الاحذية","hu":"Cipő szárítása","el":"Στέγνωμα παπουτσιών","nl":"Schoenen drogen","pl":"Buty do suszenia","fi":"Kenkien kuivaus","sv":"Torkning av skor","km":"ស្បែកជើងស្ងួត"},"Continuous":{"en":"Continuous","zh-Hans":"连续","fr":"Continu","ja":"連続","it":"Continuo","es":"Continuo","pt":"Continuo","de":"Continuous","ru":"Непрерывный","vi":"Tiếp tục","th":"ต่อเนื่อง","id":"Terus-Menerus","zh-Hant":"連續","zh-TW":"連續","ar":"متواصل","hu":"Folyamatos","el":"Συνεχής","nl":"Continu","pl":"Ciągły","fi":"Jatkuva","sv":"Kontinuerlig","km":"បន្ត"},"Timing":{"en":"Timing","zh-Hans":"定时","fr":"Horaire","ja":"タイミング","it":"tempismo","es":"sincronización","pt":"Cronometragem","de":"zeitliche Koordinierung","ru":"Настройка времени","vi":"Thời gian","th":"การตั้งเวลา","id":"Timing","zh-Hant":"定時","zh-TW":"定時","ar":"التوقيت","hu":"Időzítés","el":"Χρονισμός","nl":"Timing","pl":"Czas","fi":"Ajoitus","sv":"Tidsinställning","km":"ពេលវេលា"},"It can't be adjusted when the water is full":{"en":"It can't be adjusted when the water is full","zh-Hans":"水满时不可调节!","fr":"Il ne peut pas être ajusté lorsque l'eau est pleine","ja":"水がいっぱいになると調整できません","it":"Non può essere regolato quando l'acqua è piena","es":"No se puede ajustar cuando el agua está llena.","pt":"Não pode ser ajustado quando a água está cheia","de":"Kann bei vollem Wasserstand nicht angepasst werden","ru":"Нельзя отрегулировать, когда бак заполнен водой","vi":"Không thể được điều chỉnh khi nước đầy","th":"ไม่สามารถปรับได้เมื่อน้ำเต็ม","id":"Tidak bisa diatur saat air penuh","zh-Hant":"水滿時不可調節!","zh-TW":"水滿時不可調節!","ar":"يمكن تعديله عندما يكون الماء ممتلئاً","hu":"Nem lehet beállítani, ha a víz tele van","el":"Δεν μπορεί να ρυθμιστεί όταν το νερό είναι γεμάτο","nl":"Kan niet worden aangepast als het water vol is","pl":"Nie można regulować, gdy zbiornik wody jest pełny","fi":"Sitä ei voi säätää, kun vesi on täynnä.","sv":"Kan inte justeras när vattentanken är full","km":"មិន អាច លៃ តម្រូវ បាន ទេ ពេល ទឹក ពេញ"},"Water tank is full":{"en":"Water tank is full!","zh-Hans":"水箱水满!","fr":"Le réservoir d'eau est plein!","ja":"水タンクがいっぱいです！","it":"Il serbatoio dell'acqua è pieno!","es":"¡El tanque de agua está lleno!","pt":"O tanque de água está cheio!","de":"Wassertank ist voll","ru":"Бак для воды полон","vi":"Bình nước đầy","th":"ถังเก็บน้ำเต็ม!","id":"Tangki air penuh!","zh-Hant":"水箱水滿!","zh-TW":"水箱水滿!","ar":"خزان الماء ممتلئ!","hu":"A víztartály megtelt!","el":"Η δεξαμενή νερού είναι γεμάτη!","nl":"De watertank is vol!","pl":"Zbiornik wody jest pełny!","fi":"Vesisäiliö on täynnä!","sv":"Vattentanken är full!","km":"ធុងទឹកពេញ!"},"Humidity is not adjustable in current mode":{"en":"Humidity is not adjustable in current mode!","zh-Hans":"该模式湿度不可调","fr":"L'humidité n'est pas réglable en mode actuel!","ja":"現在のモードでは湿度を調整できません！","it":"L'umidità non è regolabile nella modalità corrente!","es":"¡La humedad no es ajustable en el modo actual!","pt":"A umidade não é ajustável no modo atual!","de":"Im aktuellen Modus ist die Feuchtigkeit nicht anpassbar!","ru":"В текущем режиме влажность не регулируется","vi":"Độ ẩm không thể điều chỉnh được ở chế độ hiện tại!","th":"ไม่สามารถปรับความชื้นได้ในโหมดปัจจุบัน!","id":"Kelembaban tidak bisa disesuaikan dalam mode ini!","zh-Hant":"該模式濕度不可調","zh-TW":"該模式濕度不可調","ar":"الرطوبة غير قابلة للتعديل تحت الوضع الحالي!","hu":"A páratartalom nem állítható a jelenlegi üzemmódban!","el":"Η υγρασία δεν είναι ρυθμιζόμενη στην τρέχουσα λειτουργία!","nl":"Vochtigheid kan niet worden ingesteld in de huidige modus!","pl":"Wilgotność nie jest regulowana w bieżącym trybie!","fi":"Kosteutta ei voi säätää nykyisessä tilassa!","sv":"Luftfuktigheten kan inte justeras i aktuellt läge!","km":"សំណើម មិន អាច លៃ តម្រូវ បាន ក្នុង របៀប បច្ចុប្បន្ន ទេ !"},"Humidity is not adjustable when water is full":{"en":"Humidity is not adjustable when water is full!","zh-Hans":"水满状态湿度不可调","fr":"L'humidité n'est pas réglable lorsque l'eau est pleine!","ja":"水がいっぱいになると湿度は調整できません！","it":"L'umidità non è regolabile quando l'acqua è piena!","es":"¡La humedad no es ajustable cuando el agua está llena!","pt":"A umidade não é ajustável quando a água está cheia!","de":"Bei vollem Wasserstand ist die Feuchtigkeit nicht anpassbar!","ru":"Влажность не регулируется, когда бак заполнен водой","vi":"Độ ẩm không thể điều chỉnh được khi nước đầy!","th":"ไม่สามารถปรับความชื้นได้เมื่อน้ำเต็ม!","id":"Kelembaban tidak bisa disesuaikan saat air penuh!","zh-Hant":"水滿狀態濕度不可調","zh-TW":"水滿狀態濕度不可調","ar":"الرطوبة غير قابلة للتعديل عندما يكون الماء ممتلئاً","hu":"A páratartalom nem állítható, ha a víztartály tele van!","el":"Η υγρασία δεν είναι ρυθμιζόμενη όταν το νερό είναι γεμάτο!","nl":"Vochtigheid kan niet worden ingesteld wanneer de watertank vol is!","pl":"Wilgotności nie można regulować, gdy zbiornik wody jest pełny!","fi":"Kosteutta ei voi säätää, kun vesi on täynnä!","sv":"Luftfuktigheten kan inte justeras när vattnet är fullt!","km":"សំណើម មិន អាច លៃ តម្រូវ បាន ទេ ពេល ទឹក ពេញ !"},"This function is not available when water is full":{"en":"This function is not available when water is full","zh-Hans":"水满状态模式不可用","fr":"Cette fonction n'est pas disponible lorsque l'eau est pleine","ja":"水がいっぱいになると、この機能は使用できません","it":"Questa funzione non è disponibile quando l'acqua è piena","es":"Esta función no está disponible cuando el agua está llena","pt":"Esta função não está disponível quando a água está cheia","de":"Bei vollem Wasserstand ist diese Funktion nicht verfügbar","ru":"Эта функция недоступна, когда бак заполнен водой","vi":"Chức năng này không khả dụng khi nước đầy","th":"ไม่สามารถใช้ฟังก์ชันนี้ได้เมื่อน้ำเต็ม","id":"Fungsi ini tidak tersedia saat air penuh","zh-Hant":"水滿狀態模式不可用","zh-TW":"水滿狀態模式不可用","ar":"هذه الوظيفة غير متوفرة عندما يكون الماء ممتلئاً","hu":"Ez a funkció nem érhető el, ha a víz tele van","el":"Αυτή η λειτουργία δεν είναι διαθέσιμη όταν το νερό είναι γεμάτο","nl":"Deze functie is niet beschikbaar als het water vol is","pl":"Ta funkcja nie jest dostępna, gdy zbiornik wody jest pełny","fi":"Tämä toiminto ei ole käytettävissä, kun vesi on täynnä","sv":"Denna funktion är inte tillgänglig när vattnet är fullt","km":"មុខងារ នេះ មិន អាច ប្រើ បាន ទេ ពេល ទឹក ពេញ"},"This function is not adjustable in drying clothes mode":{"en":"This function is not adjustable in dryer mode","zh-Hans":"干衣模式下该功能不可调节","fr":"Cette fonction n'est pas réglable en mode sèche-linge","ja":"この機能はドライヤーモードでは調整できません","it":"Questa funzione non è regolabile in modalità asciugatrice","es":"Esta función no es ajustable en modo secador","pt":"Esta função não é ajustável no modo de secador","de":"Diese Funktion ist im Trockner-Modus nicht anpassbar","ru":"Эта функция не регулируется в режиме сушки одежды","vi":"Chức năng này không điều chỉnh được ở chế độ Hút ẩm quần áo","th":"ไม่สามารถปรับฟังก์ชันนี้ได้ในโหมดเครื่องเป่าแห้ง","id":"Fungsi ini tidak bisa disesuaikan dalam mode pengering","zh-Hant":"幹衣模式下該功能不可調節","zh-TW":"幹衣模式下該功能不可調節","ar":"هذه الوظيفة غير قابلة للتعديل في وضع المجفف","hu":"Ez a funkció nem állítható szárító üzemmódban","el":"Αυτή η λειτουργία δεν είναι ρυθμιζόμενη στη λειτουργία στεγνώματος","nl":"Deze functie is niet instelbaar in drogerstand","pl":"Tej funkcji nie można regulować w trybie suszarki","fi":"Tätä toimintoa ei voi säätää kuivaustilassa","sv":"Denna funktion kan inte justeras i torkarläget","km":"មុខងារ នេះ មិន អាច លៃ តម្រូវ បាន ក្នុង របៀប ស្ងួត"},"The set humidity has reached the maximum value":{"en":"The set humidity has reached the maximum value","zh-Hans":"设定湿度已是最大值","fr":"L'humidité réglée a atteint la valeur maximale","ja":"設定湿度が最大値に達しました","it":"L'umidità impostata ha raggiunto il valore massimo","es":"La humedad configurada ha alcanzado el valor máximo","pt":"A umidade definida atingiu o valor máximo","de":"Die eingestellte Feuchtigkeit hat den Maximalwert erreicht","ru":"Установленная влажность достигла максимального значения","vi":"Độ ẩm được cài đặt đã đạt giá trị tối đa","th":"ความชื้นที่ตั้งค่าไว้ถึงค่าสูงสุดแล้ว","id":"Kelembaban yang diatur sudah mencapai nilai maksimal","zh-Hant":"設定濕度已是最大值","zh-TW":"設定濕度已是最大值","ar":"وصلت الرطوبة المحددة إلى القيمة القصوى","hu":"A beállított páratartalom elérte a maximális értéket","el":"Η ρυθμισμένη υγρασία έχει φτάσει στη μέγιστη τιμή","nl":"De ingestelde vochtigheid heeft de maximumwaarde bereikt","pl":"Ustawiona wilgotność osiągnęła wartość maksymalną","fi":"Asetettu kosteus on saavuttanut enimmäisarvon","sv":"Den inställda luftfuktigheten har nått maxvärdet","km":"សំណើម ដែល បាន កំណត់ បាន ឈាន ដល់ តម្លៃ អតិបរមា"},"The set humidity has reached the minimum value":{"en":"The set humidity has reached the minimum value","zh-Hans":"设定湿度已是最小值","fr":"L'humidité réglée a atteint la valeur minimale","ja":"設定湿度が最小値に達しました","it":"L'umidità impostata ha raggiunto il valore minimo","es":"La humedad configurada ha alcanzado el valor mínimo","pt":"A umidade definida atingiu o valor mínimo","de":"Die eingestellte Feuchtigkeit hat den Minimalwert erreicht","ru":"Установленная влажность достигла минимального значения","vi":"Độ ẩm được cài đặt đã đạt giá trị tối thiểu","th":"ความชื้นที่ตั้งค่าไว้ถึงค่าต่ำสุดแล้ว","id":"Kelembaban yang diatur sudah mencapai nilai maksimal","zh-Hant":"設定濕度已是最小值","zh-TW":"設定濕度已是最小值","ar":"وصلت الرطوبة المحددة إلى القيمة الدنيا","hu":"A beállított páratartalom elérte a minimális értéket","el":"Η ρυθμισμένη υγρασία έχει φτάσει στην ελάχιστη τιμή","nl":"De ingestelde vochtigheid heeft de minimumwaarde bereikt","pl":"Ustawiona wilgotność osiągnęła wartość minimalną","fi":"Asetettu kosteus on saavuttanut vähimmäisarvon","sv":"Den inställda luftfuktigheten har nått minimivärdet","km":"សំណើម ដែល បាន កំណត់ បាន ឈាន ដល់ តម្លៃ អប្បបរមា"},"Indoor humidity":{"en":"Room Humidity","zh-Hans":"室内湿度","fr":"Humidité de la pièce","ja":"部屋の湿度","it":"Umidità della stanza","es":"Humedad de la Habitación","pt":"Humidade do local","de":"Zimmerfeuchtigkeit","ru":"Влажность в помещении","vi":"Độ ẩm Phòng","th":"ความชื้นของห้อง","id":"Kelembaban Ruangan","zh-Hant":"室內濕度","zh-TW":"室內濕度","ar":"رطوبة الغرفة","hu":"Szobai páratartalom","el":"Υγρασία χώρου","nl":"Vochtigheid kamer","pl":"Wilgotność w pomieszczeniu","fi":"Huoneen kosteus","sv":"Luftfuktighet i rummet","km":"សំណើមបន្ទប់"},"OFF":{"en":"OFF","zh-Hans":"关","fr":"éteindre","ja":"消す","it":"Spegn","es":"Apagar","pt":"Desligar","de":"ausschalten","ru":"выключить","vi":"Tắt","th":"ปิด","id":"matikan","zh-Hant":"關","zh-TW":"關","ar":"اطفئه","hu":"OFF","el":"OFF","nl":"UIT","pl":"WYŁ.","fi":"OFF","sv":"AV","km":"OFF"},"Timer On":{"en":"Timer On","zh-Hans":"定时开","fr":"Minuterie activée","ja":"ON時間","it":"Timer acceso","es":"Temp. encendido","pt":"Temporizador ON","de":"Timer ein","ru":"Таймер включен","vi":"Bộ đếm thời gian Bật","th":"เครื่องตั้งเวลาเปิดอยู่","id":"Timer Menyala","zh-Hant":"定時開","zh-TW":"定時開","ar":"تشغيل المؤقت","hu":"Időzítő be","el":"Χρονοδιακόπτης ενεργοποιημένος","nl":"Timer Aan","pl":"Timer wł.","fi":"Ajastin päällä","sv":"Timer på","km":"Timer On"},"Timer Off":{"en":"Timer Off","zh-Hans":"定时关","fr":"Minuterie déactivée","ja":"OFF時間","it":"Timer spento","es":"Temp. Apagado","pt":"Temporizador OFF","de":"Timer aus","ru":"Таймер выключен","vi":"Bộ đếm thời gian Tắt","th":"เครื่องตั้งเวลาปิดอยู่","id":"Timer Mati","zh-Hant":"定時關","zh-TW":"定時關","ar":"إيقاف تشغيل المؤقت","hu":"Időzítő ki","el":"Χρονοδιακόπτης απενεργοποιημένος","nl":"Timer Uit","pl":"Timer wyłączony","fi":"Ajastin pois päältä","sv":"Timer Av","km":"Timer Off"},"Cations and Anions":{"en":"Cations and Anions","zh-Hans":"正负离子","fr":"Cations et anions","ja":"陽イオンと陰イオン","it":"Cationi e anioni","es":"Cationes y aniones","pt":"Cátions e ânions","de":"Kationen und Anionen","ru":"Катионы и анионы","vi":"Cation và Anion","th":"ประจุบวกและประจุลบ","id":"Kation dan Anion","zh-Hant":"正負離子","zh-TW":"正負離子","ar":"الكاتيونات والأنيونات","hu":"Kationok és anionok","el":"Κατιόντα και ανιόντα","nl":"Kationen en Anionen","pl":"Kationy i aniony","fi":"Kationit ja anionit","sv":"Katjoner och anjoner","km":"ផលប៉ះពាល់ និង Anions"},"Cancel Timer":{"en":"Cancel Timer","zh-Hans":"取消定时","fr":"Annuler la minuterie","ja":"タイマーをキャンセル","it":"Annulla timer","es":"Cancelar temporizador","pt":"Cancelar cronômetro","de":"Timer abbrechen","ru":"Отменить Таймер","vi":"Hủy bỏ Bộ đếm thời gian","th":"ยกเลิกเครื่องตั้งเวลา","id":"Batalkan Timer","zh-Hant":"取消定時","zh-TW":"取消定時","ar":"إلغاء المؤقت","hu":"Időzítő leállítása","el":"Ακύρωση χρονοδιακόπτη","nl":"Timer annuleren","pl":"Anuluj timer","fi":"Peruuta ajastin","sv":"Avbryt timer","km":"លុបចោល Timer"},"Turn on dehumidifier":{"en":"Turn on dehumidifier","zh-Hans":"开启除湿机","fr":"Allumez le déshumidificateur","ja":"除湿機をオンにします","it":"Accendi il deumidificatore","es":"Encienda el deshumidificador","pt":"Ligue o desumidificador","de":"Luftentfeuchter einschalten","ru":"Включить осушитель","vi":"Bật máy khử độ ẩm","th":"เปิดเครื่องลดความชื้น","id":"Nyalakan dehumidifier","zh-Hant":"開啟除濕機","zh-TW":"開啟除濕機","ar":"تشغيل مزيل الرطوبة","hu":"Páramentesítő bekapcsolása","el":"Ενεργοποίηση του αφυγραντήρα","nl":"Zet luchtontvochtiger aan","pl":"Włączanie osuszacza","fi":"Kytke ilmankuivain päälle","sv":"Slå på avfuktaren","km":"បើក dehumidifier"},"Turn off dehumidifier":{"en":"Turn off dehumidifier","zh-Hans":"关闭除湿机","fr":"Éteignez le déshumidificateur","ja":"除湿機をオフにします","it":"Spegni il deumidificatore","es":"Apague el deshumidificador","pt":"Desligue o desumidificador","de":"Luftentfeuchter ausschalten","ru":"Выключить осушитель","vi":"Tắt máy khử độ ẩm","th":"ปิดเครื่องลดความชื้น","id":"Matikan dehumidifier","zh-Hant":"關閉除濕機","zh-TW":"關閉除濕機","ar":"إيقاف تشغيل مزيل الرطوبة","hu":"Páramentesítő kikapcsolása","el":"Απενεργοποίηση του αφυγραντήρα","nl":"Ontvochtiger uitschakelen","pl":"Wyłącz osuszacz","fi":"Kytke kosteudenpoistin pois päältä","sv":"Stäng av avfuktaren","km":"បិទ dehumidifier"},"It can not be controlled when the device is off":{"en":"It can not be controlled when the device is off","zh-Hans":"设备关机状态下不可以控制","fr":"Il ne peut pas être contrôlé lorsque l'appareil est éteint","ja":"デバイスがオフのときは制御できません","it":"Non può essere controllato quando il dispositivo è spento","es":"No se puede controlar cuando el dispositivo está apagado","pt":"Não pode ser controlado quando o dispositivo está desligado","de":"Es kann nicht gesteuert werden, wenn das Gerät ausgeschaltet ist","ru":"Невозможно управлять, когда устройство выключено","vi":"Không thể điều khiển được khi thiết bị tắt","th":"ไม่สามารถควบคุมได้เมื่ออุปกรณ์ปิดอยู่","id":"Tidak bisa dikendalikan saat perangkat mati","zh-Hant":"裝置關機狀態下不可以控制","zh-TW":"裝置關機狀態下不可以控制","ar":"لا يمكن التحكم بها عندما يكون الجهاز متوقفاً عن التشغيل","hu":"Nem vezérelhető, ha a készülék ki van kapcsolva","el":"Δεν μπορεί να ελεγχθεί όταν η συσκευή είναι απενεργοποιημένη","nl":"Kan niet worden bediend als het apparaat uit staat","pl":"Nie można sterować, gdy urządzenie jest wyłączone","fi":"Sitä ei voi ohjata, kun laite on pois päältä.","sv":"Det går inte att styra när enheten är avstängd","km":"វា មិន អាច ត្រូវ បាន ត្រួត ពិនិត្យ នៅ ពេល ឧបករណ៍ បិទ"},"Timer not available when water is full":{"en":"Timer not available when water is full","zh-Hans":"水满状态下定时不可用","fr":"Minuterie non disponible lorsque l'eau est pleine","ja":"水がいっぱいになるとタイマーは利用できません","it":"Timer non disponibile quando l'acqua è piena","es":"Temporizador no disponible cuando el agua está llena","pt":"O temporizador não está disponível quando a água está cheia","de":"Timer nicht verfügbar, wenn das Wasser voll ist","ru":"Таймер недоступен, когда бак заполнен водой","vi":"Bộ đếm thời gian không khả dụng khi nước đầy","th":"ไม่สามารถใช้เครื่องตั้งเวลาได้เมื่อน้ำเต็ม","id":"Timer tidak tersedia saat air penuh","zh-Hant":"水滿狀態下定時不可用","zh-TW":"水滿狀態下定時不可用","ar":"لا يكون المؤقت متوفراً عندما يكون الماء ممتلئاً","hu":"Az időzítő nem áll rendelkezésre, ha a víz tele van","el":"Ο χρονοδιακόπτης δεν είναι διαθέσιμος όταν το νερό είναι γεμάτο","nl":"Timer niet beschikbaar wanneer het water vol is","pl":"Timer nie jest dostępny, gdy woda jest pełna","fi":"Ajastin ei ole käytettävissä, kun vesi on täynnä","sv":"Timer inte tillgänglig när vattnet är fullt","km":"Timer មិន មាន ពេល ទឹក ពេញ"},"Cancel":{"en":"Cancel","zh-Hans":"取消","fr":"Annuler","ja":"取消","it":"Annulla","es":"Cancelar","pt":"Cancelar","de":"Abbrechen","ru":"Нет","vi":"Hủy bỏ","th":"ยกเลิก","id":"Batal","zh-Hant":"取消","zh-TW":"取消","ar":"إلغاء","hu":"Cancel","el":"Ακύρωση","nl":"Annuleren","pl":"Anuluj","fi":"Peruuta","sv":"Avbryt","km":"លប់ចោល"},"Confirm":{"en":"Confirm","zh-Hans":"确认","fr":"confirmer","ja":"確認","it":"Confermare","es":"confirmar","pt":"Confirme","de":"bestätigen","ru":"подтверждать","vi":"xác nhận","th":"ยืนยัน","id":"mengonfirmasi","zh-Hant":"確認","zh-TW":"確認","ar":"يتأكد","hu":"Megerősítés","el":"Επιβεβαίωση","nl":"Bevestigen","pl":"Potwierdzenie","fi":"Vahvista","sv":"Bekräfta","km":"បញ្ជាក់"},"Submit":{"en":"Submit","zh-Hans":"提交","fr":"Soumettre","ja":"確認","it":"Invia","es":"Presentación","pt":"Enviar","de":"Absenden","ru":"Подтвердить","vi":"Giới thiệu","th":"ส่ง","id":"Kirim","zh-Hant":"提交","zh-TW":"提交","ar":"قدم","hu":"Küldje el","el":"Υποβολή","nl":"Aanmelden","pl":"Prześlij","fi":"Lähetä","sv":"Skicka","km":"ដាក់ស្នើ"},"More":{"en":"More","zh-Hans":"更多","fr":"Plus","ja":"もっと","it":"Mostra","es":"Más","pt":"Mais","de":"Weiter","ru":"Больше","vi":"Thêm","th":"เพิ่มเติม","id":"Lebih banyak lagi","zh-Hant":"更多","zh-TW":"更多","ar":"المزيد","hu":"További","el":"Περισσότερα","nl":"Meer","pl":"Więcej","fi":"Lisää","sv":"Mer om","km":"ច្រើនទៀត"},"Device sn code":{"en":"Sn code","zh-Hans":"序列码","fr":"Numéro de série","ja":"SNコード","it":"Codice Sn","es":"Número de serie","pt":"Código SN","de":"SN Code","ru":"Sn-код","vi":"Mã Sn","th":"รหัสประจำเครื่อง","id":"Kode SN","zh-Hant":"序列碼","zh-TW":"序列碼","ar":"الرمز التسلسلي","hu":"Sn kód","el":"Κωδικός Sn","nl":"Sn code","pl":"Kod Sn","fi":"Sn koodi","sv":"Sn kod","km":"កូដ Sn"},"Version":{"en":"Plugin Version","zh-Hans":"版本","fr":"Version","ja":"バージョン","it":"Versione","es":"Versión","pt":"Versão","de":"Ausführung","ru":"Версия","vi":"Phiên bản","th":"เวอร์ชัน","id":"Versi","zh-Hant":"版次","zh-TW":"版次","ar":"الإصدار","hu":"Plugin verzió","el":"Έκδοση του πρόσθετου","nl":"Versie plugin","pl":"Wersja wtyczki","fi":"Pluginin versio","sv":"Plugin-version","km":"កំណែជំនួយ"},"Device Name":{"en":"Device Name","zh-Hans":"设备名称","fr":"Nom de l'appareil","ja":"設備名","it":"Nome dell'impianto","es":"Nombre del Disp.","pt":"Nome Dispositivo","de":"Gerätename","ru":"Имя устройства","vi":"Tên Thiết bị","th":"ชื่ออุปกรณ์","id":"Nama Perangkat","zh-Hant":"裝置名稱","zh-TW":"裝置名稱","ar":"اسم الجهاز","hu":"Eszköz neve","el":"Όνομα συσκευής","nl":"Naam apparaat","pl":"Nazwa urządzenia","fi":"Laitteen nimi","sv":"Enhetens namn","km":"ឈ្មោះឧបករណ៍"},"Device name":{"en":"Device Name","zh-Hans":"设备名称","fr":"Nom de l'appareil","ja":"設備名","it":"Nome dell'impianto","es":"Nombre del Disp.","pt":"Nome Dispositivo","de":"Gerätename","ru":"Имя устройства","vi":"Tên Thiết bị","th":"ชื่ออุปกรณ์","id":"Nama Perangkat","zh-Hant":"裝置名稱","zh-TW":"裝置名稱","ar":"اسم الجهاز","hu":"Eszköz neve","el":"Όνομα συσκευής","nl":"Naam apparaat","pl":"Nazwa urządzenia","fi":"Laitteen nimi","sv":"Enhetens namn","km":"ឈ្មោះឧបករណ៍"},"水泵":{"en":"Pump","zh-Hans":"泵抽","fr":"Pompe","ja":"ポンプ","it":"Pompa","es":"Bomba","pt":"Bombear","de":"Pumpe","ru":"Помпа","vi":"Bơm","th":"ปั๊ม","id":"Pompa","zh-Hant":"泵抽","zh-TW":"泵抽","ar":"المضخة","hu":"Szivattyú","el":"Αντλία","nl":"Pomp","pl":"Pompa","fi":"Pumppu","sv":"Pump","km":"បូម"},"Очищено":{"en":"Clean","zh-Hans":"清洗","fr":"Faire le ménage","ja":"クリーン","it":"Pulito","es":"Limpio","pt":"Limpar","de":"Sauber","ru":"Очищено","vi":"Vệ sinh","th":"ทำความสะอาด","id":"Bersihkan","zh-Hant":"清洗","zh-TW":"清洗","ar":"تنظيف","hu":"Clean","el":"Καθαρισμός","nl":"Schoon","pl":"Czyszczenie","fi":"Clean","sv":"Rengör","km":"ស្អាត"},"取消":{"en":"Cancel","zh-Hans":"取消","fr":"Annuler","ja":"取消","it":"Annulla","es":"Cancelar","pt":"Cancelar","de":"Stornieren","ru":"Отмена","vi":"Hủy bỏ","th":"ยกเลิก","id":"Batal","zh-Hant":"取消","zh-TW":"取消","ar":"إلغاء","hu":"Cancel","el":"Ακύρωση","nl":"Annuleren","pl":"Anuluj","fi":"Peruuta","sv":"Avbryt","km":"លប់ចោល"},"滤网使用时间过长，请清洗滤网":{"en":"The filter has been used for too long, please clean the filter","zh-Hans":"过滤器已使用较长时间，请清洗过滤器","fr":"Le filtre a été utilisé pendant trop longtemps, veuillez nettoyer le filtre","ja":"満水時にはタイマーが使えません。","it":"Il filtro è stato utilizzato troppo a lungo, pulire il filtro","es":"El filtro se ha utilizado durante demasiado tiempo, límpielo","pt":"O filtro foi usado por muito tempo, por favor, limpe o filtro","de":"Der Filter wurde zu lange benutzt, bitte reinigen Sie den Filter","ru":"Фильтр использовался слишком долго, очистите фильтр","vi":"Bộ lọc đã được sử dụng quá lâu, hãy vệ sinh bộ lọc","th":"คุณใช้ไส้กรองมานานเกินไป โปรดทำความสะอาดไส้กรอง","id":"Filter sudah digunakan terlalu lama, mohon bersihkan filter","zh-Hant":"篩檢程式已使用較長時間，請清洗篩檢程式","zh-TW":"篩檢程式已使用較長時間，請清洗篩檢程式","ar":"الفلتر مستخدم منذ فترة طويلة للغاية، يرجى تنظيف الفلتر","hu":"A szűrő túl régóta használatban van, kérjük, tisztítsa meg a szűrőt","el":"Το φίλτρο έχει χρησιμοποιηθεί για πολύ καιρό, παρακαλούμε καθαρίστε το φίλτρο","nl":"Het filter is te lang gebruikt, maak het filter schoon a.u.b.","pl":"Filtr był używany zbyt długo, wyczyść filtr","fi":"Suodatinta on käytetty liian kauan, puhdista suodatin.","sv":"Filtret har använts för länge, vänligen rengör filtret","km":"តម្រង ត្រូវ បាន ប្រើ យូរ ពេក សូម សម្អាត តម្រង"},"请清洗滤网":{"en":"Please clean the filter","zh-Hans":"请清洗过滤器","fr":"Veuillez nettoyer le filtre","ja":"フィルターを清掃してください。","it":"Pulire il filtro","es":"Por favor, limpie el filtro","pt":"Limpe o filtro","de":"Bitte den Filter reinigen","ru":"Очистите фильтр","vi":"Hãy vệ sinh bộ lọc","th":"โปรดทำความสะอาดไส้กรอง","id":"Mohon bersihkan filter","zh-Hant":"請清洗篩檢程式","zh-TW":"請清洗篩檢程式","ar":"يرجى تنظيف الفلتر","hu":"Kérjük, tisztítsa meg a szűrőt","el":"Καθαρίστε το φίλτρο","nl":"Maak het filter schoon","pl":"Wyczyść filtr","fi":"Puhdista suodatin","sv":"Vänligen rengör filtret","km":"សូម សម្អាត តម្រង"},"Sleep Curve":{"en":"Sleep Curve","zh-Hans":"睡眠曲线","fr":"courbe du sommeil","ja":"スリープカーブ","it":"curva del sonno","es":"curva de sueño","pt":"Curva Sono","de":"Schlafkurve","ru":"Режим сна","vi":"Chế độ ngủ","th":"สถิติการนอนหลับ","id":"keluk tidur","zh-Hant":"睡眠曲線","zh-TW":"睡眠曲線","ar":"منحنى النوم","hu":"Alvási görbe","el":"Καμπύλη ύπνου","nl":"Slaapcurve","pl":"Krzywa uśpienia","fi":"Unikäyrä","sv":"Sömnkurva","km":"ខ្សែកោងគេង"},"Sleep curve":{"en":"Sleep Curve","zh-Hans":"睡眠曲线","fr":"Courbe de sommeil","ja":"スリープカーブ","it":"Curva del sonno","es":"Curva de sueño","pt":"Curva de sono","de":"Schlafkurve","ru":"Режим сна","vi":"Chế độ ngủ","th":"เส้นโค้งการนอนหลับ","id":"Kurva Tidur","zh-Hant":"睡眠曲線","zh-TW":"睡眠曲線","ar":"منحنى النوم","hu":"Alvási görbe","el":"Καμπύλη ύπνου","nl":"Slaapcurve","pl":"Krzywa uśpienia","fi":"Unikäyrä","sv":"Sömnkurva","km":"ខ្សែកោងគេង"},"Energy Monitor":{"en":"Energy Monitor","zh-Hans":"能源监测器","fr":"Moniteur d'énergie","ja":"エネルギーモニター","it":"Monitoraggio energetico","es":"Monitor de energía","pt":"Monitor de energia","de":"Energiemonitor","ru":"Монитор энергоэффективности","vi":"Bộ kiểm soát Năng lượng","th":"เครื่องติดตามพลังงาน","id":"Monitor Energi","zh-Hant":"能源監測器","zh-TW":"能源監測器","ar":"شاشة مراقبة الطاقة","hu":"Energiamonitor","el":"Παρακολούθηση ενέργειας","nl":"Energiemonitor","pl":"Monitor energii","fi":"Energiaseuranta","sv":"Energiövervakning","km":"ការត្រួតពិនិត្យថាមពល"},"Bill Control":{"en":"Bill Control","zh-Hans":"清单控制","fr":"Contrôle des factures","ja":"ビル管理","it":"Controllo bolletta","es":"Control de facturas","pt":"Controle de contas","de":"Rechnungskontrolle","ru":"Контроль счетов","vi":"Kiểm soát Hóa đơn","th":"การควบคุมบิล","id":"Kendali Tagihan","zh-Hant":"清單控制","zh-TW":"清單控制","ar":"التحكم بالفواتير","hu":"Számlaellenőrzés","el":"Έλεγχος λογαριασμού","nl":"Factuur controle","pl":"Kontrola rachunków","fi":"Bill Control","sv":"Kontroll av räkningar","km":"ការ គ្រប់គ្រង សេចក្តី ព្រាង ច្បាប់"},"Recommend Range":{"en":"Recommend Range","zh-Hans":"建议范围","fr":"Recommander la gamme","ja":"推奨範囲","it":"Consiglia gamma","es":"Recomendar rango","pt":"Faixa Recomendada","de":"Bereich empfehlen","ru":"Рекомендуемый диапазон","vi":"Phạm vi được Khuyến nghị","th":"ช่วงที่แนะนำ","id":"Rekomendasikan Rentang","zh-Hant":"建議範圍","zh-TW":"建議範圍","ar":"النطاق الموصى به","hu":"Ajánlott tartomány","el":"Προτείνετε το εύρος","nl":"Aanbevolen bereik","pl":"Zalecany zakres","fi":"Suosittele aluetta","sv":"Rekommendera intervall","km":"អនុសាសន៍ ជួរ"},"Real-time Power":{"en":"Real Time Power","zh-Hans":"实时功率","fr":"Puissance en temps réel","ja":"リアルタイムパワー","it":"Potenza in tempo reale","es":"Energía en tiempo real","pt":"Potêncial em tempo real","de":"Echtzeitleistung","ru":"Мощность в реальном времени","vi":"Công suất Thời gian thực","th":"กำลังไฟแบบเรียลไทม์","id":"Daya Real Time","zh-Hant":"即時功率","zh-TW":"即時功率","ar":"الطاقة في الوقت الحقيقي","hu":"Valós idejű teljesítmény","el":"Ισχύς σε πραγματικό χρόνο","nl":"Realtime vermogen","pl":"Moc w czasie rzeczywistym","fi":"Reaaliaikainen teho","sv":"Effekt i realtid","km":"អំណាច ពេលវេលា ពិត"},"Yesterday cumulative":{"en":"Yesterday cumulative","zh-Hans":"昨日累计","fr":"Hier cumulatif","ja":"昨日の累積","it":"Ieri cumulativo","es":"Ayer acumulativo","pt":"Cumulativo de ontem","de":"Gestern kumulativ","ru":"Суммарное значение за вчерашний день","vi":"Tích lũy hôm qua","th":"ยอดสะสมของเมื่อวาน","id":"Kumulasi Kemarin","zh-Hant":"昨日累計","zh-TW":"昨日累計","ar":"تراكم يوم أمس","hu":"Tegnapi kumulatív","el":"Χθες αθροιστικά","nl":"Gisteren cumulatief","pl":"Narastająco od wczoraj","fi":"Eilen kumulatiivinen","sv":"Igår kumulativt","km":"ម្សិលម៉ិញ cumulative"},"Monthly cumulative":{"en":"Monthly cumulative","zh-Hans":"每月累计","fr":"Cumul mensuel","ja":"月間累積","it":"Cumulativo mensile","es":"Acumulativo mensual","pt":"Cumulativo mensal","de":"Monatlich kumulativ","ru":"Месячное суммарное значение","vi":"Tích lũy hàng tháng","th":"ยอดสะสมประจำเดือน","id":"Kumulasi Bulanan","zh-Hant":"每月累計","zh-TW":"每月累計","ar":"التراكم الشهري","hu":"Havi kumulatív","el":"Μηνιαία αθροιστικά","nl":"Maandelijks cumulatief","pl":"Miesięczna wartość skumulowana","fi":"Kuukausittainen kumulatiivinen","sv":"Månadsvis ackumulerad","km":"សង្ខេបប្រចាំខែ"},"Chart":{"en":"Chart","zh-Hans":"图表","fr":"Graphique","ja":"チャート","it":"Grafico","es":"Gráfico","pt":"Gráfico","de":"Diagramm","ru":"Диаграмма","vi":"Sơ đồ","th":"แผนภูมิ","id":"Grafik","zh-Hant":"圖表","zh-TW":"圖表","ar":"مخطط بياني","hu":"Diagram","el":"Διάγραμμα","nl":"Grafiek","pl":"Wykres","fi":"Kaavio","sv":"Diagram","km":"តារាង"},"Time":{"en":"Time","zh-Hans":"时间","fr":"Heure","ja":"時間","it":"Tempo","es":"Tiempo","pt":"Hora","de":"Graphique","ru":"Время","vi":"Thời gian","th":"เวลา","id":"Waktu","zh-Hant":"時間","zh-TW":"時間","ar":"الوقت","hu":"Idő","el":"Χρόνος","nl":"Tijd","pl":"Czas","fi":"Aika","sv":"Tid","km":"ពេលវេលា"},"Limit":{"en":"Limit","zh-Hans":"限值","fr":"Limite","ja":"制限","it":"Limite","es":"Límite","pt":"Limite","de":"Grenze","ru":"Предел","vi":"Giới hạn","th":"ขีดจำกัด","id":"Batas","zh-Hant":"限值","zh-TW":"限值","ar":"الحد","hu":"Limit","el":"Όριο","nl":"Grens","pl":"Limit","fi":"Raja","sv":"Gräns","km":"កំណត់"},"Sleep curve only available in cool or heat mode":{"en":"Sleep curve is not available in current mode","zh-Hans":"睡眠曲线无法在当前模式下使用","fr":"Sleep curve n'est pas pris en charge dans ce mode","ja":"現在のモードでは、睡眠曲線はサポートしていません。","it":"Sleep curve non è supportato in questa modalità.","es":"Sleep curve no es soportado en este modo","pt":"Curva de sono não é suportado neste modo","de":"Sleep curve ist in diesem Modus nicht unterstützt.","ru":"Кривая сна доступна только в режиме охлаждения или обогрева","vi":"Chế độ giấc ngủ không được hỗ trợ cho Làm lạnh hay Sưởi ấm","th":"ไม่รองรับโหมด Sleep curve ในโหมดนี้","id":"Kurva tidur tidak didukung dalam mode ini","zh-Hant":"睡眠曲線無法在當前模式下使用","zh-TW":"睡眠曲線無法在當前模式下使用","ar":"منحنى النوم غير مدعوم في هذا الوضع","hu":"Az alvási görbe nem érhető el az aktuális üzemmódban","el":"Η καμπύλη ύπνου δεν είναι διαθέσιμη στην τρέχουσα λειτουργία","nl":"Slaapcurve is niet beschikbaar in de huidige modus","pl":"Krzywa uśpienia nie jest dostępna w bieżącym trybie","fi":"Lepokäyrä ei ole käytettävissä nykyisessä tilassa","sv":"Sömnkurva är inte tillgänglig i aktuellt läge","km":"កោង ដំណេក មិន អាច ប្រើ បាន ក្នុង របៀប បច្ចុប្បន្ន"},"Terminal barcode":{"en":"Terminal barcode","zh-Hans":"终端条形码","fr":"Code à barres terminal","ja":"ターミナルバーコード","it":"Cod. a barre term.","es":"Código de Barras Terminal","pt":"Código de barras","de":"Barcode Endgerät","ru":"Штрих-код терминала","vi":"Mã vạch trạm","th":"เทอร์มินัลบาร์โค้ด","id":"Kode bar terminal","zh-Hant":"終端條碼","zh-TW":"終端條碼","ar":"الباركود الطرفي","hu":"Terminál vonalkód","el":"Γραμμικός κώδικας τερματικού","nl":"Barcode terminal","pl":"Kod kreskowy terminala","fi":"Päätelaitteen viivakoodi","sv":"Streckkod för terminal","km":"បារកូដេ ស្ថានីយ"},"Refresh Function":{"en":"Refresh Function","zh-Hans":"刷新功能","fr":"Fonction de rafraîchissement","ja":"リフレッシュ機能","it":"Funzione di aggiornamento","es":"Función de actualización","pt":"Recarregar Informações","de":"Aktualisierungsfunktion","ru":"Функция Refresh","vi":"Chức năng Làm sạch","th":"ฟังก์ชันการรีเฟรช","id":"Segarkan Fungsi","zh-Hant":"整理功能","zh-TW":"整理功能","ar":"وظيفة التجديد","hu":"Frissítés funkció","el":"Λειτουργία ανανέωσης","nl":"Functie verversen","pl":"Funkcja odświeżania","fi":"Päivitä toiminto","sv":"Uppdatera funktion","km":"មុខងារស្រស់ថ្លា"},"Label name contains illegal characters!":{"en":"Label name contains illegal characters!","zh-Hans":"标签名称包含非法字符!","fr":"Le nom de l 'étiquette contient des caractères illégaux!","ja":"ラベル名に不正文字が含まれています！","it":"Il nome dell'etichetta contiene caratteri illegali!","es":"¡El nombre de la etiqueta contiene caracteres ilegales!","pt":"Nome do rótulo contém caracteres ilegais!","de":"Der Name des Labels enthält illegale Zeichen!","ru":"Название лэйбла содержит запрещенные символы!","vi":"Tên nhãn có ký tự không hợp lệ!","th":"ชื่อฉลากมีอักขระที่ไม่ถูกต้อง","id":"Nama label mengandung karakter yang tidak sah!","zh-Hant":"標識名稱包含非法字元!","zh-TW":"標識名稱包含非法字元!","ar":"اسم الملصق يحتوي على أحرف غير قانونية","hu":"A címke neve tiltott karaktereket tartalmaz!","el":"Το όνομα της ετικέτας περιέχει παράνομους χαρακτήρες!","nl":"Labelnaam bevat ongeldige tekens!","pl":"Nazwa etykiety zawiera niedozwolone znaki!","fi":"Tarran nimi sisältää laittomia merkkejä!","sv":"Etikettnamn innehåller otillåtna tecken!","km":"Label name មានអក្សរ ខុស ច្បាប់!"},"You can modify sleep curve in the chart":{"en":"You can modify sleep curve in the chart","zh-Hans":"您可修改图表中的睡眠曲线","fr":"Vous pouvez modifier la courbe de sommeil dans le graphique","ja":"リフレッシュ機能チャートのスリープカーブを変更することができます。","it":"Puoi modificare la curva del sonno nel grafico","es":"Puede modificar la curva de sueño en el gráfico.","pt":"Ajuste a temperatura a cada hora como desejar","de":"Sie können die Schlafkurve im Diagramm ändern","ru":"Вы можете изменить кривую сна на диаграмме","vi":"Bạn có thể điều chỉnh chế độ giấc ngủ trong sơ đồ","th":"คุณสามารถแก้ไขสถิติการนอนหลับได้ในแผนภูมินี้","id":"Anda bisa memodifikasi kurva tidur dalam grafik","zh-Hant":"您可修改圖表中的睡眠曲線","zh-TW":"您可修改圖表中的睡眠曲線","ar":"يمكن تعديل منحنى النوم في المخطط البياني","hu":"Módosíthatja az alvási görbét a táblázatban","el":"Μπορείτε να τροποποιήσετε την καμπύλη ύπνου στο διάγραμμα","nl":"Je kunt de slaapcurve in de grafiek aanpassen","pl":"Krzywą snu można modyfikować na wykresie","fi":"Voit muokata unikäyrää kaaviossa","sv":"Du kan ändra sömnkurvan i diagrammet","km":"អ្នកអាចកែប្រែខ្សែកោងដេកនៅក្នុងតារាង"},"JetCool":{"en":"CoolFlash","zh-Hans":"急速制冷","fr":"Refroidissement rapide","ja":"急冷","it":"Raffreddamento rapido","es":"Enfriamiento rapido","pt":"Resfriamento rápido","de":"Schnelles Kühlen","ru":"Быстрое охлаждение","vi":"Làm lạnh nhanh","th":"ระบายความร้อนอย่างรวดเร็ว","id":"Penyejukan pantas","zh-Hant":"急速製冷","zh-TW":"急速製冷","ar":"التبريد السريع","hu":"CoolFlash","el":"CoolFlash","nl":"CoolFlash","pl":"CoolFlash","fi":"CoolFlash","sv":"CoolFlash","km":"CoolFlash"},"On":{"en":"On","zh-Hans":"开","fr":"allumer","ja":"オンにする","it":"accendere","es":"Encender","pt":"Ligar","de":"Einschalten","ru":"ВКЛ","vi":"Bật","th":"เปิด","id":"hidupkan","zh-Hant":"開","zh-TW":"開","ar":"شغله","hu":"On","el":"Στο","nl":"Aan","pl":"Wł.","fi":"On","sv":"På","km":"នៅ លើ"},"Off":{"en":"Off","zh-Hans":"关","fr":"éteindre","ja":"消す","it":"Spegni","es":"Apagar","pt":"Desligar","de":"Ausschalten","ru":"ВЫКЛ","vi":"Tắt","th":"ปิด","id":"matikan","zh-Hant":"關","zh-TW":"關","ar":"اطفئه","hu":"Off","el":"Off","nl":"Uit","pl":"Wył.","fi":"Off","sv":"Av","km":"បិទ"},"Temperature":{"en":"Temperature","zh-Hans":"温度","fr":"Température","ja":"温度","it":"Temperatura","es":"temperatura","pt":"Temperatura","de":"Temperatur","ru":"температура","vi":"Nhiệt độ","th":"อุณหภูมิ","id":"suhu","zh-Hant":"溫度","zh-TW":"溫度","ar":"درجة الحرارة","hu":"Hőmérséklet","el":"Θερμοκρασία","nl":"Temperatuur","pl":"Temperatura","fi":"Lämpötila","sv":"Temperatur","km":"សីតុណ្ហភាព"},"Description of device":{"en":"Device Description","zh-Hans":"设备说明","fr":"Description de l'appareil","ja":"デバイスの説明","it":"Descrizione del dispositivo","es":"Descripción del dispositivo","pt":"Descrição do dispositivo","de":"Beschreibung des Geräts","ru":"Описание устройства","vi":"Mô tả thiết bị","th":"คำอธิบายของอุปกรณ์","id":"Perihalan Peranti","zh-Hant":"設備說明","zh-TW":"設備說明","ar":"وصف الجهاز","hu":"A készülék leírása","el":"Περιγραφή συσκευής","nl":"Beschrijving apparaat","pl":"Opis urządzenia","fi":"Laite Kuvaus","sv":"Enhet Beskrivning","km":"ការពិពណ៌នាឧបករណ៍"},"Firmware Update":{"en":"Firmware update","zh-Hans":"固件升级","fr":"Mise à jour du firmware","ja":"ファームウェアのアップデート","it":"Aggiornamento del firmware","es":"Actualización del firmware","pt":"Atualização de Firmware","de":"Firmware Update","ru":"Обновление прошивки","vi":"Cập nhật phần mềm","th":"อัพเดตเฟิร์มแวร์","id":"Kemas Kini Perisian Tegar","zh-Hant":"硬件升級","zh-TW":"硬件升級","ar":"ترقية البرامج الثابتة","hu":"Firmware frissítés","el":"Ενημέρωση υλικολογισμικού","nl":"Firmware bijwerken","pl":"Aktualizacja oprogramowania sprzętowego","fi":"Firmware-päivitys","sv":"Uppdatering av firmware","km":"ការ ធ្វើ បច្ចុប្បន្ន ភាព Firmware"},"Firmware update automatically":{"en":"Firmware update automatically","zh-Hans":"自动固件升级","fr":"Mise à jour automatique du firmware","ja":"自動ファームウェアアップグレード","it":"Aggiornamento automatico del firmware","es":"Actualización automática de firmware","pt":"Atualização automática de firmware","de":"Automatisches Firmware-Upgrade","ru":"Автоматическое обновление прошивки","vi":"Nâng cấp phần mềm tự động","th":"อัพเกรดเฟิร์มแวร์อัตโนมัติ","id":"Peningkatan perisian tegar automatik","zh-Hant":"自動固件升級","zh-TW":"自動固件升級","ar":"ترقية تلقائية للبرامج الثابتة","hu":"Firmware frissítés automatikusan","el":"Αυτόματη ενημέρωση υλικολογισμικού","nl":"Firmware-update automatisch","pl":"Automatyczna aktualizacja oprogramowania sprzętowego","fi":"Laiteohjelmiston päivitys automaattisesti","sv":"Firmware uppdateras automatiskt","km":"Firmware update ដោយស្វ័យប្រវត្តិ"},"Device firmware will update to latest version automatically":{"en":"Device firmware will update to latest version automatically","zh-Hans":"设备固件将自动更新到最新版本","fr":"Le micrologiciel de l'appareil sera automatiquement mis à jour vers la dernière version","ja":"デバイスのファームウェアは自動的に最新バージョンに更新されます","it":"Il firmware del dispositivo si aggiornerà automaticamente all'ultima versione","es":"El firmware del dispositivo se actualizará automáticamente a la última versión","pt":"O firmware do dispositivo será atualizado para a versão mais recente automaticamente","de":"Die Geräte-Firmware wird automatisch auf die neueste Version aktualisiert","ru":"Прошивка устройства автоматически обновится до последней версии","vi":"Phần mềm thiết bị sẽ tự động cập nhật lên phiên bản mới nhất","th":"เฟิร์มแวร์ของอุปกรณ์จะอัปเดตเป็นเวอร์ชันล่าสุดโดยอัตโนมัติ","id":"Perisian tegar peranti akan dikemas kini kepada versi terkini secara automatik","zh-Hant":"設備固件將自動更新到最新版本","zh-TW":"設備固件將自動更新到最新版本","ar":"سيتم تحديث البرامج الثابتة للجهاز إلى أحدث إصدار تلقائيًا","hu":"A készülék firmware-je automatikusan frissül a legújabb verzióra","el":"Το υλικολογισμικό της συσκευής θα ενημερωθεί αυτόματα στην τελευταία έκδοση","nl":"De firmware van het apparaat wordt automatisch bijgewerkt naar de nieuwste versie","pl":"Oprogramowanie sprzętowe urządzenia zostanie automatycznie zaktualizowane do najnowszej wersji","fi":"Laitteen laiteohjelmisto päivittyy uusimpaan versioon automaattisesti","sv":"Enhetens firmware uppdateras automatiskt till den senaste versionen","km":"Device firmware នឹង update ទៅកំណែចុងក្រោយដោយស្វ័យប្រវត្តិ"},"Latest version installed":{"en":"Latest version installed","zh-Hans":"已安装最新版本","fr":"La dernière version est installée","ja":"最新バージョンがインストールされています","it":"L'ultima versione è installata","es":"La última versión está instalada","pt":"A versão mais recente está instalada","de":"Die neuste Version ist installiert","ru":"Установлена ​​последняя версия","vi":"Phiên bản mới nhất đã được cài đặt","th":"ติดตั้งเวอร์ชันล่าสุดแล้ว","id":"Versi terkini dipasang","zh-Hant":"已安裝最新版本","zh-TW":"已安裝最新版本","ar":"تم تثبيت أحدث إصدار","hu":"A legújabb verzió telepítve","el":"Εγκατεστημένη η τελευταία έκδοση","nl":"Laatste versie geïnstalleerd","pl":"Zainstalowano najnowszą wersję","fi":"Uusin versio asennettu","sv":"Senaste versionen installerad","km":"កំណែ ចុងក្រោយ បំផុត ដែល បាន ដំឡើង"},"The water is full":{"en":"The condensate drain pan is full","zh-Hans":"水箱水已满","fr":"Le bac de récupération des condensats est plein","ja":"ドレンパンが満杯になっている","it":"La vaschetta di scarico della condensa è piena","es":"La bandeja de drenaje de condensado está llena","pt":"A bandeja de drenagem de condensado está cheia","de":"Die Kondensatwanne ist voll","ru":"Поддон для слива конденсата переполнен","vi":"Nước đã đầy","th":"ถาดระบายน้ำคอนเดนเสทเต็ม","id":"Panci pembuangan kondensat penuh","zh-Hant":"水箱水已滿","zh-TW":"水箱水已滿","ar":"وعاء تصريف التكثيف ممتلئ","hu":"A kondenzvíz-elvezető tálca megtelt","el":"Η λεκάνη αποστράγγισης συμπυκνωμάτων είναι γεμάτη","nl":"De condensaatopvangbak is vol","pl":"Taca skroplin jest pełna","fi":"Kondenssiveden tyhjennysastia on täynnä","sv":"Kondensatavloppstråget är fullt","km":"បន្ទះ បង្ហូរ ទឹក កុងឌិន ពេញ"},"sleep_curve_on":{"en":"On","zh-Hans":"开","fr":"allumer","ja":"オンにする","it":"accendere","es":"Encender","pt":"Ligado","de":"einschalten","ru":"включи","vi":"Bật","th":"เปิด","id":"hidupkan","zh-Hant":"開","zh-TW":"開","ar":"شغله","hu":"A  oldalon.","el":"Στο","nl":"Op","pl":"Wł.","fi":"Päällä","sv":"På","km":"នៅ លើ"},"sleep_curve_off":{"en":"Off","zh-Hans":"关","fr":"éteindre","ja":"消す","it":"Spegni","es":"apagar","pt":"Desligado","de":"ausschalten","ru":"выключить","vi":"Tắt","th":"ปิด","id":"matikan","zh-Hant":"關","zh-TW":"關","ar":"اطفئه","hu":"Ki","el":"Off","nl":"Uit","pl":"Wył.","fi":"Pois päältä","sv":"Av","km":"បិទ"},"Wind blows upwad or downward to avoid direct wind on you":{"en":"Wind blows upwad or downward to avoid direct wind on you","zh-Hans":"风向上或向下吹，以避免风直接吹到您身上","fr":"Le vent souffle vers le haut ou vers le bas pour éviter le vent direct sur vous","ja":"風は上向きまたは下向きに吹くので、風が直接当たるのを防ぎます。","it":"Il vento soffia verso l'alto o verso il basso per evitare il vento diretto su di te","es":"El viento sopla hacia arriba o hacia abajo para evitar el viento directo sobre usted.","pt":"O vento sopra para cima ou para baixo para evitar o vento direto em você","de":"Wind bläst nach oben oder unten, um direkten Wind zu vermeiden","ru":"Ветер дует вверх или вниз, чтобы избежать прямого ветра на вас","vi":"Gió thổi lên hoặc xuống để tránh gió trực tiếp vào bạn","th":"ลมพัดขึ้นหรือลงเพื่อหลีกเลี่ยงลมโดยตรง","id":"Angin bertiup ke atas atau ke bawah untuk menghindari angin langsung pada Anda","zh-Hant":"風向上或向下吹，以避免風直接吹到您身上","zh-TW":"風向上或向下吹，以避免風直接吹到您身上","ar":"تهب الرياح لأعلى أو لأسفل لتجنب الرياح المباشرة عليك","hu":"A szél felfelé vagy lefelé fúj, hogy ne érje Önt közvetlenül a szél","el":"Ο άνεμος πνέει προς τα πάνω ή προς τα κάτω για να αποφύγετε τον άμεσο άνεμο πάνω σας","nl":"Wind waait opwaarts of neerwaarts om directe wind op u te vermijden","pl":"Wiatr wieje w górę lub w dół, aby uniknąć bezpośredniego działania wiatru na użytkownika","fi":"Tuuli puhaltaa ylös- tai alaspäin, jotta vältät suoran tuulen osumisen sinuun.","sv":"Vinden blåser uppåt eller nedåt för att undvika direkt vind mot dig","km":"ខ្យល់ បក់ ឡើង លើ ឬ ចុះ ក្រោម ដើម្បី ចៀស វាង ខ្យល់ ដោយ ផ្ទាល់ លើ អ្នក"},"FP_is_not_available_in_current_mode":{"en":"FP is not available in current mode","zh-Hans":"该模式下不支持防冻功能","fr":"La fonction antigel n'est pas prise en charge dans ce mode","ja":"このモードではフロスト保護機能はサポートされていません","it":"La funzione antigelo non è supportata in questa modalità","es":"La función anticongelante no es compatible con este modo","pt":"A função anticongelante não é suportada neste modo","de":"Die Frostschutzfunktion wird in diesem Modus nicht unterstützt","ru":"Функция защиты от замерзания в этом режиме не поддерживается","vi":"Chức năng FP không được hỗ trợ trong chế độ này","th":"โหมดนี้ไม่รองรับฟังก์ชันป้องกันการแข็งตัว","id":"Fungsi antibeku tidak disokong dalam mod ini","zh-Hant":"該機型下不支持防凍功能","zh-TW":"該機型下不支持防凍功能","ar":"وظيفة مضاد التجمد غير مدعومة في هذا الوضع","hu":"A fagyvédelem nem érhető el az aktuális üzemmódban","el":"Το FP δεν είναι διαθέσιμο στην τρέχουσα λειτουργία","nl":"FP is niet beschikbaar in huidige modus","pl":"FP nie jest dostępny w bieżącym trybie","fi":"FP ei ole käytettävissä nykyisessä tilassa","sv":"FP är inte tillgängligt i aktuellt läge","km":"FP មិន មាន ក្នុង របៀប បច្ចុប្បន្ន"},"FP_is_not_available_in_SleepCurve":{"en":"FP is not available in SleepCurve","zh-Hans":"睡眠曲线不支持防冻","fr":"La courbe de sommeil ne prend pas en charge la protection contre le gel","ja":"睡眠曲線はフロスト保護をサポートしていません","it":"La curva di riposo non supporta la protezione antigelo","es":"La curva de sueño no admite la protección contra las heladas","pt":"A curva do sono não suporta anticongelante","de":"Die Schlafkurve unterstützt keinen Frostschutz","ru":"Кривая сна не поддерживает защиту от замерзания","vi":"Chế độ giấc ngủ không hỗ trợ bảo vệ sương giá","th":"สถิติการนอนหลับไม่รองรับในโหมดการป้องกันน้ำค้างแข็ง","id":"Lengkung tidur tidak menyokong antibeku","zh-Hant":"睡眠橢圓不支持防凍","zh-TW":"睡眠橢圓不支持防凍","ar":"منحنى النوم لا يدعم التجمد","hu":"A fagyvédelem nem áll rendelkezésre az alvó üzemmódban","el":"Το FP δεν είναι διαθέσιμο στην καμπύλη ύπνου","nl":"FP is niet beschikbaar in SleepCurve","pl":"FP nie jest dostępny w trybie SleepCurve","fi":"FP ei ole käytettävissä SleepCurve-tilassa","sv":"FP är inte tillgängligt i SleepCurve","km":"FP មិន មាន នៅ SleepCurve ទេ"},"This_function_can_only_be_used_in_cooling_mode":{"en":"This function is not available in current mode","zh-Hans":"该功能在当前模式下不可用","fr":"Cette fonction n'est pas disponible dans le mode actuel","ja":"この機能は現在のモードでは使用できません","it":"Questa funzione non è disponibile nella modalità corrente","es":"Esta función no está disponible en el modo actual","pt":"Esta função não está disponível no modo atual","de":"Diese Funktion ist im aktuellen Modus nicht verfügbar","ru":"Эта функция недоступна в текущем режиме","vi":"Chức năng này không khả dụng ở chế độ hiện tại","th":"ฟังก์ชันนี้ไม่พร้อมใช้งานในโหมดปัจจุบัน","id":"Fungsi ini tidak tersedia dalam mod semasa","zh-Hant":"該功能在當前模式下不可用","zh-TW":"該功能在當前模式下不可用","ar":"هذه الوظيفة غير متاحة في الوضع الحالي","hu":"Ez a funkció nem elérhető az aktuális üzemmódban","el":"Αυτή η λειτουργία δεν είναι διαθέσιμη στην τρέχουσα λειτουργία","nl":"Deze functie is niet beschikbaar in de huidige modus","pl":"Ta funkcja nie jest dostępna w bieżącym trybie","fi":"Tämä toiminto ei ole käytettävissä nykyisessä tilassa","sv":"Denna funktion är inte tillgänglig i aktuellt läge","km":"មុខងារ នេះ មិន មាន ក្នុង របៀប បច្ចុប្បន្ន ទេ"},"Gear_is_not_available_in_current_mode":{"en":"Gear is not available in current mode","zh-Hans":"当前模式下不支持功率调整","fr":"Le réglage de la puissance n'est pas pris en charge dans le mode actuel","ja":"現在のモードでは、パワー調整に対応していません","it":"La regolazione della potenza non è supportata nella modalità corrente","es":"Le réglage de la puissance n'est pas pris en charge dans le mode actuel","pt":"O ajuste da potência não é suportado no modo atual","de":"Die Leistungsanpassung wird im aktuellen Modus nicht unterstützt.","ru":"Регулировка мощности не поддерживается в текущем режиме","vi":"Chức năng tiết kiệm năng lượng Gear không được hỗ trợ ở chế độ hiện tại","th":"ไม่รองรับการปรับกำลังในโหมดปัจจุบัน","id":"Pelarasan kuasa tidak disokong dalam mod semasa","zh-Hant":"當前機型下不支持功率調整","zh-TW":"當前機型下不支持功率調整","ar":"تعديل الطاقة غير مدعوم في الوضع الحالي","hu":"A sebességváltó nem elérhető az aktuális üzemmódban","el":"Η λειτουργία Gear δεν είναι διαθέσιμη στην τρέχουσα λειτουργία","nl":"Versnelling is niet beschikbaar in de huidige modus","pl":"Bieg nie jest dostępny w bieżącym trybie","fi":"Vaihde ei ole käytettävissä nykyisessä tilassa","sv":"Växel är inte tillgänglig i aktuellt läge","km":"Gear មិន អាច ប្រើ បាន ក្នុង របៀប បច្ចុប្បន្ន"},"FreshAir":{"en":"Fresh Air","zh-Hans":"新风","fr":"Air frais","ja":"新鮮な空気","it":"Aria fresca","es":"Aire fresco","pt":"Ar fresco","de":"Frische Luft","ru":"Свежий воздух","vi":"Không khí trong lành","th":"อากาศบริสุทธิ์","id":"Udara segar","zh-Hant":"新風","zh-TW":"新風","ar":"رياح جديدة","hu":"Friss levegő","el":"Φρέσκος αέρας","nl":"Verse lucht","pl":"Świeże powietrze","fi":"Raikas ilma","sv":"Frisk luft","km":"ខ្យល់អាកាសបរិសុទ្ធ"},"WindDirection":{"en":"Direction","zh-Hans":"风向可视化","fr":"Visualisation du vent","ja":"風の可視化","it":"Visualizzazione del vento","es":"Visualización del viento","pt":"Direção do Vento","de":"Wind Visualisierung","ru":"Настройка жалюзи","vi":"Hình ảnh hóa gió","th":"การแสดทิศทางลม","id":"Visualisasi Angin","zh-Hant":"風向可視化","zh-TW":"風向可視化","ar":"تصور اتجاه الرياح","hu":"Irány","el":"Κατεύθυνση","nl":"Richting","pl":"Kierunek","fi":"Suunta","sv":"Riktning","km":"ទិស ដៅ"},"WindDirectionUd":{"en":"Direction","zh-Hans":"风向可视化","fr":"Visualisation du vent","ja":"風の可視化","it":"Visualizzazione del vento","es":"Visualización del viento","pt":"Direção do Vento","de":"Wind Visualisierung","ru":"Настройка жалюзи","vi":"Hình ảnh hóa gió","th":"การแสดทิศทางลม","id":"Visualisasi Angin","zh-Hant":"風向可視化","zh-TW":"風向可視化","ar":"تصور اتجاه الرياح","hu":"Irány","el":"Κατεύθυνση","nl":"Richting","pl":"Kierunek","fi":"Suunta","sv":"Riktning","km":"ទិស ដៅ"},"WindDirectionLr":{"en":"Direction","zh-Hans":"风向可视化","fr":"Visualisation du vent","ja":"風の可視化","it":"Visualizzazione del vento","es":"Visualización del viento","pt":"Direção do Vento","de":"Wind Visualisierung","ru":"Настройка жалюзи","vi":"Hình ảnh hóa gió","th":"การแสดทิศทางลม","id":"Visualisasi Angin","zh-Hant":"風向可視化","zh-TW":"風向可視化","ar":"تصور اتجاه الرياح","hu":"Irány","el":"Κατεύθυνση","nl":"Richting","pl":"Kierunek","fi":"Suunta","sv":"Riktning","km":"ទិស ដៅ"},"WindSwing":{"en":"Wind Swing","zh-Hans":"摆风","fr":"Swing du vent","ja":"ウィンドスイング","it":"Altalena del vento","es":"Columpio del viento","pt":"Balanço do Vento","de":"Windschaukel","ru":"Ветер Качели","vi":"Đảo gió","th":"ชิงช้าลม","id":"Ayunan Angin","zh-Hant":"擺風","zh-TW":"擺風","ar":"سوينغ الرياح","hu":"Szél lengés","el":"Ταλάντευση ανέμου","nl":"Wind Schommeling","pl":"Huśtawka wiatru","fi":"Tuulen heilunta","sv":"Vindens svängning","km":"ខ្យល់ បក់ បោក"},"TwinsType":{"en":"Twins Type","zh-Hans":"从机四向摆风","fr":"Balancement du vent dans quatre directions depuis la machine","ja":"本体からの4方向風力スイング","it":"Oscillazione del vento a quattro vie dalla macchina","es":"Balanceo del viento en cuatro direcciones desde la máquina","pt":"Vento oscilante de dupla direção","de":"Vierfacher Windschwung aus der Maschine","ru":"Четырехсторонние качели от машины","vi":"TwinsType","th":"สวิงสี่ทิศทางจากตัวเครื่อง","id":"Hayunan empat hala dari mesin","zh-Hant":"從機四向擺風","zh-TW":"從機四向擺風","ar":"أربعة اتجاهات تأرجح من الجهاز","hu":"Ikrek Típus","el":"Τύπος δίδυμων","nl":"Tweelingen Type","pl":"Typ bliźniaczy","fi":"Kaksoset Tyyppi","sv":"Tvillingar Typ","km":"ប្រភេទកូនភ្លោះ"},"FourTheWind":{"en":"Four The Wind","zh-Hans":"主机四向摆风","fr":"Quatre le vent la machine principale","ja":"本体4方向風力スイング","it":"Oscillazione del vento a quattro vie della macchina principale","es":"Oscilación del viento en cuatro direcciones de la máquina principal","pt":"Vento oscilante de quatro direções","de":"Vierfache Winddrehung der Hauptmaschine","ru":"Четырехстороннее качание ветра основной машины","vi":"FourTheWind","th":"เจ้าบ้านสวิงสี่ทาง","id":"Anjurkan hayunan empat hala","zh-Hant":"主機四向擺風","zh-TW":"主機四向擺風","ar":"تأرجح رباعي الاتجاهات","hu":"Négy A szél","el":"Τέσσερις Ο άνεμος","nl":"Vier De Wind","pl":"Cztery Wiatr","fi":"Neljä Tuuli","sv":"Fyra Vinden","km":"ខ្យល់ ៤"},"Up and down":{"en":"Up and down","zh-Hans":"上下","fr":"En haut et en bas","ja":"上・下","it":"Su e giù","es":"Arriba y abajo","pt":"Acima e abaixo","de":"Auf und ab","ru":"Вверх и вниз","vi":"Lên và xuống","th":"ขึ้นและลง","id":"atas dan bawah","zh-Hant":"上下","zh-TW":"上下","ar":"اعلى واسفل","hu":"Fel és le","el":"Πάνω και κάτω","nl":"Omhoog en omlaag","pl":"Góra i dół","fi":"Ylös ja alas","sv":"Upp och ner","km":"ឡើង ចុះ ក្រោម"},"Left and right":{"en":"Left and right","zh-Hans":"左右","fr":"Gauche et droite","ja":"左右","it":"Left and right","es":"Izquierda y derecha","pt":"Esquerda e direita","de":"Links und rechts","ru":"Слева и справа","vi":"Trái và Phải","th":"ซ้ายและขวา","id":"kiri dan kanan","zh-Hant":"左右","zh-TW":"左右","ar":"حول","hu":"Balra és jobbra","el":"Αριστερά και δεξιά","nl":"Links en rechts","pl":"W lewo i w prawo","fi":"Vasemmalle ja oikealle","sv":"Vänster och höger","km":"ឆ្វេង និង ស្តាំ"},"Master":{"en":"Main device","zh-Hans":"主机","fr":"Appareil principal","ja":"メインデバイス","it":"Dispositivo principale","es":"Dispositivo principal","pt":"Dispositivo principal","de":"Hauptgerät","ru":"Основное устройство","vi":"Thiết bị chính","th":"อุปกรณ์หลัก","id":"Peranti utama","zh-Hant":"主機","zh-TW":"主機","ar":"الجهاز الرئيسي","hu":"Fő eszköz","el":"Κύρια συσκευή","nl":"Hoofdapparaat","pl":"Urządzenie główne","fi":"Päälaite","sv":"Huvudsaklig enhet","km":"ឧបករណ៍មេ"},"Slave":{"en":"Attributive device","zh-Hans":"从机","fr":"Appareil attributif","ja":"アトリビューションデバイス","it":"Dispositivo attributivo","es":"Dispositivo atributivo","pt":"Dispositivo atributivo","de":"Attributives Gerät","ru":"Атрибутивное устройство","vi":"Thiết bị thuộc tính","th":"อุปกรณ์แสดงที่มา","id":"Peranti atributif","zh-Hant":"從機","zh-TW":"從機","ar":"جهاز الإسناد","hu":"Attributív eszköz","el":"Αποδοτική συσκευή","nl":"Attributief apparaat","pl":"Urządzenie przypisujące","fi":"Attribuuttinen laite","sv":"Attributiv enhet","km":"ឧបករណ៍ attributive"},"Share":{"en":"Share","zh-Hans":"分享","fr":"Partager","ja":"シェア","it":"Condividi","es":"Compartir","pt":"Compartilhar","de":"Teilen Sie","ru":"Поделиться","vi":"Chia sẻ","th":"แบ่งปัน","id":"Bagikan","zh-Hant":"分享","zh-TW":"分享","ar":"شارك","hu":"Share","el":"Μοιραστείτε το","nl":"Delen","pl":"Udział","fi":"Jaa","sv":"Dela","km":"ចែករំលែក"},"Delete fail":{"en":"Delete fail","zh-Hans":"删除失败","fr":"Échec de la suppression","ja":"削除失敗","it":"Elimina fallita","es":"El fallo Fail","pt":"Defeito","de":"Geschirrspüler Fail","ru":"Удалить сбой","vi":"Xóa không thành công","th":"ลบล้มเหลว","id":"Hapus gagal","zh-Hant":"刪除失敗","zh-TW":"刪除失敗","ar":"حذف تفشل","hu":"Hiba törlése","el":"Διαγραφή αποτυχίας","nl":"Storing verwijderen","pl":"Usuń błąd","fi":"Poista epäonnistuminen","sv":"Radera fel","km":"បរាជ័យ លុប"},"Wind blows upward to advoid direct wind on user":{"en":"Wind blows upward to advoid direct wind on user.","zh-Hans":"风向上吹，避免风直接吹到用户身上","fr":"Le vent souffle vers le haut pour éviter le vent direct sur l'utilisateur.","ja":"風は上向きに吹き出し、使用者に直接風が当たるのを防ぎます。","it":"Il vento soffia verso l'alto per evitare il vento diretto sull'utente.","es":"El viento sopla hacia arriba para dirigir el viento hacia el usuario.","pt":"O vento sopra para cima para evitar vento direto no usuário.","de":"Wind bläst nach oben, um direkten Wind auf den Benutzer zu übertragen.","ru":"Ветер дует вверх, чтобы вызвать прямой ветер на пользователя.","vi":"Gió thổi hướng lên trên để tránh gió thổi trực tiếp vào người sử dụng.","th":"ลมพัดขึ้นด้านบนเพื่อไม่ให้ลมปะทะผู้ใช้โดยตรง","id":"Angin bertiup ke atas untuk menghindari angin langsung pada pengguna.","zh-Hant":"風向上吹，避免風直接吹到用戶身上","zh-TW":"風向上吹，避免風直接吹到用戶身上","ar":"تهب الرياح لأعلى لتجنب الرياح المباشرة على المستخدم.","hu":"A szél felfelé fúj, hogy elkerülje a felhasználóra irányuló közvetlen szelet.","el":"Ο άνεμος πνέει προς τα πάνω για να αποφεύγεται ο άμεσος άνεμος στο χρήστη.","nl":"Wind blaast omhoog om directe wind op de gebruiker te voorkomen.","pl":"Wiatr wieje w górę, aby uniknąć bezpośredniego wiatru na użytkownika.","fi":"Tuuli puhaltaa ylöspäin välttääkseen suoraa tuulta käyttäjään.","sv":"Vinden blåser uppåt för att undvika direkt vind på användaren.","km":"ខ្យល់ បក់ ឡើង ទៅ លើ ខ្យល់ ដោយ ផ្ទាល់ នៅ លើ អ្នក ប្រើ ។"},"Wind blows mildly":{"en":"Wind blows mildly","zh-Hans":"微风吹拂","fr":"Le vent souffle légèrement","ja":"風は穏やかに吹く","it":"Il vento soffia lievemente","es":"El viento sopla suavemente","pt":"O vento sopra levemente","de":"Der Wind weht mild","ru":"Ветер дует слабый","vi":"Gió thổi nhẹ","th":"สายลมพัด","id":"Angin sepoi-sepoi","zh-Hant":"微風拂吹","zh-TW":"微風拂吹","ar":"ضربات النسيم","hu":"A szél enyhén fúj","el":"Ο άνεμος φυσάει ήπια","nl":"Wind waait mild","pl":"Wiatr wieje łagodnie","fi":"Tuuli puhaltaa lievästi","sv":"Vinden blåser svagt","km":"ខ្យល់ បក់ ទន់"},"Windless":{"en":"Windless","zh-Hans":"无风","fr":"Sans vent","ja":"無風","it":"Senza vento","es":"Sin viento","pt":"Sem vento","de":"Windlos","ru":"Безветренный","vi":"Không có gió","th":"ไม่มีลม","id":"Tidak ada angin","zh-Hant":"無風","zh-TW":"無風","ar":"لا رياح","hu":"Szélcsend","el":"Άνεμος χωρίς αέρα","nl":"Windstil","pl":"Bezwietrznie","fi":"Tuuleton","sv":"Vindlös","km":"ខ្យល់គ្មានខ្យល់"},"Distributes a stream of air to a wider area vertically":{"en":"Distributes a stream of air to a wider area vertically","zh-Hans":"将气流垂直分布到更大的范围","fr":"Distribue un flux d'air sur une zone plus large verticalement","ja":"垂直方向により広い範囲に気流を送ることができます。","it":"Distribuisce un flusso d'aria ad un'area più ampia in verticale","es":"Distribuye una corriente de aire a un área más amplia verticalmente","pt":"Distribui um fluxo de ar para uma área maior verticalmente","de":"Verteilt einen Luftstrom vertikal auf eine größere Fläche","ru":"Распространяет поток воздуха на большую площадь по вертикали","vi":"Phân phối luồng không khí theo chiều dọc trên một khu vực lớn hơn","th":"กระจายลมในแนวตั้งเหนือพื้นที่ขนาดใหญ่","id":"Mendistribusikan aliran udara secara vertikal ke area yang lebih luas","zh-Hant":"將終止垂直分佈到更大的範圍","zh-TW":"將終止垂直分佈到更大的範圍","ar":"يوزع تدفق الهواء عموديًا على مساحة أكبر","hu":"A légáramlatot függőlegesen szélesebb területre terjeszti el.","el":"Διανέμει ένα ρεύμα αέρα σε μια ευρύτερη περιοχή κάθετα","nl":"Verdeelt een luchtstroom over een groter verticaal gebied","pl":"Rozprowadza strumień powietrza na większy obszar w pionie","fi":"Jakaa ilmavirran laajemmalle alueelle pystysuoraan.","sv":"Fördelar en luftström till ett större område vertikalt","km":"បែងចែកប្រឡាយខ្យល់ទៅតំបន់ធំទូលាយបញ្ឈរ"},"Distributes a stream of air to a wider area horizontally":{"en":"Distributes a stream of air to a wider area horizontally","zh-Hans":"将气流水平分布到更大的范围","fr":"Distribue un flux d'air sur une zone plus large à l'horizontale","ja":"水平方向により広い範囲に風を送ることができます。","it":"Distribuisce un flusso d'aria ad un'area più ampia in orizzontale","es":"Distribuye una corriente de aire a un área más amplia horizontalmente","pt":"Distribui um fluxo de ar para uma área maior horizontalmente","de":"Verteilt einen Luftstrom auf eine größere Fläche in horizontaler Richtung","ru":"Распределяет поток воздуха на большую площадь по горизонтали","vi":"Phân phối luồng không khí theo chiều ngang trên một khu vực lớn hơn","th":"กระจายลมในแนวนอนเหนือพื้นที่ขนาดใหญ่","id":"Distribusikan aliran udara secara horizontal ke area yang lebih luas","zh-Hant":"將終止水平擴展到更大的範圍","zh-TW":"將終止水平擴展到更大的範圍","ar":"توزيع تدفق الهواء أفقيًا على مساحة أكبر","hu":"Vízszintesen szélesebb területre teríti a légáramot","el":"Διανέμει ρεύμα αέρα σε ευρύτερη περιοχή οριζόντια","nl":"Verdeelt een luchtstroom horizontaal over een groter gebied","pl":"Rozprowadza strumień powietrza na większy obszar w poziomie","fi":"Jakaa ilmavirran laajemmalle alueelle vaakasuunnassa.","sv":"Fördelar en luftström till ett större område horisontellt","km":"បែងចែកប្រឡាយខ្យល់ទៅតំបន់ធំទូលាយមួយ ផ្តេក"},"Auto gear control to save energy":{"en":"Auto gear control to save energy","zh-Hans":"自动调节频率，节约能源","fr":"Contrôle automatique de la vitesse pour économiser l'énergie","ja":"オートギヤーコントロールで省エネ","it":"Controllo automatico della marcia per risparmiare energia","es":"Control automático de la marcha para ahorrar energía","pt":"Controle automático para economizar energia","de":"Automatische Getriebesteuerung zum Energiesparen","ru":"Автоматическое управление производительностью для экономии энергии","vi":"Tự động điều chỉnh gear để tiết kiệm năng lượng","th":"ปรับความถี่อัตโนมัติเพื่อประหยัดพลังงาน","id":"Secara otomatis menyesuaikan frekuensi untuk menghemat energi","zh-Hant":"自動調節頻率，節省能源","zh-TW":"自動調節頻率，節省能源","ar":"ضبط التردد تلقائيًا لتوفير الطاقة","hu":"Automatikus sebességszabályozás az energiatakarékosság érdekében","el":"Αυτόματος έλεγχος ταχυτήτων για εξοικονόμηση ενέργειας","nl":"Automatische versnellingsregeling om energie te besparen","pl":"Automatyczne sterowanie biegiem w celu oszczędzania energii","fi":"Automaattinen vaihteen säätö energian säästämiseksi","sv":"Automatisk växling för att spara energi","km":"ឧបករណ៍ ស្វ័យ ប្រវត្តិ ត្រួតពិនិត្យ ដើម្បី សន្សំសំចៃ ថាមពល"},"Customize the set temperature for 8 hours while you sleep":{"en":"Customize the set temperature for 8 hours while you sleep","zh-Hans":"通过设置目标温度来定制舒适睡眠","fr":"Personnalisez un sommeil confortable en définissant une température cible","ja":"目標温度を設定し、快適な眠りをカスタマイズ。","it":"Personalizzazione del sonno confortevole grazie all'impostazione della temperatura target","es":"Personaliza un sueño confortable ajustando la temperatura objetivo","pt":"Personalize a temperatura definida e os tempos de sono","de":"Angenehmen Schlaf durch Einstellung der Zieltemperatur","ru":"Настройте комфортный сон, задав целевую температуру","vi":"Tùy chỉnh nhiệt độ cài đặt trong 8 tiếng khi bạn ngủ","th":"ปรับแต่งการนอนหลับให้สบายด้วยการตั้งค่าอุณหภูมิ 8 ชั่วโมง","id":"Sesuaikan tidur yang nyaman dengan mengatur suhu target","zh-Hant":"通過設置目標溫度來舒適定制睡眠","zh-TW":"通過設置目標溫度來舒適定制睡眠","ar":"قم بتخصيص نوم مريح من خلال تحديد درجة الحرارة المستهدفة","hu":"A beállított hőmérséklet testreszabása 8 órán keresztül alvás közben","el":"Προσαρμόστε τη ρυθμισμένη θερμοκρασία για 8 ώρες ενώ κοιμάστε","nl":"Pas de ingestelde temperatuur aan voor 8 uur terwijl je slaapt","pl":"Ustawienie temperatury na 8 godzin podczas snu","fi":"Mukauttaa asetettua lämpötilaa 8 tunnin ajan nukkuessasi","sv":"Anpassa den inställda temperaturen i 8 timmar medan du sover","km":"ប្ដូរ សីតុណ្ហភាព ដែល បាន កំណត់ តាម បំណង ៨ ម៉ោង ខណៈ ពេល អ្នក គេង"},"Customize the set temperature and sleep times":{"en":"Customize the set temperature and sleep times","zh-Hans":"通过设置目标温度来定制舒适睡眠","fr":"Personnaliser la température et la durée du sommeil","ja":"カスタム設定の温度と睡眠時間","it":"Personalizza la temperatura impostata e i tempi di sonno","es":"Configuración personalizada de la temperatura y el tiempo de sueño","pt":"Personalize a temperatura definida e os tempos de sono","de":"Passen Sie die eingestellte Temperatur und Schlafzeiten an","ru":"Выберите условия для комфортного сна","vi":"Tùy chỉnh cài đặt nhiệt độ và thời gian ngủ","th":"กำหนดอุณหภูมิและเวลาการนอนสำหรับการตั้งค่าที่กำหนดเอง","id":"Sesuaikan tidur yang nyaman dengan mengatur suhu target","zh-Hant":"通過設置目標溫度來舒適定制睡眠","zh-TW":"通過設置目標溫度來舒適定制睡眠","ar":"تخصيص إعدادات درجة الحرارة و وقت النوم","hu":"A beállított hőmérséklet és alvási idő testreszabása","el":"Προσαρμόστε τη ρυθμισμένη θερμοκρασία και τις ώρες ύπνου","nl":"De ingestelde temperatuur en slaaptijden aanpassen","pl":"Możliwość dostosowania ustawionej temperatury i czasu snu","fi":"Mukauta asetettua lämpötilaa ja nukkumisaikoja","sv":"Anpassa inställd temperatur och sovtider","km":"ប្ដូរ តាម បំណង សីតុណ្ហភាព សំណុំ និង ពេល វេលា ដេក"},"Go to check":{"en":"Go to check","zh-Hans":"转到检查","fr":"Aller vérifier","ja":"確認に行く","it":"Vai a controllare","es":"Vaya a comprobar","pt":"Verificar","de":"Gehe zum Check","ru":"Go to check","vi":"đi kiểm tra","th":"ไปตรวจสอบ","id":"Pergi untuk memeriksa","zh-Hant":"轉到檢查","zh-TW":"轉到檢查","ar":"اذهب للتحقق","hu":"Menjen az ellenőrzéshez","el":"Πηγαίνετε στον έλεγχο","nl":"Ga naar controle","pl":"Przejdź do sprawdzania","fi":"Siirry tarkistamaan","sv":"Gå till kontroll","km":"ទៅ ពិនិត្យ មើល"},"Skip":{"en":"Skip","zh-Hans":"跳过","fr":"Sauter","ja":"スキップ","it":"Salta","es":"Saltar","pt":"Pular","de":"Überspringen","ru":"Пропустить","vi":"Bỏ qua","th":"ข้าม","id":"Langkah","zh-Hant":"跳過","zh-TW":"跳過","ar":"تخطي","hu":"Skip","el":"Παράλειψη","nl":"overslaan","pl":"Pomiń","fi":"Ohita","sv":"Hoppa över","km":"រំលង"},"Next":{"en":"Next","zh-Hans":"下一步","fr":"Suivant","ja":"次へ","it":"Avanti","es":"Siguiente","pt":"Próximo","de":"Nächster","ru":"Пропустить","vi":"Tiếp theo","th":"ถัดไป","id":"Berikutnya","zh-Hant":"下一步","zh-TW":"下一步","ar":"التالي","hu":"Következő","el":"Επόμενο","nl":"Volgende","pl":"Dalej","fi":"Seuraava","sv":"Nästa","km":"Next"},"Turn on or off the LED display on the unit.":{"en":"Control the air conditioner's LED display","zh-Hans":"打开或关闭设备上的LED显示","fr":"Allumez ou éteignez l'écran LED de l'unité","ja":"本体のLEDディスプレイの点灯・消灯","it":"Accendere o spegnere il display a LED dell'unità","es":"Enciende o apaga la pantalla LED de la unidad","pt":"Ligue ou desligue o visor LED na unidade","de":"Ein- und Ausschalten der LED-Anzeige am Gerät.","ru":"Включение и выключение светодиодного дисплея на устройстве","vi":"Bật hoặc tắt màn hình LED trên thiết bị","th":"เปิดหรือปิดจอแสดงผล LED บนอุปกรณ์","id":"Nyalakan atau matikan tampilan LED pada perangkat","zh-Hant":"打開或關閉設備上的 LED 顯示","zh-TW":"打開或關閉設備上的 LED 顯示","ar":"قم بتشغيل أو إيقاف تشغيل شاشة LED بالجهاز.","hu":"A készülék LED-kijelzőjének be- vagy kikapcsolása","el":"Έλεγχος της οθόνης LED του κλιματιστικού","nl":"De LED-display van de airconditioner bedienen","pl":"Sterowanie wyświetlaczem LED klimatyzatora","fi":"Hallitse ilmastointilaitteen LED-näyttöä","sv":"Kontrollera luftkonditioneringsenhetens LED-display","km":"ត្រួតពិនិត្យ ការ បង្ហាញ LED របស់ ម៉ាស៊ីន ត្រជាក់"},"Turn on and turn off the sound of the unit.":{"en":"Turn on and turn off the sound of the unit","zh-Hans":"打开和关闭设备的声音","fr":"Allumez et éteignez le son de l'unité","ja":"本体サウンドのON/OFF","it":"Accendere e spegnere il suono dell'unità","es":"Enciende y apaga el sonido de la unidad","pt":"Ligue e desligue o som da unidade","de":"Ein- und Ausschalten des Geräusches des Geräts","ru":"Включение и выключение звука устройства","vi":"Bật và tắt âm thanh của thiết bị","th":"เปิดและปิดเสียงของอุปกรณ์","id":"Menghidupkan dan mematikan suara perangkat","zh-Hant":"打開和關閉設備的聲音","zh-TW":"打開和關閉設備的聲音","ar":"قم بتشغيل وإيقاف صوت الجهاز.","hu":"A készülék hangjának be- és kikapcsolása","el":"Ενεργοποιήστε και απενεργοποιήστε τον ήχο της μονάδας","nl":"Het geluid van het apparaat in- en uitschakelen","pl":"Włączanie i wyłączanie dźwięku urządzenia","fi":"Kytke laitteen ääni päälle ja pois päältä","sv":"Slå på och stäng av enhetens ljud","km":"បើក ហើយ បិទ សំឡេង នៃ អង្គ ភាព"},"The fastest way to attain the desired temperature.":{"en":"The fastest way to attain the desired temperature","zh-Hans":"以最快的方式达到所需温度","fr":"Le moyen le plus rapide d'atteindre la température souhaitée","ja":"希望の温度に最速で到達","it":"Il modo più veloce per raggiungere la temperatura desiderata","es":"La forma más rápida de alcanzar la temperatura deseada","pt":"A maneira mais rápida de atingir a temperatura desejada","de":"Der schnellste Weg, die gewünschte Temperatur zu erreichen","ru":"Самый быстрый способ достижения желаемой температуры","vi":"Cách nhanh nhất để đạt được nhiệt độ mong muốn","th":"วิธีที่เร็วที่สุดในการเข้าถึงอุณหภูมิที่ต้องการ","id":"Cara tercepat untuk mencapai suhu yang diinginkan","zh-Hant":"以最快的方式達到所需溫度","zh-TW":"以最快的方式達到所需溫度","ar":"أسرع طريقة للوصول إلى درجة الحرارة المطلوبة.","hu":"A kívánt hőmérséklet elérésének leggyorsabb módja","el":"Ο γρηγορότερος τρόπος επίτευξης της επιθυμητής θερμοκρασίας","nl":"De snelste manier om de gewenste temperatuur te bereiken","pl":"Najszybszy sposób na osiągnięcie żądanej temperatury","fi":"Nopein tapa saavuttaa haluttu lämpötila","sv":"Det snabbaste sättet att uppnå önskad temperatur","km":"វិធី ដែល លឿន បំផុត ដើម្បី ទទួល បាន សីតុណ្ហភាព ដែល ចង់ បាន"},"Adjust wind direction to blow on the user.":{"en":"Adjust wind direction to blow on the user","zh-Hans":"调整风向，使其吹向用户","fr":"Réglez la direction du vent pour qu'il souffle sur l'utilisateur","ja":"風向きを調整し、風を当てないようにする","it":"Regolare la direzione del vento per evitare che soffi sull'utente","es":"Ajustar la dirección del viento para que sople sobre el usuario","pt":"Ajuste a direção do vento para soprar sobre o usuário","de":"Einstellen der Windrichtung, damit der Wind auf den Benutzer bläst","ru":"Регулировка направления ветра, чтобы он дул на пользователя","vi":"Điều chỉnh hướng gió thổi về phía người dùng","th":"ปรับทิศทางลมให้พัดเข้าหาผู้ใช้","id":"Sesuaikan arah angin sehingga bertiup ke arah pengguna","zh-Hant":"調整風向，吹向用戶","zh-TW":"調整風向，吹向用戶","ar":"اضبط اتجاه الرياح بحيث تهب باتجاه المستخدم.","hu":"A szél irányának beállítása a felhasználóra fújáshoz","el":"Ρύθμιση της κατεύθυνσης του ανέμου για να φυσήξει στο χρήστη","nl":"Windrichting aanpassen om op de gebruiker te blazen","pl":"Regulacja kierunku wiatru wiejącego na użytkownika","fi":"Säädä tuulen suunta puhaltamaan käyttäjää","sv":"Justera vindriktningen så att den blåser på användaren","km":"លៃតម្រូវ ទិស ខ្យល់ ដើម្បី ផ្លុំ លើ អ្នក ប្រើ"},"Advoid wind blowing on the user.":{"en":"Advoid wind blowing on the user","zh-Hans":"避免风吹到用户身上","fr":"Éviter que le vent ne souffle sur l'utilisateur","ja":"ユーザーに風が当たらないようにする。","it":"Evitare che il vento soffi sull'utente","es":"Evitar que el viento sople sobre el usuario.","pt":"Evitar que o vento sopre sobre o usuário.","de":"Verhindern Sie, dass der Wind auf den Benutzer bläst","ru":"Избегайте дуновения ветра на пользователя","vi":"Tránh gió thổi vào người sử dụng","th":"หลีกเลี่ยงลมที่พัดเข้าหาผู้ใช้","id":"Hindari angin bertiup ke pengguna","zh-Hant":"避免風吹到用戶身上","zh-TW":"避免風吹到用戶身上","ar":"تجنب هبوب الرياح للمستخدم","hu":"A felhasználóra fújó szél elkerülése","el":"Αποφυγή του ανέμου που φυσάει πάνω στο χρήστη","nl":"Voorkom dat de wind op de gebruiker blaast","pl":"Unikanie wiatru wiejącego na użytkownika","fi":"Vältä tuulen puhaltamista käyttäjän päälle","sv":"Förhindra att vinden blåser på användaren","km":"ខ្យល់ Advoid បក់ បោក លើ អ្នក ប្រើ"},"Keep the temperature at 8℃ and provide frost protection.":{"en":"Keep the temperature at 8℃ and provide frost protection","zh-Hans":"保持温度在8℃，提供防冻保护。","fr":"Maintenir la température à 8℃ et prévoir une protection contre le gel","ja":"8℃を維持し、霜対策をする。","it":"Mantenere la temperatura a 8℃ e garantire una protezione antigelo.","es":"Mantenga la temperatura a 8℃ y proporcione protección contra las heladas.","pt":"Manter a temperatura em 8℃ e fornecer proteção contra congelamento.","de":"Halten Sie die Temperatur bei 8℃ und sorgen Sie für Frostschutz.","ru":"Поддерживайте температуру на уровне 8℃ и обеспечьте защиту от замерзания.","vi":"Giữ nhiệt độ ở 8 ° C để bảo vệ chống sương giá.","th":"รักษาอุณหภูมิไว้ที่ 8°C เพื่อป้องกันความเย็นจัด.","id":"Pertahankan suhu pada 8°C untuk memberikan perlindungan terhadap embun beku.","zh-Hant":"保持溫度在8℃，提供防凍保護。","zh-TW":"保持溫度在8℃，提供防凍保護。","ar":"حافظ على درجة الحرارة عند 8 درجات مئوية لتوفير الحماية من الصقيع.","hu":"A hőmérséklet 8 ℃-on tartása és fagyvédelem biztosítása","el":"Διατήρηση της θερμοκρασίας στους 8 ℃ και παροχή προστασίας από τον παγετό","nl":"De temperatuur op 8℃ houden en vorstbescherming bieden","pl":"Utrzymywanie temperatury na poziomie 8℃ i zapewnienie ochrony przed mrozem","fi":"Pitää lämpötilan 8 ℃:ssa ja antaa pakkassuojan","sv":"Håll temperaturen på 8 ℃ och ge frostskydd","km":"រក្សាសីតុណ្ហភាពនៅ 8°C និងផ្តល់នូវការការពារ frost"},"If you are away for 30mins, AC will gear down to save energy.":{"en":"If you are away for 30mins, AC will gear down to save energy","zh-Hans":"如果离开30分钟，空调就会开始自适应降频节能","fr":"Si vous vous absentez pendant 30 minutes, la climatisation se réduit pour économiser de l'énergie","ja":"30分以上不在にすると、エアコンはギアダウンして省エネになります","it":"Se ci si assenta per 30 minuti, l'AC si riduce per risparmiare energia","es":"Si te ausentas durante 30 minutos, el aire acondicionado se reducirá para ahorrar energía","pt":"Se você estiver fora por 30mins, o ar condicionado irá se adaptar para economizar energia","de":"Wenn Sie 30 Minuten abwesend sind, wird die Klimaanlage heruntergeschaltet, um Energie zu sparen","ru":"Если вы отсутствуете в течение 30 минут, кондиционер выключится для экономии энергии","vi":"Nếu bạn để trong 30 phút, máy lạnh sẽ bắt đầu giảm tần số thích ứng để tiết kiệm năng lượng","th":"หากปล่อยทิ้งไว้ 30 นาที เครื่องปรับอากาศจะเริ่มปรับลดความถี่เพื่อประหยัดพลังงาน","id":"Jika Anda pergi selama 30 menit, AC akan mulai secara adaptif mengurangi frekuensi untuk menghemat energi","zh-Hant":"如果離開30分鐘，空調就會開始自適應降頻節能","zh-TW":"如果離開30分鐘，空調就會開始自適應降頻節能","ar":"إذا غادرت لمدة 30 دقيقة ، سيبدأ مكيف الهواء في تقليل التردد بشكل تكيفي لتوفير الطاقة","hu":"Ha 30 percig távol van, a légkondicionáló leállítja a sebességet, hogy energiát takarítson meg","el":"Εάν λείπετε για 30 λεπτά, το κλιματιστικό θα κατεβάσει ταχύτητα για εξοικονόμηση ενέργειας","nl":"Als je 30 minuten weg bent, schakelt de AC uit om energie te besparen.","pl":"Jeśli użytkownik jest nieobecny przez 30 minut, klimatyzacja wyłączy się, aby oszczędzać energię.","fi":"Jos olet poissa 30 minuuttia, AC kytkeytyy pois päältä energian säästämiseksi.","sv":"Om du är borta i 30 minuter kommer AC att växla ner för att spara energi","km":"ប្រសិន បើ អ្នក នៅ ឆ្ងាយ ពី 30 នាទី AC នឹង រៀប ចំ ដើម្បី សន្សំ ថាមពល"},"Clean the internal side of the unit and prevent the breeding of bacteria.":{"en":"Clean the internal side of the unit and prevent the breeding of bacteria","zh-Hans":"清洁设备内部，防止细菌滋生","fr":"Nettoie la face interne de l'appareil et empêche la reproduction des bactéries","ja":"本体内部を清掃し、雑菌の繁殖を防ぐ","it":"Pulisce il lato interno dell'unità e previene la formazione di batteri","es":"Limpie la parte interna de la unidad y evite la reproducción de bacterias","pt":"Limpe o lado interno da unidade e evite a proliferação de bactérias","de":"Reinigen Sie die Innenseite des Geräts und verhindern Sie die Vermehrung von Bakterien","ru":"Самоочистка теплообменника кондиционера и предотвращение размножения бактерий","vi":"Làm sạch bên trong thiết bị để ngăn vi khuẩn phát triển","th":"ทำความสะอาดภายในเครื่องเพื่อป้องกันการเจริญเติบโตของแบคทีเรีย","id":"Bersihkan bagian dalam perangkat untuk mencegah pertumbuhan bakteri","zh-Hant":"內部清潔設備，預防細菌滋生","zh-TW":"內部清潔設備，預防細菌滋生","ar":"نظف الجهاز من الداخل لمنع نمو البكتيريا","hu":"Tisztítsa meg a készülék belső oldalát és akadályozza meg a baktériumok elszaporodását","el":"Καθαρίστε την εσωτερική πλευρά της μονάδας και αποτρέψτε την ανάπτυξη βακτηρίων","nl":"Reinig de binnenkant van het apparaat en voorkom het ontstaan van bacteriën","pl":"Czyszczenie wewnętrznej strony urządzenia i zapobieganie rozwojowi bakterii","fi":"Puhdista laitteen sisäpuoli ja estä bakteerien lisääntyminen.","sv":"Rengör enhetens insida och förhindra bakterietillväxt","km":"សម្អាត ផ្នែក ខាង ក្នុង នៃ អង្គ ភាព និង ការពារ ការ ចិញ្ចឹម បាក់តេរី"},"One-click to activate your pre-set favorite settings including mode, temperature and fan speed.":{"en":"One-click to activate your pre-set favorite settings including mode, temperature and fan speed","zh-Hans":"一键激活你预先设定的最爱设置，包含模式、温度和风扇速度等设置","fr":"Un seul clic pour activer vos paramètres favoris préréglés, notamment le mode, la température et la vitesse du ventilateur","ja":"モード、温度、ファンの速度など、プリセットされたお気に入りの設定をワンクリックで作動させる","it":"Basta un clic per attivare le impostazioni preferite preimpostate, tra cui modalità, temperatura e velocità della ventola","es":"Un clic para activar sus ajustes favoritos preestablecidos, incluyendo el modo, la temperatura y la velocidad del ventilador","pt":"Um clique para ativar seus ajustes favoritos pré-definidos, incluindo modo, temperatura e velocidade do ventilador","de":"Mit einem Klick aktivieren Sie Ihre voreingestellten Lieblingseinstellungen wie Modus, Temperatur und Lüftergeschwindigkeit","ru":"Одним щелчком мыши активировать предварительно заданные любимые настройки, включая режим, температуру и скорость вентилятора","vi":"Kích hoạt bằng một nhấp chuột đối với các cài đặt yêu thích đã đặt trước, bao gồm các cài đặt như chế độ, nhiệt độ và tốc độ quạt","th":"เปิดใช้งานการตั้งค่าโปรดที่ตั้งไว้ล่วงหน้าได้ในคลิกเดียว รวมถึงการตั้งค่าต่างๆ เช่น โหมด อุณหภูมิ และความเร็วพัดลม","id":"Aktivasi sekali klik dari pengaturan favorit Anda yang telah ditentukan sebelumnya, termasuk pengaturan seperti mode, suhu, dan kecepatan kipas","zh-Hant":"一鍵激活您預先設定的最愛設置，包含模式、溫度和風扇速度等設置","zh-TW":"一鍵激活您預先設定的最愛設置，包含模式、溫度和風扇速度等設置","ar":"تنشيط بنقرة واحدة لإعداداتك المفضلة المحددة مسبقًا ، بما في ذلك الإعدادات مثل الوضع ودرجة الحرارة وسرعة المروحة","hu":"Egy kattintással aktiválhatja az előre beállított kedvenc beállításait, beleértve az üzemmódot, a hőmérsékletet és a ventilátor sebességét is","el":"Ένα κλικ για να ενεργοποιήσετε τις προκαθορισμένες αγαπημένες σας ρυθμίσεις, συμπεριλαμβανομένης της λειτουργίας, της θερμοκρασίας και της ταχύτητας του ανεμιστήρα","nl":"Activeer met één klik je vooraf ingestelde favoriete instellingen, zoals modus, temperatuur en ventilatorsnelheid","pl":"Jedno kliknięcie, aby aktywować wstępnie skonfigurowane ulubione ustawienia, w tym tryb, temperaturę i prędkość wentylatora","fi":"Aktivoi esiasetetut suosikkiasetukset, mukaan lukien tila, lämpötila ja tuulettimen nopeus, yhdellä napsautuksella.","sv":"Aktivera dina förinställda favoritinställningar med ett klick, inklusive läge, temperatur och fläkthastighet","km":"ចុច មួយ ដើម្បី ធ្វើ ឲ្យ ការ កំណត់ ដែល អ្នក ចូល ចិត្ត មុន កំណត់ រួម មាន របៀប សីតុណ្ហភាព និង ល្បឿន អ្នក គាំទ្រ"},"Make AC work at the time set in advance":{"en":"Make AC work at the time set in advance","zh-Hans":"使空调在预先设定的时间内工作","fr":"Faites fonctionner la climatisation à l'heure fixée à l'avance","ja":"あらかじめ設定した時刻にエアコンを作動させる","it":"Far funzionare il condizionatore all'ora impostata in precedenza","es":"Haga que el aire acondicionado funcione a la hora fijada de antemano","pt":"Faça com que a AC funcione na hora definida com antecedência.","de":"Lassen Sie die Klimaanlage zu der im Voraus eingestellten Zeit laufen.","ru":"Заставьте кондиционер работать в заранее установленное время","vi":"Làm cho máy điều hòa không khí hoạt động trong một thời gian đặt trước","th":"ทำให้เครื่องปรับอากาศทำงานตามเวลาที่ตั้งไว้ล่วงหน้า","id":"Jadikan AC berfungsi untuk waktu yang telah ditentukan sebelumnya","zh-Hant":"使空調在預先設定的期限內工作","zh-TW":"使空調在預先設定的期限內工作","ar":"اجعل مكيف الهواء يعمل لفترة محددة مسبقًا","hu":"A légkondicionáló működjön az előre meghatározott időpontban","el":"Κάντε το κλιματιστικό να λειτουργεί την ώρα που έχει οριστεί εκ των προτέρων","nl":"Laat de AC werken op de vooraf ingestelde tijd","pl":"Spraw, aby klimatyzator działał w ustawionym wcześniej czasie","fi":"Laita ilmastointilaite toimimaan etukäteen asetettuun aikaan","sv":"Få AC att arbeta vid den tid som ställts in i förväg","km":"ធ្វើ ឲ្យ AC ធ្វើការ នៅ ពេល កំណត់ ជា មុន"},"Do not operate the device during operation":{"en":"Do not operate the device during operation.","zh-Hans":"操作过程中不要操作设备","fr":"Ne pas utiliser l'appareil pendant le fonctionnement.","ja":"操作中はデバイスを操作しないでください","it":"Non utilizzare il dispositivo durante il funzionamento","es":"No utilice el dispositivo durante el funcionamiento","pt":"Não opere o dispositivo durante a operação","de":"Betreiben Sie das Gerät nicht während des Betriebs","ru":"Не эксплуатируйте устройство во время работы","vi":"Không vận hành thiết bị trong quá trình hoạt động","th":"ห้ามใช้งานอุปกรณ์ระหว่างการใช้งาน","id":"Jangan mengoperasikan perangkat selama pengoperasian","zh-Hant":"操作過程中不要操作設備","zh-TW":"操作過程中不要操作設備","ar":"لا تقم بتشغيل الجهاز أثناء التشغيل","hu":"Működés közben ne működtesse a készüléket.","el":"Μην χειρίζεστε τη συσκευή κατά τη διάρκεια της λειτουργίας.","nl":"Bedien het apparaat niet tijdens de werking.","pl":"Nie obsługuj urządzenia podczas pracy.","fi":"Älä käytä laitetta käytön aikana.","sv":"Använd inte enheten under drift.","km":"កុំ ប្រតិបត្តិ ឧបករណ៍ ក្នុង អំឡុង ពេល ប្រតិបត្តិការ ។"},"Active Clean will be started soon":{"en":"Active Clean is about to start soon, it will take 20~130mins;","zh-Hans":"即将开始主动清洁，预计需要20~130分钟","fr":"Le nettoyage actif commencera bient?t, ce qui devrait prendre de 20 à 130 minutes","ja":"間もなくアクティブクリーンが開始されます。所要時間は20〜130分です","it":"La pulizia attiva sarà avviata a breve, con una durata prevista di 20~130 minuti","es":"La limpieza activa se iniciará pronto, lo que se espera que tome 20~130 min","pt":"A limpeza ativa será iniciada em breve, o que deve levar 20~130 min","de":"Die aktive Reinigung wird in Kürze beginnen, was voraussichtlich 20-130 Minuten dauern wird","ru":"Вскоре начнется активная очистка, которая, как ожидается, займет 20~130 минут","vi":"Hoạt động dọn dẹp sẽ sớm được bắt đầu, dự kiến sẽ mất 20 ~ 130 phút","th":"การล้างข้อมูลแบบแอคทีฟจะเริ่มต้นเร็วๆ นี้ ซึ่งคาดว่าจะใช้เวลาประมาณ 20~130 นาที","id":"Pembersihan aktif akan segera dimulai, yang diperkirakan akan memakan waktu 20~130 menit","zh-Hant":"即將開始活力清潔，預計需要20~130分鐘","zh-TW":"即將開始活力清潔，預計需要20~130分鐘","ar":"سيبدأ التنظيف النشط قريبًا ، والذي من المتوقع أن يستغرق من 20 إلى 130 دقيقة","hu":"Az aktív tisztítás hamarosan megkezdődik, ez 20~130 percet vesz igénybe;","el":"Ο ενεργός καθαρισμός πρόκειται να ξεκινήσει σύντομα, θα διαρκέσει 20~130λεπτά,","nl":"Active Clean gaat binnenkort beginnen, dit duurt 20 ~ 130 minuten;","pl":"Aktywne czyszczenie rozpocznie się wkrótce i potrwa 20~130 minut;","fi":"Aktiivinen puhdistus alkaa pian, se kestää 20~130min;","sv":"Active Clean kommer snart att starta, det tar 20~130 minuter;","km":"Active Clean ជិតចាប់ផ្តើមឆាប់ៗនេះ វានឹងយក 20~130mins;"},"The device cannot beoperated when it is turned off":{"en":"The device cannot beoperated when it is turned off","zh-Hans":"设备关闭时无法操作","fr":"L'appareil ne peut pas fonctionner lorsqu'il est éteint","ja":"装置の電源が切れているのに動作しない","it":"L'apparecchio non può funzionare quando è spento","es":"El aparato no puede funcionar cuando está apagado","pt":"O dispositivo não pode ser operado quando está desligado","de":"Das Gerät kann nicht betrieben werden, wenn es ausgeschaltet ist","ru":"Устройство не может работать, когда оно выключено","vi":"Thiết bị không thể hoạt động khi nó bị tắt","th":"อุปกรณ์ไม่สามารถใช้งานได้เมื่อปิดเครื่อง","id":"Perangkat tidak dapat dioperasikan saat dimatikan","zh-Hant":"設備關閉時無法操作","zh-TW":"設備關閉時無法操作","ar":"لا يمكن تشغيل الجهاز عند إيقاف تشغيله","hu":"A készüléket nem lehet működtetni, ha ki van kapcsolva","el":"Η συσκευή δεν μπορεί να λειτουργήσει όταν είναι απενεργοποιημένη","nl":"Het apparaat kan niet worden bediend als het is uitgeschakeld.","pl":"Nie można obsługiwać urządzenia, gdy jest wyłączone.","fi":"Laitetta ei voi käyttää, kun se on sammutettu","sv":"Enheten kan inte användas när den är avstängd","km":"ឧបករណ៍ មិន អាច operated បាន ទេ ពេល បិទ វា"},"Are you sure to delete":{"en":"Are you sure to delete?","zh-Hans":"是否确认删除?","fr":"Êtes - vous sûr de vouloir supprimer ?","ja":"必ず削除する","it":"Sei sicuro di eliminare","es":"Está seguro de que desea borrar","pt":"Realmente desejar apagar?","de":"Are you sure to delete","ru":"Are you sure to delete","vi":"Bạn có chắc chắn muốn xóa không","th":"Are you sure to delete","id":"Are you sure to delete","zh-Hant":"是否確認刪除？","zh-TW":"是否確認刪除？","ar":"Are you sure to delete","hu":"Biztos, hogy törölni szeretné?","el":"Είστε σίγουροι για τη διαγραφή;","nl":"Weet u zeker dat u moet wissen?","pl":"Czy na pewno chcesz usunąć urządzenie?","fi":"Oletko varma poistamisesta?","sv":"Är du säker på att du vill radera?","km":"តើ អ្នក ប្រាកដ ជា លុប ឬ ទេ ?"},"The water is full!":{"en":"The condensate drain pan is full！","zh-Hans":"The condensate drain pan is full！","fr":"The condensate drain pan is full！","ja":"The condensate drain pan is full！","it":"The condensate drain pan is full！","es":"The condensate drain pan is full！","pt":"O tanque de água está cheio!","de":"The condensate drain pan is full！","ru":"The condensate drain pan is full！","vi":"Nước đã đầy!","th":"ถาดระบายน้ำคอนเดนเสทเต็ม！","id":"The condensate drain pan is full！","zh-Hant":"冷凝水盤已滿！","zh-TW":"冷凝水盤已滿！","ar":"The condensate drain pan is full！","hu":"A kondenzátum leeresztő tálca megtelt！","el":"Το δοχείο αποστράγγισης συμπυκνωμάτων είναι γεμάτο！","nl":"De condensaatopvangbak is vol！","pl":"Taca skroplin jest pełna！","fi":"Kondenssiveden tyhjennysastia on täynnä！","sv":"Kondensatavloppet är fullt！","km":"បន្ទះទឹកខ្មត់ខ្មៃពេញ!"},"My Favorite":{"en":"My Favorite","zh-Hans":"我喜爱的模式","fr":"Mon mode préféré","ja":"お気に入りのモード","it":"La mia modalità preferita","es":"Mi modo favorito","pt":"Modo favorito","de":"Mein Lieblingsmodus","ru":"Любимый режим","vi":"Yêu thích","th":"ที่ฉันชื่นชอบ","id":"Mode favorit saya","zh-Hant":"我喜愛的模式","zh-TW":"我喜愛的模式","ar":"وضعي المفضل","hu":"Kedvencem","el":"Το αγαπημένο μου","nl":"Mijn favoriet","pl":"Moje ulubione","fi":"Suosikkini","sv":"Min favorit","km":"សំណព្វចិត្តខ្ញុំ"},"Run dry mode based on a target humidity level":{"en":"Run dry mode based on a target humidity level","zh-Hans":"根据目标湿度水平运行干燥模式","fr":"Faites fonctionner le mode sec en fonction d'un taux d'humidité cible","ja":"目標湿度に基づいてドライモードを実行する","it":"Eseguire la modalità a secco in base a un livello di umidità target","es":"Funciona en modo seco en función de un nivel de humedad objetivo","pt":"Funcionamento em modo seco com base em um nível de umidade alvo","de":"Entfeuchtungmodus auf der Grundlage einer Zielfeuchtigkeitsstufe","ru":"Запускайте сухой режим на основе заданного уровня влажности","vi":"Chế độ Hút ẩm dựa trên mức độ ẩm mục tiêu","th":"เรียกใช้โหมดแห้งตามระดับความชื้นเป้าหมาย","id":"Jalankan mode kering berdasarkan tingkat kelembaban target","zh-Hant":"根據目標濕度水平運行乾燥模式","zh-TW":"根據目標濕度水平運行乾燥模式","ar":"قم بتشغيل الوضع الجاف بناءً على مستوى الرطوبة المستهدف","hu":"Száraz üzemmód futtatása egy célzott páratartalomszint alapján","el":"Εκτέλεση ξηρής λειτουργίας με βάση ένα επίπεδο υγρασίας-στόχο","nl":"De droogmodus uitvoeren op basis van een doelvochtigheidsniveau","pl":"Uruchom tryb suchy w oparciu o docelowy poziom wilgotności","fi":"Suorita kuiva tila tavoitekosteuden perusteella","sv":"Kör torrt läge baserat på en målfuktighetsnivå","km":"រត់ របៀប ស្ងួត ដោយ ផ្អែក លើ កម្រិត សំណើម គោលដៅ"},"Music":{"en":"Music Garden","zh-Hans":"音乐","fr":"Musique","ja":"音楽","it":"Musica","es":"Música","pt":"Música","de":"Musik","ru":"Музыка","vi":"Nhạc","th":"ดนตรี","id":"Musik","zh-Hant":"音樂","zh-TW":"音樂","ar":"موسيقى","hu":"Zenei kert","el":"Μουσικός κήπος","nl":"Muziek Tuin","pl":"Ogród muzyczny","fi":"Musiikkipuutarha","sv":"Musik trädgård","km":"សួនភ្លេង"},"ENNO":{"en":"iECO","zh-Hans":"iECO","fr":"iECO","ja":"iECO","it":"iECO","es":"iECO","pt":"iECO","de":"iECO","ru":"iECO","vi":"iECO","th":"iECO","id":"iECO","zh-Hant":"iECO","zh-TW":"iECO","ar":"iECO","hu":"iECO","el":"iECO","nl":"iECO","pl":"iECO","fi":"iECO","sv":"iECO","km":"iECO"},"Feature preference":{"en":"Feature preference","zh-Hans":"功能偏好","fr":"Préférence de fonctionnalité","ja":"機能の優先順位","it":"Preferenza della funzione","es":"Preferencia de función","pt":"Preferência de características","de":"Präferenz der Funktion","ru":"Предпочтение функции","vi":"Tùy chọn tính năng","th":"คุณลักษณะที่ต้องการ","id":"Preferensi fitur","zh-Hant":"功能偏好","zh-TW":"功能偏好","ar":"تفضيل الميزة","hu":"Funkció preferencia","el":"Προτίμηση χαρακτηριστικών","nl":"Functie voorkeur","pl":"Preferencje funkcji","fi":"Ominaisuuden mieltymys","sv":"Preferens för funktion","km":"ចំណង់ ចំណូល ចិត្ត ពិសេស"},"Run when Powered On":{"en":"Run when Powered On","zh-Hans":"开机运行","fr":"Fonctionnement sous tension","ja":"電源ON時の動作","it":"Funziona quando è acceso","es":"Funcionar cuando está encendido","pt":"Funciona quando Ligado","de":"Einschalten, wenn eingeschaltet","ru":"Запуск при включении питания","vi":"Chạy khi bật nguồn","th":"เรียกใช้เมื่อเปิดเครื่อง","id":"Jalankan saat Dinyalakan","zh-Hant":"啟動運行","zh-TW":"啟動運行","ar":"تشغيل عند التشغيل","hu":"Futtatás bekapcsolt állapotban","el":"Εκτέλεση κατά την ενεργοποίηση","nl":"Draaien wanneer ingeschakeld","pl":"Uruchom po włączeniu zasilania","fi":"Käynnistä, kun virta on päällä","sv":"Kör när strömmen är på","km":"រត់ ពេល ប្រើ ថាមពល លើ"},"Save energy by intelligently adjusting frequency and temperature":{"en":"Save energy by intelligently adjusting frequency and temperature","zh-Hans":"通过智能调节","fr":"Économisez de l'énergie en ajustant intelligemment la fréquence et la température","ja":"周波数と温度をインテリジェントに調整し、エネルギーを節約します。","it":"Risparmia energia regolando in modo intelligente frequenza e temperatura","es":"Ahorra energía ajustando de forma inteligente la frecuencia y la temperatura","pt":"Poupar energia ajustando inteligentemente a frequência e a temperatura","de":"Energie sparen durch intelligente Anpassung von Frequenz und Temperatur","ru":"Экономия энергии за счет интеллектуальной регулировки частоты и температуры","vi":"Tiết kiệm năng lượng bằng cách điều chỉnh tần số và nhiệt độ một cách thông minh","th":"ประหยัดพลังงานด้วยการปรับความถี่และอุณหภูมิอย่างชาญฉลาด","id":"Menghemat energi dengan menyesuaikan frekuensi dan suhu secara cerdas","zh-Hant":"通過智能調節","zh-TW":"通過智能調節","ar":"وفر الطاقة عن طريق ضبط التردد ودرجة الحرارة بذكاء","hu":"Energiatakarékosság a frekvencia és a hőmérséklet intelligens beállításával","el":"Εξοικονόμηση ενέργειας με έξυπνη ρύθμιση της συχνότητας και της θερμοκρασίας","nl":"Bespaar energie door frequentie en temperatuur intelligent aan te passen","pl":"Oszczędność energii dzięki inteligentnej regulacji częstotliwości i temperatury","fi":"Säästä energiaa säätämällä taajuutta ja lämpötilaa älykkäästi","sv":"Spara energi genom intelligent justering av frekvens och temperatur","km":"សន្សំសំចៃថាមពលដោយភាពឆ្លាតវៃក្នុងការលៃតម្រូវ ប្រេកង់និងសីតុណ្ហភាព"},"Model":{"en":"Model","zh-Hans":"型号","fr":"Modèle","ja":"モデル","it":"Modello","es":"Modo","pt":"Modelo","de":"Modell","ru":"Модель","vi":"Tên sản phẩm","th":"รุ่น","id":"Model","zh-Hant":"型號","zh-TW":"型號","ar":"نموذج .","hu":"Modell","el":"Μοντέλο","nl":"Model","pl":"Model","fi":"Malli","sv":"Modell","km":"ម៉ូដែល"},"GenMode":{"en":"Gen Mode","zh-Hans":"发动机模式","fr":"Mode moteur","ja":"エンジンモード","it":"Modalità motore","es":"Modo motor","pt":"Modo motor","de":"Motorbetrieb","ru":"Режим работы двигателя","vi":"Chế độ Gen","th":"โหมดเครื่องยนต์","id":"Mode mesin","zh-Hant":"啟動模式","zh-TW":"啟動模式","ar":"وضع المحرك","hu":"Gen üzemmód","el":"Gen Mode","nl":"Gen-modus","pl":"Tryb generatora","fi":"Gen Mode","sv":"Gen Läge","km":"របៀប Gen"},"Gear5":{"en":"Gear","zh-Hans":"Gear","fr":"Gear","ja":"Gear","it":"Gear","es":"Gear","pt":"Gear","de":"Gear","ru":"Gear","vi":"Gear","th":"Gear","id":"Gear","zh-Hant":"Gear","zh-TW":"Gear","ar":"Gear","hu":"Gear","el":"Gear","nl":"Versnelling","pl":"Sprzęt","fi":"Gear","sv":"Utrustning","km":"ហ្គៀ"},"Baby":{"en":"Baby","zh-Hans":"母婴模式","fr":"Mode mère et bébé","ja":"母子手帳モード","it":"Modalità mamma e bambino","es":"Modo madre y bebé","pt":"Bebê","de":"Mutter-und-Baby-Modus","ru":"Режим матери и ребенка","vi":"Trẻ em","th":"โหมดแม่ลูก","id":"Mode ibu dan bayi","zh-Hant":"母嬰模式","zh-TW":"母嬰模式","ar":"وضع الأم والطفل","hu":"Baby","el":"Baby","nl":"Baby","pl":"Dziecko","fi":"Baby","sv":"Baby","km":"ទារក"},"Pet":{"en":"Pet","zh-Hans":"宠物模式","fr":"Mode animalier","ja":"ペットモード","it":"Modalità animale domestico","es":"Modo mascota","pt":"Modo Pet","de":"Haustier-Modus","ru":"Режим для домашних животных","vi":"Thú cưng","th":"โหมดสัตว์เลี้ยง","id":"Mode hewan peliharaan","zh-Hant":"寵物模式","zh-TW":"寵物模式","ar":"وضع الحيوانات الأليفة","hu":"Háziállat","el":"Pet","nl":"Huisdier","pl":"Zwierzę","fi":"Lemmikki","sv":"Husdjur","km":"Pet"},"Week":{"en":"Week","zh-Hans":"星期","fr":"Semaine","ja":"週","it":"Settimana","es":"Semana","pt":"Semana","de":"Woche","ru":"Неделя","vi":"Tuần","th":"สัปดาห์","id":"Pekan","zh-Hant":"星期","zh-TW":"星期","ar":"أسبوع","hu":"Hét","el":"Εβδομάδα","nl":"Week","pl":"Tydzień","fi":"Viikko","sv":"Vecka","km":"សប្ដាហ៍"},"Month":{"en":"Month","zh-Hans":"月","fr":"lune","ja":"月","it":"luna","es":"luna","pt":"Mês","de":"Mond","ru":"луна","vi":"mặt trăng","th":"ดวงจันทร์","id":"bulan","zh-Hant":"月","zh-TW":"月","ar":"قمر","hu":"Hónap","el":"Μήνας","nl":"Maand","pl":"Miesiąc","fi":"Kuukausi","sv":"Månad","km":"ខែ"},"Year":{"en":"Year","zh-Hans":"年","fr":"Année","ja":"年","it":"Anno","es":"Año","pt":"Ano","de":"Jahr","ru":"Год","vi":"Năm","th":"ปี","id":"Tahun","zh-Hant":"年","zh-TW":"年","ar":"سنة","hu":"Év","el":"Έτος","nl":"Jaar","pl":"Rok","fi":"Vuosi","sv":"År","km":"ឆ្នាំខាល"},"Gear":{"en":"Gear","zh-Hans":"Gear","fr":"Gear","ja":"Gear","it":"Gear","es":"Gear","pt":"Gear","de":"Gear","ru":"Gear","vi":"Gear","th":"Gear","id":"Gear","zh-Hant":"Gear","zh-TW":"Gear","ar":"Gear","hu":"Gear","el":"Εξοπλισμός","nl":"Uitrusting","pl":"Sprzęt","fi":"Varusteet","sv":"Redskap","km":"ហ្គៀ"},"Flash":{"en":"Flash","zh-Hans":"Flash","fr":"Flash","ja":"Flash","it":"Flash","es":"Flash","pt":"Flash","de":"Flash","ru":"Flash","vi":"Flash","th":"Flash","id":"Flash","zh-Hant":"Flash","zh-TW":"Flash","ar":"Flash","hu":"Flash","el":"Flash","nl":"Flash","pl":"Lampa błyskowa","fi":"Flash","sv":"Flash","km":"Flash"},"Cumulative":{"en":"Cumulative","zh-Hans":"累计","fr":"total","ja":"総計","it":"somma totale","es":"gran total","pt":"Acumulativo","de":"Gesamtsumme","ru":"общий итог","vi":"Tổng cộng","th":"ผลรวมทั้งสิ้น","id":"Total keseluruhan","zh-Hant":"累計","zh-TW":"累計","ar":"المجموع الإجمالي","hu":"Kumulatív","el":"Αθροιστικό","nl":"Cumulatief","pl":"Łącznie","fi":"Kumulatiivinen","sv":"Kumulativt","km":"ការ សង្ខេប"},"Real-time":{"en":"Real time","zh-Hans":"实时的","fr":"Temps réel","ja":"リアルタイム","it":"Tempo reale","es":"Tiempo real","pt":"Tempo real","de":"Echtzeit","ru":"В реальном времени","vi":"Thời gian thực","th":"เรียลไทม์","id":"Waktu sebenarnya","zh-Hant":"實時的","zh-TW":"實時的","ar":"في الوقت الحالى","hu":"Valós idejű","el":"Πραγματικός χρόνος","nl":"Real time","pl":"Czas rzeczywisty","fi":"Reaaliaikainen","sv":"I realtid","km":"ពេលវេលាពិត"},"Favorite Name":{"en":"Favorite Name","zh-Hans":"名字","fr":"Nom","ja":"名称","it":"Nome","es":"Nombre","pt":"Nome Favorito","de":"Name","ru":"Имя","vi":"Tên yêu thích","th":"ชื่อ","id":"Nama","zh-Hant":"名字","zh-TW":"名字","ar":"اسم","hu":"Kedvenc neve","el":"Αγαπημένο όνομα","nl":"Favoriete naam","pl":"Ulubiona nazwa","fi":"Suosikki Nimi","sv":"Favoritnamn","km":"ឈ្មោះសំណព្វចិត្ត"},"Energy saver":{"en":"Energy saver","zh-Hans":"节能模式","fr":"Mode d'économie d'énergie","ja":"エナジーセービングモード","it":"Modalità di risparmio energetico","es":"Modo de ahorro de energía","pt":"Modo de economia de energia","de":"Energiesparmodus","ru":"Режим энергосбережения","vi":"Tiết kiệm năng lượng","th":"โหมดประหยัดพลังงาน","id":"Mode hemat energi","zh-Hant":"節能模式","zh-TW":"節能模式","ar":"وضع توفير الطاقة","hu":"Energiatakarékos","el":"Εξοικονόμηση ενέργειας","nl":"Energiebesparing","pl":"Oszczędzanie energii","fi":"Energiansäästäjä","sv":"Energisparare","km":"អ្នក សន្សំ ថាមពល"},"Favorite setting":{"en":"Favorite setting","zh-Hans":"最爱设置","fr":"Cadre préféré","ja":"好きな設定","it":"Ambientazione preferita","es":"Entorno favorito","pt":"Ambiente favorito","de":"Bevorzugte Einstellung","ru":"Любимая обстановка","vi":"Cài đặt yêu thích","th":"การตั้งค่าที่ชื่นชอบ","id":"Pengaturan favorit","zh-Hant":"最愛設置","zh-TW":"最愛設置","ar":"الإعدادات المفضلة","hu":"Kedvenc beállítás","el":"Αγαπημένη ρύθμιση","nl":"Favoriete instelling","pl":"Ulubione ustawienie","fi":"Suosikki asetus","sv":"Favoritinställning","km":"ការ កំណត់ ដែល ចូលចិត្ត"},"has been enabled":{"en":"enable","zh-Hans":"已允许","fr":"Autorisé","ja":"許可","it":"Consentito","es":"Permitido","pt":"Permitido","de":"Erlaubt","ru":"Разрешено","vi":"Bật","th":"อนุญาต","id":"Diizinkan","zh-Hant":"已允許","zh-TW":"已允許","ar":"مسموح","hu":"engedélyezze","el":"Ενεργοποίηση","nl":"inschakelen","pl":"enable","fi":"enable","sv":"Aktivera","km":"បើក"},"enable":{"en":"enable","zh-Hans":"允许","fr":"Autorisé","ja":"許可","it":"Consentito","es":"Permitido","pt":"Permitido","de":"Erlaubt","ru":"Разрешено","vi":"Bật","th":"อนุญาต","id":"Diizinkan","zh-Hant":"允許","zh-TW":"允許","ar":"السماح","hu":"enable","el":"Ενεργοποίηση","nl":"inschakelen","pl":"włącz","fi":"enable","sv":"Aktivera","km":"បើក"},"Your favorite had been created. Do you want to run it now":{"en":"Your favorite item has been created. Do you want to run it now","zh-Hans":"你的最爱设置已保存，请问要现在运行吗","fr":"Vos paramètres préférés ont été enregistrés, voulez-vous les exécuter maintenant","ja":"お気に入りの設定が保存されましたが、今すぐ実行しますか","it":"Le impostazioni preferite sono state salvate, volete eseguirle ora","es":"Tus ajustes favoritos se han guardado, ¿quieres ejecutarlos ahora","pt":"As suas definições favoritas foram guardadas, quer executá-las agora","de":"Ihre bevorzugten Einstellungen wurden gespeichert, möchten Sie sie jetzt ausführen","ru":"Ваши любимые настройки были сохранены, хотите ли вы запустить их сейчас","vi":"Yêu thích của bạn đã được tạo. Bạn có muốn chạy bây giờ","th":"บันทึกการตั้งค่าโปรดของคุณแล้ว คุณต้องการเรียกใช้งานทันทีหรือไม่","id":"Pengaturan favorit Anda sudah disimpan, apakah Anda ingin menjalankannya sekarang","zh-Hant":"您最喜歡的設置已保存，請問現在運行嗎","zh-TW":"您最喜歡的設置已保存，請問現在運行嗎","ar":"تم حفظ إعداداتك المفضلة ، هل ترغب في تشغيلها الآن؟","hu":"A kedvence már létre lett hozva, szeretné most futtatni","el":"Το αγαπημένο σας στοιχείο έχει δημιουργηθεί. Θέλετε να το εκτελέσετε τώρα","nl":"Je favoriete item is aangemaakt. Wilt u het nu uitvoeren","pl":"Ulubiony element został utworzony. Czy chcesz ją teraz uruchomić?","fi":"Suosikkikohteesi on luotu. Haluatko käyttää sitä nyt","sv":"Ditt favoritobjekt har skapats. Vill du köra det nu?","km":"ធាតុ ដែល អ្នក ចូលចិត្ត ត្រូវ បាន បង្កើត & # 160; ។ តើ អ្នក ចង់ រត់ វា ឥឡូវ"},"When powered on, the device will default to this setting":{"en":"The device will default to these settings when it   is powered on via App control page","zh-Hans":"当设备开机就会自动按设置运行。","fr":"L'appareil est réglé par défaut sur ces paramètres lorsqu'il est mis sous tension à l'aide de la carte de contrôle App.","ja":"デバイスは、Appコントロールカード経由で電源オンされると、デフォルトで以下の設定になります。","it":"Il dispositivo viene impostato di default su queste impostazioni quando viene acceso tramite la scheda di controllo dell'app.","es":"El dispositivo adoptará por defecto estos ajustes cuando se encienda a través de la tarjeta de control de la aplicación","pt":"O dispositivo assume estas definições por defeito quando é ligado através do cartão de controlo da aplicação","de":"Wenn das Gerät über die App-Steuerkarte eingeschaltet wird, werden diese Einstellungen standardmäßig verwendet","ru":"При включении устройства через карту управления App по умолчанию будут установлены следующие настройки","vi":"Thiết bị sẽ mặc định có các cài đặt này khi được bật nguồn qua thẻ Kiểm soát ứng dụng","th":"อุปกรณ์จะใช้การตั้งค่าเหล่านี้ตามค่าเริ่มต้นเมื่อเปิดเครื่องผ่านการ์ดควบคุมแอป","id":"Perangkat akan secara default menggunakan pengaturan ini saat dinyalakan melalui kartu kontrol Aplikasi","zh-Hant":"當設備開機就會自動依設定運作。","zh-TW":"當設備開機就會自動依設定運作。","ar":"عند تشغيل الجهاز، سيتم تشغيله تلقائيًا وفقًا للإعدادات.","hu":"A készülék alapértelmezés szerint ezeket a beállításokat fogja használni, amikor az App vezérlőkártyán keresztül bekapcsolják.","el":"Η συσκευή θα προεπιλεγεί σε αυτές τις ρυθμίσεις όταν ενεργοποιηθεί μέσω της κάρτας ελέγχου App","nl":"Het apparaat zal standaard deze instellingen gebruiken wanneer het wordt ingeschakeld via de App-bedieningskaart","pl":"Urządzenie domyślnie przyjmie te ustawienia, gdy zostanie włączone za pomocą karty sterowania aplikacji","fi":"Laite ottaa oletusarvoisesti käyttöön nämä asetukset, kun se kytketään päälle App-ohjauskortin kautta.","sv":"Enheten kommer som standard att ha dessa inställningar när den slås på via App-kontrollkortet","km":"ឧបករណ៍ នឹង លំនាំ ដើម ទៅ ការ កំណត់ ទាំង នេះ នៅ ពេល ដែល វា ត្រូវ បាន ប្រើ ថាមពល តាម រយៈ ទំព័រ បញ្ជា App"},"Lower the level of power to save energy":{"en":"Lower the level of power to save energy","zh-Hans":"调低电量实现节能","fr":"Baisser la puissance pour économiser l'énergie","ja":"省エネのために電力を下げる","it":"Abbassare la potenza per risparmiare energia","es":"Baja la potencia para ahorrar energía","pt":"Reduzir a potência para poupar energia","de":"Energiesparen durch Herunterfahren der Leistung","ru":"Выключите питание для экономии энергии","vi":"Giảm mức công suất để tiết kiệm năng lượng","th":"ปิดไฟเพื่อประหยัดพลังงาน","id":"Turunkan daya untuk penghematan energi","zh-Hant":"調低樓層實現節能","zh-TW":"調低樓層實現節能","ar":"قم بخفض الطاقة لتوفير الطاقة","hu":"Alacsonyabb teljesítményszint az energiatakarékosság érdekében","el":"Χαμηλώστε το επίπεδο ισχύος για εξοικονόμηση ενέργειας","nl":"Verlaag het energieniveau om energie te besparen","pl":"Obniż poziom mocy, aby oszczędzać energię","fi":"Alenna tehotasoa energian säästämiseksi","sv":"Sänk effektnivån för att spara energi","km":"បន្ថយ កម្រិត ថាមពល ដើម្បី សន្សំសំចៃ ថាមពល"},"Choose your favorite setting to activate it with one touch":{"en":"Choose your favorite setting to activate it with one touch","zh-Hans":"一键启动最爱设置","fr":"Activation d'une seule touche des réglages favoris","ja":"お気に入りの設定をワンタッチで起動","it":"Attivazione con un solo tocco delle impostazioni preferite","es":"Activación de los ajustes favoritos con una sola pulsación","pt":"Ativação com um toque das definições favoritas","de":"One-Touch-Aktivierung der bevorzugten Einstellungen","ru":"Выберите любимые настройки и активируйте их одним нажатием","vi":"Cài đặt chế độ yêu thích của bạn để kích hoạt bằng một lần chạm","th":"การตั้งค่ารายการโปรดเพียงคลิกเดียว","id":"Aktivasi pengaturan favorit dengan sekali sentuh","zh-Hant":"一鍵啟動最愛設置","zh-TW":"一鍵啟動最愛設置","ar":"بنقرة واحدة الإعدادات المفضلة","hu":"Válassza ki kedvenc beállítását, hogy egyetlen érintéssel aktiválja azt","el":"Επιλέξτε την αγαπημένη σας ρύθμιση για να την ενεργοποιήσετε με ένα άγγιγμα","nl":"Kies je favoriete instelling om deze met één aanraking te activeren","pl":"Wybierz ulubione ustawienie, aby aktywować je jednym dotknięciem","fi":"Valitse suosikkiasetuksesi aktivoidaksesi sen yhdellä kosketuksella","sv":"Välj din favoritinställning för att aktivera den med en knapptryckning","km":"ជ្រើសការកំណត់ដែលអ្នកចូលចិត្តដើម្បីធ្វើឱ្យវាសកម្មដោយប៉ះមួយ"},"Choose a maximum and minimum set temperature range allowed.":{"en":"Choose your favorite setting to activate it with one touch","zh-Hans":"选择允许的最大和最小设置温度范围","fr":"Choisissez la plage de température de réglage maximale et minimale autorisée","ja":"許容最大設定温度範囲と最小設定温度範囲の選択","it":"Scegliere un intervallo di temperatura impostato massimo e minimo consentito","es":"Elija el rango de temperatura máximo y mínimo permitido","pt":"Escolha uma faixa de temperatura máxima e mínima permitida","de":"Wählen Sie einen maximal und minimal eingestellten Temperaturbereich","ru":"Выберите максимально допустимый и минимальный диапазон температур","vi":"Chọn mức nhiệt độ tối đa và tối thiểu cho phép","th":"เลือกช่วงอุณหภูมิการตั้งค่าสูงสุดและต่ำสุดที่อนุญาต","id":"Pilih jangkauan suhu maksimum dan minimum yang diizinkan","zh-Hant":"選擇允許的最大和最小設置溫度範圍","zh-TW":"選擇允許的最大和最小設置溫度範圍","ar":"حدد الحد الأقصى والحد الأدنى المسموح به مجموعة درجة الحرارة","hu":"Válassza ki kedvenc beállítását, hogy egyetlen érintéssel aktiválja azt","el":"Επιλέξτε την αγαπημένη σας ρύθμιση για να την ενεργοποιήσετε με ένα άγγιγμα","nl":"Kies je favoriete instelling om deze met één aanraking te activeren","pl":"Wybierz ulubione ustawienie, aby aktywować je jednym dotknięciem","fi":"Valitse suosikkiasetuksesi aktivoidaksesi sen yhdellä kosketuksella","sv":"Välj din favoritinställning för att aktivera den med en knapptryckning","km":"ជ្រើសការកំណត់ដែលអ្នកចូលចិត្តដើម្បីធ្វើឱ្យវាសកម្មដោយប៉ះមួយ"},"TempRange":{"en":"Temp. Range","zh-Hans":"温度范围","fr":"Plage de température","ja":"温度範囲","it":"Intervallo di temperatura","es":"Temperatura","pt":"Níveis de temperaturas","de":"Temperaturbereich","ru":"Температурный диапазон","vi":"Nhiệt độ. Phạm vi","th":"ช่วงอุณหภูมิ","id":"Kisaran suhu","zh-Hant":"溫度範圍","zh-TW":"溫度範圍","ar":"نطاق درجة حرارة","hu":"Hőmérséklet. Tartomány","el":"Θερμοκρασία. Εύρος","nl":"Temp. Bereik","pl":"Temp. Zakres","fi":"Lämpötila. Alue","sv":"Temp. Område","km":"Temp. ជួរ"},"AiControl":{"en":"AI Saving","zh-Hans":"智能节能","fr":"Économie d'énergie intelligente","ja":"インテリジェント・エナジー・セーブ","it":"Risparmio energetico intelligente","es":"Ahorro inteligente de energía","pt":"AI Eco modo","de":"Intelligentes Energiesparen","ru":"Интеллектуальное энергосбережение","vi":"Ái lưu","th":"การประหยัดพลังงานอย่างชาญฉลาด","id":"Penghematan energi yang cerdas","zh-Hant":"智能節能","zh-TW":"智能節能","ar":"توفير الطاقة الذكي","hu":"AI Megtakarítás","el":"Εξοικονόμηση AI","nl":"AI Besparing","pl":"AI Saving","fi":"AI Säästö","sv":"AI besparing","km":"សន្សំ AI"},"Ai Saving":{"en":"AI Saving","zh-Hans":"智能节能","fr":"Économie d'énergie intelligente","ja":"インテリジェント・エナジー・セーブ","it":"Risparmio energetico intelligente","es":"Ahorro inteligente de energía","pt":"AI Eco modo","de":"Intelligentes Energiesparen","ru":"Интеллектуальное энергосбережение","vi":"Ái lưu","th":"การประหยัดพลังงานอย่างชาญฉลาด","id":"Penghematan energi yang cerdas","zh-Hant":"智能節能","zh-TW":"智能節能","ar":"توفير الطاقة الذكي","hu":"AI Mentés","el":"Εξοικονόμηση AI","nl":"AI Besparing","pl":"Oszczędność AI","fi":"AI Saving","sv":"AI besparing","km":"សន្សំ AI"},"Cascade":{"en":"Cascade","zh-Hans":"上下环绕风","fr":"Air enveloppant de haut en bas","ja":"上下巻きのエアー","it":"Aria avvolgente su e giù","es":"Aire envolvente arriba y abajo","pt":"Vento para cima e para baixo","de":"Auf- und abwärts gerichtete Rundumluft","ru":"Подъем и опускание воздуха","vi":"quanh gió","th":"ลมขึ้นและลง","id":"Udara yang membungkus ke atas dan ke bawah","zh-Hant":"上下環繞風","zh-TW":"上下環繞風","ar":"يختفي ويهبط","hu":"Cascade","el":"Cascade","nl":"Cascade","pl":"Kaskada","fi":"Cascade","sv":"Kaskad","km":"កាស្កាដ"},"Smart control maximizes both comfort and energy savings":{"en":"Smart control maximizes both comfort and energy savings","zh-Hans":"智能节能使舒适度和节能最大化。","fr":"L'économie d'énergie intelligente optimise le confort et l'efficacité énergétique.","ja":"インテリジェントな省エネにより、快適性とエネルギー効率を最大化します。","it":"Il risparmio energetico intelligente massimizza il comfort e l'efficienza energetica.","es":"El ahorro inteligente de energía maximiza el confort y la eficiencia energética.","pt":"Smart control maximiza o conforto e a economia de energia.","de":"Intelligentes Energiesparen maximiert den Komfort und die Energieeffizienz.","ru":"Интеллектуальное энергосбережение обеспечивает максимальный комфорт и энергоэффективность.","vi":"Điều khiển thông minh tối đa hóa sự thoải mái và tiết kiệm năng lượng","th":"Energy Smart ช่วยเพิ่มความสะดวกสบายและประหยัดพลังงาน","id":"Penghematan energi yang cerdas memaksimalkan kenyamanan dan efisiensi energi.","zh-Hant":"智能節能使舒適度和節能最大化。","zh-TW":"智能節能使舒適度和節能最大化。","ar":"تعمل Energy Smart على زيادة الراحة وتوفير الطاقة إلى أقصى حد.","hu":"Az intelligens vezérlés maximalizálja a kényelmet és az energiamegtakarítást","el":"Ο έξυπνος έλεγχος μεγιστοποιεί τόσο την άνεση όσο και την εξοικονόμηση ενέργειας","nl":"Slimme regeling maximaliseert zowel comfort als energiebesparing","pl":"Inteligentne sterowanie maksymalizuje zarówno komfort, jak i oszczędność energii","fi":"Älykäs ohjaus maksimoi sekä mukavuuden että energiansäästön","sv":"Smart styrning maximerar både komfort och energibesparingar","km":"ការ គ្រប់ គ្រង ឆ្លាត អតិបរមា ទាំង ការ សន្សំ សំចៃ ថាមពល និង ការ សន្សំ សំចៃ ថាមពល"},"The unit will intelligently control the device for better energy efficiency":{"en":"The unit will intelligently control the device for better energy efficiency","zh-Hans":"空调会自行调节来实现更好节能。","fr":"Le climatiseur s'ajuste lui-même pour réaliser de meilleures économies d'énergie.","ja":"エアコンはより省エネになるように自ら調整します。","it":"Il condizionatore d'aria si regolerà da solo per ottenere un migliore risparmio energetico.","es":"El aire acondicionado se ajustará para conseguir un mayor ahorro de energía.","pt":"O ar condicionado irá ajustar-se para conseguir uma melhor poupança de energia.","de":"Das Klimagerät passt sich selbst an, um eine bessere Energieeinsparung zu erzielen.","ru":"Кондиционер настроит себя так, чтобы добиться лучшей экономии энергии.","vi":"Điều khiển thiết bị thông minh để đạt hiệu suất năng lượng tốt hơn","th":"เครื่องปรับอากาศจะปรับตัวเองเพื่อให้ได้การประหยัดพลังงานที่ดีขึ้น","id":"AC akan menyesuaikan dirinya sendiri untuk mencapai penghematan energi yang lebih baik.","zh-Hant":"空調會自行調節來實現更好的節能。","zh-TW":"空調會自行調節來實現更好的節能。","ar":"سيعدل مكيف الهواء نفسه لتحقيق توفير أفضل للطاقة.","hu":"A készülék intelligensen vezérli a készüléket a jobb energiahatékonyság érdekében","el":"Η μονάδα θα ελέγχει έξυπνα τη συσκευή για καλύτερη ενεργειακή απόδοση","nl":"De unit regelt het apparaat op intelligente wijze voor een betere energie-efficiëntie","pl":"Jednostka będzie inteligentnie sterować urządzeniem w celu zapewnienia lepszej efektywności energetycznej.","fi":"Laite ohjaa laitetta älykkäästi parempaa energiatehokkuutta varten","sv":"Enheten styr enheten på ett intelligent sätt för bättre energieffektivitet","km":"អង្គ ភាព នេះ នឹង ត្រួត ពិនិត្យ ឧបករណ៍ ដោយ ឆ្លាត វៃ ដើម្បី បង្កើន ប្រសិទ្ធិ ភាព ថាមពល កាន់ តែ ប្រសើរ ឡើង"},"Sleep Duration":{"en":"Sleep Duration","zh-Hans":"睡眠时长","fr":"Durée de la veille","ja":"スリープ時間","it":"Durata del sonno","es":"Duração do sono","pt":"Duração do sono","de":"Dauer des Ruhezustands","ru":"Продолжительность сна","vi":"Thời gian ngủ","th":"ระยะเวลาการนอนหลับ","id":"Durasi Tidur","zh-Hant":"睡眠時長","zh-TW":"睡眠時長","ar":"مدة النوم","hu":"Alvás időtartama","el":"Διάρκεια ύπνου","nl":"Slaapduur","pl":"Czas uśpienia","fi":"Lepotilan kesto","sv":"Viloläge Varaktighet","km":"ដំណេកពេលគេង"},"recommend":{"en":"recommend","zh-Hans":"建议","fr":"recommander","ja":"おすすめ","it":"consiglia","es":"Recomendar","pt":"recomendar","de":"empfehlen","ru":"рекомендовать","vi":"gợi ý","th":"แนะนำ","id":"merekomendasikan","zh-Hant":"建議","zh-TW":"建議","ar":"يوصي","hu":"ajánljuk","el":"προτείνουμε","nl":"aanbevelen","pl":"zalecane","fi":"suosittele","sv":"rekommendera","km":"អនុសាសន៍"},"Set the temperature to change while you sleep.":{"en":"Set the temperature to change while you sleep.","zh-Hans":"调整睡眠期间的温度变化","fr":"Réglez la température pour qu'elle change pendant votre sommeil.","ja":"寝ている間に温度が変化するように設定する","it":"Impostare la variazione della temperatura durante il sonno.","es":"Ajustar la temperatura para que cambie mientras duermes","pt":"Ajustar a temperatura para mudar enquanto dorme.","de":"Stellen Sie die Temperatur so ein, dass sie sich ändert, während Sie schlafen.","ru":"Установите изменение температуры во время сна.","vi":"Đặt nhiệt độ để thay đổi trong khi bạn ngủ.","th":"ตั้งอุณหภูมิให้เปลี่ยนแปลงในขณะที่คุณนอนหลับ","id":"Mengatur suhu agar berubah saat Anda tidur.","zh-Hant":"調整睡眠期間的溫度變化","zh-TW":"調整睡眠期間的溫度變化","ar":"اضبط درجة الحرارة لتغييرها أثناء النوم.","hu":"Állítsa be, hogy a hőmérséklet alvás közben változzon.","el":"Ρυθμίστε τη θερμοκρασία ώστε να αλλάζει όσο κοιμάστε.","nl":"Stel in dat de temperatuur verandert terwijl je slaapt.","pl":"Ustawienie zmiany temperatury podczas snu.","fi":"Aseta lämpötila muuttumaan nukkuessasi.","sv":"Ställ in temperaturen så att den ändras medan du sover.","km":"កំណត់ សីតុណ្ហភាព ដើម្បី ផ្លាស់ ប្ដូរ ខណៈ ពេល អ្នក ដេក ។"},"Change to Smart Curve":{"en":"Change to Smart Curve","zh-Hans":"调整至智能曲线","fr":"Passer à la courbe intelligente","ja":"スマートカーブに変更する","it":"Passa alla curva intelligente","es":"Cambiar a Curva Inteligente","pt":"Mudar para Smart Curve","de":"Zu Smart Curve wechseln","ru":"Переход на интеллектуальную кривую","vi":"Thay đổi thành Đường cong thông minh","th":"เปลี่ยนเป็นสมาร์ทเคิร์ฟ","id":"Mengubah ke Kurva Cerdas","zh-Hant":"調整至智能曲線","zh-TW":"調整至智能曲線","ar":"لتغيير إلى المنحنى الذكي","hu":"Váltás az intelligens görbére","el":"Αλλαγή σε έξυπνη καμπύλη","nl":"Overschakelen naar Smart Curve","pl":"Zmień na inteligentną krzywą","fi":"Vaihda älykkääseen käyrään","sv":"Ändra till smart kurva","km":"ផ្លាស់ ប្តូរ ទៅ ខ្សែកោង ឆ្លាត"},"When enabled, the AC will power off at the end of the sleep cycle. When disabled,the unit will maintain the last setpoint":{"en":"When enabled, the AC will power off at the end of the sleep cycle. When disabled,the unit will maintain the last setpoint","zh-Hans":"当启用时，空调将在睡眠周期结束时关闭电源。当禁用时,设备将保持最后的设定点。","fr":"Lorsqu'il est activé, le CA s'éteint à la fin du cycle de sommeil. Lorsqu'elle est désactivée, l'unité maintient le dernier point de consigne.","ja":"有効な場合、ACはスリープサイクルの終了時に電源が切れます。無効の場合、最後の設定値を維持します。","it":"Se abilitato, il condizionatore si spegne al termine del ciclo di sonno. Se disabilitata, l'unità manterrà l'ultimo setpoint.","es":"Si está activada, la unidad se apagará al final del ciclo de sueño. Si está desactivada, la unidad mantendrá el último valor de consigna.","pt":"Quando ativado, o ar condicionado desliga-se no final do ciclo do sono. Quando desativada, a unidade manterá a último configuração","de":"Wenn aktiviert, schaltet sich die Klimaanlage am Ende des Schlafzyklus aus. Wenn deaktiviert, behält das Gerät den letzten Sollwert bei.","ru":"Если включена, кондиционер выключится в конце цикла сна. Если отключено, устройство будет поддерживать последнее заданное значение.","vi":"Khi được bật, AC sẽ tắt nguồn khi kết thúc chu kỳ ngủ. Khi bị tắt, thiết bị sẽ duy trì điểm cài đặt cuối cùng","th":"เมื่อเปิดใช้งาน AC จะปิดเมื่อสิ้นสุดรอบการนอนหลับ เมื่อปิดใช้งาน เครื่องจะรักษาค่าที่ตั้งไว้ล่าสุด","id":"Saat diaktifkan, AC akan mati di akhir siklus tidur. Saat dinonaktifkan, unit akan mempertahankan setpoint terakhir","zh-Hant":"當啟用時，空調將在周期睡眠結束時關閉電源。當禁用時，設備將保持最後的設定點。","zh-TW":"當啟用時，空調將在周期睡眠結束時關閉電源。當禁用時，設備將保持最後的設定點。","ar":"عند التمكين ، سيتم إيقاف تشغيل التيار المتردد في نهاية دورة السكون. وعند التعطيل ، ستحتفظ الوحدة بآخر نقطة ضبط","hu":"Ha engedélyezve van, a légkondicionáló az alvási ciklus végén kikapcsol. Ha ki van kapcsolva, a készülék megtartja az utolsó beállított értéket.","el":"Όταν είναι ενεργοποιημένη, το κλιματιστικό θα απενεργοποιηθεί στο τέλος του κύκλου ύπνου. Όταν είναι απενεργοποιημένη, η μονάδα θα διατηρήσει το τελευταίο σημείο ρύθμισης","nl":"Indien ingeschakeld, wordt de AC uitgeschakeld aan het einde van de slaapcyclus. Wanneer uitgeschakeld, handhaaft het apparaat het laatste instelpunt.","pl":"Po włączeniu, klimatyzator wyłączy się po zakończeniu cyklu uśpienia. Po wyłączeniu, urządzenie utrzyma ostatnią wartość zadaną","fi":"Kun tämä on käytössä, AC kytkeytyy pois päältä unijakson päätyttyä. Kun se on poistettu käytöstä, laite säilyttää viimeisimmän asetusarvon","sv":"När den är aktiverad stängs AC-enheten av i slutet av viloperioden. När den är inaktiverad kommer enheten att behålla det senaste börvärdet","km":"នៅ ពេល ដែល អាច ធ្វើ បាន AC នឹង ប្រើ ថាមពល នៅ ចុង បញ្ចប់ នៃ វដ្ត ដេក ។ នៅពេលបិទ,អង្គភាពនឹងរក្សាទុកចំណុចកំណត់ចុងក្រោយ"},"January":{"en":"January","zh-Hans":"一月","fr":"Janvier","ja":"1月","it":"Gennaio","es":"Enero","pt":"Janeiro","de":"Januar","ru":"январь","vi":"Tháng Một","th":"มกราคม","id":"Januari","zh-Hant":"一月","zh-TW":"一月","ar":"يناير","hu":"Január","el":"Ιανουάριος","nl":"Januari","pl":"Styczeń","fi":"Tammikuu","sv":"Januari Februari","km":"ខែមករា"},"February":{"en":"February","zh-Hans":"二月","fr":"Février","ja":"2月","it":"Febbraio","es":"Febrero","pt":"Fevereiro","de":"Februar","ru":"февраль","vi":"Tháng hai","th":"กุมภาพันธ์","id":"Februari","zh-Hant":"二月","zh-TW":"二月","ar":"شهر فبراير","hu":"Február","el":"Φεβρουάριος","nl":"Februari","pl":"Luty","fi":"Helmikuu","sv":"Februari","km":"ខែកុម្ភៈ"},"March":{"en":"March","zh-Hans":"行进","fr":"marcher","ja":"行進する","it":"marciare","es":"Marchar","pt":"Março","de":"bis März","ru":"маршировать","vi":"diễu hành","th":"เดินขบวน","id":"untuk berbaris","zh-Hant":"行進","zh-TW":"行進","ar":"للقيام بمسيرة","hu":"Március","el":"Μάρτιος","nl":"Maart","pl":"Marzec","fi":"Maaliskuu","sv":"mars","km":"ខែមិនា"},"April":{"en":"April","zh-Hans":"四月","fr":"Avril","ja":"4月","it":"aprile","es":"Abril","pt":"Abril","de":"April","ru":"апрель","vi":"Tháng tư","th":"เมษายน","id":"April","zh-Hant":"四月","zh-TW":"四月","ar":"أبريل","hu":"Április","el":"Απρίλιος","nl":"April","pl":"Kwiecień","fi":"Huhtikuu","sv":"april","km":"ខែមេសា"},"May":{"en":"May","zh-Hans":"可能","fr":"possible","ja":"可能","it":"possibile","es":"posible","pt":"Maio","de":"möglich","ru":"возможный","vi":"khả thi","th":"เป็นไปได้","id":"mungkin","zh-Hant":"可能","zh-TW":"可能","ar":"ممكن","hu":"Május","el":"Μάιος","nl":"Mei","pl":"maj","fi":"Toukokuu","sv":"maj","km":"ខែឧសភា"},"June":{"en":"June","zh-Hans":"六月","fr":"Juin","ja":"六月","it":"Giugno","es":"Junio","pt":"Junho","de":"Juni","ru":"Июнь","vi":"Tháng sáu","th":"มิถุนายน","id":"Juni","zh-Hant":"六月","zh-TW":"六月","ar":"يونيو","hu":"Június","el":"Ιούνιος","nl":"Juni","pl":"czerwiec","fi":"Kesäkuu","sv":"juni","km":"ខែមិថុនា"},"July":{"en":"July","zh-Hans":"七月","fr":"Juillet","ja":"7月","it":"Luglio","es":"Julio","pt":"Julho","de":"Juli","ru":"Июль","vi":"Tháng bảy","th":"กรกฎาคม","id":"Juli","zh-Hant":"七月","zh-TW":"七月","ar":"يوليو","hu":"Július","el":"Ιούλιος","nl":"Juli","pl":"lipiec","fi":"Heinäkuu","sv":"juli","km":"ខែកក្កដា"},"August":{"en":"August","zh-Hans":"八月","fr":"Août","ja":"8月","it":"agosto","es":"Agosto","pt":"Agosto","de":"August","ru":"Август","vi":"Tháng tám","th":"สิงหาคม","id":"Agustus","zh-Hant":"八月","zh-TW":"八月","ar":"أغسطس","hu":"Augusztus","el":"Αύγουστος","nl":"Augustus","pl":"sierpień","fi":"Elokuu","sv":"augusti","km":"ខែសីហា"},"September":{"en":"September","zh-Hans":"九月","fr":"Septembre","ja":"9月","it":"settembre","es":"Septiembre","pt":"Setembro","de":"September","ru":"Сентябрь","vi":"Tháng 9","th":"กันยายน","id":"September","zh-Hant":"九月","zh-TW":"九月","ar":"سبتمبر","hu":"Szeptember","el":"Σεπτέμβριος","nl":"September","pl":"wrzesień","fi":"Syyskuu","sv":"september oktober","km":"ខែកញ្ញា"},"October":{"en":"October","zh-Hans":"十月","fr":"Octobre","ja":"10月","it":"ottobre","es":"Octubre","pt":"Outubro","de":"Oktober","ru":"Октябрь","vi":"Tháng Mười","th":"ตุลาคม","id":"Oktober","zh-Hant":"十月","zh-TW":"十月","ar":"اكتوبر","hu":"Október","el":"Οκτώβριος","nl":"Oktober","pl":"październik","fi":"Lokakuu","sv":"oktober november","km":"ខែតុលា"},"November":{"en":"November","zh-Hans":"十一月","fr":"Novembre","ja":"11月","it":"novembre","es":"Noviembre","pt":"Novembro","de":"November","ru":"ноябрь","vi":"Tháng mười một","th":"พฤศจิกายน","id":"November","zh-Hant":"十一月","zh-TW":"十一月","ar":"شهر نوفمبر","hu":"November","el":"Νοέμβριος","nl":"November","pl":"listopad","fi":"Marraskuu","sv":"november december","km":"ខែវិច្ឆិកា"},"December":{"en":"December","zh-Hans":"十二月","fr":"Décembre","ja":"12月","it":"Dicembre","es":"Diciembre","pt":"Dezembro","de":"Dezember","ru":"Декабрь","vi":"Tháng 12","th":"ธันวาคม","id":"Desember","zh-Hant":"十二月","zh-TW":"十二月","ar":"ديسمبر","hu":"December","el":"Δεκέμβριος","nl":"December","pl":"Grudzień","fi":"Joulukuu","sv":"december","km":"ខែធ្នូ"},"Target":{"en":"Target","zh-Hans":"目标","fr":"Cible","ja":"目標","it":"Bersaglio","es":"Objetivo","pt":"Alvo","de":"Ziel","ru":"Цель","vi":"Mục tiêu","th":"เป้า","id":"Target","zh-Hant":"目標","zh-TW":"目標","ar":"هدف","hu":"Cél","el":"Στόχος","nl":"Doel","pl":"Cel","fi":"Tavoite","sv":"Mål","km":"គោលដៅ"},"Dynamically adjust the temperature while sleeping":{"en":"Dynamically adjust the temperature while sleeping","zh-Hans":"睡眠时动态调节温度","fr":"Ajuster dynamiquement la température pendant le sommeil","ja":"睡眠中に温度を動的に調整する","it":"Regola dinamicamente la temperatura durante il sonno","es":"Ajuste dinámicamente la temperatura durante el sueño","pt":"Ajuste dinamicamente a temperatura durante o sono","de":"Passen Sie die Temperatur während des Schlafs dynamisch an","ru":"Динамическая регулировка температуры во время сна","vi":"Tự động điều chỉnh nhiệt độ trong khi ngủ","th":"ปรับอุณหภูมิแบบไดนามิกระหว่างการนอนหลับ","id":"Menyesuaikan suhu secara dinamis selama tidur","zh-Hant":"睡眠時動態調節溫度","zh-TW":"睡眠時動態調節溫度","ar":"ضبط درجة الحرارة ديناميكيًا أثناء النوم","hu":"A hőmérséklet dinamikus beállítása alvás közben","el":"Δυναμική προσαρμογή της θερμοκρασίας κατά τη διάρκεια του ύπνου","nl":"Pas de temperatuur dynamisch aan tijdens het slapen","pl":"Dynamiczna regulacja temperatury podczas snu","fi":"Säädä lämpötilaa dynaamisesti nukkumisen aikana","sv":"Justera temperaturen dynamiskt medan du sover","km":"លៃ តម្រូវ សីតុណ្ហភាព ពេល កំពុង ដេក"},"Preselect your favoritesettings for one touch activation":{"en":"Preselect your favoritesettings for one touch activation","zh-Hans":"预先选择您最喜爱的设置以进行一键激活","fr":"Présélectionnez vos paramètres favoris pour une activation en un clic","ja":"ワンクリックでアクティベーションできるようにお気に入りの設定を事前に選択してください","it":"Preseleziona le tue impostazioni preferite per l'attivazione con un clic","es":"Preseleccione su configuración favorita para la activación con un solo clic","pt":"Pré-selecione suas configurações favoritas para ativação com um clique","de":"Wählen Sie Ihre bevorzugten Einstellungen für die Ein-Klick-Aktivierung vorab aus","ru":"Предварительно выберите ваши любимые настройки для активации в один клик","vi":"Chọn trước cài đặt yêu thích của bạn để kích hoạt bằng một cú nhấp chuột","th":"เลือกการตั้งค่าที่คุณชื่นชอบล่วงหน้าสำหรับการเปิดใช้งานด้วยคลิกเดียว","id":"Pra-pilih pengaturan favorit Anda untuk aktivasi sekali klik","zh-Hant":"預先選擇您最喜愛的設置以進行一鍵激活","zh-TW":"預先選擇您最喜愛的設置以進行一鍵激活","ar":"حدد مسبقًا الإعدادات المفضلة لديك للتنشيط بنقرة واحدة","hu":"Előre kiválasztja kedvenc beállításait az egyérintéses aktiváláshoz","el":"Προεπιλογή των αγαπημένων σας ρυθμίσεων για ενεργοποίηση με ένα άγγιγμα","nl":"Voorselecteer je favoriete instellingen voor activering met één druk op de knop","pl":"Wstępny wybór ulubionych ustawień dla aktywacji jednym dotknięciem","fi":"Esivalitse suosikkiasetukset yhdellä kosketuksella aktivoitavaksi.","sv":"Förvalt dina favoritinställningar för aktivering med en knapptryckning","km":"Preselect your favoritesettings for one touch activation"},"Control when and how your AC operates":{"en":"Control when and how your AC operates","zh-Hans":"控制空调的运行时间和方式","fr":"Contrôlez quand et comment votre climatiseur fonctionne","ja":"エアコンをいつどのように作動させるかを制御する","it":"Controlla quando e come funziona il tuo climatizzatore","es":"Controla cuándo y cómo funciona tu aire acondicionado","pt":"Controle quando e como o seu ar condicionado funciona","de":"Steuern Sie, wann und wie Ihre Klimaanlage läuft","ru":"Контролируйте, когда и как работает ваш кондиционер","vi":"Kiểm soát thời gian và cách máy điều hòa không khí của bạn chạy","th":"ควบคุมเวลาและวิธีที่เครื่องปรับอากาศของคุณทำงาน","id":"Kontrol kapan dan bagaimana AC Anda bekerja","zh-Hant":"控制空調的運行時間和方式","zh-TW":"控制空調的運行時間和方式","ar":"تحكم في وقت وكيفية تشغيل مكيف الهواء الخاص بك","hu":"Szabályozza, hogy mikor és hogyan működjön a légkondicionáló","el":"Ελέγξτε πότε και πώς λειτουργεί το κλιματιστικό σας","nl":"Bepaal wanneer en hoe je AC werkt","pl":"Kontroluj, kiedy i jak działa klimatyzacja","fi":"Hallitse, milloin ja miten ilmastointilaite toimii","sv":"Styr när och hur AC:n ska vara igång","km":"ត្រួតពិនិត្យពេល និងរបៀបដែល AC របស់អ្នកដំណើរការ"},"Only online data of power consumption after 11/10/2019 is available":{"en":"*Only count power on hours while the device is online","zh-Hans":"仅提供2019年11月10日之后的电力消耗在线数据","fr":"*Compter uniquement les heures de mise sous tension lorsque l'appareil est en ligne","ja":"*デバイスがオンラインである間のみ、電源オン時間をカウントします。","it":"*Conta solo le ore di accensione mentre il dispositivo è online","es":"*Sólo cuenta las horas de encendido mientras el dispositivo está conectado","pt":"*Só conta as horas de ligação enquanto o dispositivo estiver online","de":"*Zählt nur die Einschaltstunden, wenn das Gerät online ist","ru":"*Считать только время включения, пока устройство находится в сети.","vi":"*Chỉ tính nguồn điện theo giờ khi thiết bị đang trực tuyến","th":"*นับเฉพาะการเปิดเครื่องเป็นชั่วโมงในขณะที่อุปกรณ์ออนไลน์อยู่","id":"*Hanya menghitung jam penyalaan saat perangkat online","zh-Hant":"僅提供2019年11月10日後的電力消耗線上數據","zh-TW":"僅提供2019年11月10日後的電力消耗線上數據","ar":"يتم توفير البيانات عبر الإنترنت فقط حول استهلاك الكهرباء بعد 10 نوفمبر 2019","hu":"* Csak akkor számolja a bekapcsolt órákat, amikor a készülék online van.","el":"*Μετράτε μόνο τις ώρες λειτουργίας όσο η συσκευή είναι συνδεδεμένη","nl":"*Alleen inschakeluren tellen als het apparaat online is","pl":"*Zliczanie godzin włączonego zasilania tylko wtedy, gdy urządzenie jest online","fi":"*Laskekaa vain päälläolotunnit, kun laite on verkossa.","sv":"*Räknar endast påslagna timmar när enheten är online","km":"*គ្រាន់តែរាប់ថាមពលលើម៉ោងខណៈពេលដែលឧបករណ៍មាននៅលើអ៊ីនធើណែត"},"Well done!":{"en":"Well done!","zh-Hans":"做得好！","fr":"bien joué!","ja":"素晴らしい！","it":"ben fatto!","es":"¡bien hecho!","pt":"bom trabalho!","de":"gut gemacht!","ru":"отличная работа!","vi":"làm tốt!","th":"ทำได้ดี!","id":"bagus sekali!","zh-Hant":"做得好！","zh-TW":"做得好！","ar":"أحسنت!","hu":"Szép munka!","el":"Μπράβο!","nl":"Goed gedaan!","pl":"Brawo!","fi":"Hyvin tehty!","sv":"Bra jobbat!","km":"ធ្វើបានល្អ​ណាស់!"},"You’re within your monthly target":{"en":"You're within your monthly target","zh-Hans":"您已达到每月目标","fr":"Vous avez atteint votre objectif mensuel","ja":"毎月の目標を達成しました","it":"Hai raggiunto il tuo obiettivo mensile","es":"Has alcanzado tu objetivo mensual","pt":"Você atingiu sua meta mensal","de":"Sie haben Ihr Monatsziel erreicht","ru":"Вы достигли месячной цели","vi":"Bạn đã đạt được mục tiêu hàng tháng của mình","th":"คุณบรรลุเป้าหมายประจำเดือนแล้ว","id":"Anda telah mencapai target bulanan Anda","zh-Hant":"您已達到每月目標","zh-TW":"您已達到每月目標","ar":"لقد وصلت إلى هدفك الشهري","hu":"A havi célon belül van","el":"Βρίσκεστε εντός του μηνιαίου στόχου σας","nl":"Je bent binnen je maandelijkse doelstelling","pl":"Osiągnąłeś swój miesięczny cel","fi":"Olet kuukausittaisen tavoitteesi sisällä.","sv":"Du ligger inom ditt månadsmål","km":"អ្នក ស្ថិត នៅ ក្នុង គោលដៅ ប្រចាំ ខែ របស់ អ្នក"},"This Month":{"en":"This Month","zh-Hans":"这个月","fr":"Ce mois-ci","ja":"今月","it":"Questo mese","es":"Este mes","pt":"Este mês","de":"Diesen Monat","ru":"Этот месяц","vi":"Tháng này","th":"เดือนนี้","id":"Bulan ini","zh-Hant":"這個月","zh-TW":"這個月","ar":"هذا الشهر","hu":"Ebben a hónapban","el":"Αυτός ο μήνας","nl":"Deze maand","pl":"W tym miesiącu","fi":"Tämä kuukausi","sv":"Denna månad","km":"ខែ នេះ"},"Last Month":{"en":"Last Month","zh-Hans":"上个月","fr":"le mois dernier","ja":"先月","it":"lo scorso mese","es":"el mes pasado","pt":"Mês passado","de":"Im vergangenen Monat","ru":"прошлый месяц","vi":"tháng trước","th":"เดือนที่แล้ว","id":"bulan lalu","zh-Hant":"上個月","zh-TW":"上個月","ar":"الشهر الماضي","hu":"Múlt hónap","el":"Τελευταίος μήνας","nl":"Laatste maand","pl":"Ostatni miesiąc","fi":"Viime kuukausi","sv":"Förra månaden","km":"ខែ មុន"},"Monthly Target":{"en":"Monthly Target","zh-Hans":"每月目标","fr":"objectif mensuel","ja":"毎月の目標","it":"obiettivo mensile","es":"meta mensual","pt":"Meta mensal","de":"Monatsziel","ru":"ежемесячная цель","vi":"mục tiêu hàng tháng","th":"เป้าหมายรายเดือน","id":"target bulanan","zh-Hant":"每月目標","zh-TW":"每月目標","ar":"الهدف الشهري","hu":"Havi cél","el":"Μηνιαίος στόχος","nl":"Maandelijks doel","pl":"Miesięczny cel","fi":"Kuukausitavoite","sv":"Månatligt mål","km":"គោលដៅប្រចាំខែ"},"Difference":{"en":"Difference","zh-Hans":"不同之处","fr":"la différence","ja":"違い","it":"la differenza","es":"la diferencia","pt":"Diferença","de":"der Unterschied","ru":"разница","vi":"Sự khác biệt","th":"ความแตกต่าง","id":"perbedaan","zh-Hant":"不同之處","zh-TW":"不同之處","ar":"الاختلاف","hu":"Különbség","el":"Διαφορά","nl":"Verschil","pl":"Różnica","fi":"Ero","sv":"Skillnad","km":"ភាពខុសគ្នា"},"Choose the maximum and miniumim set temperature range allowed":{"en":"Choose the maximum and miniumim set temperature range allowed","zh-Hans":"选择允许的最大和最小设定温度范围","fr":"Sélectionnez la plage de température de consigne maximale et minimale autorisée","ja":"許容される最大および最小の設定温度範囲を選択します","it":"Selezionare l'intervallo di temperatura impostato massimo e minimo consentito","es":"Seleccione el rango de temperatura establecido máximo y mínimo permitido","pt":"Selecione a faixa de temperatura máxima e mínima permitida","de":"Wählen Sie den zulässigen maximalen und minimalen Temperaturbereich aus","ru":"Выберите допустимый максимальный и минимальный диапазон заданной температуры","vi":"Chọn phạm vi nhiệt độ cài đặt tối đa và tối thiểu cho phép","th":"เลือกช่วงอุณหภูมิสูงสุดและต่ำสุดที่ตั้งไว้","id":"Pilih kisaran suhu maksimum dan minimum yang diperbolehkan","zh-Hant":"選擇允許的最大和最小設定溫度範圍","zh-TW":"選擇允許的最大和最小設定溫度範圍","ar":"حدد الحد الأقصى والأدنى المسموح به لنطاق درجة الحرارة المحددة","hu":"Válassza ki a maximális és minimálisan megengedett hőmérsékleti tartományt.","el":"Επιλέξτε το μέγιστο και το ελάχιστο επιτρεπόμενο εύρος της ρυθμισμένης θερμοκρασίας","nl":"Kies het maximaal en minimaal toegestane temperatuurbereik","pl":"Wybór maksymalnego i minimalnego zakresu ustawionej temperatury","fi":"Valitse suurin ja pienin sallittu lämpötilan vaihteluväli.","sv":"Välj högsta och lägsta tillåtna inställda temperaturintervall","km":"ជ្រើស ជួរ សីតុណ្ហភាព អតិបរមា និង miniumim ដែល អនុញ្ញាត"},"Preselect your favorite settings for one touch activation":{"en":"Preselect your favorite settings for one touch activation","zh-Hans":"预先选择您最喜爱的一键激活设置","fr":"Présélectionnez vos paramètres d'activation en un clic préférés","ja":"お気に入りのワンクリックアクティベーション設定を事前に選択してください","it":"Preseleziona le tue impostazioni di attivazione con un clic preferite","es":"Preseleccione su configuración favorita de activación con un solo clic","pt":"Pré-selecione suas configurações de ativação com um clique favoritas","de":"Wählen Sie Ihre bevorzugten Ein-Klick-Aktivierungseinstellungen aus","ru":"Предварительно выберите ваши любимые настройки активации в один клик","vi":"Chọn trước cài đặt kích hoạt bằng một cú nhấp chuột yêu thích của bạn","th":"เลือกการตั้งค่าการเปิดใช้งานแบบคลิกเดียวที่คุณชื่นชอบไว้ล่วงหน้า","id":"Pra-pilih pengaturan aktivasi satu-klik favorit Anda","zh-Hant":"預先選擇您最喜愛的一鍵激活設置","zh-TW":"預先選擇您最喜愛的一鍵激活設置","ar":"حدد مسبقًا إعدادات التنشيط المفضلة لديك بنقرة واحدة","hu":"Előre kiválasztja kedvenc beállításait az egyérintéses aktiváláshoz","el":"Προεπιλογή των αγαπημένων σας ρυθμίσεων για ενεργοποίηση με ένα άγγιγμα","nl":"Voorselecteer je favoriete instellingen voor activering met één druk op de knop","pl":"Wstępny wybór ulubionych ustawień dla aktywacji jednym dotknięciem","fi":"Esivalitse suosikkiasetuksesi yhdellä kosketuksella aktivoitaviksi.","sv":"Förvalt dina favoritinställningar för aktivering med en knapptryckning","km":"Preselect your favorite settings for one touch activation"},"Sleep Curve feature updated":{"en":"Sleep Curve feature updated","zh-Hans":"睡眠曲线功能更新","fr":"Mise à jour de la fonctionnalité de courbe de sommeil","ja":"睡眠カーブ機能のアップデート","it":"Aggiornamento delle funzionalità della curva del sonno","es":"Actualización de la función de curva de sueño","pt":"Atualização do recurso de curva de sono","de":"Aktualisierung der Schlafkurvenfunktion","ru":"Обновление функции кривой сна","vi":"Cập nhật tính năng đường cong giấc ngủ","th":"อัพเดตฟีเจอร์ Sleep Curve","id":"Pembaruan Fitur Kurva Tidur","zh-Hant":"睡眠曲線功能更新","zh-TW":"睡眠曲線功能更新","ar":"تحديث ميزة منحنى النوم","hu":"Az alvási görbe funkció frissítve","el":"Ενημέρωση της λειτουργίας καμπύλης ύπνου","nl":"Sleep Curve functie bijgewerkt","pl":"Zaktualizowano funkcję krzywej uśpienia","fi":"Unikäyrätoiminto päivitetty","sv":"Funktionen Sleep Curve uppdaterad","km":"លក្ខណៈពិសេសខ្សែកោងគេង updated"},"Application may be off-power or in use":{"en":"Application may be off-power or in use","zh-Hans":"应用程序可能已断电或正在使用","fr":"L'application peut être éteinte ou en cours d'utilisation","ja":"アプリケーションの電源がオフになっているか、使用中の可能性があります","it":"L'applicazione potrebbe essere spenta o in uso","es":"La aplicación puede estar apagada o en uso","pt":"O aplicativo pode estar desligado ou em uso","de":"Die Anwendung ist möglicherweise ausgeschaltet oder wird verwendet","ru":"Приложение может быть выключено или используется","vi":"Ứng dụng có thể bị tắt nguồn hoặc đang sử dụng","th":"แอปพลิเคชันอาจถูกปิดหรือใช้งานอยู่","id":"Aplikasi mungkin dimatikan atau sedang digunakan","zh-Hant":"應用程序可能已斷電或正在使用","zh-TW":"應用程序可能已斷電或正在使用","ar":"قد يتم إيقاف تشغيل التطبيق أو استخدامه","hu":"Az alkalmazás kikapcsolt állapotban vagy használatban lehet.","el":"Η εφαρμογή μπορεί να είναι εκτός λειτουργίας ή σε χρήση","nl":"Toepassing kan uit of in gebruik zijn","pl":"Aplikacja może być wyłączona lub w użyciu","fi":"Sovellus voi olla pois päältä tai käytössä.","sv":"Applikationen kan vara strömlös eller i bruk","km":"កម្មវិធី អាច នឹង មិន មាន ថាមពល ឬ ប្រើ ប្រាស់"},"Reconnect":{"en":"Reconnect","zh-Hans":"重新连接","fr":"se reconnecter","ja":"再接続する","it":"riconnettersi","es":"reconectar","pt":"reconectar","de":"wieder verbinden","ru":"восстановить соединение","vi":"kết nối lại","th":"เชื่อมต่อใหม่","id":"menghubungkan kembali","zh-Hant":"重新連接","zh-TW":"重新連接","ar":"أعد الاتصال","hu":"Újracsatlakozás","el":"Επανασύνδεση","nl":"Opnieuw aansluiten","pl":"Połącz ponownie","fi":"Kytke uudelleen","sv":"Återanslut","km":"ការតភ្ជាប់ឡើងវិញ"},"1. Please confirm whether the device is properly powered":{"en":"1. Please confirm whether the device is properly powered","zh-Hans":"1.请确认设备是否正常供电","fr":"1. Veuillez confirmer si l'appareil est alimenté normalement","ja":"1. デバイスに正常に電力が供給されているかどうかを確認してください","it":"1. Confermare se il dispositivo è alimentato normalmente","es":"1. Confirma si el dispositivo funciona normalmente.","pt":"1. Confirme se o dispositivo está funcionando normalmente","de":"1. Bitte überprüfen Sie, ob das Gerät normal mit Strom versorgt wird","ru":"1. Пожалуйста, подтвердите, нормально ли питание устройства.","vi":"1. Vui lòng xác nhận xem thiết bị có được cấp nguồn bình thường không","th":"1.โปรดยืนยันว่าอุปกรณ์เปิดอยู่ตามปกติหรือไม่","id":"1. Harap konfirmasi apakah perangkat diberi daya secara normal","zh-Hant":"1.請確認設備是否正常供電","zh-TW":"1.請確認設備是否正常供電","ar":"1. يرجى تأكيد ما إذا كان الجهاز يعمل بشكل طبيعي","hu":"1. Kérjük, ellenőrizze, hogy a készülék megfelelően van-e bekapcsolva.","el":"1. Παρακαλούμε επιβεβαιώστε αν η συσκευή τροφοδοτείται σωστά με ρεύμα","nl":"1. Controleer of het apparaat correct is ingeschakeld","pl":"1. sprawdź, czy urządzenie jest prawidłowo zasilane","fi":"1. Varmista, että laitteeseen on kytketty virta oikein.","sv":"1. Vänligen bekräfta att enheten är korrekt strömförsörjd","km":"១. សូម បញ្ជាក់ ថា តើ ឧបករណ៍ នេះ មាន ថាមពល ត្រឹមត្រូវ ឬ អត់"},"2. Whether the WiFi name or password has been changed, if so, please reconnect;":{"en":"2. Whether the WiFi name or password has been changed, if so, please reconnect;","zh-Hans":"2. WiFi名称或密码是否已更改，如有，请重新连接；","fr":"2. Si le nom ou le mot de passe WiFi a été modifié, si c'est le cas, veuillez vous reconnecter ;","ja":"2. WiFi 名またはパスワードが変更されているかどうか、変更されている場合は再接続してください。","it":"2. Se il nome WiFi o la password sono stati modificati, in tal caso riconnettersi;","es":"2. Si se ha cambiado el nombre o la contraseña de WiFi, si es así, vuelva a conectarse;","pt":"2. Se o nome ou a senha do WiFi foi alterado, em caso afirmativo, reconecte-se;","de":"2. Ob der WLAN-Name oder das Passwort geändert wurde. Wenn ja, stellen Sie bitte erneut eine Verbindung her.","ru":"2. Были ли изменены имя или пароль WiFi, если да, повторите подключение;","vi":"2. Tên WiFi hoặc mật khẩu có bị thay đổi hay không, nếu có, vui lòng kết nối lại;","th":"2. เปลี่ยนชื่อ WiFi หรือรหัสผ่านหรือไม่ ถ้าใช่ โปรดเชื่อมต่อใหม่","id":"2. Apakah nama atau kata sandi WiFi telah diubah, jika demikian, harap sambungkan kembali;","zh-Hant":"2. WiFi名稱或密碼是否已更改，如有，請重新連接；","zh-TW":"2. WiFi名稱或密碼是否已更改，如有，請重新連接；","ar":"2. ما إذا تم تغيير اسم WiFi أو كلمة المرور ، إذا كان الأمر كذلك ، يرجى إعادة الاتصال ؛","hu":"2. Megváltozott-e a WiFi név vagy jelszó, ha igen, kérjük, csatlakozzon újra;","el":"2. Εάν έχει αλλάξει το όνομα ή ο κωδικός πρόσβασης WiFi, εάν ναι, παρακαλούμε επανασυνδεθείτε,","nl":"2. Of de WiFi-naam of het wachtwoord is gewijzigd, zo ja, maak dan opnieuw verbinding;","pl":"2. Czy nazwa WiFi lub hasło zostały zmienione, jeśli tak, połącz się ponownie;","fi":"2. Onko WiFi-nimi tai salasana muutettu, jos on, ota yhteys uudelleen;","sv":"2. Kontrollera om WiFi-namnet eller lösenordet har ändrats, om så är fallet, återanslut;","km":"2. មិន ថា ឈ្មោះ WiFi ឬ ពាក្យ សម្ងាត់ ត្រូវ បាន ផ្លាស់ប្ដូរ ទេ បើ ដូច្នេះ សូម ភ្ជាប់ ឡើង វិញ;"},"3. Whether the network signal is stable":{"en":"3. Whether the network signal is stable","zh-Hans":"3. 网络信号是否稳定","fr":"3. Si le signal réseau est stable","ja":"3. ネットワーク信号が安定しているかどうか","it":"3. Se il segnale di rete è stabile","es":"3. Si la señal de la red es estable","pt":"3. Se o sinal da rede é estável","de":"3. Ob das Netzwerksignal stabil ist","ru":"3. Стабилен ли сетевой сигнал?восстановить соединение","vi":"3. Tín hiệu mạng có ổn định không","th":"3. สัญญาณเครือข่ายเสถียรหรือไม่","id":"3. Apakah sinyal jaringan stabil","zh-Hant":"3. 網絡信號是否穩定","zh-TW":"3. 網絡信號是否穩定","ar":"3. ما إذا كانت إشارة الشبكة مستقرة","hu":"3. Hogy a hálózati jel stabil-e","el":"3. Εάν το σήμα του δικτύου είναι σταθερό","nl":"3. Of het netwerksignaal stabiel is","pl":"3. Czy sygnał sieciowy jest stabilny","fi":"3. Onko verkkosignaali vakaa","sv":"3. Om nätverkssignalen är stabil","km":"៣. ថា តើ សញ្ញា បណ្ដាញ មាន ស្ថេរ ភាព ឬ អត់"},"Device may be powered off or in use":{"en":"Device may be powered off or in use","zh-Hans":"设备可能已关闭电源或正在使用","fr":"L'appareil peut être hors tension ou en cours d'utilisation","ja":"デバイスの電源がオフであるか、使用中であるか","it":"Il dispositivo può essere spento o in uso","es":"El dispositivo puede estar apagado o en uso","pt":"O dispositivo pode estar desligado ou a ser utilizado","de":"Das Gerät kann ausgeschaltet oder in Betrieb sein","ru":"Устройство может быть выключено или находиться в рабочем состоянии","vi":"Thiết bị có thể bị tắt nguồn hoặc đang sử dụng","th":"อุปกรณ์อาจปิดอยู่หรือกำลังใช้งานอยู่","id":"Perangkat dapat dimatikan atau sedang digunakan","zh-Hant":"設備可能已關閉電源或正在使用","zh-TW":"設備可能已關閉電源或正在使用","ar":"قد يتم إيقاف تشغيل الجهاز أو استخدامه","hu":"A készülék kikapcsolt vagy használatban lévő","el":"Η συσκευή μπορεί να είναι απενεργοποιημένη ή σε χρήση","nl":"Apparaat kan uitgeschakeld of in gebruik zijn","pl":"Urządzenie może być wyłączone lub w użyciu","fi":"Laite voi olla pois päältä tai käytössä","sv":"Enheten kan vara avstängd eller användas","km":"ឧបករណ៍ អាច ត្រូវ បាន ប្រើ ថាមពល ឬ ប្រើ"},"1. Please confirm whether the device is properly powered on":{"en":"1. Please confirm whether the device is properly powered on","zh-Hans":"1. 请确认设备的电源是否正确打开","fr":"1. Veuillez vérifier si l'appareil est correctement mis sous tension","ja":"1. デバイスの電源が入っているか確認してください。","it":"1. Verificare che il dispositivo sia correttamente acceso","es":"1. Por favor, confirme si el dispositivo está correctamente encendido","pt":"1. Confirme se o dispositivo está corretamente ligado","de":"1. Prüfen Sie, ob das Gerät ordnungsgemäß eingeschaltet ist.","ru":"1. Убедитесь, что устройство правильно включено","vi":"1. Vui lòng xác nhận xem nguồn của thiết bị đã được bật chính xác hay chưa","th":"1. โปรดยืนยันว่าอุปกรณ์เปิดอย่างถูกต้องหรือไม่","id":"1. Harap konfirmasikan apakah perangkat telah dihidupkan dengan benar","zh-Hant":"1. 請確認設備的電源是否正確打開","zh-TW":"1. 請確認設備的電源是否正確打開","ar":"1. يرجى تأكيد ما إذا كانت طاقة الجهاز قيد التشغيل بشكل صحيح","hu":"1. Kérjük, ellenőrizze, hogy a készülék megfelelően be van-e kapcsolva","el":"1. Παρακαλούμε επιβεβαιώστε αν η συσκευή είναι σωστά ενεργοποιημένη","nl":"1. Controleer of het apparaat goed is ingeschakeld","pl":"1. Sprawdź, czy urządzenie jest prawidłowo włączone","fi":"1. Varmista, että laitteeseen on kytketty virta oikein","sv":"1. Kontrollera att enheten är korrekt påslagen","km":"១. សូម បញ្ជាក់ ថា តើ ឧបករណ៍ នេះ មាន ថាមពល ត្រឹមត្រូវ ឬ អត់"},"2. If someone is connecting, please ask him/her to exit the page first":{"en":"2. If someone is connecting, please ask him/her to exit the page first","zh-Hans":"2. 如果有人正在连接，请先让他/她退出页面","fr":"2. Si quelqu'un est en train de se connecter, demandez-lui de quitter la page d'abord.","ja":"2. 接続中の人がいる場合は、その人にページを終了してもらうようお願いしてください。","it":"2. Se qualcuno si sta collegando, chiedergli di uscire dalla pagina.","es":"2. Si alguien se está conectando, por favor, pídale que salga de la página primero","pt":"2. Se alguém estiver a estabelecer ligação, peça-lhe que saia primeiro da página","de":"2. Wenn jemand eine Verbindung herstellt, bitten Sie ihn/sie, die Seite zuerst zu verlassen.","ru":"2. Если кто-то подключается, попросите его/ее сначала выйти со страницы.","vi":"2. Nếu ai đó đang kết nối, hãy yêu cầu họ thoát khỏi trang trước","th":"2. หากมีคนกำลังเชื่อมต่อ ขอให้เขา/เธอออกจากหน้านี้ก่อน","id":"2. Jika ada orang yang sedang terhubung, mohon minta dia untuk keluar dari halaman terlebih dahulu","zh-Hant":"2. 如果有人正在連接，請先讓他/她退出頁面","zh-TW":"2. 如果有人正在連接，請先讓他/她退出頁面","ar":"2. إذا كان هناك شخص ما متصل ، اطلب منه / منها الخروج من الصفحة أولاً","hu":"2. Ha valaki csatlakozik, kérjük, kérje meg, hogy először lépjen ki az oldalról","el":"2. Εάν κάποιος συνδέεται, παρακαλούμε ζητήστε του/της να βγει πρώτα από τη σελίδα","nl":"2. Als iemand verbinding maakt, vraag hem/haar dan eerst de pagina te verlaten","pl":"2. Jeśli ktoś się łączy, poproś go/ją o opuszczenie strony w pierwszej kolejności.","fi":"2. Jos joku on kytkeytymässä, pyydä häntä poistumaan sivulta ensin","sv":"2. Om någon håller på att ansluta, be honom/henne att först lämna sidan","km":"2. បើ មាន នរណា ម្នាក់ កំពុង ភ្ជាប់ គ្នា សូម លោក/នាង ចេញ ទំព័រ មុន"},"3. Keep your phone close to the device":{"en":"3. Keep your phone close to the device","zh-Hans":"3. 请将您的手机靠近设备","fr":"3. Gardez votre téléphone à proximité de l'appareil","ja":"3. 携帯電話を機器に近づけてください。","it":"3. Tenere il telefono vicino al dispositivo","es":"3. Mantenga el teléfono cerca del dispositivo","pt":"3. Mantenha o telemóvel perto do dispositivo","de":"3. Halten Sie Ihr Telefon in der Nähe des Geräts","ru":"3. Держите телефон рядом с устройством","vi":"3. Vui lòng giữ điện thoại của bạn gần thiết bị","th":"3. โปรดถือโทรศัพท์ของคุณใกล้กับอุปกรณ์","id":"3. Dekatkan ponsel Anda ke perangkat","zh-Hant":"3. 請將您的手機靠近設備","zh-TW":"3. 請將您的手機靠近設備","ar":"3. يرجى الإمساك بهاتفك بالقرب من الجهاز","hu":"3. Tartsa a telefonját a készülék közelében","el":"3. Κρατήστε το τηλέφωνό σας κοντά στη συσκευή","nl":"3. Houd uw telefoon dicht bij het apparaat","pl":"3. Trzymaj telefon blisko urządzenia","fi":"3. Pidä puhelin lähellä laitetta","sv":"3. Håll telefonen nära enheten","km":"3. រក្សា ទូរស័ព្ទ របស់ អ្នក ឲ្យ នៅ ជិត ឧបករណ៍"},"Try Again":{"en":"Try Again","zh-Hans":"再试一次","fr":"Réessayez","ja":"再試行","it":"Riprovare","es":"Inténtelo de nuevo","pt":"Tentar novamente","de":"Erneut versuchen","ru":"Попробуйте еще раз","vi":"thử lại","th":"ลองอีกครั้ง","id":"Coba Lagi","zh-Hant":"再試一次","zh-TW":"再試一次","ar":"حاول ثانية","hu":"Próbálja újra","el":"Δοκιμάστε ξανά","nl":"Probeer het opnieuw","pl":"Spróbuj ponownie","fi":"Yritä uudelleen","sv":"Försök igen","km":"ព្យាយាម​ម្តង​ទៀត"},"3. Please sure your phone is close to the device":{"en":"3. Please sure your phone is close to the device","zh-Hans":"3. 请确保你的手机靠近设备","fr":"3. Veillez à ce que votre téléphone soit proche de l'appareil","ja":"3. 携帯電話がデバイスの近くにあることを確認してください。","it":"3. Assicurarsi che il telefono sia vicino al dispositivo","es":"3. Asegúrese de que el teléfono está cerca del dispositivo","pt":"3. Certifique-se de que o seu telemóvel está próximo do dispositivo","de":"3. Bitte stellen Sie sicher, dass sich Ihr Telefon in der Nähe des Geräts befindet.","ru":"3. Убедитесь, что ваш телефон находится рядом с устройством","vi":"3. Hãy chắc chắn rằng điện thoại của bạn ở gần thiết bị","th":"3. โปรดตรวจสอบให้แน่ใจว่าโทรศัพท์ของคุณอยู่ใกล้กับอุปกรณ์","id":"3. Pastikan ponsel Anda dekat dengan perangkat","zh-Hant":"3. 請確保你的手機靠近設備","zh-TW":"3. 請確保你的手機靠近設備","ar":"3. يرجى التأكد من أن هاتفك قريب من الجهاز","hu":"3. Kérjük, győződjön meg róla, hogy a telefonja közel van a készülékhez","el":"3. Βεβαιωθείτε ότι το τηλέφωνό σας είναι κοντά στη συσκευή","nl":"3. Zorg ervoor dat uw telefoon dicht bij het apparaat is","pl":"3. Upewnij się, że telefon znajduje się blisko urządzenia","fi":"3. Varmista, että puhelin on lähellä laitetta","sv":"3. Se till att telefonen är nära enheten","km":"3. សូម ប្រាកដ ថា ទូរស័ព្ទ របស់ អ្នក នៅ ជិត ឧបករណ៍"},"Connect router and get more features":{"en":"Connect to router for more features","zh-Hans":"连接路由器，获得更多的功能","fr":"Se connecter au routeur pour plus de fonctionnalités","ja":"ルーターに接続する","it":"Collegamento al router per ulteriori funzioni","es":"Conéctate al router para obtener más funciones","pt":"Ligar ao router para obter mais funcionalidades","de":"Verbinden Sie das Gerät mit dem Router für weitere Funktionen","ru":"Подключение к маршрутизатору для получения дополнительных возможностей","vi":"Kết nối với bộ định tuyến để có thêm tính năng","th":"เชื่อมต่อกับเราเตอร์เพื่อรับคุณสมบัติเพิ่มเติม","id":"Sambungkan ke router untuk fitur lainnya","zh-Hant":"連接路由器，獲得更多的功能","zh-TW":"連接路由器，獲得更多的功能","ar":"اتصل بجهاز التوجيه الخاص بك للحصول على المزيد من الميزات","hu":"Csatlakoztassa a routerhez a további funkciókért","el":"Σύνδεση σε δρομολογητή για περισσότερες δυνατότητες","nl":"Verbinden met router voor meer functies","pl":"Podłącz do routera, aby uzyskać więcej funkcji","fi":"Yhdistä reitittimeen saadaksesi lisää ominaisuuksia","sv":"Anslut till router för fler funktioner","km":"តភ្ជាប់ ទៅ router សម្រាប់ លក្ខណៈ ពិសេស បន្ថែម"},"This app feature is not available for your model, please use the remote control":{"en":"This app feature is not available for your model, please use the remote control","zh-Hans":"您的型号不具备此应用功能，请使用遥控器。","fr":"Cette fonction de l'application n'est pas disponible pour votre modèle, veuillez utiliser la télécommande.","ja":"リモコンを使用してください。","it":"Questa funzione dell'app non è disponibile per il modello in uso, utilizzare il telecomando.","es":"Esta aplicación no está disponible para su modelo, por favor utilice el mando a distancia.","pt":"Esta funcionalidade da aplicação não está disponível para o seu modelo, utilize o controlo remoto","de":"Diese App-Funktion ist für Ihr Modell nicht verfügbar, bitte verwenden Sie die Fernbedienung","ru":"Эта функция приложения недоступна для вашей модели, пожалуйста, используйте пульт дистанционного управления","vi":"Tính năng ứng dụng này không khả dụng cho kiểu máy của bạn, vui lòng sử dụng điều khiển từ xa","th":"คุณลักษณะแอปนี้ไม่พร้อมใช้งานสำหรับรุ่นของคุณ โปรดใช้รีโมทคอนโทรล","id":"Fitur aplikasi ini tidak tersedia untuk model Anda, gunakan remote control","zh-Hant":"您的型號不具備此應用功能，請使用遙控器。","zh-TW":"您的型號不具備此應用功能，請使用遙控器。","ar":"ميزة التطبيق هذه غير متاحة لطرازك ، يرجى استخدام جهاز التحكم عن بعد","hu":"Ez az alkalmazás funkció nem érhető el az Ön modelljénél, kérjük, használja a távirányítót","el":"Αυτή η λειτουργία της εφαρμογής δεν είναι διαθέσιμη για το μοντέλο σας, παρακαλούμε χρησιμοποιήστε το τηλεχειριστήριο","nl":"Deze app-functie is niet beschikbaar voor uw model, gebruik de afstandsbediening","pl":"Ta funkcja aplikacji nie jest dostępna dla Twojego modelu, użyj pilota zdalnego sterowania.","fi":"Tämä sovellusominaisuus ei ole käytettävissä mallissasi, käytä kaukosäädintä.","sv":"Denna appfunktion är inte tillgänglig för din modell, använd fjärrkontrollen","km":"លក្ខណៈ ពិសេស កម្មវិធី នេះ មិន មាន សម្រាប់ ម៉ូដែល របស់ អ្នក ទេ សូម ប្រើ ការ បញ្ជា ពី ចម្ងាយ"},"The device is switched off and cannot be operated":{"en":"The device is switched off and cannot be operated","zh-Hans":"设备已关机，无法操作","fr":"L'appareil est éteint et ne peut pas être utilisé","ja":"デバイスの電源が切れており、操作できません。","it":"Il dispositivo è spento e non può essere utilizzato","es":"El dispositivo está apagado y no se puede utilizar","pt":"O dispositivo está desligado e não pode ser operado","de":"Das Gerät ist ausgeschaltet und kann nicht bedient werden","ru":"Устройство выключено и им невозможно управлять","vi":"Thiết bị bị tắt và không thể hoạt động","th":"เครื่องดับและใช้งานไม่ได้","id":"Perangkat dimatikan dan tidak dapat dioperasikan","zh-Hant":"設備已關機，無法操作","zh-TW":"設備已關機，無法操作","ar":"الجهاز مغلق ولا يمكن تشغيله","hu":"A készülék ki van kapcsolva és nem működtethető","el":"Η συσκευή είναι απενεργοποιημένη και δεν είναι δυνατή η λειτουργία της","nl":"Het apparaat is uitgeschakeld en kan niet worden bediend","pl":"Urządzenie jest wyłączone i nie można go obsługiwać","fi":"Laite on kytketty pois päältä, eikä sitä voi käyttää","sv":"Enheten är avstängd och kan inte användas","km":"ឧបករណ៍ ត្រូវ បាន បិទ ហើយ មិន អាច ដំណើរ ការ បាន ទេ"},"Stop SleepCurve failed!":{"en":"Stop SleepCurve failed!","zh-Hans":"停止睡眠曲线失败!","fr":"L'arrêt de la courbe de sommeil a échoué !","ja":"スリープカーブの停止に失敗しました！","it":"Arresto della SleepCurve non riuscito!","es":"Stop SleepCurve ha fallado","pt":"O desligamento da Curva de Sono falhou","de":"SleepCurve stoppen ist fehlgeschlagen!","ru":"Остановить SleepCurve не удалось!","vi":"Dừng SleepCurve không thành công!","th":"หยุด SleepCurve ล้มเหลว!","id":"Hentikan SleepCurve gagal!","zh-Hant":"停止睡眠曲線失敗!","zh-TW":"停止睡眠曲線失敗!","ar":"وقف فشل SleepCurve!","hu":"A SleepCurve leállítása nem sikerült!","el":"Η διακοπή του SleepCurve απέτυχε!","nl":"Stop SleepCurve mislukt!","pl":"Zatrzymanie funkcji SleepCurve nie powiodło się!","fi":"SleepCurven pysäyttäminen epäonnistui!","sv":"Stoppa SleepCurve misslyckades!","km":"ឈប់គេងមិនបានសម្រេច!"},"Sleep curve is not available in ECO":{"en":"Sleep curve is not available in ECO","zh-Hans":"睡眠曲线在ECO中不可用","fr":"La courbe de sommeil n'est pas disponible en ECO","ja":"スリープカーブはECOでは使用できません","it":"La curva di riposo non è disponibile in ECO","es":"La curva de sueño no está disponible en ECO","pt":"A curva de sono não está disponível em ECO","de":"Die Schlafkurve ist in ECO nicht verfügbar","ru":"Кривая сна недоступна в ECO","vi":"Đường cong giấc ngủ không khả dụng trong ECO","th":"เส้นโค้งการนอนหลับไม่พร้อมใช้งานใน ECO","id":"Kurva tidur tidak tersedia di ECO","zh-Hant":"睡眠曲線在ECO中不可用","zh-TW":"睡眠曲線在ECO中不可用","ar":"منحنى النوم غير متوفر في ECO","hu":"Az alvógörbe nem elérhető az ECO-ban","el":"Η καμπύλη ύπνου δεν είναι διαθέσιμη στο ECO","nl":"Slaapcurve is niet beschikbaar in ECO","pl":"Krzywa uśpienia nie jest dostępna w trybie ECO","fi":"Lepokäyrä ei ole käytettävissä ECO-ohjelmassa","sv":"Sömnkurva är inte tillgänglig i ECO","km":"កោង ដំណេក មិន អាច ប្រើ បាន នៅ ក្នុង ECO"},"Sleep curve is not available in FP":{"en":"Sleep curve is not available in FP","zh-Hans":"睡眠曲线在FP中不可用","fr":"La courbe de sommeil n'est pas disponible en FP","ja":"スリープカーブはFPでは使用できません","it":"La curva del sonno non è disponibile in FP","es":"La curva de sueño no está disponible en FP","pt":"A curva de sono não está disponível em FP","de":"Die Schlafkurve ist in FP nicht verfügbar.","ru":"Кривая сна недоступна в FP","vi":"Đường cong giấc ngủ không có sẵn trong FP","th":"เส้นโค้งการนอนหลับไม่พร้อมใช้งานใน FP","id":"Kurva tidur tidak tersedia di FP","zh-Hant":"睡眠曲線在FP中不可用","zh-TW":"睡眠曲線在FP中不可用","ar":"منحنى النوم غير متوفر في FP","hu":"Az alvásgörbe nem elérhető az FP-ben","el":"Η καμπύλη ύπνου δεν είναι διαθέσιμη στο FP","nl":"Slaapcurve is niet beschikbaar in FP","pl":"Krzywa uśpienia nie jest dostępna w trybie FP","fi":"Unikäyrä ei ole käytettävissä FP:ssä","sv":"Sömnkurvan är inte tillgänglig i FP","km":"ខ្សែកោងគេងមិនអាចប្រើបានក្នុង FP"},"AI sleep curve will set temperature smartly to make you comfort":{"en":"AI sleep curve will set temperature smartly to make you comfort","zh-Hans":"人工智能睡眠曲线将智能调节温度，以达到舒适效果。","fr":"La courbe de sommeil AI règle la température de manière intelligente pour assurer votre confort.","ja":"AIスリープカーブは、快適な温度設定を行います。","it":"La curva del sonno AI imposta la temperatura in modo intelligente per garantire il comfort dell'utente.","es":"La curva de sueño AI ajustará la temperatura de forma inteligente para su comodidad.","pt":"A curva de sono da IA define a temperatura de forma inteligente para lhe proporcionar conforto","de":"Die AI-Schlafkurve stellt die Temperatur intelligent ein, damit Sie sich wohl fühlen.","ru":"Кривая сна с искусственным интеллектом установит температуру так, чтобы вам было комфортно.","vi":"Đường cong giấc ngủ AI sẽ thiết lập nhiệt độ thông minh để giúp bạn thoải mái","th":"AI sleep curve จะตั้งค่าอุณหภูมิอย่างชาญฉลาดเพื่อให้คุณรู้สึกสบาย","id":"Kurva tidur AI akan mengatur suhu secara cerdas untuk membuat Anda nyaman","zh-Hant":"人工智能睡眠曲線將智能調節溫度，以達到舒適效果。","zh-TW":"人工智能睡眠曲線將智能調節溫度，以達到舒適效果。","ar":"سيضبط منحنى النوم المدعوم بالذكاء الاصطناعي درجة الحرارة بذكاء ليمنحك الراحة","hu":"Az AI alvásgörbe okosan állítja be a hőmérsékletet, hogy kényelmesen érezze magát","el":"Η AI καμπύλη ύπνου θα ρυθμίσει έξυπνα τη θερμοκρασία για να σας κάνει να νιώθετε άνετα","nl":"AI-slaapcurve zal de temperatuur slim instellen voor uw comfort.","pl":"Krzywa snu AI inteligentnie ustawi temperaturę, aby zapewnić komfort.","fi":"AI-nukkumiskäyrä asettaa lämpötilan älykkäästi, jotta olosi olisi mukava.","sv":"AI-sömnkurvan ställer in temperaturen på ett smart sätt för att göra det bekvämt för dig","km":"ខ្សែកោងគេង AI នឹងកំណត់សីតុណ្ហភាពយ៉ាងឆ្លាតវៃដើម្បីធ្វើឱ្យអ្នកធូរស្រាល"},"Creating scheduled tasks":{"en":"Creating scheduled tasks","zh-Hans":"创建预定任务","fr":"Création de tâches programmées","ja":"スケジュールタスクの作成","it":"Creazione di attività programmate","es":"Creación de tareas programadas","pt":"Criar tarefas programadas","de":"Erstellen von geplanten Aufgaben","ru":"Создание запланированных задач","vi":"Tạo nhiệm vụ theo lịch trình","th":"การสร้างงานตามกำหนดเวลา","id":"Membuat tugas terjadwal","zh-Hant":"創建預定任務","zh-TW":"創建預定任務","ar":"إنشاء المهام المجدولة","hu":"Ütemezett feladatok létrehozása","el":"Δημιουργία προγραμματισμένων εργασιών","nl":"Geplande taken maken","pl":"Tworzenie zaplanowanych zadań","fi":"Ajastettujen tehtävien luominen","sv":"Skapa schemalagda uppgifter","km":"ការ បង្កើត កិច្ចការ ដែល បាន គ្រោង ទុក"},"Instruction execution, expected to take 2s":{"en":"Instruction execution, expected to take 2s","zh-Hans":"指令执行，预计需要2秒","fr":"Exécution d'une instruction, prévue pour durer 2 secondes","ja":"命令実行に2秒かかる見込み","it":"Esecuzione di un'istruzione che dovrebbe richiedere 2 secondi","es":"Ejecución de instrucciones, se espera que tome 2s","pt":"Execução de instruções, espera-se que demore 2s","de":"Befehlsausführung, die voraussichtlich 2s dauert","ru":"Выполнение инструкции, как ожидается, займет 2 с","vi":"Thực thi lệnh, dự kiến mất 2 giây","th":"การดำเนินการคำสั่ง คาดว่าจะใช้เวลา 2 วินาที","id":"Eksekusi instruksi, diperkirakan membutuhkan waktu 2 detik","zh-Hant":"指令執行，預計需要2秒","zh-TW":"指令執行，預計需要2秒","ar":"من المتوقع أن يستغرق تنفيذ التعليمات 2 ثانية","hu":"Utasítás végrehajtása, várhatóan 2s","el":"Εκτέλεση εντολών, αναμένεται να διαρκέσει 2s","nl":"Instructie-uitvoering duurt naar verwachting 2s","pl":"Wykonanie instrukcji, oczekiwane 2s","fi":"Ohjeen suoritus, jonka odotetaan vievän 2s","sv":"Instruktionsexekvering, förväntas ta 2 s","km":"ការ អនុវត្ត សេចក្ដី ណែនាំ ដែល រំពឹង ថា នឹង ចំណាយ ពេល ២"},"Flash can not be used under current mode":{"en":"Flash can not be used under current mode","zh-Hans":"在当前模式下不能使用Flash","fr":"La mémoire flash ne peut pas être utilisée dans le mode actuel","ja":"フラッシュは現在のモードでは使用できません","it":"Il flash non può essere utilizzato in modalità corrente","es":"Flash no se puede utilizar en el modo actual","pt":"O flash não pode ser utilizado no modo atual","de":"Flash kann im aktuellen Modus nicht verwendet werden","ru":"Флэш-память не может быть использована в текущем режиме","vi":"Không thể sử dụng đèn flash ở chế độ hiện tại","th":"ไม่สามารถใช้แฟลชในโหมดปัจจุบันได้","id":"Flash tidak dapat digunakan dalam mode saat ini","zh-Hant":"在當前模式下不能使用Flash","zh-TW":"在當前模式下不能使用Flash","ar":"لا يمكن استخدام الفلاش في الوضع الحالي","hu":"Flash nem használható a jelenlegi üzemmódban","el":"Το φλας δεν μπορεί να χρησιμοποιηθεί στην τρέχουσα λειτουργία","nl":"Flash kan niet worden gebruikt in de huidige modus","pl":"Lampa błyskowa nie może być używana w bieżącym trybie","fi":"Flashia ei voi käyttää nykyisessä tilassa","sv":"Flash kan inte användas i aktuellt läge","km":"Flash មិន អាច ប្រើ បាន ក្រោម របៀប បច្ចុប្បន្ន"},"Only available in cool or heat mode":{"en":"Only available in cool or heat mode","zh-Hans":"只在制冷或制热模式下可用","fr":"Uniquement disponible en mode froid ou chaud","ja":"クールモードまたはヒートモードでのみ使用可能","it":"Disponibile solo in modalità fredda o calda","es":"Sólo disponible en modo frío o calor","pt":"Apenas disponível no modo de resfriamento ou de aquecimento","de":"Nur im Kühl- oder Wärmemodus verfügbar","ru":"Доступно только в режиме охлаждения или нагрева","vi":"Chỉ khả dụng ở chế độ mát hoặc nhiệt","th":"ใช้งานได้ในโหมดเย็นหรือร้อนเท่านั้น","id":"Hanya tersedia dalam mode dingin atau panas","zh-Hant":"只在製冷或製熱模式下可用","zh-TW":"只在製冷或製熱模式下可用","ar":"متوفر فقط في الوضع البارد أو الحار","hu":"Csak hűvös vagy meleg üzemmódban érhető el","el":"Διατίθεται μόνο σε λειτουργία ψύξης ή θέρμανσης","nl":"Alleen beschikbaar in koel- of warmtemodus","pl":"Dostępne tylko w trybie chłodzenia lub ogrzewania","fi":"Käytettävissä vain viileässä tai lämpimässä tilassa","sv":"Endast tillgängligt i kyl- eller värmeläge","km":"មាន តែ ក្នុង របៀប ត្រជាក់ ឬ កំដៅ ប៉ុណ្ណោះ"},"Only available in cool mode":{"en":"Only available in cool mode","zh-Hans":"只在制冷模式下可用","fr":"Uniquement disponible en mode froid","ja":"クールモードでのみ使用可能","it":"Disponibile solo in modalità fredda","es":"Sólo disponible en modo frío","pt":"Apenas disponível no modo de resfriamento","de":"Nur im Kühlmodus verfügbar","ru":"Доступно только в режиме охлаждения","vi":"Chỉ khả dụng ở chế độ mát","th":"ใช้ได้เฉพาะในโหมดเย็นเท่านั้น","id":"Hanya tersedia dalam mode dingin","zh-Hant":"只在製冷模式下可用","zh-TW":"只在製冷模式下可用","ar":"متوفر فقط في الوضع البارد","hu":"Csak hűvös üzemmódban elérhető","el":"Διατίθεται μόνο σε ψυχρή λειτουργία","nl":"Alleen beschikbaar in koelmodus","pl":"Dostępne tylko w trybie chłodzenia","fi":"Käytettävissä vain viileässä tilassa","sv":"Endast tillgängligt i kylläge","km":"មាន តែ ក្នុង របៀប ត្រជាក់ ប៉ុណ្ណោះ"},"Cascade is not available in current mode":{"en":"Cascade is not available in current mode","zh-Hans":"环绕风在当前模式下不可用","fr":"Cascade n'est pas disponible dans le mode actuel","ja":"カスケードは現在のモードでは使用できません","it":"Cascade non è disponibile nella modalità corrente","es":"Cascade no está disponible en el modo actual","pt":"Cascata não está disponível no modo atual","de":"Kaskade ist im aktuellen Modus nicht verfügbar","ru":"Каскад недоступен в текущем режиме","vi":"Cascade không khả dụng ở chế độ hiện tại","th":"Cascade ไม่สามารถใช้งานได้ในโหมดปัจจุบัน","id":"Cascade tidak tersedia dalam mode saat ini","zh-Hant":"環繞風在當前模式下不可用","zh-TW":"環繞風在當前模式下不可用","ar":"لا يتوفر Cascade في الوضع الحالي","hu":"A kaszkád nem áll rendelkezésre az aktuális üzemmódban","el":"Η κασκάνδα δεν είναι διαθέσιμη στην τρέχουσα λειτουργία","nl":"Cascade is niet beschikbaar in de huidige modus","pl":"Kaskada nie jest dostępna w bieżącym trybie","fi":"Kaskadointi ei ole käytettävissä nykyisessä tilassa","sv":"Kaskad är inte tillgängligt i aktuellt läge","km":"Cascade មិន មាន ក្នុង របៀប បច្ចុប្បន្ន"},"AvoidMe is not available in current mode":{"en":"AvoidMe is not available in current mode","zh-Hans":"风避人在当前模式下不可用","fr":"AvoidMe n'est pas disponible dans le mode actuel","ja":"AvoidMeは現在のモードでは使用できません。","it":"AvoidMe non è disponibile nella modalità corrente","es":"AvoidMe no está disponible en el modo actual","pt":"Esta função não esta disponível no modo atual","de":"AvoidMe ist im aktuellen Modus nicht verfügbar","ru":"AvoidMe недоступен в текущем режиме","vi":"TránhMe không khả dụng trong chế độ hiện tại","th":"AvoidMe ไม่สามารถใช้งานได้ในโหมดปัจจุบัน","id":"AvoidMe tidak tersedia dalam mode saat ini","zh-Hant":"風避人在當前模式下不可用","zh-TW":"風避人在當前模式下不可用","ar":"AvoidMe غير متاح في الوضع الحالي","hu":"AvoidMe nem elérhető az aktuális üzemmódban","el":"Η AvoidMe δεν είναι διαθέσιμη στην τρέχουσα λειτουργία","nl":"AvoidMe is niet beschikbaar in huidige modus","pl":"Funkcja AvoidMe nie jest dostępna w bieżącym trybie","fi":"AvoidMe ei ole käytettävissä nykyisessä tilassa.","sv":"AvoidMe är inte tillgängligt i aktuellt läge","km":"AvoidMe មិន មាន ក្នុង របៀប បច្ចុប្បន្ន"},"Start SleepCurve failed!":{"en":"Start SleepCurve failed!","zh-Hans":"启动睡眠曲线失败!","fr":"Le démarrage de SleepCurve a échoué !","ja":"SleepCurveの起動に失敗しました！","it":"Avvio SleepCurve non riuscito!","es":"Error al iniciar SleepCurve.","pt":"Falha ao iniciar o Curva do Sono","de":"Start SleepCurve fehlgeschlagen!","ru":"Запуск SleepCurve не удался!","vi":"Bắt đầu SleepCurve không thành công!","th":"เริ่ม SleepCurve ล้มเหลว!","id":"Memulai SleepCurve gagal!","zh-Hant":"啟動睡眠曲線失敗!","zh-TW":"啟動睡眠曲線失敗!","ar":"فشل بدء SleepCurve!","hu":"Az alvógörbe indítása sikertelen!","el":"Η εκκίνηση της καμπύλης ύπνου απέτυχε!","nl":"Start SleepCurve mislukt!","pl":"Uruchomienie SleepCurve nie powiodło się!","fi":"Käynnistä SleepCurve epäonnistui!","sv":"Starta SleepCurve misslyckades!","km":"ចាប់ផ្តើម SleepCurve បរាជ័យ!"},"Server busy, please try again later. errorCode=40504":{"en":"Server busy, please try again later. errorCode=40504","zh-Hans":"服务器繁忙，请稍后再试。 errorCode=40504","fr":"Serveur occupé, veuillez réessayer plus tard. errorCode=40504","ja":"サーバーがビジー状態です。","it":"Server occupato, riprovare più tardi. errorCode=40504","es":"Servidor ocupado, inténtelo de nuevo más tarde. errorCode=40504","pt":"Servidor ocupado, tente novamente mais tarde. errorCode=40504","de":"Server beschäftigt, bitte versuchen Sie es später erneut. errorCode=40504","ru":"Сервер занят, повторите попытку позже. errorCode=40504","vi":"Máy chủ bận rộn xin vui lòng thử lại sau. errorCode=40504","th":"เซิร์ฟเวอร์ไม่ว่าง โปรดลองอีกครั้งในภายหลัง รหัสข้อผิดพลาด = 40504","id":"Server sibuk, silakan coba lagi nanti. errorCode = 40504","zh-Hant":"服務器繁忙，請稍後再試。 errorCode=40504","zh-TW":"服務器繁忙，請稍後再試。 errorCode=40504","ar":"الخدمة مشغولة رجاء حاول مرة أخرى لاحقا. كود الخطأ = 40504","hu":"A szerver foglalt, kérjük, próbálja meg később újra. errorCode=40504","el":"Ο διακομιστής είναι απασχολημένος, δοκιμάστε ξανά αργότερα. errorCode=40504","nl":"Server bezet, probeer het later opnieuw. errorCode=40504","pl":"Serwer zajęty, spróbuj ponownie później. errorCode=40504","fi":"Palvelin varattu, yritä myöhemmin uudelleen. errorCode=40504","sv":"Servern är upptagen, försök igen senare. errorCode=40504","km":"ម៉ាស៊ីន បម្រើ រវល់ សូម សាកល្បង ម្ដង ទៀត នៅ ពេល ក្រោយ ។ errorCode=40504"},"Please connect router before using special functions":{"en":"Please connect router before using special functions","zh-Hans":"在使用特殊功能之前，请连接路由器","fr":"Veuillez connecter le routeur avant d'utiliser les fonctions spéciales","ja":"特殊機能を使用する前に、ルーターを接続してください。","it":"Collegare il router prima di utilizzare le funzioni speciali","es":"Por favor, conecte el router antes de utilizar las funciones especiales","pt":"Ligue o router antes de utilizar funções especiais","de":"Bitte schließen Sie den Router an, bevor Sie spezielle Funktionen nutzen","ru":"Пожалуйста, подключите маршрутизатор перед использованием специальных функций","vi":"Vui lòng kết nối bộ định tuyến trước khi sử dụng các chức năng đặc biệt","th":"โปรดเชื่อมต่อเราเตอร์ก่อนใช้ฟังก์ชันพิเศษ","id":"Harap sambungkan router sebelum menggunakan fungsi khusus","zh-Hant":"在使用特殊功能之前，請連接路由器","zh-TW":"在使用特殊功能之前，請連接路由器","ar":"يرجى توصيل جهاز التوجيه قبل استخدام الوظائف الخاصة","hu":"Kérjük, a speciális funkciók használata előtt csatlakoztassa a routert","el":"Παρακαλούμε συνδέστε το δρομολογητή πριν χρησιμοποιήσετε τις ειδικές λειτουργίες","nl":"Sluit de router aan voordat u speciale functies gebruikt","pl":"Przed użyciem funkcji specjalnych należy podłączyć router","fi":"Yhdistä reititin ennen erikoistoimintojen käyttöä","sv":"Anslut routern innan du använder specialfunktioner","km":"សូមភ្ជាប់ router មុនពេលប្រើមុខងារពិសេស"},"Remote Control":{"en":"Remote Control","zh-Hans":"遥控器","fr":"Commande à distance","ja":"リモートコントロール","it":"Controllo remoto","es":"Mando a distancia","pt":"Controlo remoto","de":"Fernsteuerung","ru":"Дистанционное управление","vi":"Điều khiển từ xa","th":"รีโมท","id":"Kontrol Jarak Jauh","zh-Hant":"遙控器","zh-TW":"遙控器","ar":"جهاز التحكم","hu":"Távvezérlés","el":"Τηλεχειρισμός","nl":"Afstandsbediening","pl":"Zdalne sterowanie","fi":"Kauko-ohjaus","sv":"Fjärrkontroll","km":"ការបញ្ជាពីចម្ងាយ"},"Refresh":{"en":"Refresh","zh-Hans":"刷新","fr":"Rafraîchir","ja":"リフレッシュ","it":"Aggiornare","es":"Actualizar","pt":"Atualizar","de":"Aktualisieren","ru":"Обновить","vi":"Làm cho khỏe lại","th":"รีเฟรช","id":"Segarkan","zh-Hant":"刷新","zh-TW":"刷新","ar":"ينعش","hu":"Refresh","el":"Ανανέωση","nl":"Vernieuwen","pl":"Odśwież","fi":"Päivitä","sv":"Uppdatera","km":"ស្រស់ថ្លា"},"Connection failed":{"en":"Connection failed","zh-Hans":"连接失败","fr":"Échec de la connexion","ja":"接続に失敗しました","it":"Connessione fallita","es":"Error de conexión","pt":"Falha na ligação","de":"Verbindung fehlgeschlagen","ru":"Не удалось подключиться","vi":"Kết nối thất bại","th":"การเชื่อมต่อล้มเหลว","id":"Koneksi gagal","zh-Hant":"連接失敗","zh-TW":"連接失敗","ar":"فشل الاتصال","hu":"A kapcsolat sikertelen","el":"Η σύνδεση απέτυχε","nl":"Verbinding mislukt","pl":"Połączenie nie powiodło się","fi":"Yhteys epäonnistui","sv":"Anslutningen misslyckades","km":"ការភ្ជាប់បានបរាជ័យ"},"Please connect your family router":{"en":"Please connect to your home router","zh-Hans":"请连接您的家庭路由器","fr":"Veuillez vous connecter au routeur de votre domicile","ja":"ご自宅のルーターに接続してください。","it":"Collegare il dispositivo al router di casa","es":"Por favor, conéctelo a su router","pt":"Ligue-se ao seu router doméstico","de":"Bitte verbinden Sie das Gerät mit Ihrem Heimrouter","ru":"Пожалуйста, подключитесь к домашнему маршрутизатору","vi":"Vui lòng kết nối với bộ định tuyến tại nhà của bạn","th":"โปรดเชื่อมต่อกับเราเตอร์ที่บ้านของคุณ","id":"Harap sambungkan ke router rumah Anda","zh-Hant":"請連接您的家庭路由器","zh-TW":"請連接您的家庭路由器","ar":"يرجى توصيل جهاز التوجيه المنزلي الخاص بك","hu":"Kérjük, csatlakozzon otthoni routeréhez","el":"Παρακαλούμε συνδεθείτε στον οικιακό σας δρομολογητή","nl":"Maak verbinding met uw thuisrouter","pl":"Połącz się z routerem domowym","fi":"Ole hyvä ja yhdistä kotireitittimeen","sv":"Vänligen anslut till din hemrouter","km":"សូម ភ្ជាប់ ទៅ router ផ្ទះ របស់ អ្នក"},"By connecting to router, you may control your AC when you are away from home. You also gain access to additional features.":{"en":"By connecting this device to the Internet you will be able to control your Air Conditioner when you are away from home. You will also gain access to additional features.","zh-Hans":"通过连接到路由器，你不在家的时候也可以控制你的空调。你还可以获得更多的功能。","fr":"En connectant cet appareil à Internet, vous pourrez contrôler votre climatiseur lorsque vous n'êtes pas chez vous. Vous aurez également accès à des fonctionnalités supplémentaires.","ja":"このデバイスをインターネットに接続することで、外出先からエアコンをコントロールできるようになります。また、追加機能にもアクセスできます。","it":"Collegando questo dispositivo a Internet, potrete controllare il vostro condizionatore d'aria quando siete fuori casa. Avrete inoltre accesso a funzioni aggiuntive.","es":"Conectando este dispositivo a Internet podrá controlar su Aire Acondicionado cuando esté fuera de casa. También tendrá acceso a funciones adicionales.","pt":"Ao ligar este dispositivo à Internet, poderá controlar o seu ar condicionado quando estiver fora de casa. Terá também acesso a funcionalidades adicionais.","de":"Wenn Sie dieses Gerät mit dem Internet verbinden, können Sie Ihre Klimaanlage steuern, wenn Sie nicht zu Hause sind. Außerdem erhalten Sie Zugang zu zusätzlichen Funktionen.","ru":"Подключив это устройство к Интернету, вы сможете управлять кондиционером, находясь вне дома. Кроме того, вы получите доступ к дополнительным функциям.","vi":"Bằng cách kết nối thiết bị này với Internet, bạn sẽ có thể điều khiển Máy điều hòa của mình khi bạn vắng nhà. Bạn cũng sẽ có quyền truy cập vào các tính năng bổ sung.","th":"เมื่อเชื่อมต่ออุปกรณ์นี้กับอินเทอร์เน็ต คุณจะสามารถควบคุมเครื่องปรับอากาศได้เมื่อคุณไม่อยู่บ้าน และยังสามารถเข้าถึงคุณสมบัติเพิ่มเติมได้อีกด้วย","id":"Dengan menghubungkan perangkat ini ke Internet, Anda akan dapat mengontrol Pendingin Udara saat Anda jauh dari rumah. Anda juga akan mendapatkan akses ke fitur tambahan.","zh-Hant":"透過連接到路由器，你不在家的時候也可以控制你的空調。 你還可以獲得更多的功能。","zh-TW":"透過連接到路由器，你不在家的時候也可以控制你的空調。 你還可以獲得更多的功能。","ar":"من خلال الاتصال بجهاز التوجيه الخاص بك، يمكنك التحكم في مكيف الهواء الخاص بك عندما لا تكون في المنزل. يمكنك أيضًا الحصول على المزيد من الميزات.","hu":"Az eszköz internethez való csatlakoztatásával Ön akkor is képes lesz vezérelni légkondicionálóját, amikor nincs otthon. Emellett további funkciókhoz is hozzáférhet.","el":"Με τη σύνδεση αυτής της συσκευής στο διαδίκτυο θα μπορείτε να ελέγχετε το κλιματιστικό σας όταν βρίσκεστε εκτός σπιτιού. Θα αποκτήσετε επίσης πρόσβαση σε πρόσθετες λειτουργίες.","nl":"Door dit apparaat met het internet te verbinden, kunt u uw airconditioner bedienen wanneer u niet thuis bent. U krijgt ook toegang tot extra functies.","pl":"Podłączenie tego urządzenia do Internetu umożliwia sterowanie klimatyzatorem poza domem. Uzyskasz również dostęp do dodatkowych funkcji.","fi":"Yhdistämällä tämän laitteen Internetiin voit ohjata ilmastointilaitetta, kun olet poissa kotoa. Saat myös lisäominaisuuksia käyttöösi.","sv":"Genom att ansluta denna enhet till Internet kommer du att kunna styra din luftkonditionering när du inte är hemma. Du kommer också att få tillgång till ytterligare funktioner.","km":"ដោយ ភ្ជាប់ ឧបករណ៍ នេះ ទៅ អ៊ីនធឺណិត អ្នក នឹង អាច ត្រួត ពិនិត្យ ម៉ាស៊ីន ត្រជាក់ របស់ អ្នក នៅ ពេល ដែល អ្នក នៅ ឆ្ងាយ ពី ផ្ទះ ។ អ្នក ក៏ នឹង ទទួល បាន លក្ខណៈ ពិសេស បន្ថែម ផង ដែរ ។"},"Confirm family router password is correct.":{"en":"Confirm family router password is correct.","zh-Hans":"确认家庭路由器的密码正确。","fr":"Confirmez que le mot de passe du routeur familial est correct.","ja":"ファミリールーターのパスワードが正しいか確認してください。","it":"Verificare che la password del router familiare sia corretta.","es":"Confirme que la contraseña del router familiar es correcta.","pt":"Confirme se a palavra-passe do router familiar está correcta.","de":"Vergewissern Sie sich, dass das Passwort des Familienrouters korrekt ist.","ru":"Убедитесь, что пароль семейного маршрутизатора верен.","vi":"Xác nhận mật khẩu bộ định tuyến gia đình là chính xác.","th":"ยืนยันว่ารหัสผ่านเราเตอร์ของครอบครัวถูกต้อง","id":"Konfirmasikan kata sandi router keluarga sudah benar.","zh-Hant":"確認家庭路由器的密碼正確。","zh-TW":"確認家庭路由器的密碼正確。","ar":"تأكد من صحة كلمة مرور جهاز التوجيه العائلي.","hu":"Erősítse meg, hogy a családi router jelszava helyes.","el":"Επιβεβαιώστε ότι ο κωδικός πρόσβασης του οικογενειακού δρομολογητή είναι σωστός.","nl":"Controleer of het wachtwoord van de familierouter correct is.","pl":"Potwierdź, że hasło routera rodzinnego jest prawidłowe.","fi":"Vahvista, että perheen reitittimen salasana on oikein.","sv":"Bekräfta att lösenordet för familjens router är korrekt.","km":"បញ្ជាក់ពាក្យសម្ងាត់រ៉ោតទ័រជាលក្ខណៈគ្រួសារត្រឹមត្រូវ។"},"Make sure you connect to 2.4GHz wireless network, since 5GHz wireless network is not supported.":{"en":"Make sure you connect to 2.4GHz wireless network, since 5GHz wireless network is not supported.","zh-Hans":"确保你连接到2.4GHz无线网络，因为不支持5GHz无线网络。","fr":"Assurez-vous de vous connecter à un réseau sans fil de 2,4 GHz, car le réseau sans fil de 5 GHz n'est pas pris en charge.","ja":"5GHz帯の無線LANには対応していませんので、2.4GHz帯の無線LANに接続してください。","it":"Assicurarsi di collegarsi alla rete wireless a 2,4 GHz, poiché la rete wireless a 5 GHz non è supportata.","es":"Asegúrese de que se conecta a una red inalámbrica de 2,4 GHz, ya que la red inalámbrica de 5 GHz no es compatible.","pt":"Certifique-se de que liga a uma rede sem fios de 2,4 GHz, uma vez que a rede sem fios de 5 GHz não é suportada.","de":"Vergewissern Sie sich, dass Sie sich mit einem 2,4-GHz-Wireless-Netzwerk verbinden, da ein 5-GHz-Wireless-Netzwerk nicht unterstützt wird.","ru":"Убедитесь, что вы подключаетесь к беспроводной сети 2,4 ГГц, так как беспроводная сеть 5 ГГц не поддерживается.","vi":"Đảm bảo bạn kết nối với mạng không dây 2.4GHz, vì mạng không dây 5GHz không được hỗ trợ.","th":"ตรวจสอบให้แน่ใจว่าคุณเชื่อมต่อกับเครือข่ายไร้สาย 2.4GHz เนื่องจากไม่รองรับเครือข่ายไร้สาย 5GHz","id":"Pastikan Anda tersambung ke jaringan nirkabel 2,4GHz, karena jaringan nirkabel 5GHz tidak didukung.","zh-Hant":"確保你連接到2.4GHz無線網絡，因為不支持5GHz無線網絡。","zh-TW":"確保你連接到2.4GHz無線網絡，因為不支持5GHz無線網絡。","ar":"تأكد من الاتصال بشبكة لاسلكية 2.4 جيجا هرتز ، حيث إن الشبكة اللاسلكية 5 جيجا هرتز غير مدعومة.","hu":"Győződjön meg róla, hogy 2,4 GHz-es vezeték nélküli hálózathoz csatlakozik, mivel az 5 GHz-es vezeték nélküli hálózat nem támogatott.","el":"Βεβαιωθείτε ότι συνδέεστε σε ασύρματο δίκτυο 2,4GHz, καθώς το ασύρματο δίκτυο 5GHz δεν υποστηρίζεται.","nl":"Zorg ervoor dat u verbinding maakt met een draadloos 2,4GHz-netwerk, aangezien een draadloos 5GHz-netwerk niet wordt ondersteund.","pl":"Upewnij się, że łączysz się z siecią bezprzewodową 2,4 GHz, ponieważ sieć bezprzewodowa 5 GHz nie jest obsługiwana.","fi":"Varmista, että muodostat yhteyden 2,4 GHz:n langattomaan verkkoon, sillä 5 GHz:n langatonta verkkoa ei tueta.","sv":"Se till att du ansluter till ett trådlöst nätverk på 2,4 GHz, eftersom trådlösa nätverk på 5 GHz inte stöds.","km":"សូម ប្រាកដ ថា អ្នក ត ភ្ជាប់ ទៅ បណ្ដាញ ឥត ខ្សែ 2.4GHz ដោយ សារ តែ បណ្តាញ ឥត ខ្សែ 5GHz មិន ត្រូវ បាន គាំទ្រ ឡើយ។"},"Make sure the device is plugged into a power outlet and the router is working normally.":{"en":"Make sure the device is plugged into a power outlet and the router is working normally.","zh-Hans":"确保设备电源已正常接通，路由器正常工作。","fr":"Assurez-vous que l'appareil est branché sur une prise de courant et que le routeur fonctionne normalement.","ja":"デバイスがコンセントに接続され、ルーターが正常に動作していることを確認してください。","it":"Assicurarsi che il dispositivo sia collegato a una presa di corrente e che il router funzioni normalmente.","es":"Asegúrate de que el dispositivo está enchufado a una toma de corriente y de que el router funciona con normalidad.","pt":"Certifique-se de que o dispositivo está ligado a uma tomada eléctrica e de que o router está a funcionar normalmente.","de":"Stellen Sie sicher, dass das Gerät an eine Steckdose angeschlossen ist und der Router normal funktioniert.","ru":"Убедитесь, что устройство подключено к розетке и маршрутизатор работает нормально.","vi":"Đảm bảo thiết bị được cắm vào ổ cắm điện và bộ định tuyến đang hoạt động bình thường.","th":"ตรวจสอบให้แน่ใจว่าเสียบอุปกรณ์เข้ากับเต้าเสียบไฟแล้ว และเราเตอร์ทำงานตามปกติ","id":"Pastikan perangkat dicolokkan ke stopkontak dan router berfungsi normal.","zh-Hant":"確保設備電源已正常接通，路由器正常工作。","zh-TW":"確保設備電源已正常接通，路由器正常工作。","ar":"تأكد من توصيل الجهاز بمأخذ طاقة وأن جهاز التوجيه يعمل بشكل طبيعي.","hu":"Győződjön meg róla, hogy a készülék be van dugva a konnektorba, és a router rendesen működik.","el":"Βεβαιωθείτε ότι η συσκευή είναι συνδεδεμένη σε πρίζα και ότι ο δρομολογητής λειτουργεί κανονικά.","nl":"Zorg ervoor dat het apparaat is aangesloten op een stopcontact en dat de router normaal werkt.","pl":"Upewnij się, że urządzenie jest podłączone do gniazdka elektrycznego, a router działa prawidłowo.","fi":"Varmista, että laite on kytketty pistorasiaan ja reititin toimii normaalisti.","sv":"Kontrollera att enheten är ansluten till ett eluttag och att routern fungerar normalt.","km":"សូម ប្រាកដ ថា ឧបករណ៍ ត្រូវ បាន ដោត ចូល ទៅ ក្នុង ចរន្ត ថាមពល ហើយ រ៉ោតទ័រ កំពុង ដំណើរ ការ ជា ធម្មតា & # 160; ។"},"Please ensure the current connection is the 2.4G wireless network.":{"en":"Please ensure the current connection is the 2.4G wireless network.","zh-Hans":"请确保当前连接的是2.4G无线网络。","fr":"Assurez-vous que la connexion actuelle est le réseau sans fil 2.4G.","ja":"現在の接続が2.4Gワイヤレスネットワークであることを確認してください。","it":"Assicurarsi che la connessione attuale sia la rete wireless a 2,4 GHz.","es":"Por favor, asegúrese de que la conexión actual es la red inalámbrica 2.4G.","pt":"Certifique-se de que a ligação atual é à rede sem fios de 2,4 GHz.","de":"Vergewissern Sie sich, dass die aktuelle Verbindung ein 2,4G-Wireless-Netzwerk ist.","ru":"Убедитесь, что текущее подключение является беспроводной сетью 2.4G.","vi":"Vui lòng đảm bảo kết nối hiện tại là mạng không dây 2.4G.","th":"โปรดตรวจสอบว่าการเชื่อมต่อปัจจุบันเป็นเครือข่ายไร้สาย 2.4G","id":"Pastikan koneksi saat ini adalah jaringan nirkabel 2,4G.","zh-Hant":"請確保當前連接的是2.4G無線網絡。","zh-TW":"請確保當前連接的是2.4G無線網絡。","ar":"يرجى التأكد من أن الاتصال الحالي هو شبكة 2.4G اللاسلكية.","hu":"Győződjön meg arról, hogy az aktuális kapcsolat a 2,4G vezeték nélküli hálózat.","el":"Βεβαιωθείτε ότι η τρέχουσα σύνδεση είναι το ασύρματο δίκτυο 2,4G.","nl":"Controleer of de huidige verbinding het draadloze 2.4G netwerk is.","pl":"Upewnij się, że bieżące połączenie to sieć bezprzewodowa 2.4G.","fi":"Varmista, että nykyinen yhteys on 2,4G langaton verkko.","sv":"Kontrollera att den aktuella anslutningen är det trådlösa 2.4G-nätverket.","km":"សូម ធានា ថា ការ ត ភ្ជាប់ បច្ចុប្បន្ន គឺ ជា បណ្តាញ ឥត ខ្សែ 2.4G ។"},"Please check phone wireless network setting and ensure phone is connected to the right wireless network, then refresh this page.":{"en":"Please check phone wireless network setting and ensure phone is connected to the right wireless network, then refresh this page.","zh-Hans":"请检查手机无线网络设置，确保手机连接到正确的无线网络，然后刷新此页面。","fr":"Vérifiez les paramètres du réseau sans fil du téléphone et assurez-vous que le téléphone est connecté au bon réseau sans fil, puis actualisez cette page.","ja":"電話のワイヤレスネットワーク設定を確認し、電話が正しいワイヤレスネットワークに接続されていることを確認してから、このページを更新してください。","it":"Controllare le impostazioni della rete wireless del telefono e assicurarsi che il telefono sia connesso alla rete wireless corretta, quindi aggiornare la pagina.","es":"Compruebe la configuración de la red inalámbrica del teléfono y asegúrese de que el teléfono está conectado a la red inalámbrica correcta; a continuación, actualice esta página.","pt":"Verifique a definição de rede sem fios do celular e certifique-se de que o celularl está ligado à rede sem fios correta e, em seguida, atualize esta página.","de":"Bitte überprüfen Sie die WLAN-Einstellungen des Telefons und stellen Sie sicher, dass das Telefon mit dem richtigen WLAN verbunden ist.","ru":"Проверьте настройки беспроводной сети телефона и убедитесь, что телефон подключен к правильной беспроводной сети, затем обновите эту страницу.","vi":"Vui lòng kiểm tra cài đặt mạng không dây của điện thoại và đảm bảo điện thoại được kết nối với mạng không dây phù hợp, sau đó làm mới trang này.","th":"โปรดตรวจสอบการตั้งค่าเครือข่ายไร้สายของโทรศัพท์และตรวจสอบว่าโทรศัพท์เชื่อมต่อกับเครือข่ายไร้สายที่ถูกต้อง จากนั้นรีเฟรชหน้านี้","id":"Periksa pengaturan jaringan nirkabel ponsel dan pastikan ponsel tersambung ke jaringan nirkabel yang benar, lalu refresh halaman ini.","zh-Hant":"請檢查手機無線網絡設置，確保手機連接到正確的無線網絡，然後刷新此頁面。","zh-TW":"請檢查手機無線網絡設置，確保手機連接到正確的無線網絡，然後刷新此頁面。","ar":"يرجى التحقق من إعداد الشبكة اللاسلكية للهاتف والتأكد من أن الهاتف متصل بالشبكة اللاسلكية الصحيحة ، ثم قم بتحديث هذه الصفحة.","hu":"Kérjük, ellenőrizze a telefon vezeték nélküli hálózati beállításait, és győződjön meg arról, hogy a telefon a megfelelő vezeték nélküli hálózathoz csatlakozik, majd frissítse ezt az oldalt.","el":"Ελέγξτε τη ρύθμιση ασύρματου δικτύου του τηλεφώνου και βεβαιωθείτε ότι το τηλέφωνο είναι συνδεδεμένο στο σωστό ασύρματο δίκτυο και, στη συνέχεια, ανανεώστε αυτή τη σελίδα.","nl":"Controleer de instellingen voor het draadloze netwerk van de telefoon en zorg ervoor dat de telefoon is verbonden met het juiste draadloze netwerk.","pl":"Sprawdź ustawienia sieci bezprzewodowej telefonu i upewnij się, że telefon jest podłączony do właściwej sieci bezprzewodowej, a następnie odśwież tę stronę.","fi":"Tarkista puhelimen langattoman verkon asetukset ja varmista, että puhelin on yhdistetty oikeaan langattomaan verkkoon, ja päivitä sitten tämä sivu.","sv":"Kontrollera telefonens inställningar för trådlöst nätverk och se till att telefonen är ansluten till rätt trådlöst nätverk och uppdatera sedan den här sidan.","km":"សូម ពិនិត្យ មើល ការ កំណត់ បណ្ដាញ ឥត ខ្សែ ទូរស័ព្ទ និង ធានា ថា ទូរស័ព្ទ ត្រូវ បាន ភ្ជាប់ ទៅ នឹង បណ្ដាញ ឥត ខ្សែ ដែល ត្រឹមត្រូវ បន្ទាប់ មក ធ្វើ ឲ្យ ទំព័រ នេះ មាន ភាព ស្រស់ ស្អាត ។"},"get current wireless network failed":{"en":"get current wireless network failed","zh-Hans":"当前无线网络获取失败","fr":"L'obtention du réseau sans fil actuel a échoué","ja":"現在のワイヤレスネットワークの取得に失敗しました。","it":"ottenere la rete wireless corrente non riuscita","es":"Obtener la red inalámbrica actual falló","pt":"falha na obtenção da rede sem fios atual","de":"Abrufen des aktuellen drahtlosen Netzwerks fehlgeschlagen","ru":"получить текущую беспроводную сеть не удалось","vi":"nhận mạng không dây hiện tại không thành công","th":"รับเครือข่ายไร้สายปัจจุบันล้มเหลว","id":"mendapatkan jaringan nirkabel saat ini gagal","zh-Hant":"當前無線網絡獲取失敗","zh-TW":"當前無線網絡獲取失敗","ar":"الحصول على فشل الشبكة اللاسلكية الحالية","hu":"az aktuális vezeték nélküli hálózat lekérdezése sikertelen","el":"Αποτυχία λήψης τρέχοντος ασύρματου δικτύου","nl":"huidige draadloze netwerk ophalen mislukt","pl":"połączenie z bieżącą siecią bezprzewodową nie powiodło się","fi":"nykyisen langattoman verkon hakeminen epäonnistui","sv":"Hämta aktuellt trådlöst nätverk misslyckades","km":"ទទួល បាន បណ្ដាញ ឥត ខ្សែ បច្ចុប្បន្ន បាន បរាជ័យ"},"Connect Successful, entering the home page":{"en":"Connect Successful, entering the home page","zh-Hans":"连接成功，进入主页","fr":"Connexion réussie, entrée sur la page d'accueil","ja":"接続に成功しました。","it":"Connessione riuscita, accesso alla pagina iniziale","es":"Conectar con éxito, entrar en la página de inicio","pt":"Ligação bem sucedida, a entrar na página inicial","de":"Verbindung erfolgreich, Aufrufen der Startseite","ru":"Подключение успешно, вход на главную страницу","vi":"Kết nối thành công, vào trang chủ","th":"เชื่อมต่อสำเร็จ เข้าสู่หน้าแรก","id":"Sambungan berhasil, masuk ke halaman beranda","zh-Hant":"連接成功，進入主頁","zh-TW":"連接成功，進入主頁","ar":"تم الاتصال بنجاح ، ودخول الصفحة الرئيسية","hu":"Sikeres csatlakozás, belép a kezdőlapra","el":"Σύνδεση Επιτυχής, είσοδος στην αρχική σελίδα","nl":"Verbinding gelukt, naar de startpagina","pl":"Połączenie powiodło się, przejście do strony głównej","fi":"Yhteyden muodostaminen onnistui, siirtyminen etusivulle","sv":"Anslutningen lyckades och du kommer till startsidan","km":"តភ្ជាប់ភាពជោគជ័យ, ចូលទៅក្នុងទំព័រផ្ទះ"},"bind device fail":{"en":"bind device fail","zh-Hans":"设备绑定失败","fr":"Échec de la liaison avec l'appareil","ja":"デバイスのバインドに失敗しました","it":"bind device non riuscito","es":"Fallo al enlazar dispositivo","pt":"falha na ligação do dispositivo","de":"Gerät verbinden fehlgeschlagen","ru":"привязка устройства не удалась","vi":"thiết bị liên kết thất bại","th":"อุปกรณ์ผูกล้มเหลว","id":"ikat perangkat gagal","zh-Hant":"設備綁定失敗","zh-TW":"設備綁定失敗","ar":"فشل ربط الجهاز","hu":"eszköz kötése sikertelen","el":"Αποτυχία σύνδεσης συσκευής","nl":"Bind apparaat mislukt","pl":"powiązanie urządzenia nie powiodło się","fi":"laitteen sitominen epäonnistui","sv":"binda enhet misslyckades","km":"ឧបករណ៍ ចង បរាជ័យ"},"Please enter password":{"en":"Please enter password","zh-Hans":"请输入密码","fr":"Veuillez saisir le mot de passe","ja":"パスワードを入力してください","it":"Inserire la password","es":"Introduzca la contraseña","pt":"Introduzir a palavra-passe","de":"Bitte Passwort eingeben","ru":"Пожалуйста, введите пароль","vi":"Xin vui lòng nhập mật khẩu","th":"กรุณาใส่รหัสผ่าน","id":"Masukkan kata sandi","zh-Hant":"請輸入密碼","zh-TW":"請輸入密碼","ar":"الرجاء إدخال كلمة المرور","hu":"Kérjük, adja meg a jelszót","el":"Παρακαλώ εισάγετε τον κωδικό πρόσβασης","nl":"Voer wachtwoord in","pl":"Wprowadź hasło","fi":"Anna salasana","sv":"Ange lösenord","km":"សូម បញ្ចូល ពាក្យ សម្ងាត់"},"Ask the device owner for the password":{"en":"Ask the device owner for the password","zh-Hans":"要求设备所有者提供密码","fr":"Demandez le mot de passe au propriétaire de l'appareil","ja":"デバイスの所有者にパスワードを聞いてください","it":"Chiedere la password al proprietario del dispositivo","es":"Solicite la contraseña al propietario del dispositivo","pt":"Pedir a palavra-passe ao proprietário do dispositivo","de":"Fragen Sie den Besitzer des Geräts nach dem Passwort","ru":"Запросите пароль у владельца устройства","vi":"Yêu cầu chủ sở hữu thiết bị cung cấp mật khẩu","th":"ขอรหัสผ่านจากเจ้าของอุปกรณ์","id":"Tanyakan kata sandi kepada pemilik perangkat","zh-Hant":"要求設備所有者提供密碼","zh-TW":"要求設備所有者提供密碼","ar":"اسأل مالك الجهاز عن كلمة المرور","hu":"Kérje a készülék tulajdonosától a jelszót","el":"Ζητήστε από τον ιδιοκτήτη της συσκευής τον κωδικό πρόσβασης","nl":"Vraag de eigenaar van het apparaat om het wachtwoord","pl":"Zapytaj właściciela urządzenia o hasło","fi":"Pyydä laitteen omistajalta salasana","sv":"Be enhetens ägare om lösenordet","km":"សួរ ម្ចាស់ ឧបករណ៍ សម្រាប់ ពាក្យ សម្ងាត់"},"Please  confirm the password is correct.":{"en":"Please  confirm the password is correct.","zh-Hans":"请确认密码是否正确","fr":"Veuillez confirmer que le mot de passe est correct.","ja":"パスワードが正しいことを確認してください。","it":"Confermare che la password è corretta.","es":"Confirme que la contraseña es correcta.","pt":"Confirme se a palavra-passe está correta.","de":"Bitte bestätigen Sie, dass das Kennwort korrekt ist.","ru":"Пожалуйста, подтвердите правильность пароля.","vi":"Vui lòng xác nhận mật khẩu là chính xác.","th":"กรุณายืนยันรหัสผ่านให้ถูกต้อง","id":"Konfirmasikan kata sandi sudah benar.","zh-Hant":"請確認密碼是否正確","zh-TW":"請確認密碼是否正確","ar":"يرجى التأكد من صحة كلمة المرور.","hu":"Kérjük, erősítse meg, hogy a jelszó helyes.","el":"Παρακαλούμε επιβεβαιώστε ότι ο κωδικός πρόσβασης είναι σωστός.","nl":"Controleer of het wachtwoord correct is.","pl":"Potwierdź, że hasło jest prawidłowe.","fi":"Vahvista, että salasana on oikein.","sv":"Bekräfta att lösenordet är korrekt.","km":"សូមបញ្ជាក់ពាក្យសម្ងាត់គឺត្រឹមត្រូវ។"},"Please ensure your phone is close to the device, then try again.":{"en":"Please ensure your phone is close to the device, then try again.","zh-Hans":"请确保你的手机靠近设备后重试。","fr":"Assurez-vous que votre téléphone est proche de l'appareil, puis réessayez.","ja":"携帯電話をデバイスに近づけてから、もう一度お試しください。","it":"Assicurarsi che il telefono sia vicino al dispositivo, quindi riprovare.","es":"Asegúrese de que el teléfono está cerca del dispositivo y vuelva a intentarlo.","pt":"Certifique-se de que o seu telemóvel está próximo do dispositivo e tente novamente.","de":"Stellen Sie sicher, dass sich Ihr Telefon in der Nähe des Geräts befindet, und versuchen Sie es dann erneut.","ru":"Пожалуйста, убедитесь, что ваш телефон находится рядом с устройством, затем повторите попытку.","vi":"Vui lòng đảm bảo điện thoại của bạn ở gần thiết bị, sau đó thử lại.","th":"โปรดตรวจสอบว่าโทรศัพท์ของคุณอยู่ใกล้กับอุปกรณ์ แล้วลองอีกครั้ง","id":"Pastikan ponsel Anda dekat dengan perangkat, lalu coba lagi.","zh-Hant":"請確保你的手機靠近設備後重試。","zh-TW":"請確保你的手機靠近設備後重試。","ar":"يرجى التأكد من أن هاتفك قريب من الجهاز ، ثم حاول مرة أخرى.","hu":"Kérjük, ellenőrizze, hogy a telefonja közel van-e a készülékhez, majd próbálja meg újra.","el":"Βεβαιωθείτε ότι το τηλέφωνό σας βρίσκεται κοντά στη συσκευή και δοκιμάστε ξανά.","nl":"Zorg ervoor dat uw telefoon dicht bij het apparaat is en probeer het opnieuw.","pl":"Upewnij się, że telefon znajduje się blisko urządzenia, a następnie spróbuj ponownie.","fi":"Varmista, että puhelin on lähellä laitetta, ja yritä sitten uudelleen.","sv":"Kontrollera att din telefon är nära enheten och försök sedan igen.","km":"សូម ធានា ថា ទូរស័ព្ទ របស់ អ្នក នៅ ជិត ឧបករណ៍ បន្ទាប់ មក សាកល្បង ម្ដង ទៀត ។"},"Please scan the correct QR code on the device.":{"en":"Please scan the correct QR code on the device.","zh-Hans":"请扫描设备上正确的二维码。","fr":"Veuillez scanner le code QR correct sur l'appareil.","ja":"デバイスの正しいQRコードをスキャンしてください。","it":"Eseguire la scansione del codice QR corretto sul dispositivo.","es":"Escanee el código QR correcto en el dispositivo.","pt":"Leia o código QR correto no dispositivo.","de":"Bitte scannen Sie den richtigen QR-Code auf dem Gerät.","ru":"Пожалуйста, отсканируйте правильный QR-код на устройстве.","vi":"Vui lòng quét đúng mã QR trên thiết bị.","th":"กรุณาสแกนรหัส QR ที่ถูกต้องบนอุปกรณ์","id":"Pindai kode QR yang benar pada perangkat.","zh-Hant":"請掃描設備上正確的二維碼。","zh-TW":"請掃描設備上正確的二維碼。","ar":"يرجى مسح رمز الاستجابة السريعة الصحيح ضوئيًا على الجهاز.","hu":"Kérjük, olvassa be a megfelelő QR-kódot a készüléken.","el":"Παρακαλούμε σαρώστε τον σωστό κωδικό QR στη συσκευή.","nl":"Scan de juiste QR-code op het apparaat.","pl":"Zeskanuj prawidłowy kod QR na urządzeniu.","fi":"Skannaa oikea QR-koodi laitteeseen.","sv":"Skanna den korrekta QR-koden på enheten.","km":"សូម ស្កេន QR កូដ ត្រឹមត្រូវ នៅ លើ ឧបករណ៍ ។"},"Password is no longer valid. You can set a new one if necessary.":{"en":"Password is no longer valid. You can set a new one if necessary.","zh-Hans":"密码已失效。如有必要，您可以设置一个新的。","fr":"Le mot de passe n'est plus valide. Vous pouvez en définir un nouveau si nécessaire.","ja":"パスワードは無効です。必要に応じて新しいパスワードを設定してください。","it":"La password non è più valida. Se necessario, è possibile impostarne una nuova.","es":"La contraseña ya no es válida. Puede establecer una nueva si es necesario.","pt":"A palavra-passe já não é válida. Pode definir uma nova, se necessário.","de":"Das Passwort ist nicht mehr gültig. Sie können bei Bedarf ein neues festlegen.","ru":"Пароль больше не действителен. При необходимости вы можете задать новый.","vi":"Mật khẩu không còn hiệu lực. Bạn có thể đặt một cái mới nếu cần thiết.","th":"รหัสผ่านใช้ไม่ได้อีกต่อไป คุณสามารถตั้งค่าใหม่ได้หากจำเป็น","id":"Kata sandi sudah tidak berlaku. Anda dapat mengatur kata sandi baru jika perlu.","zh-Hant":"密碼已失效。如有必要，您可以設置一個新的。","zh-TW":"密碼已失效。如有必要，您可以設置一個新的。","ar":"كلمة المرور لم تعد صالحة. يمكنك تعيين واحدة جديدة إذا لزم الأمر.","hu":"A jelszó már nem érvényes. Szükség esetén új jelszót állíthat be.","el":"Ο κωδικός πρόσβασης δεν είναι πλέον έγκυρος. Μπορείτε να ορίσετε έναν νέο, εάν είναι απαραίτητο.","nl":"Wachtwoord is niet langer geldig. U kunt indien nodig een nieuwe instellen.","pl":"Hasło straciło ważność. W razie potrzeby można ustawić nowe.","fi":"Salasana ei ole enää voimassa. Voit tarvittaessa asettaa uuden.","sv":"Lösenordet är inte längre giltigt. Du kan ange ett nytt om det behövs.","km":"ពាក្យសម្ងាត់លែងមានសុពលភាពទៀតទេ។ អ្នក អាច កំណត់ ថ្មី មួយ ប្រសិន បើ ចាំបាច់ & # 160; ។"},"login successfully":{"en":"login successfully","zh-Hans":"登录成功","fr":"Connexion réussie","ja":"ログイン成功","it":"accesso riuscito","es":"Inicio de sesión correcto","pt":"iniciar sessão com sucesso","de":"Anmeldung erfolgreich","ru":"успешный вход","vi":"đăng nhập thành công","th":"เข้าสู่ระบบสำเร็จ","id":"berhasil masuk","zh-Hant":"登錄成功","zh-TW":"登錄成功","ar":"تسجيل الدخول بنجاح","hu":"Sikeres bejelentkezés","el":"επιτυχής σύνδεση","nl":"succesvol inloggen","pl":"logowanie powiodło się","fi":"kirjautuminen onnistui","sv":"Logga in framgångsrikt","km":"ចូល ដោយ ជោគជ័យ"},"Security":{"en":"Security","zh-Hans":"安全性","fr":"Sécurité","ja":"セキュリティ","it":"Sicurezza","es":"Seguridad","pt":"Segurança","de":"Sicherheit","ru":"Безопасность","vi":"Bảo vệ","th":"ความปลอดภัย","id":"Keamanan","zh-Hant":"安全性","zh-TW":"安全性","ar":"حماية","hu":"Biztonság","el":"Ασφάλεια","nl":"Beveiliging","pl":"Bezpieczeństwo","fi":"Turvallisuus","sv":"Säkerhet","km":"សន្តិសុខ"},"Someone has set the password. You can only reset it by scanning the QR code on the device.":{"en":"Someone has set the password. You can only reset it by scanning the QR code on the device.","zh-Hans":"有人设置了密码。你只能通过扫描设备上的二维码来重置。","fr":"Quelqu'un a défini le mot de passe. Vous ne pouvez le réinitialiser qu'en scannant le code QR sur l'appareil.","ja":"誰かがパスワードを設定しました。デバイスのQRコードをスキャンすることでのみリセットできます。","it":"Qualcuno ha impostato la password. È possibile reimpostarla solo scansionando il codice QR sul dispositivo.","es":"Alguien ha establecido la contraseña. Sólo puede restablecerla escaneando el código QR del dispositivo.","pt":"Alguém definiu a palavra-passe. Só é possível repor a palavra-passe através da leitura do código QR no dispositivo.","de":"Jemand hat das Passwort festgelegt. Sie können es nur zurücksetzen, indem Sie den QR-Code auf dem Gerät scannen.","ru":"Кто-то установил пароль. Вы можете сбросить его только путем сканирования QR-кода на устройстве.","vi":"AI đó đã đặt mật khẩu. Bạn chỉ có thể đặt lại bằng cách quét mã QR trên thiết bị.","th":"มีคนตั้งรหัสผ่าน คุณสามารถรีเซ็ตได้โดยการสแกนรหัส QR บนอุปกรณ์เท่านั้น","id":"Seseorang telah mengatur kata sandi. Anda hanya dapat mengatur ulang dengan memindai kode QR pada perangkat.","zh-Hant":"有人設置了密碼。你只能通過掃描設備上的二維碼來重置。","zh-TW":"有人設置了密碼。你只能通過掃描設備上的二維碼來重置。","ar":"قام شخص ما بتعيين كلمة المرور. يمكنك إعادة تعيينه فقط عن طريق مسح رمز الاستجابة السريعة الموجود على الجهاز.","hu":"Valaki beállította a jelszót. Csak a készüléken lévő QR-kód beolvasásával tudja visszaállítani.","el":"Κάποιος έχει ορίσει τον κωδικό πρόσβασης. Μπορείτε να τον επαναφέρετε μόνο με σάρωση του κωδικού QR στη συσκευή.","nl":"Iemand heeft het wachtwoord ingesteld. Je kunt het alleen resetten door de QR-code op het apparaat te scannen.","pl":"Ktoś ustawił hasło. Można je zresetować tylko poprzez zeskanowanie kodu QR na urządzeniu.","fi":"Joku on asettanut salasanan. Voit nollata sen vain skannaamalla laitteessa olevan QR-koodin.","sv":"Någon har ställt in lösenordet. Du kan bara återställa det genom att skanna QR-koden på enheten.","km":"នរណា ម្នាក់ បាន កំណត់ ពាក្យ សម្ងាត់ & # 160; ។ អ្នក អាច កំណត់ វា ឡើង វិញ ដោយ ស្កេន កូដ QR នៅ លើ ឧបករណ៍ & # 160; ។"},"Reset":{"en":"Reset","zh-Hans":"重新设置","fr":"Réinitialiser","ja":"リセット","it":"Azzeramento","es":"Restablecer","pt":"Repor","de":"Zurücksetzen","ru":"Сброс","vi":"Cài lại","th":"รีเซ็ต","id":"Atur ulang","zh-Hant":"重新設置","zh-TW":"重新設置","ar":"إعادة ضبط","hu":"Reset","el":"Επαναφορά","nl":"Reset","pl":"Reset","fi":"Nollaa","sv":"Återställ","km":"Reset"},"Sleep curve is not available in ECO or FP":{"en":"Sleep curve is not available in ECO or FP","zh-Hans":"睡眠曲线在ECO或FP中不可用","fr":"La courbe de sommeil n'est pas disponible en ECO ou FP","ja":"スリープカーブはECOまたはFPでは使用できません。","it":"La curva di riposo non è disponibile in ECO o FP","es":"La curva de reposo no está disponible en ECO o FP","pt":"A curva de sono não está disponível em ECO ou FP","de":"Die Ruhekurve ist in ECO oder FP nicht verfügbar.","ru":"Режим сна недоступен в режимах ECO или FP","vi":"Đường cong giấc ngủ không khả dụng trong ECO hoặc FP","th":"เส้นโค้งการนอนหลับไม่พร้อมใช้งานใน ECO หรือ FP","id":"Kurva tidur tidak tersedia dalam ECO atau FP","zh-Hant":"睡眠曲線在ECO或FP中不可用","zh-TW":"睡眠曲線在ECO或FP中不可用","ar":"منحنى النوم غير متاح في ECO أو FP","hu":"Az alvó görbe nem érhető el ECO vagy FP üzemmódban.","el":"Η καμπύλη ύπνου δεν είναι διαθέσιμη στο ECO ή στο FP","nl":"Slaapcurve is niet beschikbaar in ECO of FP","pl":"Krzywa uśpienia nie jest dostępna w trybie ECO lub FP.","fi":"Lepokäyrä ei ole käytettävissä ECO- tai FP-tilassa.","sv":"Viloläge är inte tillgängligt i ECO eller FP","km":"ខ្សែកោងគេងមិនអាចប្រើបាននៅក្នុង ECO ឬ FP"},"Safety":{"en":"Safety","zh-Hans":"安全","fr":"Sécurité","ja":"安全性","it":"Sicurezza","es":"Seguridad","pt":"Segurança","de":"Sicherheit","ru":"Безопасность","vi":"Sự an toàn","th":"ความปลอดภัย","id":"Keamanan","zh-Hant":"安全","zh-TW":"安全","ar":"أمان","hu":"Biztonság","el":"Ασφάλεια","nl":"Veiligheid","pl":"Bezpieczeństwo","fi":"Turvallisuus","sv":"Säkerhet","km":"សុវត្ថិភាព"},"Require a password to gain local control of the device via Bluetooth.":{"en":"Require a password to gain local control of the device via Bluetooth.","zh-Hans":"要求有密码才能通过蓝牙获得对设备的本地控制。","fr":"Exiger un mot de passe pour obtenir le contrôle local de l'appareil via Bluetooth.","ja":"Bluetooth経由でデバイスをローカル制御するにはパスワードが必要です。","it":"Richiede una password per ottenere il controllo locale del dispositivo tramite Bluetooth.","es":"Requiere una contraseña para obtener el control local del dispositivo a través de Bluetooth.","pt":"Exigir uma palavra-passe para obter controlo local do dispositivo através de Bluetooth.","de":"Für die lokale Steuerung des Geräts über Bluetooth ist ein Kennwort erforderlich.","ru":"Требуется пароль для получения локального контроля над устройством через Bluetooth.","vi":"Yêu cầu mật khẩu để giành quyền kiểm soát cục bộ thiết bị qua Bluetooth.","th":"ต้องใช้รหัสผ่านเพื่อควบคุมอุปกรณ์ผ่าน Bluetooth","id":"Memerlukan kata sandi untuk mendapatkan kontrol lokal perangkat melalui Bluetooth.","zh-Hant":"要求有密碼才能通過藍牙獲得對設備的本地控制。","zh-TW":"要求有密碼才能通過藍牙獲得對設備的本地控制。","ar":"طلب كلمة مرور للحصول على تحكم محلي في الجهاز عبر البلوتوث.","hu":"Jelszó megadása szükséges a készülék Bluetooth-on keresztüli helyi vezérléséhez.","el":"Απαιτείται κωδικός πρόσβασης για την απόκτηση τοπικού ελέγχου της συσκευής μέσω Bluetooth.","nl":"Vereist een wachtwoord om lokale controle over het apparaat te krijgen via Bluetooth.","pl":"Wymagaj hasła, aby uzyskać lokalną kontrolę nad urządzeniem przez Bluetooth.","fi":"Vaadi salasana, jotta voit hallita laitetta paikallisesti Bluetoothin kautta.","sv":"Kräv ett lösenord för att få lokal kontroll över enheten via Bluetooth.","km":"ទាមទារពាក្យសម្ងាត់ដើម្បីទទួលបានការត្រួតពិនិត្យមូលដ្ឋាននៃឧបករណ៍តាមរយៈ Bluetooth។"},"Password":{"en":"Password","zh-Hans":"密码","fr":"Mot de passe","ja":"パスワード","it":"Password","es":"Contraseña","pt":"Palavra-passe","de":"Kennwort","ru":"Пароль","vi":"Mật khẩu","th":"รหัสผ่าน","id":"Kata sandi","zh-Hant":"密碼","zh-TW":"密碼","ar":"كلمة المرور","hu":"Jelszó","el":"Κωδικός πρόσβασης","nl":"Wachtwoord","pl":"Hasło","fi":"Salasana","sv":"Lösenord","km":"ពាក្យសម្ងាត់"},"Please Enter Password":{"en":"Please Enter Password","zh-Hans":"请输入密码","fr":"Veuillez saisir le mot de passe","ja":"パスワードを入力してください。","it":"Inserire la password","es":"Introduzca la contraseña","pt":"Introduzir palavra-passe","de":"Bitte Passwort eingeben","ru":"Пожалуйста, введите пароль","vi":"Xin vui lòng nhập mật khẩu","th":"กรุณาใส่รหัสผ่าน","id":"Silakan Masukkan Kata Sandi","zh-Hant":"請輸入密碼","zh-TW":"請輸入密碼","ar":"الرجاء إدخال كلمة المرور","hu":"Kérjük, adja meg a jelszót","el":"Παρακαλώ εισάγετε τον κωδικό πρόσβασης","nl":"Voer wachtwoord in","pl":"Wprowadź hasło","fi":"Anna salasana","sv":"Vänligen ange lösenord","km":"សូម បញ្ចូល Password"},"The password must contain at lease 6 characters. Changing the password will disconnect any currently connected users.":{"en":"The password must contain at lease 6 characters. Changing the password will disconnect any currently connected users.","zh-Hans":"密码必须包含至少6个字符。改变密码将断开当前连接的所有用户。","fr":"Le mot de passe doit contenir au moins 6 caractères. La modification du mot de passe déconnectera tous les utilisateurs actuellement connectés.","ja":"パスワードは6文字以上でなければなりません。パスワードを変更すると、現在接続しているユーザーはすべて切断されます。","it":"La password deve contenere almeno 6 caratteri. La modifica della password comporta la disconnessione degli utenti attualmente connessi.","es":"La contraseña debe contener al menos 6 caracteres. Si cambia la contraseña, se desconectará cualquier usuario conectado actualmente.","pt":"A palavra-passe deve conter pelo menos 6 caracteres. A alteração da palavra-passe desligará todos os utilizadores atualmente ligados.","de":"Das Passwort muss aus mindestens 6 Zeichen bestehen. Wenn Sie das Kennwort ändern, wird die Verbindung aller derzeit verbundenen Benutzer getrennt.","ru":"Пароль должен содержать не менее 6 символов. Изменение пароля приведет к отключению всех подключенных пользователей.","vi":"Mật khẩu phải chứa ít nhất 6 ký tự. Thay đổi mật khẩu sẽ ngắt kết nối mọi người dùng hiện đang kết nối.","th":"รหัสผ่านต้องมีอักขระอย่างน้อย 6 ตัว การเปลี่ยนรหัสผ่านจะยกเลิกการเชื่อมต่อผู้ใช้ที่เชื่อมต่ออยู่","id":"Kata sandi harus terdiri dari minimal 6 karakter. Mengubah kata sandi akan memutuskan pengguna yang sedang terhubung.","zh-Hant":"密碼必須包含至少6個字符。改變密碼將斷開當前連接的所有用戶。","zh-TW":"密碼必須包含至少6個字符。改變密碼將斷開當前連接的所有用戶。","ar":"يجب أن تحتوي كلمة المرور في عقد الإيجار 6 أحرف. سيؤدي تغيير كلمة المرور إلى قطع اتصال أي مستخدمين متصلين حاليًا.","hu":"A jelszónak legalább 6 karaktert kell tartalmaznia. A jelszó megváltoztatása megszakítja a jelenleg csatlakoztatott felhasználók kapcsolatát.","el":"Ο κωδικός πρόσβασης πρέπει να περιέχει τουλάχιστον 6 χαρακτήρες. Η αλλαγή του κωδικού πρόσβασης θα αποσυνδέσει όλους τους συνδεδεμένους χρήστες που βρίσκονται επί του παρόντος σε σύνδεση.","nl":"Het wachtwoord moet minimaal 6 tekens bevatten. Als u het wachtwoord wijzigt, worden alle momenteel verbonden gebruikers verbroken.","pl":"Hasło musi zawierać co najmniej 6 znaków. Zmiana hasła spowoduje rozłączenie aktualnie podłączonych użytkowników.","fi":"Salasanan on sisällettävä vähintään 6 merkkiä. Salasanan muuttaminen katkaisee kaikkien tällä hetkellä yhteydessä olevien käyttäjien yhteyden.","sv":"Lösenordet måste innehålla minst 6 tecken. Om du ändrar lösenordet kopplas alla användare som för närvarande är anslutna bort.","km":"ពាក្យ សម្ងាត់ ត្រូវ តែ មាន នៅ ក្នុង ការ ជួល 6 តួ ។ ការ ផ្លាស់ប្ដូរ ពាក្យ សម្ងាត់ នឹង ផ្តាច់ អ្នក ប្រើ ដែល បាន តភ្ជាប់ បច្ចុប្បន្ន & # 160; ។"},"Password should be 6 digits":{"en":"Password should be 6 digits","zh-Hans":"密码应该是6个字符。","fr":"Le mot de passe doit être composé de 6 chiffres","ja":"パスワードは6桁でなければなりません。","it":"La password deve essere di 6 cifre","es":"La contraseña debe tener 6 dígitos","pt":"A palavra-passe deve ter 6 dígitos","de":"Das Passwort sollte 6 Ziffern enthalten","ru":"Пароль должен состоять из 6 цифр","vi":"Mật khẩu phải có 6 chữ số","th":"รหัสผ่านควรเป็น 6 หลัก","id":"Kata sandi harus terdiri dari 6 digit","zh-Hant":"密碼應該是6個字符。","zh-TW":"密碼應該是6個字符。","ar":"يجب أن تتكون كلمة المرور من 6 أرقام","hu":"A jelszónak 6 számjegyűnek kell lennie","el":"Ο κωδικός πρόσβασης πρέπει να είναι 6 ψηφία","nl":"Wachtwoord moet uit 6 cijfers bestaan","pl":"Hasło powinno składać się z 6 cyfr","fi":"Salasanan on oltava 6-numeroinen","sv":"Lösenordet ska vara 6 siffror","km":"ពាក្យសម្ងាត់គួរតែជាលេខ 6"},"no records!":{"en":"no records!","zh-Hans":"没有记录!","fr":"pas d'enregistrement !","ja":"記録はありません！","it":"nessun record!","es":"¡no hay registros!","pt":"sem registos!","de":"keine Aufzeichnungen!","ru":"никаких записей!","vi":"không có hồ sơ!","th":"ไม่มีบันทึก!","id":"tidak ada catatan!","zh-Hant":"沒有記錄!","zh-TW":"沒有記錄!","ar":"لا تسجيلات!","hu":"nincs rekord!","el":"Δεν υπάρχουν εγγραφές!","nl":"geen records!","pl":"brak zapisów!","fi":"ei tietueita!","sv":"inga registreringar!","km":"គ្មាន កំណត់ត្រា ទេ !"},"The device cannot be operated when it is turned off.":{"en":"The device cannot be operated when it is turned off.","zh-Hans":"设备关闭时不能操作。","fr":"L'appareil ne peut pas être utilisé lorsqu'il est éteint.","ja":"デバイスの電源がオフの場合は操作できません。","it":"Il dispositivo non può essere utilizzato quando è spento.","es":"El dispositivo no puede funcionar cuando está apagado.","pt":"O dispositivo não pode ser operado quando está desligado.","de":"Das Gerät kann nicht bedient werden, wenn es ausgeschaltet ist.","ru":"Прибор не может работать, если он выключен.","vi":"Thiết bị không thể hoạt động khi đã tắt.","th":"ไม่สามารถใช้งานอุปกรณ์ได้เมื่อปิดอยู่","id":"Perangkat tidak dapat dioperasikan saat dimatikan.","zh-Hant":"設備關閉時不能操作。","zh-TW":"設備關閉時不能操作。","ar":"لا يمكن تشغيل الجهاز عند إيقاف تشغيله.","hu":"A készülék kikapcsolt állapotban nem működtethető.","el":"Η συσκευή δεν μπορεί να λειτουργήσει όταν είναι απενεργοποιημένη.","nl":"Het apparaat kan niet worden bediend als het is uitgeschakeld.","pl":"Urządzenie nie może być obsługiwane, gdy jest wyłączone.","fi":"Laitetta ei voi käyttää, kun se on kytketty pois päältä.","sv":"Enheten kan inte användas när den är avstängd.","km":"ឧបករណ៍ មិន អាច ដំណើរ ការ បាន ទេ នៅ ពេល ដែល វា ត្រូវ បាន បិទ & # 160; ។"},"Only online data of power consumption after 11/10/2019 is available.":{"en":"*Only count power on hours while the device is online.","zh-Hans":"仅记录设备在线状态时的能耗。","fr":"*Ne comptez que les heures de mise sous tension lorsque l'appareil est en ligne.","ja":"*デバイスがオンラインである間のみ電源オン時間をカウントする。","it":"*Conta solo le ore di accensione quando il dispositivo è online.","es":"*Sólo cuenta las horas de encendido mientras el dispositivo está conectado.","pt":"*Só conta as horas de ligação enquanto o dispositivo está online.","de":"*Zählt nur die Einschaltstunden, wenn das Gerät online ist.","ru":"*Учитываются только часы включения, когда устройство находится в сети.","vi":"Chỉ mức tiêu thụ năng lượng khi thiết bị trực tuyến mới được ghi lại.","th":"เฉพาะการใช้พลังงานเมื่ออุปกรณ์ออนไลน์เท่านั้นที่จะถูกบันทึก","id":"Hanya konsumsi energi saat perangkat online yang dicatat.","zh-Hant":"僅記錄設備在線上狀態時的能耗。","zh-TW":"僅記錄設備在線上狀態時的能耗。","ar":"يتم تسجيل استهلاك الطاقة فقط عندما يكون الجهاز متصلاً بالإنترنت.","hu":"*Csak akkor számolja a bekapcsolt órákat, amikor a készülék online van.","el":"*Μετρά μόνο τις ώρες ενεργοποίησης όσο η συσκευή είναι συνδεδεμένη.","nl":"*Telt alleen inschakeluren als het apparaat online is.","pl":"*Zliczane są tylko godziny włączonego zasilania, gdy urządzenie jest w trybie online.","fi":"*Lasketaan vain virtatunnit, kun laite on verkossa.","sv":"*Räkna endast strömtimmar när enheten är online.","km":"*គ្រាន់តែរាប់ថាមពលលើម៉ោងប៉ុណ្ណោះខណៈពេលដែលឧបករណ៍មាននៅលើអ៊ិនធឺណិត។"},"Energy Usage Reminder":{"en":"Energy Usage Reminder","zh-Hans":"能源使用提醒","fr":"Rappel de la consommation d'énergie","ja":"エネルギー使用量リマインダー","it":"Promemoria sul consumo di energia","es":"Recordatorio de consumo de energía","pt":"Lembrete de consumo de energia","de":"Energieverbrauchs-Erinnerung","ru":"Напоминание об энергопотреблении","vi":"Nhắc nhở sử dụng năng lượng","th":"เตือนการใช้พลังงาน","id":"Pengingat Penggunaan Energi","zh-Hant":"能源使用提醒","zh-TW":"能源使用提醒","ar":"تذكير استخدام الطاقة","hu":"Energiafelhasználási emlékeztető","el":"Υπενθύμιση χρήσης ενέργειας","nl":"Herinnering energieverbruik","pl":"Przypomnienie o zużyciu energii","fi":"Energiankulutuksen muistutus","sv":"Påminnelse om energianvändning","km":"ការរំឭកការប្រើប្រាស់ថាមពល"},"Per Week":{"en":"Per Week","zh-Hans":"每周","fr":"Par semaine","ja":"1週間あたり","it":"Per settimana","es":"Por semana","pt":"Por semana","de":"Pro Woche","ru":"За неделю","vi":"Mỗi tuần","th":"ต่อสัปดาห์","id":"Per Minggu","zh-Hant":"每週","zh-TW":"每週","ar":"في الاسبوع","hu":"Heti","el":"Ανά εβδομάδα","nl":"Per week","pl":"Za tydzień","fi":"Viikoittain","sv":"Per vecka","km":"ក្នុង មួយ សប្តាហ៍"},"Per Month":{"en":"Per Month","zh-Hans":"每月","fr":"Par mois","ja":"1ヶ月あたり","it":"Per mese","es":"Por mes","pt":"Por mês","de":"Pro Monat","ru":"За месяц","vi":"Mỗi tháng","th":"ต่อเดือน","id":"Per Bulan","zh-Hant":"每月","zh-TW":"每月","ar":"كل شهر","hu":"Havonta","el":"Ανά μήνα","nl":"Per maand","pl":"Na miesiąc","fi":"Kuukautta kohti","sv":"Per månad","km":"ក្នុងមួយខែ"},"Per Year":{"en":"Per Year","zh-Hans":"每年","fr":"Par année","ja":"年間","it":"Per anno","es":"Por año","pt":"Por ano","de":"Pro Jahr","ru":"За год","vi":"Mỗi năm","th":"ต่อปี","id":"Per Tahun","zh-Hant":"每年","zh-TW":"每年","ar":"كل سنة","hu":"Évente","el":"Ανά έτος","nl":"Per jaar","pl":"Na rok","fi":"Vuotta kohden","sv":"Per år","km":"ក្នុងមួយឆ្នាំ"},"Notify me when energy cunsumption reaches percentage of the target":{"en":"Notify me when energy consumption reaches percentage of the target","zh-Hans":"当能源消耗达到目标时通知我","fr":"Me notifier lorsque la consommation d'énergie atteint un pourcentage de l'objectif.","ja":"エネルギー消費量が目標値に達した場合に通知します。","it":"Avvisami quando il consumo di energia raggiunge la percentuale dell'obiettivo","es":"Notificarme cuando el cunsumo de energía alcance el porcentaje del objetivo","pt":"Notificar-me quando o consumo de energia atingir a percentagem do objetivo","de":"Benachrichtigen Sie mich, wenn der Energieverbrauch einen bestimmten Prozentsatz des Zielwerts erreicht.","ru":"Уведомить меня, когда потребление энергии достигает процента от целевого показателя","vi":"Thông báo cho tôi khi năng lượng tiêu thụ đạt phần trăm mục tiêu","th":"แจ้งเตือนฉันเมื่อการสิ้นเปลืองพลังงานถึงเปอร์เซ็นต์ของเป้าหมาย","id":"Beri tahu saya ketika konsumsi energi mencapai persentase dari target","zh-Hant":"當能源消耗達到目標時通知我","zh-TW":"當能源消耗達到目標時通知我","ar":"أعلمني عندما يصل استهلاك الطاقة إلى النسبة المئوية للهدف","hu":"Értesítés, ha az energiafogyasztás eléri a célérték százalékát","el":"Ειδοποιήστε με όταν η κατανάλωση ενέργειας φτάσει σε ποσοστό του στόχου","nl":"Waarschuw me wanneer het energieverbruik een percentage van de doelstelling bereikt","pl":"Powiadomienie, gdy zużycie energii osiągnie wartość procentową wartości docelowej","fi":"Ilmoita minulle, kun energiankulutus saavuttaa prosenttiosuuden tavoitteesta","sv":"Meddela mig när energiförbrukningen når en procentandel av målet","km":"ជូន ដំណឹង ដល់ ខ្ញុំ ពេល ដែល ការ ប្រើប្រាស់ ថាមពល ឈាន ដល់ ភាគរយ នៃ គោលដៅ"},"Report":{"en":"Report","zh-Hans":"报告","fr":"Rapport","ja":"レポート","it":"Rapporto","es":"Informe","pt":"Relatório","de":"Bericht","ru":"Отчет","vi":"Báo cáo","th":"รายงาน","id":"Laporan","zh-Hant":"報告","zh-TW":"報告","ar":"تقرير","hu":"Jelentés","el":"Αναφορά","nl":"Rapporteer","pl":"Raport","fi":"Raportti","sv":"Rapportera","km":"របាយការណ៍"},"Warning!":{"en":"Warning!","zh-Hans":"警告!","fr":"Attention !","ja":"警告","it":"Attenzione!","es":"Advertencia","pt":"Aviso!","de":"Warnung!","ru":"Внимание!","vi":"Cảnh báo!","th":"คำเตือน!","id":"Peringatan!","zh-Hant":"警告!","zh-TW":"警告!","ar":"تحذير!","hu":"Figyelmeztetés!","el":"Προειδοποίηση!","nl":"Waarschuwing!","pl":"Ostrzeżenie!","fi":"Varoitus!","sv":"Varning!","km":"ព្រមាន!"},"You’re over your monthly target":{"en":"You’re over your monthly target","zh-Hans":"您已经超过了月度目标","fr":"Vous avez dépassé votre objectif mensuel","ja":"月間目標値を超えています","it":"Hai superato il tuo obiettivo mensile","es":"Ha superado su objetivo mensual","pt":"Ultrapassou o seu objetivo mensal","de":"Sie sind über Ihrem monatlichen Zielwert","ru":"Вы превысили месячную норму","vi":"Bạn đã vượt quá mục tiêu hàng tháng của mình","th":"คุณเกินเป้าหมายรายเดือนของคุณแล้ว","id":"Anda telah melampaui target bulanan Anda","zh-Hant":"您已經超過了月度目標","zh-TW":"您已經超過了月度目標","ar":"لقد تجاوزت هدفك الشهري","hu":"Túllépte a havi célértéket","el":"Ξεπεράσατε το μηνιαίο σας στόχο","nl":"Je hebt je maandelijkse streefcijfer overschreden","pl":"Przekroczyłeś swój miesięczny cel","fi":"Olet ylittänyt kuukausittaisen tavoitteesi","sv":"Du har överskridit ditt månadsmål","km":"អ្នក លើស គោលដៅ ប្រចាំ ខែ របស់ អ្នក"},"Used":{"en":"Used","zh-Hans":"已用","fr":"Vous avez consommé","ja":"使用量","it":"Utilizzato","es":"Ha consumido","pt":"Utilizou","de":"Verbraucht","ru":"Использовали","vi":"Đã sử dụng","th":"ใช้แล้ว","id":"Digunakan","zh-Hant":"已用","zh-TW":"已用","ar":"مستخدم","hu":"Felhasznált","el":"Χρησιμοποιημένο","nl":"gebruikt","pl":"Zużyto","fi":"Käytetty","sv":"Använt","km":"ប្រើ"},"more than last month":{"en":"more than last month","zh-Hans":"比上个月多","fr":"plus que le mois dernier","ja":"先月より多い","it":"più del mese scorso","es":"más que el mes pasado","pt":"mais do que no mês passado","de":"mehr als im letzten Monat","ru":"больше, чем в прошлом месяце","vi":"hơn tháng trước","th":"มากกว่าเดือนที่แล้ว","id":"lebih dari bulan lalu","zh-Hant":"比上個月多","zh-TW":"比上個月多","ar":"أكثر من الشهر الماضي","hu":"többet, mint az előző hónapban","el":"περισσότερο από τον προηγούμενο μήνα","nl":"meer dan vorige maand","pl":"więcej niż w poprzednim miesiącu","fi":"enemmän kuin viime kuussa","sv":"mer än förra månaden","km":"ច្រើន ជាង ខែ មុន"},"less than last month":{"en":"less than last month","zh-Hans":"比上个月少","fr":"moins que le mois dernier","ja":"先月より少ない","it":"meno del mese scorso","es":"menos que el mes pasado","pt":"menos do que no mês passado","de":"weniger als im Vormonat","ru":"меньше, чем в прошлом месяце","vi":"ít hơn tháng trước","th":"น้อยกว่าเดือนที่แล้ว","id":"kurang dari bulan lalu","zh-Hant":"比上個月少","zh-TW":"比上個月少","ar":"أقل من الشهر الماضي","hu":"kevesebb, mint az előző hónapban","el":"λιγότερο από τον προηγούμενο μήνα","nl":"minder dan vorige maand","pl":"mniej niż w poprzednim miesiącu","fi":"vähemmän kuin viime kuussa","sv":"mindre än förra månaden","km":"តិច ជាង ខែ មុន"},"Coincidence!":{"en":"Coincidence!","zh-Hans":"巧合!","fr":"Coïncidence !","ja":"偶然です！","it":"Coincidenza!","es":"¡Coincidencia!","pt":"Coincidência!","de":"Zufall!","ru":"Совпадение!","vi":"Thật trùng hợp!","th":"เหตุบังเอิญ!","id":"Kebetulan!","zh-Hant":"巧合!","zh-TW":"巧合!","ar":"صدفة!","hu":"Véletlen egybeesés!","el":"Σύμπτωση!","nl":"Toeval!","pl":"Przypadek!","fi":"Sattuma!","sv":"Sammanträffande!","km":"ចៃដន្យ!"},"Great!":{"en":"Great!","zh-Hans":"很好!","fr":"Génial !","ja":"素晴らしい","it":"Grande!","es":"¡Estupendo!","pt":"Ótimo!","de":"Na toll!","ru":"Отлично!","vi":"Tuyệt vời!","th":"ยอดเยี่ยม!","id":"Bagus!","zh-Hant":"很好!","zh-TW":"很好!","ar":"عظيم!","hu":"Nagyszerű!","el":"Υπέροχα!","nl":"Geweldig!","pl":"Świetnie!","fi":"Hienoa!","sv":"Jättebra!","km":"អស្ចារ្យមែន!"},"Used as much as last month":{"en":"Used as much as last month","zh-Hans":"与上月使用的一样多","fr":"Utilisé autant que le mois dernier","ja":"先月と同じくらい使用","it":"Usato quanto il mese scorso","es":"Usado tanto como el mes pasado","pt":"Utilizado tanto como no mês passado","de":"Genauso viel benutzt wie letzten Monat","ru":"Использовано столько же, сколько в прошлом месяце","vi":"Được sử dụng nhiều như tháng trước","th":"ใช้เท่าเดือนที่แล้ว","id":"Digunakan sebanyak bulan lalu","zh-Hant":"與上月使用的一樣多","zh-TW":"與上月使用的一樣多","ar":"استخدمت بقدر الشهر الماضي","hu":"Ugyanannyit használtam, mint a múlt hónapban","el":"Χρησιμοποιήθηκε όσο και τον προηγούμενο μήνα","nl":"Evenveel gebruikt als vorige maand","pl":"Zużyto tyle samo co w zeszłym miesiącu","fi":"Käytetty yhtä paljon kuin viime kuussa","sv":"Används lika mycket som förra månaden","km":"ប្រើ ច្រើន ដូច ខែ មុន"},"Password login":{"en":"Password login","zh-Hans":"密码登录","fr":"Mot de passe de connexion","ja":"パスワードログイン","it":"Password di accesso","es":"Contraseña","pt":"Palavra-passe de acesso","de":"Passwort Anmeldung","ru":"Вход по паролю","vi":"Mật khẩu đăng nhập","th":"เข้าสู่ระบบรหัสผ่าน","id":"Login kata sandi","zh-Hant":"密碼登錄","zh-TW":"密碼登錄","ar":"تسجيل الدخول كلمة المرور","hu":"Jelszó bejelentkezés","el":"Σύνδεση με κωδικό πρόσβασης","nl":"Inloggen met wachtwoord","pl":"Hasło logowania","fi":"Salasana kirjautuminen","sv":"Lösenord för inloggning","km":"ការ ចូល ពាក្យ សម្ងាត់"},"Set the allowed temperature range for operation.":{"en":"Set the allowed temperature range for operation.","zh-Hans":"请设置允许的工作温度范围。","fr":"Définissez la plage de température autorisée pour le fonctionnement.","ja":"動作許容温度範囲を設定します。","it":"Impostare l'intervallo di temperatura consentito per il funzionamento.","es":"Establezca el rango de temperatura permitido para el funcionamiento.","pt":"Defina a faixa de temperatura permitida para operação.","de":"Stellen Sie den zulässigen Temperaturbereich für den Betrieb ein.","ru":"Установите допустимый диапазон температур для работы.","vi":"Đặt phạm vi nhiệt độ cho phép để hoạt động.","th":"กำหนดช่วงอุณหภูมิที่อนุญาตสำหรับการทำงาน","id":"Tetapkan rentang suhu yang diizinkan untuk pengoperasian.","zh-Hant":"請設置允許的工作溫度範圍。","zh-TW":"請設置允許的工作溫度範圍。","ar":"اضبط نطاق درجة الحرارة المسموح به للتشغيل.","hu":"Állítsa be a működéshez megengedett hőmérsékleti tartományt.","el":"Ορίστε το επιτρεπόμενο εύρος θερμοκρασίας για τη λειτουργία.","nl":"Stel het toegestane temperatuurbereik in.","pl":"Ustaw dozwolony zakres temperatur pracy.","fi":"Aseta sallittu lämpötila-alue toimintaa varten.","sv":"Ställ in det tillåtna temperaturintervallet för drift.","km":"កំណត់ ជួរ សីតុណ្ហភាព ដែល បាន អនុញ្ញាត សម្រាប់ ប្រតិបត្តិការ & # 160; ។"},"Please set the temperature range, the maximum value should be at least 24℃/75℉.":{"en":"Please set the temperature range, the maximum value should be at least 24℃/75℉.","zh-Hans":"请设定温度范围，最高值需高于24℃/75℉。","fr":"Veuillez définir la plage de température, la valeur maximale doit être au moins 24℃/75℉.","ja":"温度範囲を設定してください、最大値は少なくとも24℃/75℉です。","it":"Impostare l'intervallo di temperatura, il valore massimo deve essere di almeno 24℃/75℉.","es":"Por favor, ajuste el rango de temperatura, el valor máximo debe ser de al menos 24℃/75℉.","pt":"Por favor, defina a faixa de temperatura, o valor máximo deve ser de pelo menos 24 ℃ / 75 ℉.","de":"Bitte stellen Sie den Temperaturbereich ein, der Höchstwert sollte mindestens 24℃/75℉ betragen.","ru":"Пожалуйста, установите диапазон температур, максимальное значение должно быть не менее 24℃/75℉.","vi":"Vui lòng đặt phạm vi nhiệt độ, giá trị tối đa ít nhất phải là 24℃/75℉.","th":"โปรดตั้งค่าช่วงอุณหภูมิ ค่าสูงสุดควรเป็นอย่างน้อย 24℃/75℉","id":"Silakan atur kisaran suhu, nilai maksimum harus setidaknya 24℃/75℉.","zh-Hant":"請設定溫度範圍，最高值需高於24℃/75℉。","zh-TW":"請設定溫度範圍，最高值需高於24℃/75℉。","ar":"يرجى ضبط نطاق درجة الحرارة ، يجب أن تكون القيمة القصوى على الأقل 24 درجة / 75 درجة مئوية.","hu":"Kérjük, állítsa be a hőmérsékleti tartományt, a maximális értéknek legalább 24 ℃/75℉ kell lennie.","el":"Ορίστε το εύρος θερμοκρασίας, η μέγιστη τιμή πρέπει να είναι τουλάχιστον 24℃/75℉.","nl":"Stel het temperatuurbereik in, de maximale waarde moet ten minste 24℃/75℉ zijn.","pl":"Należy ustawić zakres temperatur, maksymalna wartość powinna wynosić co najmniej 24℃/75℉.","fi":"Aseta lämpötila-alue, enimmäisarvon tulisi olla vähintään 24 ℃/75℉.","sv":"Vänligen ställ in temperaturintervallet, det maximala värdet bör vara minst 24 ℃ / 75 ℉.","km":"សូម កំណត់ ជួរ សីតុណ្ហភាព តម្លៃ អតិបរមា គួរ តែ មាន យ៉ាង ហោច ណាស់ 24°C/75°F។"},"Auto gear control to save energy，will start automatically when device is turned on":{"en":"Auto gear control to save energy，will start automatically when device is turned on","zh-Hans":"自动调档节能，开机自行启动","fr":"Contrôle automatique de l'engrenage pour économiser l'énergie，démarre automatiquement lorsque l'appareil est mis en marche","ja":"エネルギーを節約する自動ギア制御、デバイスがオンになったときに自動的に開始されます。","it":"Controllo automatico dell'ingranaggio per risparmiare energia, si avvia automaticamente all'accensione del dispositivo.","es":"Control de engranaje automático para ahorrar energía, se iniciará automáticamente cuando se encienda el dispositivo.","pt":"Controle automático de engrenagem para economizar energia, iniciará automaticamente quando o dispositivo for ligado","de":"Automatische Getriebesteuerung, um Energie zu sparen, startet automatisch, wenn das Gerät eingeschaltet wird.","ru":"Автоматическое управление передачей для экономии энергии, автоматический запуск при включении устройства","vi":"Điều khiển bánh răng tự động để tiết kiệm năng lượng, sẽ tự khởi động khi bật thiết bị","th":"การควบคุมเกียร์อัตโนมัติเพื่อประหยัดพลังงานจะเริ่มโดยอัตโนมัติเมื่อเปิดเครื่อง","id":"Kontrol roda gigi otomatis untuk menghemat energi, akan dimulai secara otomatis saat perangkat dihidupkan","zh-Hant":"自動調檔節能，開機自行啟動","zh-TW":"自動調檔節能，開機自行啟動","ar":"سيبدأ التحكم التلقائي في الترس لتوفير الطاقة تلقائيًا عند تشغيل الجهاز","hu":"Automatikus sebességváltó vezérlés az energiatakarékosság érdekében, automatikusan elindul, amikor a készüléket bekapcsolják.","el":"Αυτόματος έλεγχος ταχυτήτων για εξοικονόμηση ενέργειας，θα ξεκινήσει αυτόματα όταν ενεργοποιείται η συσκευή","nl":"Auto gear control om energie te besparen, start automatisch wanneer het apparaat wordt ingeschakeld","pl":"Automatyczne sterowanie biegiem w celu oszczędzania energii， uruchomi się automatycznie po włączeniu urządzenia","fi":"Automaattinen vaihteenohjaus säästää energiaa，käynnistyy automaattisesti, kun laite kytketään päälle.","sv":"Automatisk växelkontroll för att spara energi ， startar automatiskt när enheten är påslagen","km":"ឧបករណ៍ បញ្ជា ឧបករណ៍ ស្វ័យ ប្រវត្តិ ដើម្បី សន្សំ ថាមពល នឹង ចាប់ ផ្តើម ដោយ ស្វ័យ ប្រវត្តិ នៅ ពេល ឧបករណ៍ ត្រូវ បាន បើក"},"Auto gear control to save energy，will quit automatically after 8 hours":{"en":"Auto gear control to save energy，will quit automatically after 8 hours","zh-Hans":"自动节能档位控制，8小时后自动退出。","fr":"Contrôle automatique de l'engrenage pour économiser l'énergie，arrêtera automatiquement au bout de 8 heures","ja":"エネルギーを節約する自動ギア制御、8時間後に自動的に終了します。","it":"Il controllo automatico dell'ingranaggio per il risparmio energetico si spegne automaticamente dopo 8 ore.","es":"Control de engranaje automático para ahorrar energía，se apagará automáticamente después de 8 horas.","pt":"Controle automático de engrenagem para economizar energia, sairá automaticamente após 8 horas","de":"Automatische Getriebesteuerung zum Energiesparen, schaltet sich nach 8 Stunden automatisch ab","ru":"Автоматическое управление передачей для экономии энергии, автоматическое отключение через 8 часов","vi":"Điều khiển bánh răng tự động để tiết kiệm năng lượng, sẽ tự động thoát sau 8 giờ","th":"การควบคุมเกียร์อัตโนมัติเพื่อประหยัดพลังงานจะหยุดโดยอัตโนมัติหลังจากผ่านไป 8 ชั่วโมง","id":"Kontrol roda gigi otomatis untuk menghemat energi, akan berhenti secara otomatis setelah 8 jam","zh-Hant":"自動節能檔位控制，8小時後自動退出。","zh-TW":"自動節能檔位控制，8小時後自動退出。","ar":"سيتم إنهاء التحكم التلقائي في التروس لتوفير الطاقة تلقائيًا بعد 8 ساعات","hu":"Automatikus sebességszabályozás az energiatakarékosság érdekében, 8 óra elteltével automatikusan kikapcsol.","el":"Αυτόματος έλεγχος ταχυτήτων για εξοικονόμηση ενέργειας, θα τερματιστεί αυτόματα μετά από 8 ώρες","nl":"Automatische versnelling om energie te besparen, stopt automatisch na 8 uur","pl":"Automatyczne sterowanie przekładnią w celu oszczędzania energii，wyłączy się automatycznie po 8 godzinach","fi":"Automaattinen vaihteenohjaus energian säästämiseksi, sammuu automaattisesti 8 tunnin kuluttua.","sv":"Automatisk växellåda för att spara energi ， avslutas automatiskt efter 8 timmar","km":"ការត្រួតពិនិត្យឧបករណ៍ស្វ័យប្រវត្តិដើម្បីសន្សំសំចៃថាមពល,នឹងឈប់ដោយស្វ័យប្រវត្តិបន្ទាប់ពី 8 ម៉ោង"},"The maximum value should be at least 24°C/75°F":{"en":"The maximum value should be at least 24°C/75°F","zh-Hans":"最高值需要高于24°C/75°F","fr":"La valeur maximale doit être d'au moins 24°C/75°F","ja":"最大値は少なくとも24℃/75°Fでなければなりません。","it":"Il valore massimo deve essere di almeno 24°C/75°F","es":"El valor máximo debe ser de al menos 24°C/75°F","pt":"O valor máximo deve ser de pelo menos 24°C/75°F","de":"Der Höchstwert sollte mindestens 24°C/75°F betragen.","ru":"Максимальное значение должно быть не менее 24°C/75°F","vi":"Giá trị tối đa ít nhất phải là 24°C/75°F","th":"ค่าสูงสุดควรอยู่ที่ 24°C/75°F เป็นอย่างน้อย","id":"Nilai maksimum setidaknya harus 24°C/75°F","zh-Hant":"最高值需要高於24°C/75°F","zh-TW":"最高值需要高於24°C/75°F","ar":"يجب ألا تقل القيمة القصوى عن 24 درجة مئوية / 75 درجة فهرنهايت","hu":"A maximális értéknek legalább 24°C/75°F-nek kell lennie.","el":"Η μέγιστη τιμή θα πρέπει να είναι τουλάχιστον 24°C/75°F","nl":"De maximumwaarde moet minstens 24°C/75°F zijn.","pl":"Maksymalna wartość powinna wynosić co najmniej 24°C/75°F","fi":"Enimmäisarvon on oltava vähintään 24°C/75°F.","sv":"Maxvärdet bör vara minst 24°C/75°F","km":"តម្លៃអតិបរមាគួរតែយ៉ាងហោចណាស់ 24°C/75°F"},"running successfully":{"en":"running successfully","zh-Hans":"运行成功","fr":"Une course réussie","ja":"成功した走り","it":"Corsa di successo","es":"Correr con éxito","pt":"Corrida bem sucedida","de":"Erfolgreicher Lauf","ru":"Успешная пробежка","vi":"chạy thành công","th":"ทำงานสำเร็จ","id":"berjalan dengan sukses","zh-Hant":"運行成功","zh-TW":"運行成功","ar":"يعمل بنجاح","hu":"sikeresen fut","el":"να λειτουργεί με επιτυχία","nl":"succesvol in werking","pl":"pomyślne uruchomienie","fi":"käynnissä onnistuneesti","sv":"körs framgångsrikt","km":"រត់ ដោយ ជោគជ័យ"},"running":{"en":"running","zh-Hans":"运行","fr":"Fonctionnement","ja":"ランニング","it":"Funzionamento","es":"En marcha","pt":"Funcionamento","de":"Laufend","ru":"Работа","vi":"chạy","th":"วิ่ง","id":"berlari","zh-Hant":"運行","zh-TW":"運行","ar":"جري","hu":"fut","el":"λειτουργία","nl":"draait","pl":"działa","fi":"käynnissä","sv":"igång","km":"រត់"},"Avoid Me is not available in current mode":{"en":"Avoid Me is not available in current mode","zh-Hans":"当前模式不支持上下防直吹。","fr":"Avoid Me n'est pas disponible dans le mode actuel","ja":"現在のモードではAvoid Meは使用できません。","it":"Evita Me non è disponibile nella modalità corrente","es":"Evitarme no está disponible en el modo actual","pt":"Esta função não está disponível no modo atual","de":"Avoid Me ist im aktuellen Modus nicht verfügbar","ru":"Функция Avoid Me недоступна в текущем режиме","vi":"Tránh tôi không khả dụng trong chế độ hiện tại","th":"หลีกเลี่ยงฉันไม่พร้อมใช้งานในโหมดปัจจุบัน","id":"Hindari Saya tidak tersedia dalam mode saat ini","zh-Hant":"當前模式不支持上下防直吹。","zh-TW":"當前模式不支持上下防直吹。","ar":"لا يتوفر Avoid Me في الوضع الحالي","hu":"Avoid Me nem áll rendelkezésre a jelenlegi üzemmódban","el":"Η επιλογή Avoid Me δεν είναι διαθέσιμη στην τρέχουσα λειτουργία","nl":"Vermijd mij is niet beschikbaar in de huidige modus","pl":"Funkcja Unikaj mnie nie jest dostępna w bieżącym trybie","fi":"Avoid Me ei ole käytettävissä nykyisessä tilassa.","sv":"Avoid Me är inte tillgängligt i aktuellt läge","km":"ជៀសវាងខ្ញុំមិនអាចប្រើបានក្នុងរបៀបបច្ចុប្បន្ន"},"Custom Dry is not available in current mode":{"en":"Custom Dry is not available in current mode","zh-Hans":"自定义烘干在当前模式下不可用","fr":"Le séchage personnalisé n'est pas disponible dans le mode actuel","ja":"現在のモードではカスタムドライは使用できません。","it":"L'asciugatura personalizzata non è disponibile nella modalità corrente","es":"Secado personalizado no está disponible en el modo actual","pt":"A secagem personalizada não está disponível no modo atual","de":"Custom Dry ist im aktuellen Modus nicht verfügbar","ru":"Функция Custom Dry недоступна в текущем режиме","vi":"Chế độ khô tùy chỉnh không khả dụng ở chế độ hiện tại","th":"Custom Dry ไม่สามารถใช้งานได้ในโหมดปัจจุบัน","id":"Custom Dry tidak tersedia dalam mode saat ini","zh-Hant":"自定義乾燥在當前模式下不可用","zh-TW":"自定義乾燥在當前模式下不可用","ar":"Custom Dry غير متوفر في الوضع الحالي","hu":"Az egyéni szárítás nem elérhető az aktuális üzemmódban","el":"Το Custom Dry δεν είναι διαθέσιμο στην τρέχουσα λειτουργία","nl":"Custom Dry is niet beschikbaar in de huidige modus","pl":"Funkcja Custom Dry nie jest dostępna w bieżącym trybie","fi":"Custom Dry ei ole käytettävissä nykyisessä tilassa","sv":"Custom Dry är inte tillgängligt i det aktuella läget","km":"ស្ងោរ ងាយៗ មិន អាច ប្រើ បាន ក្នុង របៀប បច្ចុប្បន្ន"},"Setting successful":{"en":"Setting successful","zh-Hans":"设置成功","fr":"Configurer avec succès","ja":"設定に成功しました","it":"Impostazione riuscita","es":"Configuración exitosa","pt":"Configuração com Sucesso","de":"Einstellung erfolgreich","ru":"Изменения приняты","vi":"Thiết lập thành công","th":"ตั้งค่าสำเร็จ","id":"Menetapkan Sukses","zh-Hant":"設定成功","zh-TW":"設定成功","ar":"مجموعة ناجحة","hu":"Sikeres beállítás","el":"Ρύθμιση επιτυχής","nl":"Instelling succesvol","pl":"Ustawienie powiodło się","fi":"Asetus onnistui","sv":"Inställningen lyckades","km":"ការកំណត់ជោគជ័យ"},"Please check your latest energy report.":{"en":"Please check your latest energy report.","zh-Hans":"请检查你最新的能源报告","fr":"Veuillez consulter votre dernier rapport sur l'énergie","ja":"最新のエネルギーレポートをご確認ください","it":"Controllare l'ultimo rapporto energetico","es":"Consulte su último informe energético","pt":"Verifique o seu último relatório de energia","de":"Bitte prüfen Sie Ihren aktuellen Energiebericht","ru":"Пожалуйста, проверьте свой последний энергетический отчет","vi":"Hãy kiểm tra báo cáo năng lượng mới nhất","th":"โปรดตรวจสอบรายงานพลังงานล่าสุดของคุณ","id":"Silakan periksa laporan energi terbaru Anda","zh-Hant":"請檢查妳最新的能源報告","zh-TW":"請檢查妳最新的能源報告","ar":"يرجى التحقق من أحدث تقرير الطاقة الخاص بك","hu":"Kérjük, ellenőrizze a legutóbbi energiajelentését","el":"Παρακαλούμε ελέγξτε την τελευταία αναφορά ενέργειας.","nl":"Controleer uw laatste energierapport.","pl":"Sprawdź najnowszy raport energetyczny.","fi":"Tarkista viimeisin energiaraportti.","sv":"Vänligen kontrollera din senaste energirapport.","km":"សូម ពិនិត្យ មើល របាយការណ៍ ថាមពល ចុងក្រោយ បំផុត របស់ អ្នក ។"},"2 choices can be selected at most. Please cancel one first.":{"en":"2 choices can be selected at most. Please cancel one first.","zh-Hans":"最多可以选择2个选项。 请先取消一个。","fr":"Jusqu'à 2 options peuvent être sélectionnées. Veuillez annuler l'une d'entre elles en premier.","ja":"オプションは2つまで選択できます。どちらかを先にキャンセルしてください。","it":"È possibile selezionare fino a 2 opzioni. Si prega di cancellarne prima una.","es":"Se pueden seleccionar hasta 2 opciones. Por favor, cancela una primero.","pt":"Podem ser seleccionadas até 2 opções. Por favor, cancele uma delas primeiro.","de":"Es können bis zu 2 Optionen ausgewählt werden. Bitte stornieren Sie zuerst eine.","ru":"Можно выбрать до 2 опций. Пожалуйста, сначала отмените один из них.","vi":"Nhiều nhất là 2 lựa chọn. Xin vui lòng hủy bỏ một.","th":"คุณสามารถเลือกได้ 2 ตัวเลือกกรุณายกเลิกก่อน","id":"Hingga 2 opsi dapat dipilih. Harap batalkan salah satu terlebih dahulu.","zh-Hant":"最多可以選擇2個選項。 請先取消壹個。","zh-TW":"最多可以選擇2個選項。 請先取消壹個。","ar":"يمكن اختيار خيارين على الأكثر. يرجى إلغاء واحد أولاً.","hu":"Legfeljebb 2 opció választható. Kérjük, először az egyiket törölje.","el":"Μπορούν να επιλεγούν το πολύ 2 επιλογές. Παρακαλούμε ακυρώστε πρώτα μία από αυτές.","nl":"Er kunnen maximaal 2 keuzes worden geselecteerd. Annuleer er eerst een.","pl":"Można wybrać maksymalnie 2 opcje. Najpierw anuluj jedną z nich.","fi":"Enintään 2 vaihtoehtoa voidaan valita. Peruuta toinen ensin.","sv":"2 alternativ kan väljas som mest. Vänligen avbryt ett först.","km":"២ ជម្រើសអាចជ្រើសរើសបានច្រើនបំផុត។ សូម លុប ចោល មួយ មុន សិន។"},"Target must be greater than 0":{"en":"Target must be greater than 0","zh-Hans":"目标必须大于 0","fr":"La cible doit être supérieure à 0","ja":"目標は0より大きくなければならない","it":"L'obiettivo deve essere maggiore di 0","es":"El objetivo debe ser mayor que 0","pt":"O objetivo deve ser superior a 0","de":"Das Ziel muss größer als 0 sein","ru":"Целевое значение должно быть больше 0","vi":"Mục tiêu phải lớn hơn 0","th":"เป้าหมายต้องสูงกว่า 0","id":"Target harus lebih besar dari 0","zh-Hant":"目標必須大於 0","zh-TW":"目標必須大於 0","ar":"يجب أن يكون الهدف أكبر من 0.","hu":"A célértéknek nagyobbnak kell lennie, mint 0","el":"Ο στόχος πρέπει να είναι μεγαλύτερος από 0","nl":"Doel moet groter zijn dan 0","pl":"Wartość docelowa musi być większa niż 0","fi":"Tavoitteen on oltava suurempi kuin 0","sv":"Målet måste vara större än 0","km":"គោលដៅត្រូវតែធំជាង 0"},"Boost can not be used under current mode":{"en":"Boost is not available in current mode","zh-Hans":"在当前模式下无法使用强劲功能","fr":"Des fonctions puissantes ne sont pas disponibles dans le mode actuel","ja":"現在のモードでは、強力な機能は使用できません","it":"Le funzioni più potenti non sono disponibili nella modalità corrente.","es":"Las funciones potentes no están disponibles en el modo actual","pt":"As funções poderosas não estão disponíveis no modo atual","de":"Leistungsstarke Funktionen sind im aktuellen Modus nicht verfügbar","ru":"Мощные функции недоступны в текущем режиме","vi":"Không thể sử dụng năng lượng mạnh trong chế độ hiện tại","th":"ไม่สามารถใช้การทำงาน ที่แข็งแกร่งในโหมดปัจจุบัน","id":"Fungsi yang kuat tidak tersedia dalam mode saat ini","zh-Hant":"在當前模式下無法使用強勁功能","zh-TW":"在當前模式下無法使用強勁功能","ar":"لا يمكن استخدام وظيفة قوية في النموذج الحالي","hu":"Az aktuális üzemmódban nem állnak rendelkezésre nagy teljesítményű funkciók","el":"Η ενίσχυση δεν είναι διαθέσιμη στην τρέχουσα λειτουργία","nl":"Boost is niet beschikbaar in huidige modus","pl":"Funkcja Boost nie jest dostępna w bieżącym trybie","fi":"Boost ei ole käytettävissä nykyisessä tilassa","sv":"Boost är inte tillgängligt i aktuellt läge","km":"Boost មិន អាច ប្រើ បាន ក្នុង របៀប បច្ចុប្បន្ន"},"Yes":{"en":"Yes","zh-Hans":"确定","fr":"D'accord","ja":"OK","it":"Ok","es":"Okay","pt":"Ok","de":"Ok","ru":"Да","vi":"Được","th":"ตกลง","id":"Oke","zh-Hant":"確定","zh-TW":"確定","ar":"موافق","hu":"Ok","el":"Ναι","nl":"Ja","pl":"Tak","fi":"Kyllä","sv":"Ja, det är det","km":"បាទ/ចាស"},"Keep the temperature at 46℉ and provide frost protection.":{"en":"Keep the temperature at 46℉ and provide frost protection.","zh-Hans":"温度保持在 46℉，并提供防冻保护。","fr":"Maintenir la température à 46℉ et assurer la protection contre le gel.","ja":"温度を46℉に保ち、霜保護を提供します。","it":"Mantiene la temperatura a 46℉ e fornisce una protezione antigelo.","es":"Mantiene la temperatura a 46℉ y proporciona protección contra heladas.","pt":"Mantenha a temperatura em 46 ℉ e forneça proteção contra congelamento.","de":"Halten Sie die Temperatur auf 46℉ und sorgen Sie für Frostschutz.","ru":"Поддерживайте температуру на уровне 46℉ и обеспечивайте защиту от замерзания.","vi":"Giữ nhiệt độ ở 46 ℉ và bảo vệ chống sương giá.","th":"รักษาอุณหภูมิไว้ที่ 46°F และป้องกันน้ำค้างแข็ง","id":"Menjaga suhu pada 46℉ dan memberikan perlindungan terhadap embun beku.","zh-Hant":"溫度保持在 46℉，並提供防凍保護。","zh-TW":"溫度保持在 46℉，並提供防凍保護。","ar":"يتم الحفاظ على درجة الحرارة عند 46 درجة فهرنهايت ويتم توفير الحماية من الصقيع.","hu":"A hőmérsékletet 46℉-on tartja, és fagyvédelmet biztosít.","el":"Διατήρηση της θερμοκρασίας στα 46℉ και παροχή προστασίας από τον παγετό.","nl":"Houd de temperatuur op 46℉ en zorg voor vorstbeveiliging.","pl":"Utrzymuj temperaturę na poziomie 46℉ i zapewnij ochronę przed mrozem.","fi":"Pitää lämpötilan 46℉:ssa ja antaa pakkassuojan.","sv":"Håll temperaturen på 46 ℉ och ge frostskydd.","km":"រក្សាសីតុណ្ហភាពនៅ 46°F និងផ្តល់នូវការការពារ frost។"},"Please connect to your home router":{"en":"Please connect to your home router","zh-Hans":"请连接您的家庭路由器","fr":"Veuillez vous connecter à votre routeur domestique","ja":"ご自宅のルーターに接続してください。","it":"Collegare il dispositivo al router di casa","es":"Conéctelo al router de su casa","pt":"Por favor, ligue-se ao seu router doméstico","de":"Bitte verbinden Sie das Gerät mit Ihrem Router zu Hause","ru":"Пожалуйста, подключитесь к домашнему маршрутизатору","vi":"Vui lòng kết nối với bộ định tuyến tại nhà của bạn","th":"โปรดเชื่อมต่อกับเราเตอร์ที่บ้านของคุณ","id":"Harap sambungkan ke router rumah Anda","zh-Hant":"請連接您的家庭路由器","zh-TW":"請連接您的家庭路由器","ar":"يرجى توصيل جهاز التوجيه المنزلي الخاص بك","hu":"Kérjük, csatlakoztassa otthoni routeréhez","el":"Παρακαλούμε συνδεθείτε στον οικιακό σας δρομολογητή","nl":"Maak verbinding met je thuisrouter","pl":"Połącz się z routerem domowym","fi":"Ole hyvä ja yhdistä kotireitittimeen","sv":"Anslut till din hemrouter","km":"សូម ភ្ជាប់ ទៅ router ផ្ទះ របស់ អ្នក"},"By connecting this device to the Internet you will be able to control your Air Conditioner when you are away from home. You will also gain access to additional features.":{"en":"By connecting this device to the Internet you will be able to control your Air Conditioner when you are away from home. You will also gain access to additional features.","zh-Hans":"通过连接到路由器，你不在家的时候也可以控制你的空调。你还可以获得更多的功能。","fr":"En connectant cet appareil à Internet, vous pourrez contrôler votre Climatiseur lorsque vous n'êtes pas chez vous. Vous aurez également accès à des fonctionnalités supplémentaires.","ja":"このデバイスをインターネットに接続することで、外出先からエアコンを制御することができます。また、追加機能にもアクセスできます。","it":"Collegando questo dispositivo a Internet, potrete controllare il vostro condizionatore d'aria quando siete fuori casa. Potrete inoltre accedere a funzioni aggiuntive.","es":"Al conectar este dispositivo a Internet podrá controlar su Aire Acondicionado cuando esté fuera de casa. También obtendrá acceso a funciones adicionales.","pt":"Ao ligar este dispositivo à Internet, poderá controlar o seu Ar Condicionado quando estiver fora de casa. Também terá acesso a funcionalidades adicionais.","de":"Wenn Sie dieses Gerät mit dem Internet verbinden, können Sie Ihre Klimaanlage steuern, wenn Sie nicht zu Hause sind. Außerdem erhalten Sie Zugang zu zusätzlichen Funktionen.","ru":"Подключив это устройство к Интернету, вы сможете управлять кондиционером, находясь вне дома. Кроме того, вы получите доступ к дополнительным функциям.","vi":"Bằng cách kết nối thiết bị này với Internet, bạn sẽ có thể điều khiển Máy điều hòa của mình khi bạn vắng nhà. Bạn cũng sẽ có quyền truy cập vào các tính năng bổ sung.","th":"เมื่อเชื่อมต่ออุปกรณ์นี้กับอินเทอร์เน็ต คุณจะสามารถควบคุมเครื่องปรับอากาศได้เมื่อคุณไม่อยู่บ้าน และยังสามารถเข้าถึงคุณสมบัติเพิ่มเติมได้อีกด้วย","id":"Dengan menghubungkan perangkat ini ke Internet, Anda akan dapat mengontrol Pendingin Udara saat Anda jauh dari rumah. Anda juga akan mendapatkan akses ke fitur tambahan.","zh-Hant":"透過連接到路由器，你不在家的時候也可以控制你的空調。 你還可以獲得更多的功能。","zh-TW":"透過連接到路由器，你不在家的時候也可以控制你的空調。 你還可以獲得更多的功能。","ar":"من خلال الاتصال بجهاز التوجيه الخاص بك، يمكنك التحكم في مكيف الهواء الخاص بك عندما لا تكون في المنزل. يمكنك أيضًا الحصول على المزيد من الميزات.","hu":"Ha ezt a készüléket csatlakoztatja az internethez, akkor is képes lesz vezérelni a légkondicionálóját, amikor nem tartózkodik otthon. Emellett további funkciókhoz is hozzáférhet.","el":"Με τη σύνδεση αυτής της συσκευής στο διαδίκτυο θα μπορείτε να ελέγχετε το κλιματιστικό σας όταν βρίσκεστε εκτός σπιτιού. Θα αποκτήσετε επίσης πρόσβαση σε πρόσθετες λειτουργίες.","nl":"Door dit apparaat met het internet te verbinden, kunt u uw airconditioner bedienen wanneer u niet thuis bent. U krijgt ook toegang tot extra functies.","pl":"Podłączenie tego urządzenia do Internetu umożliwi sterowanie klimatyzatorem poza domem. Uzyskasz również dostęp do dodatkowych funkcji.","fi":"Yhdistämällä tämän laitteen Internetiin voit ohjata ilmastointilaitetta, kun olet poissa kotoa. Saat myös käyttöön lisäominaisuuksia.","sv":"Genom att ansluta denna enhet till Internet kommer du att kunna styra din luftkonditionering när du är borta från hemmet. Du kommer också att få tillgång till ytterligare funktioner.","km":"ដោយ ភ្ជាប់ ឧបករណ៍ នេះ ទៅ អ៊ីនធឺណិត អ្នក នឹង អាច ត្រួត ពិនិត្យ ម៉ាស៊ីន ត្រជាក់ របស់ អ្នក នៅ ពេល ដែល អ្នក នៅ ឆ្ងាយ ពី ផ្ទះ ។ អ្នក ក៏ នឹង ទទួល បាន លក្ខណៈ ពិសេស បន្ថែម ផង ដែរ ។"},"ION":{"en":"ION","zh-Hans":"ION","fr":"ION","ja":"ION","it":"ION","es":"ION","pt":"ION","de":"ION","ru":"ION","vi":"ION","th":"ION","id":"ION","zh-Hant":"ION","zh-TW":"ION","ar":"ION","hu":"ION","el":"ION","nl":"ION","pl":"ION","fi":"ION","sv":"ION","km":"ION"},"Mshield":{"en":"Mshield","zh-Hans":"Mshield","fr":"Mshield","ja":"Mshield","it":"Mshield","es":"Mshield","pt":"Mshield","de":"Mshield","ru":"Mshield","vi":"Mshield","th":"Mshield","id":"Mshield","zh-Hant":"Mshield","zh-TW":"Mshield","ar":"Mshield","hu":"Mshield","el":"Mshield","nl":"Mshield","pl":"Mshield","fi":"Mshield","sv":"Mshield","km":"Mshield"},"Turn on":{"en":"Turn on","zh-Hans":"开启","fr":"Allumer","ja":"オン","it":"Accendere","es":"Encender","pt":"Ligar","de":"Einschalten","ru":"Включить","vi":"Bật","th":"เปิด","id":"Nyalakan","zh-Hant":"開","zh-TW":"開","ar":"يفتح","hu":"Kapcsolja be","el":"Ενεργοποίηση","nl":"Aanzetten","pl":"Włącz","fi":"Kytke päälle","sv":"Slå på","km":"បើក"},"Turn off":{"en":"Turn off","zh-Hans":"关闭","fr":"Désactiver","ja":"オフにする","it":"Spegnere","es":"Apagar","pt":"Desligar","de":"Ausschalten","ru":"Выключить","vi":"Tắt","th":"ปิด","id":"Matikan","zh-Hant":"關","zh-TW":"關","ar":"يغلق","hu":"Kikapcsolás","el":"Απενεργοποίηση","nl":"Uitschakelen","pl":"Wyłącz","fi":"Kytke pois päältä","sv":"Stäng av","km":"បិទ"},"I'm sorry, due to unstable network connection, not all faults were detected this time, and the number of undetected faults is:":{"en":"I'm sorry, due to unstable network connection, not all faults were detected this time, and the number of undetected faults is:","zh-Hans":"非常抱歉，由于网络连接不稳定，本次未能检测到所有故障，未检测到的故障数为：","fr":"Je suis désolé, en raison d'une connexion réseau instable, toutes les pannes n'ont pas été détectées cette fois-ci, et le nombre de pannes non détectées est :","ja":"申し訳ありませんが、ネットワーク接続が不安定であったため、今回すべての障害を検出できませんでした。検出されなかった障害の数は：","it":"Mi dispiace, a causa di una connessione di rete instabile, non tutti i guasti sono stati rilevati questa volta, e il numero di guasti non rilevati è:","es":"Lo siento, debido a una conexión de red inestable, no se detectaron todas las fallas esta vez, y el número de fallas no detectadas es:","pt":"Lamentamos muito, devido a uma conexão de rede instável, nem todas as falhas foram detectadas desta vez e o número de falhas não detectadas é:","de":"Es tut uns sehr leid, aufgrund einer instabilen Netzwerkverbindung konnten nicht alle Fehler dieses Mal erkannt werden und die Anzahl der nicht erkannten Fehler beträgt:","ru":"Извините, из-за нестабильного соединения сети не все сбои были обнаружены на этот раз, и количество необнаруженных сбоев составляет:","vi":"Rất xin lỗi, do kết nối mạng không ổn định, không phát hiện được tất cả các lỗi lần này và số lỗi chưa được phát hiện là:","th":"ขออภัยมากเนื่องจากการเชื่อมต่อเครือข่ายไม่เสถียรไม่สามารถตรวจสอบข้อผิดพลาดทั้งหมดได้ในครั้งนี้และจำนวนข้อผิดพลาดที่ไม่ตรวจพบคือ:","id":"Maaf, karena koneksi jaringan yang tidak stabil, tidak semua kesalahan terdeteksi kali ini, dan jumlah kesalahan yang tidak terdeteksi adalah:","zh-Hant":"非常抱歉，由於網絡連接不穩定，本次未能檢測到所有故障，未檢測到的故障數為：","zh-TW":"非常抱歉，由於網絡連接不穩定，本次未能檢測到所有故障，未檢測到的故障數為：","ar":"نعتذر، بسبب اتصال الشبكة غير المستقر، لم يتم الكشف عن جميع الأخطاء هذه المرة، وعدد الأخطاء غير المكتشفة هو:","hu":"Sajnálom, az instabil hálózati kapcsolat miatt nem minden hibát észleltek ebben az időben, és az észleletlen hibák száma:","el":"Λυπούμαστε πολύ, λόγω ασταθούς σύνδεσης δικτύου δεν ανιχνεύτηκαν όλα τα σφάλματα αυτή τη φορά και ο αριθμός των μη ανιχνευμένων σφαλμάτων είναι:","nl":"Onze excuses, vanwege een onstabiele netwerkverbinding zijn niet alle fouten gedetecteerd deze keer en het aantal niet-gedetecteerde fouten is:","pl":"Przepraszamy, ze względu na niestabilne połączenie sieciowe nie wszystkie błędy zostały wykryte tym razem, a liczba niewykrytych błędów wynosi:","fi":"Olemme pahoillamme, epävakaan verkkoyhteyden vuoksi kaikkia vikoja ei havaittu tällä kertaa ja havaitsemattomien vikojen määrä on:","sv":"Vi är mycket ledsna, på grund av en instabil nätverksanslutning upptäcktes inte alla fel den här gången och antalet oupptäckta fel är:","km":"ខ្ញុំ សូម អភ័យ ទោស ដោយសារ តែ ការ ត ភ្ជាប់ បណ្តាញ មិន មាន ស្ថេរ ភាព មិន មែន កំហុស ទាំង អស់ ត្រូវ បាន រក ឃើញ នៅ ពេល នេះ ទេ ហើយ ចំនួន កំហុស ដែល មិន បាន រក ឃើញ គឺ ៖"},"Get it":{"en":"Get it","zh-Hans":"我知道了","fr":"Obtenir","ja":"取得","it":"Recupera","es":"Compruébelo","pt":"Obter","de":"Holen Sie es","ru":"Получить","vi":"Hiểu rồi","th":"รับมัน","id":"Dapatkan itu.","zh-Hant":"得到它","zh-TW":"得到它","ar":"احصل عليه","hu":"Szerezd meg","el":"Πάρτε το","nl":"Ontvangen","pl":"Pobierz","fi":"Hae se","sv":"Hämta den","km":"យកវា"},"Check again":{"en":"Check again","zh-Hans":"重新检查","fr":"Vérifier à nouveau","ja":"再チェック","it":"Ricontrollare","es":"Comprobar de nuevo","pt":"Verificar novamente","de":"Erneut prüfen","ru":"Проверьте еще раз","vi":"Kiểm tra lại","th":"ตรวจสอบอีกครั้ง","id":"Periksa lagi","zh-Hant":"再檢查一遍","zh-TW":"再檢查一遍","ar":"تحقق مرة اخرى","hu":"Ellenőrizze újra","el":"Ελέγξτε ξανά","nl":"Opnieuw controleren","pl":"Sprawdź ponownie","fi":"Tarkista uudelleen","sv":"Kontrollera igen","km":"ពិនិត្យ មើល ម្តង ទៀត"},"I'm very sorry, due to unstable network connection, please check and try again. If the problem persists,":{"en":"I'm very sorry, due to unstable network connection, please check and try again. If the problem persists,","zh-Hans":"非常抱歉，由于网络连接不稳定，请检查后重新尝试。如果问题仍然存在，","fr":"Désolé, en raison d'une connexion réseau instable, veuillez vérifier et réessayer. Si le problème persiste,","ja":"申し訳ありませんが、ネットワーク接続が不安定なため、確認してから再度お試しください。問題が解決しない場合は、","it":"Spiacenti, a causa di una connessione di rete instabile, controllare e riprovare. Se il problema persiste,","es":"Lo siento mucho, debido a una conexión de red inestable, verifique y vuelva a intentarlo. Si el problema persiste,","pt":"Desculpe, devido a uma conexão de rede instável, verifique e tente novamente. Se o problema persistir,","de":"Es tut uns sehr leid, aufgrund einer instabilen Netzwerkverbindung überprüfen Sie bitte und versuchen Sie es erneut. Wenn das Problem weiterhin besteht,","ru":"Извините, из-за нестабильного сетевого подключения, проверьте и повторите попытку. Если проблема сохраняется,","vi":"Xin lỗi, do kết nối mạng không ổn định, vui lòng kiểm tra và thử lại. Nếu vấn đề vẫn còn tồn tại,","th":"ขออภัยมากเนื่องจากการเชื่อมต่อเครือข่ายไม่เสถียร โปรดตรวจสอบและลองอีกครั้ง หากปัญหายังคงอยู่","id":"Maaf, karena koneksi jaringan tidak stabil, silakan periksa dan coba lagi. Jika masalah masih ada,","zh-Hant":"非常抱歉，由於網絡連接不穩定，請檢查後重新嘗試。如果問題仍然存在，","zh-TW":"非常抱歉，由於網絡連接不穩定，請檢查後重新嘗試。如果問題仍然存在，","ar":"نعتذر، بسبب اتصال الشبكة غير المستقر، يرجى التحقق والمحاولة مرة أخرى. إذا استمرت المشكلة،","hu":"Sajnáljuk, az instabil hálózati kapcsolat miatt ellenőrizze és próbálja újra. Ha a probléma továbbra is fennáll,","el":"Λυπούμαστε πολύ, λόγω ασταθούς σύνδεσης δικτύου, παρακαλούμε ελέγξτε και δοκιμάστε ξανά. Εάν το πρόβλημα εξακολουθεί να υπάρχει,","nl":"Onze excuses, vanwege een instabiele netwerkverbinding, controleer en probeer opnieuw. Als het probleem aanhoudt,","pl":"Przepraszamy, ze względu na niestabilne połączenie sieciowe, sprawdź i spróbuj ponownie. Jeśli problem nadal występuje,","fi":"Olemme pahoillamme, epävakaan verkkoyhteyden vuoksi, tarkista ja yritä uudelleen. Jos ongelma jatkuu,","sv":"Vi är mycket ledsna, på grund av en instabil nätverksanslutning, kontrollera och försök igen. Om problemet kvarstår,","km":"សុំទោសណាស់ ព្រោះការភ្ជាប់បណ្តាញមិនស្ថេរ សូមពិនិត្យ និងសាកល្បងម្តងទៀត។ បើ បញ្ហា នៅ តែ បន្ត"},"Egyptian law requires that air conditioners have an adjustable temperature range of 20 to 28, and you will need to make changes to the Temp. Range .":{"en":"Due to law requires that air conditioners have an adjustable temperature range of 20 to 28, and you will need to make changes to the Temp. Range .","zh-Hans":"由于法律要求空调具有20到28的可调温度范围，您需要对温度范围进行更改。","fr":"En raison des exigences légales, la plage de température réglable de la climatisation doit être modifiée de 20 à 28 degrés.","ja":"法律により、エアコンの可変温度範囲を20℃から28℃に変更する必要があります。","it":"A causa delle normative, è necessario modificare la gamma di temperatura regolabile dell'aria condizionata da 20 a 28 gradi.","es":"Debido a los requisitos legales, es necesario cambiar el rango de temperatura ajustable del aire acondicionado de 20 a 28 grados.","pt":"Devido aos requisitos legais, é necessário alterar a faixa de temperatura ajustável do ar condicionado de 20 a 28 graus.","de":"Aufgrund gesetzlicher Anforderungen muss der einstellbare Temperaturbereich der Klimaanlage von 20 bis 28 Grad geändert werden.","ru":"В соответствии с требованиями закона необходимо изменить диапазон регулируемой температуры кондиционера с 20 до 28 градусов.","vi":"Do yêu cầu của pháp luật, bạn cần thay đổi phạm vi nhiệt độ có thể điều chỉnh của điều hòa từ 20 đến 28 độ.","th":"เนื่องจากข้อกำหนดของกฎหมาย คุณต้องเปลี่ยนช่วงอุณหภูมิที่สามารถปรับได้ของเครื่องปรับอากาศจาก 20 ถึง 28 องศา","id":"Karena persyaratan hukum, Anda perlu mengubah rentang suhu yang dapat diatur dari AC dari 20 hingga 28 derajat.","zh-Hant":"由於法律要求空調具有20到28的可調溫度範圍，您需要對溫度範圍進行更改。","zh-TW":"由於法律要求空調具有20到28的可調溫度範圍，您需要對溫度範圍進行更改。","ar":"نظرًا للمتطلبات القانونية، يجب تغيير نطاق درجة حرارة التكييف المتغير من 20 إلى 28 درجة.","hu":"Jogi követelmények miatt a légkondicionáló állítható hőmérsékleti tartományát 20 és 28 fok között kell módosítani.","el":"Λόγω νομικών απαιτήσεων, πρέπει να αλλάξετε το εύρος της ρυθμιζόμενης θερμοκρασίας του κλιματιστικού από 20 έως 28 βαθμούς.","nl":"Vanwege wettelijke vereisten moet het instelbare temperatuurbereik van de airconditioning worden gewijzigd van 20 tot 28 graden.","pl":"Zgodnie z wymaganiami prawnymi należy zmienić zakres regulowanej temperatury klimatyzacji z 20 do 28 stopni.","fi":"Lakisääteisten vaatimusten vuoksi ilmastointilaitteen säädettävä lämpötila-alue on muutettava 20–28 asteesta.","sv":"På grund av lagkrav måste det justerbara temperaturintervallet för luftkonditioneringen ändras från 20 till 28 grader.","km":"ដោយសារ ច្បាប់ តម្រូវ ឲ្យ ម៉ាស៊ីន ត្រជាក់ មាន កម្រិត សីតុណ្ហភាព អាច លៃ តម្រូវ បាន ពី ២០ ទៅ ២៨ ហើយ អ្នក នឹង ត្រូវ ធ្វើ ការ ផ្លាស់ ប្តូរ ទៅ កាន់ Temp។ Range ។"},"User Guide":{"en":"User Guide","zh-Hans":"电子说明书","fr":"Guide Utilisateur","ja":"電子説明書","it":"Guida utente","es":"Guía del usuario","pt":"Guia do Usuário","de":"Benutzerhandbuch","ru":"Руководство пользователя","vi":"Sách hướng dẫn điện tử","th":"หนังสืออธิบายอิเล็กทรอนิกส์","id":"Panduan Pengguna","zh-Hant":"電子說明書","zh-TW":"電子說明書","ar":"إرشادات APP","hu":"Felhasználói Kézikönyv","el":"Οδηγός χρήστη","nl":"Gebruikershandleiding","pl":"Podręcznik użytkownika","fi":"Käyttöopas","sv":"Användarhandbok","km":"មគ្គុទ្ទេសក៍អ្នកប្រើ"},"Service Request":{"en":"Service Request","zh-Hans":"报修服务","fr":"Demande de service","ja":"サービスリクエスト","it":"Richiesta di assistenza","es":"Solicitud de Servicio","pt":"Pedido de Serviço","de":"Service-Anfrage","ru":"Запрос на обслуживание","vi":"Yêu cầu dịch vụ","th":"คําขอบริการ","id":"Permintaan Layanan","zh-Hant":"報修服務","zh-TW":"報修服務","ar":"طلب خدمة","hu":"Szolgáltatáskérés","el":"Αίτημα υπηρεσιών","nl":"Service aanvraag","pl":"Zgłoszenie serwisowe","fi":"Palvelupyyntö","sv":"Serviceförfrågan","km":"សំណើសុំសេវាកម្ម"},"Troubleshooting":{"en":"Troubleshooting","zh-Hans":"故障自查","fr":"Dépannage","ja":"トラブルシューティング","it":"Risoluzione dei problemi","es":"Solución de Problemas","pt":"Resolução de problemas","de":"Fehlerbehebung","ru":"Поиск и устранение неисправностей","vi":"Tự kiểm tra lỗi","th":"แก้ไขปัญหา","id":"Pemecahan Masalah","zh-Hant":"故障自查","zh-TW":"故障自查","ar":"استكشاف الأخطاء وإصلاحها","hu":"Hibajavítás","el":"Αντιμετώπιση Προβλημάτων","nl":"Probleemoplossing","pl":"Rozwiązywanie problemów","fi":"Vianmääritys","sv":"Felsökning","km":"បញ្ហា"},"Contact Us":{"en":"Contact Us","zh-Hans":"联系我们","fr":"Nous contacter","ja":"お問い合わせ","it":"Contattaci","es":"Contáctanos","pt":"Contate-nos","de":"Kontakt","ru":"Свяжитесь с нами","vi":"Liên hệ chúng tôi","th":"ติดต่อเรา","id":"Hubungi kami","zh-Hant":"聯繫我們","zh-TW":"聯絡我們","ar":"اتصل بنا","hu":"Kapcsolatfelvétel","el":"Επικοινωνήστε μαζί μας","nl":"Contact met ons op","pl":"Kontakt","fi":"Ota meihin yhteyttä","sv":"Kontakta oss","km":"ទំនាក់ទំនងមកយើងខ្ញុំ"},"please contact us.":{"en":"Please Contact Us","zh-Hans":"请联系我们","fr":"Veuillez Nous contacter","ja":"お問い合わせ","it":"Per favore Contattaci","es":"Por favor Contáctanos","pt":"Por favor Contate-nos","de":"Bitte Kontakt","ru":"Пожалуйста Свяжитесь с нами","vi":"Làm ơn Liên hệ chúng tôi","th":"โปรด ติดต่อเรา","id":"Silakan Hubungi kami","zh-Hant":"請聯繫我們","zh-TW":"請聯繫我們","ar":"من فضلك اتصل بنا","hu":"Kérem Kapcsolatfelvétel","el":"Παρακαλώ Επικοινωνήστε μαζί μας","nl":"Alsjeblieft Contact met ons op","pl":"Proszę Kontakt","fi":"Ole hyvä Ota meihin yhteyttä","sv":"Snälla Kontakta oss","km":"សូមទំនាក់ទំនងមកយើងខ្ញុំ"},"NewBreezeAway":{"en":"Breeze Away","zh-Hans":"防直吹","fr":"Empêcher le soufflage direct","ja":"直接吹き付けを防ぐ","it":"Prevenire il soffiaggio diretto","es":"Prevenir el soplado directo","pt":"Brisa Distante","de":"Direktes Anblasen verhindern","ru":"Мягкое охлаждение","vi":"Phân phối luồng gió","th":"ป้องกันการเป่าโดยตรง","id":"Elakkan tiupan langsung","zh-Hant":"防直接吹風","zh-TW":"防直接吹風","ar":"منع النفخ المباشر","hu":"Megakadályozza a szélbe fújást","el":"Αντι άμεσο χτύπημα","nl":"Windje Weg","pl":"Breeze Away","fi":"Breeze Away","sv":"Breeze Borta","km":"Breeze Away"},"Setting End Conditions":{"en":"Setting End Conditions","zh-Hans":"设定结束条件","fr":"Définition des conditions de fin","ja":"終了条件の設定","it":"Impostazione delle condizioni di fine","es":"Establecimiento de las condiciones de finalización","pt":"Definição das condições de término","de":"Festlegung der Endbedingungen","ru":"Установка условий завершения","vi":"Thiết lập điều kiện kết thúc","th":"การตั้งเงื่อนไขสิ้นสุด","id":"Penetapan Kondisi Akhir","zh-Hant":"設定結束條件","zh-TW":"設定結束條件","ar":"تحديد شروط الانتهاء","hu":"Befejező feltételek beállítása","el":"Ορισμός των συνθηκών λήξης","nl":"Instellen van eindvoorwaarden","pl":"Ustawianie warunków zakończenia","fi":"Lopetusehtojen asettaminen","sv":"Inställning av slutvillkor","km":"ការកំណត់លក្ខខណ្ឌបញ្ចប់"},"FlashCool will turn off when the room temperature reaches the setpoint temperature or the running time reaches the set time. If neither is set, FlashCool will remain on.":{"en":"FlashCool will turn off when the room temperature reaches the setpoint temperature or the running time reaches the set time. If neither is set, FlashCool will remain on.","zh-Hans":"当室温达到设定温度或运行时间达到设定时间时，FlashCool将关闭。如果两者都未设置，FlashCool将保持打开状态。","fr":"FlashCool s'éteindra lorsque la température de la pièce atteindra la température de consigne ou que le temps de fonctionnement atteindra le temps défini. Si aucun n'est défini, FlashCool restera allumé.","ja":"設定温度に到達するか、設定時間が経過すると、FlashCoolはオフになります。どちらも設定されていない場合、FlashCoolはオンのままです。","it":"FlashCool si spegnerà quando la temperatura della stanza raggiunge la temperatura impostata o il tempo di funzionamento raggiunge il tempo impostato. Se nessuno dei due è impostato, FlashCool rimarrà acceso.","es":"FlashCool se apagará cuando la temperatura de la habitación alcance la temperatura de consigna o el tiempo de funcionamiento alcance el tiempo establecido. Si no se establece ninguno de los dos, FlashCool permanecerá encendido.","pt":"FlashCool desligará quando a temperatura da sala atingir a temperatura definida ou o tempo de funcionamento atingir o tempo definido. Se nenhum deles estiver definido, FlashCool permanecerá ligado.","de":"FlashCool wird ausgeschaltet, wenn die Raumtemperatur die Solltemperatur erreicht oder die Laufzeit die eingestellte Zeit erreicht hat. Wenn keine der beiden eingestellt ist, bleibt FlashCool eingeschaltet.","ru":"FlashCool отключится, когда температура в комнате достигнет заданной температуры или время работы достигнет заданного времени. Если ни то, ни другое не установлено, FlashCool останется включенным.","vi":"FlashCool sẽ tắt khi nhiệt độ phòng đạt nhiệt độ đặt hoặc thời gian chạy đạt thời gian đặt. Nếu không có gì được đặt, FlashCool sẽ vẫn bật.","th":"FlashCool จะปิดเมื่ออุณหภูมิห้องถึงอุณหภูมิที่กำหนดหรือเวลาการทำงานถึงเวลาที่กำหนด หากไม่มีการตั้งค่าเลย FlashCool จะยังคงเปิดอยู่","id":"FlashCool akan mati ketika suhu ruangan mencapai suhu setpoint atau waktu berjalan mencapai waktu yang ditetapkan. Jika tidak ada yang diatur, FlashCool akan tetap menyala.","zh-Hant":"當房間溫度達到設定溫度或運行時間達到設定時間時，FlashCool將關閉。如果都沒有設置，FlashCool將保持開啟。","zh-TW":"當房間溫度達到設定溫度或運行時間達到設定時間時，FlashCool將關閉。如果都沒有設置，FlashCool將保持開啟。","ar":"سيتم إيقاف FlashCool عندما تصل درجة حرارة الغرفة إلى درجة الحرارة المحددة أو يصل وقت التشغيل إلى الوقت المحدد. إذا لم يتم تعيين أي منهما ، فستظل FlashCool قيد التشغيل.","hu":"A FlashCool kikapcsolódik, ha a szobahőmérséklet eléri a beállított hőmérsékletet, vagy a futási idő eléri a beállított időt. Ha egyik sem van beállítva, a FlashCool bekapcsolva marad.","el":"Το FlashCool θα απενεργοποιηθεί όταν η θερμοκρασία του δωματίου φτάσει στην θερμοκρασία στόχο ή ο χρόνος λειτουργίας φτάσει στον καθορισμένο χρόνο. Εάν κανένα από τα δύο δεν έχει οριστεί, το FlashCool θα παραμείνει ενεργοποιημένο.","nl":"FlashCool wordt uitgeschakeld wanneer de kamertemperatuur de ingestelde temperatuur bereikt of de looptijd de ingestelde tijd bereikt. Als geen van beide is ingesteld, blijft FlashCool aan.","pl":"FlashCool zostanie wyłączony, gdy temperatura w pokoju osiągnie ustawioną temperaturę lub czas pracy osiągnie ustawiony czas. Jeśli żaden z nich nie jest ustawiony, FlashCool pozostanie włączony.","fi":"FlashCool sammuu, kun huoneen lämpötila saavuttaa asetetun lämpötilan tai käyttöaika saavuttaa asetetun ajan. Jos kumpaakaan ei ole asetettu, FlashCool pysyy päällä.","sv":"FlashCool stängs av när rumstemperaturen når inställd temperatur eller drifttiden når inställd tid. Om ingen av dem är inställda förblir FlashCool påslagen.","km":"FlashCool នឹង បិទ នៅ ពេល សីតុណ្ហភាព បន្ទប់ ឈាន ដល់ សីតុណ្ហភាព ចំណុច កំណត់ ឬ ពេល វេលា រត់ ទៅ ដល់ ពេល វេលា ដែល បាន កំណត់ ។ ប្រសិន បើ គ្មាន អ្វី ត្រូវ បាន កំណត់ FlashCool នឹង នៅ តែ បន្ត ។"},"min":{"en":"min","zh-Hans":"最小","fr":"min","ja":"最小","it":"minimo","es":"minimo","pt":"minimo","de":"min","ru":"мин","vi":"tối thiểu","th":"น้อยที่สุด","id":"min","zh-Hant":"最小","zh-TW":"最小","ar":"الحد الأدنى","hu":"min","el":"ελάχιστο","nl":"min","pl":"min","fi":"min","sv":"min","km":"min"},"Not Set":{"en":"Not Set","zh-Hans":"未设置","fr":"Non défini","ja":"未設定","it":"Non impostato","es":"No establecido","pt":"Não definido","de":"Nicht festgelegt","ru":"Не установлено","vi":"Chưa được thiết lập","th":"ไม่ได้ตั้งค่า","id":"Tidak Diatur","zh-Hant":"未設置","zh-TW":"未設置","ar":"غير محدد","hu":"Nincs beállítva","el":"Δεν έχει οριστεί","nl":"Niet ingesteld","pl":"Nie ustawiono","fi":"Ei asetettu","sv":"Inte inställt","km":"មិនកំណត់"},"Reach setpoint temperature faster while in cooling mode.":{"en":"Reach setpoint temperature faster while in cooling mode.","zh-Hans":"在制冷模式下，更快地达到设定点温度。","fr":"Atteindre plus rapidement la température de consigne en mode de refroidissement.","ja":"冷房モードで設定温度により速く到達します。","it":"Raggiungere più rapidamente la temperatura di consigna in modalità di raffreddamento.","es":"Alcanzar la temperatura de consigna más rápido en modo de enfriamiento.","pt":"Alcançar a temperatura de consigna mais rapidamente no modo de resfriamento.","de":"Erreichen Sie die Solltemperatur schneller im Kühlmodus.","ru":"Достигать заданной температуры быстрее в режиме охлаждения.","vi":"Đạt nhiệt độ đặt nhanh hơn trong chế độ làm mát.","th":"เร่งการไปยังอุณหภูมิตั้งค่าได้อย่างรวดเร็วขึ้นในโหมดการทำความเย็น","id":"Mencapai suhu setpoint lebih cepat saat dalam mode pendinginan.","zh-Hant":"在冷卻模式下更快達到設定溫度。","zh-TW":"在冷卻模式下更快達到設定溫度。","ar":"الوصول إلى درجة الحرارة المحددة بشكل أسرع أثناء وضع التبريد.","hu":"Gyorsabban elérheti a beállított hőmérsékletet hűtési módban.","el":"Επιτυγχάνετε τη θερμοκρασία στόχο πιο γρήγορα κατά τη λειτουργία ψύξης.","nl":"Sneller de ingestelde temperatuur bereiken in koelmodus.","pl":"Szybsze osiągnięcie temperatury zadanej w trybie chłodzenia.","fi":"Saavuta asetettu lämpötila nopeammin jäähdytystilassa.","sv":"Nå inställd temperatur snabbare i kylningläge.","km":"១. ឈានដល់កម្រិតសីតុណ្ហភាព setpoint លឿនជាងមុនខណៈពេលក្នុងរបៀបត្រជាក់។"},"Filter Management":{"en":"Filter Management","zh-Hans":"滤网功能","fr":"Gestion des filtres","ja":"フィルター管理","it":"Gestione del filtro","es":"Gestión de filtros","pt":"Gerenciamento de filtro","de":"Filtermanagement","ru":"Управление фильтрами","vi":"Quản lý bộ lọc","th":"การจัดการฟิลเตอร์","id":"Manajemen Filter","zh-Hant":"濾網管理","zh-TW":"濾網管理","ar":"إدارة الفلاتر","hu":"Szűrőkezelés","el":"Διαχείριση φίλτρων","nl":"Filterbeheer","pl":"Zarządzanie filtrem","fi":"Suodattimen hallinta","sv":"Filterhantering","km":"ការគ្រប់គ្រងតម្រង"},"Operation Monitor":{"en":"Operation Monitor","zh-Hans":"运行可视化","fr":"Moniteur d'opération","ja":"操作モニター","it":"Monitoraggio operativo","es":"Monitor de operación","pt":"Monitor de operação","de":"Betriebsüberwachung","ru":"Мониторинг операций","vi":"Máy giám sát hoạt động","th":"ตัวควบคุมการทำงาน","id":"Pemantauan Operasi","zh-Hant":"操作監控","zh-TW":"操作監控","ar":"مراقبة العمليات","hu":"Műveleti monitor","el":"Παρακολούθηση λειτουργίας","nl":"Bedrijfsmonitor","pl":"Monitorowanie operacji","fi":"Toimintavalvonta","sv":"Driftsövervakning","km":"ការត្រួតពិនិត្យប្រតិបត្តិការ"},"On Time":{"en":"On Time","zh-Hans":"在线时长","fr":"Temps de démarrage","ja":"起動時間","it":"Tempo di avvio","es":"Tiempo de encendido","pt":"Tempo de inicialização","de":"Startzeit","ru":"Время запуска","vi":"Thời gian khởi động","th":"เวลาเปิดเครื่อง","id":"Waktu booting","zh-Hant":"開機時間","zh-TW":"開機時間","ar":"وقت التشغيل","hu":"Indítási idő","el":"Χρόνος εκκίνησης","nl":"Opstarttijd","pl":"Czas uruchamiania","fi":"Käynnistysaika","sv":"Starttid","km":"ពេល វេលា"},"Statistics for the last 7 days only":{"en":"Statistics for the last 7 days only","zh-Hans":"仅过去7天的统计数据","fr":"Statistiques pour les 7 derniers jours seulement","ja":"過去7日間の統計のみ","it":"Solo statistiche degli ultimi 7 giorni","es":"Estadísticas solo de los últimos 7 días","pt":"Estatísticas apenas dos últimos 7 dias","de":"Statistiken nur für die letzten 7 Tage","ru":"Статистика только за последние 7 дней","vi":"Thống kê chỉ trong vòng 7 ngày qua","th":"สถิติเฉพาะเพียง 7 วันที่ผ่านมาเท่านั้น","id":"Statistik hanya untuk 7 hari terakhir","zh-Hant":"僅顯示過去7天的統計","zh-TW":"僅顯示過去7天的統計","ar":"إحصائيات فقط لآخر 7 أيام","hu":"Statisztika csak az utolsó 7 napra vonatkozóan","el":"Στατιστικά μόνο για τις τελευταίες 7 ημέρες","nl":"Alleen statistieken voor de laatste 7 dagen","pl":"Statystyki tylko za ostatnie 7 dni","fi":"Tilastot vain viimeisestä 7 päivästä","sv":"Statistik endast för de senaste 7 dagarna","km":"ស្ថិតិរយៈពេល 7 ថ្ងៃចុងក្រោយតែប៉ុណ្ណោះ"},"Note":{"en":"Note","zh-Hans":"注意","fr":"Attention","ja":"注意","it":"Attenzione","es":"Atención","pt":"Atenção","de":"Achtung","ru":"Внимание","vi":"Chú ý","th":"โปรดทราบ","id":"Perhatian","zh-Hant":"注意","zh-TW":"注意","ar":"تنبيه","hu":"Figyelem","el":"Προσοχή","nl":"Let op","pl":"Uwaga","fi":"Huomio","sv":"Uppmärksamhet","km":"ចំណាំ"},"Monitoring the device usage is only possible if the device is online.":{"en":"Monitoring the device usage is only possible if the device is online.","zh-Hans":"只有当设备处于联机状态时，才能监视设备的使用情况。","fr":"La surveillance de l'utilisation de l'appareil n'est possible que si l'appareil est en ligne.","ja":"デバイスの使用状況を監視するには、デバイスがオンラインである必要があります。","it":"Il monitoraggio dell'utilizzo del dispositivo è possibile solo se il dispositivo è online.","es":"El monitoreo del uso del dispositivo solo es posible si el dispositivo está en línea.","pt":"A monitorização do uso do dispositivo só é possível se o dispositivo estiver online.","de":"Die Überwachung der Gerätenutzung ist nur möglich, wenn das Gerät online ist.","ru":"Мониторинг использования устройства возможен только при наличии подключения к Интернету.","vi":"Theo dõi việc sử dụng thiết bị chỉ có thể thực hiện nếu thiết bị đó đang trực tuyến.","th":"การตรวจสอบการใช้งานอุปกรณ์เป็นเรื่องที่เป็นไปได้เฉพาะเมื่ออุปกรณ์ออนไลน์","id":"Pemantauan penggunaan perangkat hanya mungkin dilakukan jika perangkat dalam keadaan online.","zh-Hant":"只有设备在线才能监控设备使用情况。","zh-TW":"只有设备在线才能监控设备使用情况。","ar":"يمكن مراقبة استخدام الجهاز فقط إذا كان الجهاز متصلاً بالإنترنت.","hu":"Az eszköz használatának ellenőrzése csak akkor lehetséges, ha az eszköz online állapotban van.","el":"Η παρακολούθηση της χρήσης της συσκευής είναι δυνατή μόνο εάν η συσκευή είναι σε σύνδεση.","nl":"Het monitoren van het apparaatgebruik is alleen mogelijk als het apparaat online is.","pl":"Monitorowanie korzystania z urządzenia jest możliwe tylko wtedy, gdy urządzenie jest online.","fi":"Laitteen käytön valvonta on mahdollista vain, jos laite on verkossa.","sv":"Övervakning av enhetsanvändning är endast möjlig om enheten är online.","km":"ការ ត្រួតពិនិត្យ ការ ប្រើ ឧបករណ៍ គឺ អាច ធ្វើ បាន តែ បើ ឧបករណ៍ នេះ មាន នៅ លើ បណ្ដាញ ប៉ុណ្ណោះ ។"},"Temperature & Humidity":{"en":"Temperature & Humidity","zh-Hans":"温度和湿度","fr":"Température et humidité","ja":"温度と湿度","it":"Temperatura e umidità","es":"Temperatura y humedad","pt":"Temperatura e umidade","de":"Temperatur und Luftfeuchtigkeit","ru":"Температура и влажность","vi":"Nhiệt độ và độ ẩm","th":"อุณหภูมิและความชื้น","id":"Suhu dan Kelembaban","zh-Hant":"温度和湿度","zh-TW":"溫度和濕度","ar":"درجة الحرارة والرطوبة","hu":"Hőmérséklet és páratartalom","el":"Θερμοκρασία και υγρασία","nl":"Temperatuur en vochtigheid","pl":"Temperatura i wilgotność","fi":"Lämpötila ja kosteus","sv":"Temperatur och luftfuktighet","km":"សីតុណ្ហភាព & សំណើម"},"Statistics for the last 7 days only.":{"en":"Statistics for the last 7 days only.","zh-Hans":"仅过去7天的统计数据。","fr":"Statistiques pour les 7 derniers jours seulement.","ja":"過去7日間の統計のみ。","it":"Solo statistiche degli ultimi 7 giorni.","es":"Estadísticas solo de los últimos 7 días.","pt":"Estatísticas apenas dos últimos 7 dias.","de":"Statistiken nur für die letzten 7 Tage.","ru":"Статистика только за последние 7 дней.","vi":"Thống kê chỉ trong vòng 7 ngày qua.","th":"สถิติเฉพาะเพียง 7 วันที่ผ่านมาเท่านั้น。","id":"Statistik hanya untuk 7 hari terakhir.","zh-Hant":"僅顯示過去7天的統計。","zh-TW":"僅顯示過去7天的統計。","ar":"إحصائيات فقط لآخر 7 أيام.","hu":"Statisztika csak az utolsó 7 napra vonatkozóan.","el":"Στατιστικά μόνο για τις τελευταίες 7 ημέρες.","nl":"Alleen statistieken voor de laatste 7 dagen.","pl":"Statystyki tylko za ostatnie 7 dni.","fi":"Tilastot vain viimeisestä 7 päivästä.","sv":"Statistik endast för de senaste 7 dagarna.","km":"ស្ថិតិរយៈពេល 7 ថ្ងៃចុងក្រោយតែប៉ុណ្ណោះ។"},"Outdoor temperature and humidity are interfaced with third-party weather services.":{"en":"Outdoor temperature and humidity are interfaced with third-party weather services.","zh-Hans":"室外温度和湿度与第三方气象服务接口。","fr":"La température et l'humidité extérieures sont interfacées avec des services météorologiques tiers.","ja":"屋外の温度と湿度は第三者の天気サービスと接続されます。","it":"La temperatura e l'umidità esterne sono interfacciate con servizi meteorologici di terze parti.","es":"La temperatura y la humedad exteriores se interfazan con servicios meteorológicos de terceros.","pt":"A temperatura e a umidade externas são conectadas a serviços meteorológicos de terceiros.","de":"Die Außentemperatur und Luftfeuchtigkeit sind mit Wetterdiensten von Drittanbietern verbunden.","ru":"Температура и влажность на улице связаны с сервисами погоды третьих сторон.","vi":"Nhiệt độ và độ ẩm bên ngoài được kết nối với các dịch vụ thời tiết của bên thứ ba.","th":"อุณหภูมิและความชื้นข้างนอกถูกเชื่อมต่อกับบริการพยากรณ์อากาศบุคคลที่สาม","id":"Suhu dan kelembaban luar ruangan dihubungkan dengan layanan cuaca pihak ketiga.","zh-Hant":"室外温度和湿度与第三方天气服务相连。","zh-TW":"室外溫度和濕度與第三方天氣服務相連。","ar":"درجة الحرارة والرطوبة في الهواء الخارجي متصلة بخدمات الطقس من جهات خارجية.","hu":"Az outdoor hőmérséklet és páratartalom harmadik fél időjárási szolgáltatásokkal van interfészként összekapcsolva.","el":"Η εξωτερική θερμοκρασία και υγρασία συνδέονται με υπηρεσίες καιρού τρίτων.","nl":"De buitentemperatuur en luchtvochtigheid zijn gekoppeld aan weerdiensten van derden.","pl":"Temperatura i wilgotność na zewnątrz są połączone z usługami pogodowymi firm trzecich.","fi":"Ulkoilman lämpötila ja kosteus on yhdistetty kolmannen osapuolen sääpalveluihin.","sv":"Utomhustemperaturen och luftfuktigheten är gränssnittade med tredjeparts väder tjänster.","km":"សីតុណ្ហភាព នៅ ខាង ក្រៅ និង សំណើម ត្រូវ បាន តភ្ជាប់ ជាមួយ សេវា អាកាស ធាតុ ភាគី ទី បី ។"},"Temperature and humidity values are only estimates and may vary.":{"en":"Temperature and humidity values are only estimates and may vary.","zh-Hans":"温度和湿度值仅为估计值，可能会有所不同。","fr":"Les valeurs de température et d'humidité ne sont que des estimations et peuvent varier.","ja":"温度と湿度の値は推定値であり、異なる場合があります。","it":"I valori di temperatura e umidità sono solo stime e possono variare.","es":"Los valores de temperatura y humedad son solo estimaciones y pueden variar.","pt":"Os valores de temperatura e umidade são apenas estimativas e podem variar.","de":"Die Temperatur- und Feuchtigkeitswerte sind nur Schätzungen und können variieren.","ru":"Значения температуры и влажности являются только оценочными и могут отличаться.","vi":"Các giá trị nhiệt độ và độ ẩm chỉ là ước tính và có thể thay đổi.","th":"ค่าอุณหภูมิและความชื้นเป็นการประมาณเท่านั้นและอาจแตกต่างกันได้","id":"Nilai suhu dan kelembaban hanya perkiraan dan dapat bervariasi.","zh-Hant":"温度和湿度值仅为估计值，可能会有所不同。","zh-TW":"溫度和濕度值僅為估計值，可能會有所不同。","ar":"قيم درجة الحرارة والرطوبة هي تقديرات فقط وقد تختلف.","hu":"A hőmérséklet- és páratartalom-értékek csak becslések és változhatnak.","el":"Οι τιμές θερμοκρασίας και υγρασίας είναι μόνο εκτιμήσεις και μπορεί να διαφέρουν.","nl":"Temperatuur- en vochtigheidswaarden zijn slechts schattingen en kunnen variëren.","pl":"Wartości temperatury i wilgotności są tylko szacunkowe i mogą się różnić.","fi":"Lämpötila- ja kosteusarvot ovat vain arvioita ja voivat vaihdella.","sv":"Temperatur- och fuktighetsvärden är endast uppskattningar och kan variera.","km":"តម្លៃ សីតុណ្ហភាព និង សំណើម គឺ គ្រាន់ តែ ជា ការ ប៉ាន់ ស្មាន ប៉ុណ្ណោះ ហើយ អាច ប្រែប្រួល ។"},"Target Temp.":{"en":"Target Temp.","zh-Hans":"目标温度","fr":"Température cible","ja":"目標温度","it":"Temperatura obiettivo","es":"Temperatura objetivo","pt":"Temperatura alvo","de":"Zieltemperatur","ru":"Целевая температура","vi":"Nhiệt độ mục tiêu","th":"อุณหภูมิเป้าหมาย","id":"Suhu target","zh-Hant":"目标温度","zh-TW":"目標溫度","ar":"درجة الحرارة المستهدفة","hu":"Céltartam hőmérséklet","el":"Στόχος θερμοκρασίας","nl":"Doeltemperatuur","pl":"Temperatura docelowa","fi":"Tavoitelämpötila","sv":"Målstemperatur","km":"គោលដៅ Temp."},"Indoor Temp.":{"en":"Indoor Temp.","zh-Hans":"室内温度","fr":"Température intérieure","ja":"室内温度","it":"Temperatura interna","es":"Temperatura interior","pt":"Temperatura interna","de":"Innentemperatur","ru":"Температура внутри помещения","vi":"Nhiệt độ trong nhà","th":"อุณหภูมิภายในอาคาร","id":"Suhu dalam ruangan","zh-Hant":"室內溫度","zh-TW":"室內溫度","ar":"درجة حرارة داخلية","hu":"Belső hőmérséklet","el":"Εσωτερική θερμοκρασία","nl":"Binnentemperatuur","pl":"Temperatura wewnątrz","fi":"Sisälämpötila","sv":"Inomhustemperatur","km":"Indoor Temp."},"Outdoor Temp.":{"en":"Outdoor Temp.","zh-Hans":"室外温度","fr":"Température extérieure","ja":"屋外温度","it":"Temperatura esterna","es":"Temperatura exterior","pt":"Temperatura exterior","de":"Außentemperatur","ru":"Температура на улице","vi":"Nhiệt độ ngoài trời","th":"อุณหภูมิภายนอก","id":"Suhu luar ruangan","zh-Hant":"室外温度","zh-TW":"室外溫度","ar":"درجة حرارة خارجية","hu":"Kültéri hőmérséklet","el":"Θερμοκρασία εξωτερικού χώρου","nl":"Buitentemperatuur","pl":"Temperatura na zewnątrz","fi":"Ulkoilman lämpötila","sv":"Utomhustemperatur","km":"ខាងក្រៅ Temp."},"Target humidity":{"en":"Target humidity","zh-Hans":"目标湿度","fr":"Humidité cible","ja":"目標湿度","it":"Umidità obiettivo","es":"Humedad objetivo","pt":"Umidade alvo","de":"Ziel-Luftfeuchtigkeit","ru":"Целевая влажность","vi":"Độ ẩm mục tiêu","th":"ความชื้นเป้าหมาย","id":"Kelembapan target","zh-Hant":"目标湿度","zh-TW":"目標濕度","ar":"الرطوبة المستهدفة","hu":"Cél páratartalom","el":"Στόχος υγρασίας","nl":"Doel-luchtvochtigheid","pl":"Docelowa wilgotność","fi":"Tavoite kosteus","sv":"Målvärde för luftfuktighet","km":"សំណើមគោលដៅ"},"Room humidity":{"en":"Room humidity","zh-Hans":"房间湿度","fr":"Humidité de la pièce","ja":"室内湿度","it":"Umidità della stanza","es":"Humedad de la habitación","pt":"Umidade do quarto","de":"Luftfeuchtigkeit im Raum","ru":"Влажность в комнате","vi":"Độ ẩm trong phòng","th":"ความชื้นในห้อง","id":"Kelembapan ruangan","zh-Hant":"室内湿度","zh-TW":"室內濕度","ar":"رطوبة الغرفة","hu":"Szobai páratartalom","el":"Υγρασία δωματίου","nl":"Luchtvochtigheid in de kamer","pl":"Wilgotność w pomieszczeniu","fi":"Huoneen kosteus","sv":"Luftfuktighet i rummet","km":"សំណើមបន្ទប់"},"Outdoor humidity":{"en":"Outdoor humidity","zh-Hans":"室外湿度","fr":"Humidité extérieure","ja":"屋外湿度","it":"Umidità esterna","es":"Humedad exterior","pt":"Umidade externa","de":"Luftfeuchtigkeit im Freien","ru":"Влажность на улице","vi":"Độ ẩm ngoài trời","th":"ความชื้นภายนอก","id":"Kelembapan luar ruangan","zh-Hant":"室外湿度","zh-TW":"室外濕度","ar":"رطوبة الهواء الخارجي","hu":"Kültéri páratartalom","el":"Υγρασία εξωτερικού χώρου","nl":"Luchtvochtigheid buiten","pl":"Wilgotność na zewnątrz","fi":"Ulkoilman kosteus","sv":"Luftfuktighet utomhus","km":"សំណើមខាងក្រៅ"},"h":{"en":"h","zh-Hans":"h","fr":"h","ja":"h","it":"h","es":"h","pt":"h","de":"h","ru":"h","vi":"h","th":"h","id":"h","zh-Hant":"h","zh-TW":"h","ar":"h","hu":"h","el":"h","nl":"h","pl":"h","fi":"h","sv":"h","km":"h"},"Remaining":{"en":"Remaining","zh-Hans":"剩余","fr":"Restant","ja":"残り","it":"Rimanente","es":"Restante","pt":"Restante","de":"Verbleibend","ru":"Осталось","vi":"Còn lại","th":"ที่เหลืออยู่","id":"Sisa","zh-Hant":"剩餘","zh-TW":"剩餘","ar":"متبقي","hu":"Hátralévő","el":"Υπόλοιπο","nl":"Overgebleven","pl":"Pozostało","fi":"Jäljellä","sv":"Kvarstående","km":"នៅ សល់"},"Filter Life:":{"en":"Filter Life:","zh-Hans":"滤网寿命","fr":"Durée de vie du filtre","ja":"フィルター寿命","it":"Durata del filtro","es":"Vida útil del filtro","pt":"Vida útil do filtro","de":"Filterlebensdauer","ru":"Время работы фильтра","vi":"Thời gian sử dụng bộ lọc","th":"อายุการใช้งานตัวกรอง","id":"Umur filter","zh-Hant":"濾網壽命","zh-TW":"濾網壽命","ar":"عمر الفلتر","hu":"Szűrőélettartam","el":"Διάρκεια ζωής φίλτρου","nl":"Filterlevensduur","pl":"Żywotność filtra","fi":"Suodattimen käyttöikä","sv":"Filterlivslängd","km":"ជីវិតតម្រង:"},"After cleaning the filter, tap on “Filter Reset” to restart the counter.":{"en":"After cleaning the filter, tap on “Filter Reset” to restart the counter.","zh-Hans":"清洁滤网后，点击“过滤器重置”以重新启动计数器。","fr":"Après avoir nettoyé le filtre, appuyez sur \"Réinitialiser le filtre\" pour redémarrer le compteur.","ja":"フィルターを清掃した後、「フィルターリセット」をタップしてカウンターをリスタートしてください。","it":"Dopo la pulizia del filtro, toccare \"Reset filtro\" per riavviare il contatore.","es":"Después de limpiar el filtro, toque \"Restablecer filtro\" para reiniciar el contador.","pt":"Após a limpeza do filtro, toque em \"Redefinir filtro\" para reiniciar o contador.","de":"Nach der Reinigung des Filters tippen Sie auf \"Filter zurücksetzen\", um den Zähler neu zu starten.","ru":"После очистки фильтра нажмите на \"Сбросить фильтр\", чтобы перезапустить счетчик.","vi":"Sau khi vệ sinh bộ lọc, nhấn vào \"Đặt lại bộ lọc\" để khởi động lại bộ đếm.","th":"หลังจากทำความสะอาดตัวกรองแล้ว แตะที่ \"รีเซ็ตตัวกรอง\" เพื่อเริ่มต้นนับความถี่ใหม่","id":"Setelah membersihkan filter, ketuk \"Reset Filter\" untuk memulai ulang penghitung.","zh-Hant":"清潔過濾網後，輕觸「重置濾網」以重新啟動計數器。","zh-TW":"清潔過濾網後，輕觸「重置濾網」以重新啟動計數器。","ar":"بعد تنظيف الفلتر ، اضغط على \"إعادة تعيين الفلتر\" لإعادة تشغيل العداد.","hu":"Szűrő tisztítása után kattintson a \"Szűrő visszaállítása\" gombra a számláló újraindításához.","el":"Μετά τον καθαρισμό του φίλτρου, πατήστε \"Επαναφορά φίλτρου\" για να επανεκκινήσετε τον μετρητή.","nl":"Na het reinigen van het filter, tik op \"Filterlevensduur resetten\" om de teller opnieuw te starten.","pl":"Po wyczyszczeniu filtra dotknij \"Reset filtra\", aby zrestartować licznik.","fi":"Puhdista suodatin ja napauta \"Suodattimen käyttöiän nollaus\" aloittaaksesi laskurin uudelleen.","sv":"Efter rengöring av filtret, tryck på \"Återställ filter\" för att starta räknaren igen.","km":"បន្ទាប់ ពី សម្អាត តម្រង តម្រង វាយ លើ \"Filter Reset\" ដើម្បី ចាប់ ផ្តើម ឡើង វិញ នូវ counter ។"},"Filter cleaning tips":{"en":"Filter cleaning tips","zh-Hans":"滤网清洁提示","fr":"Conseils de nettoyage du filtre","ja":"フィルターの掃除のヒント","it":"Consigli per la pulizia del filtro","es":"Consejos de limpieza del filtro","pt":"Dicas de limpeza do filtro","de":"Filterreinigungstipps","ru":"Советы по очистке фильтра","vi":"Mẹo vệ sinh bộ lọc","th":"เคล็ดลับการทำความสะอาดตัวกรอง","id":"Tips pembersihan filter","zh-Hant":"濾網清潔提示","zh-TW":"濾網清潔提示","ar":"نصائح تنظيف الفلتر","hu":"Szűrőtisztítási tippek","el":"Συμβουλές καθαρισμού φίλτρου","nl":"Filterreinigingstips","pl":"Porady dotyczące czyszczenia filtra","fi":"Suodattimen puhdistusvinkit","sv":"Tips för filterrengöring","km":"គន្លឹះសំអាតតម្រង"},"Remind me when the filter":{"en":"Remind me when the filter","zh-Hans":"当需要清洗滤网时提醒我","fr":"Rappelle-moi quand le filtre","ja":"フィルターのリマインド","it":"Ricordami il filtro","es":"Recuérdame el filtro","pt":"Lembre-me do filtro","de":"Erinnere mich an den Filter","ru":"Напомните мне о фильтре","vi":"Nhắc tôi về bộ lọc","th":"แจ้งเตือนฉันเมื่อมีตัวกรอง","id":"Ingatkan saya tentang filter","zh-Hant":"提醒我清洗过滤器","zh-TW":"提醒我清洗過濾器","ar":"تذكرني بالفلتر","hu":"Emlékeztessen a szűrőre","el":"Υπενθύμισέ μου το φίλτρο","nl":"Herinner me aan het filter","pl":"Przypomnij mi o filtrze","fi":"Muistuta minua suodattimesta","sv":"Påminn mig om filtret","km":"រំឭក ខ្ញុំ ពេល តម្រង"},"needs cleaning":{"en":"needs cleaning","zh-Hans":"需要清洁","fr":"doit être nettoyé","ja":"掃除が必要です","it":"necessita di pulizia","es":"necesita limpieza","pt":"precisa de limpeza","de":"muss gereinigt werden","ru":"требуется очистка","vi":"cần được vệ sinh","th":"ต้องทำความสะอาด","id":"perlu dibersihkan","zh-Hant":"需要清洁","zh-TW":"需要清潔","ar":"يحتاج إلى تنظيف","hu":"takarításra szorul","el":"χρειάζεται καθαρισμό","nl":"moet worden schoongemaakt","pl":"wymaga czyszczenia","fi":"tarvitsee puhdistusta","sv":"behöver rengöras","km":"ត្រូវការ ការ សម្អាត"},"Remind me":{"en":"Remind me","zh-Hans":"提醒我","fr":"Rappelle-moi","ja":"リマインドしてください","it":"Ricordami","es":"Recuérdame","pt":"Lembre-me","de":"Erinnere mich","ru":"Напомните мне","vi":"Nhắc tôi","th":"แจ้งเตือนฉัน","id":"Ingatkan saya","zh-Hant":"提醒我","zh-TW":"提醒我","ar":"تذكرني","hu":"Emlékeztessen","el":"Υπενθύμισέ μου","nl":"Herinner me","pl":"Przypomnij mi","fi":"Muistuta minua","sv":"Påminn mig","km":"រំឭក ខ្ញុំ"},"when the filter needs cleaning":{"en":"when the filter needs cleaning","zh-Hans":"当滤网需要清洁时","fr":"quand le filtre doit être nettoyé","ja":"フィルターの掃除が必要なとき","it":"quando il filtro necessita di pulizia","es":"cuando el filtro necesita limpieza","pt":"quando o filtro precisa de limpeza","de":"wenn der Filter gereinigt werden muss","ru":"когда требуется очистка фильтра","vi":"khi bộ lọc cần được vệ sinh","th":"เมื่อต้องทำความสะอาดตัวกรอง","id":"ketika filter perlu dibersihkan","zh-Hant":"當過濾器需要清洗時","zh-TW":"當過濾器需要清潔時","ar":"عندما يحتاج الفلتر للتنظيف","hu":"amikor a szűrőt takarítani kell","el":"όταν χρειάζεται καθαρισμός του φίλτρου","nl":"wanneer het filter moet worden schoongemaakt","pl":"gdy filtr wymaga czyszczenia","fi":"kun suodatin tarvitsee puhdistusta","sv":"när filtret behöver rengöras","km":"ពេល តម្រង ត្រូវ ការ សម្អាត"},"Setting Filter Life":{"en":"Setting Filter Life","zh-Hans":"设置过滤器寿命","fr":"Réglage de la durée de vie du filtre","ja":"フィルター寿命の設定","it":"Impostazione della durata del filtro","es":"Configuración de la vida útil del filtro","pt":"Configuração da vida útil do filtro","de":"Einstellung der Filterlebensdauer","ru":"Настройка срока службы фильтра","vi":"Cài đặt tuổi thọ bộ lọc","th":"การตั้งค่าอายุการใช้งานของตัวกรอง","id":"Pengaturan Umur Filter","zh-Hant":"設置過濾器壽命","zh-TW":"設置過濾器壽命","ar":"إعداد عمر الفلتر","hu":"Szűrőélettartam beállítása","el":"Ρύθμιση διάρκειας ζωής φίλτρου","nl":"Instellen van de levensduur van het filter","pl":"Ustawianie żywotności filtra","fi":"Suodattimen käyttöiän asettaminen","sv":"Inställning av filterlivslängd","km":"ការកំណត់ជីវិតតម្រង"},"The filter cleaning interval is dependent on air quality. Typically we recommend 250 hours.":{"en":"The filter cleaning interval is dependent on air quality. Typically we recommend 250 hours.","zh-Hans":"滤网的清洁时长隔取决于空气质量。通常我们建议使用250小时。","fr":"L'intervalle de nettoyage du filtre dépend de la qualité de l'air. En général, nous recommandons 250 heures.","ja":"フィルターの清掃間隔は空気の質に依存します。通常、250時間を推奨しています。","it":"L'intervallo di pulizia del filtro dipende dalla qualità dell'aria. Di solito consigliamo 250 ore.","es":"El intervalo de limpieza del filtro depende de la calidad del aire. Normalmente recomendamos 250 horas.","pt":"O intervalo de limpeza do filtro depende da qualidade do ar. Normalmente recomendamos 250 horas.","de":"Das Filterreinigungsintervall hängt von der Luftqualität ab. In der Regel empfehlen wir 250 Stunden.","ru":"Интервал очистки фильтра зависит от качества воздуха. Обычно мы рекомендуем 250 часов.","vi":"Khoảng thời gian vệ sinh bộ lọc phụ thuộc vào chất lượng không khí. Thông thường, chúng tôi khuyến nghị 250 giờ.","th":"ช่วงเวลาการทำความสะอาดตัวกรองขึ้นอยู่กับคุณภาพของอากาศ โดยทั่วไปเราแนะนำ 250 ชั่วโมง","id":"Interval pembersihan filter tergantung pada kualitas udara. Biasanya kami merekomendasikan 250 jam.","zh-Hant":"過濾器清潔間隔取決於空氣質量。通常我們建議250小時。","zh-TW":"過濾器清潔間隔取決於空氣質量。通常我們建議250小時。","ar":"فترة تنظيف الفلتر تعتمد على جودة الهواء. عادة ما نوصي بـ 250 ساعة.","hu":"A szűrőtisztítási időköz a levegőminőségtől függ. Általában 250 órát javasolunk.","el":"Το διάστημα καθαρισμού του φίλτρου εξαρτάται από την ποιότητα του αέρα. Συνήθως συνιστούμε 250 ώρες.","nl":"Het reinigingsinterval van het filter is afhankelijk van de luchtkwaliteit. Gewoonlijk raden we 250 uur aan.","pl":"Częstotliwość czyszczenia filtra zależy od jakości powietrza. Zwykle zalecamy 250 godzin.","fi":"Suodattimen puhdistusväli riippuu ilman laadusta. Yleensä suosittelemme 250 tuntia.","sv":"Intervallet för filterrengöring beror på luftkvaliteten. Vanligtvis rekommenderar vi 250 timmar.","km":"ចន្លោះ ពេល សម្អាត តម្រង គឺ ពឹង ផ្អែក លើ គុណភាព ខ្យល់ & # 160; ។ ជា ធម្មតា យើង ផ្តល់ អនុសាសន៍ ២៥០ ម៉ោង ។"},"Range: 200 - 2000 hours":{"en":"Range: 200 - 2000 hours","zh-Hans":"范围：200-2000小时","fr":"Plage : 200 - 2000 heures","ja":"範囲：200〜2000時間","it":"Intervallo: 200 - 2000 ore","es":"Rango: 200 - 2000 horas","pt":"Faixa: 200 - 2000 horas","de":"Bereich: 200 - 2000 Stunden","ru":"Диапазон: 200 - 2000 часов","vi":"Khoảng: 200 - 2000 giờ","th":"ช่วง: 200 - 2000 ชั่วโมง","id":"Rentang: 200 - 2000 jam","zh-Hant":"范围：200-2000小时","zh-TW":"范圍：200-2000小時","ar":"المدى: 200 - 2000 ساعة","hu":"Tartomány: 200 - 2000 óra","el":"Εύρος: 200 - 2000 ώρες","nl":"Bereik: 200 - 2000 uur","pl":"Zakres: 200 - 2000 godzin","fi":"Vaihteluväli: 200 - 2000 tuntia","sv":"Intervall: 200 - 2000 timmar","km":"Range: 200 - 2000 ម៉ោង"},"confirm not to remind":{"en":"confirm not to remind","zh-Hans":"确认不提醒","fr":"confirmer de ne pas rappeler","ja":"リマインドしないことを確認する","it":"confermare di non ricordare","es":"confirmar que no recordar","pt":"confirmar para não lembrar","de":"bestätigen, nicht zu erinnern","ru":"подтвердить, чтобы не напоминать","vi":"xác nhận không nhắc nhở","th":"ยืนยันไม่ต้องการเตือน","id":"konfirmasi untuk tidak mengingatkan","zh-Hant":"確認不提醒","zh-TW":"確認不提醒","ar":"تأكيد عدم التذكير","hu":"megerősítse, hogy nem emlékeztet","el":"επιβεβαιώστε ότι δεν θα υπενθυμίζετε","nl":"bevestigen om niet te herinneren","pl":"potwierdzić, że nie przypominać","fi":"vahvistaa, ettei muistuteta","sv":"bekräfta att inte påminna","km":"បញ្ជាក់ ថា មិន ត្រូវ រំឭក"},"confirm to remind":{"en":"confirm to remind","zh-Hans":"确认提醒","fr":"confirmer de rappeler","ja":"リマインドすることを確認する","it":"confermare di ricordare","es":"confirmar para recordar","pt":"confirmar para lembrar","de":"bestätigen, um zu erinnern","ru":"подтвердить, чтобы напомнить","vi":"xác nhận nhắc nhở","th":"ยืนยันต้องการเตือน","id":"konfirmasi untuk mengingatkan","zh-Hant":"確認提醒","zh-TW":"確認提醒","ar":"تأكيد التذكير","hu":"megerősítse, hogy emlékeztesse","el":"επιβεβαιώστε να υπενθυμίζετε","nl":"bevestigen om te herinneren","pl":"potwierdzić, że przypominać","fi":"vahvistaa muistuttaa","sv":"bekräfta att påminna","km":"បញ្ជាក់ដើម្បីរំលឹក"},"It is recommended to clean the filter at least every 200 hours to ensure optimal filter performance.":{"en":"It is recommended to clean the filter at least every 200 hours to ensure optimal filter performance.","zh-Hans":"建议至少每200小时清洁一次过滤器，以确保最佳的过滤器性能。","fr":"Il est recommandé de nettoyer le filtre au moins tous les 200 heures pour assurer une performance de filtre optimale.","ja":"最適なフィルター性能を確保するために、少なくとも200時間ごとにフィルターを清掃することを推奨します。","it":"Si consiglia di pulire il filtro almeno ogni 200 ore per garantire un'ottimale performance del filtro.","es":"Se recomienda limpiar el filtro al menos cada 200 horas para garantizar un rendimiento óptimo del filtro.","pt":"É recomendado limpar o filtro pelo menos a cada 200 horas para garantir um desempenho ótimo do filtro.","de":"Es wird empfohlen, den Filter mindestens alle 200 Stunden zu reinigen, um eine optimale Filterleistung zu gewährleisten.","ru":"Рекомендуется чистить фильтр не реже чем каждые 200 часов, чтобы обеспечить оптимальную производительность фильтра.","vi":"Được khuyến nghị nên vệ sinh bộ lọc ít nhất mỗi 200 giờ để đảm bảo hiệu suất lọc tối ưu.","th":"แนะนำให้ทำความสะอาดตัวกรองอย่างน้อยทุก 200 ชั่วโมงเพื่อให้มีประสิทธิภาพการกรองที่ดีที่สุด","id":"Disarankan untuk membersihkan filter setidaknya setiap 200 jam untuk memastikan kinerja filter optimal.","zh-Hant":"建议每200小时至少清洗一次过滤器，以确保最佳的过滤性能。","zh-TW":"建議每200小時至少清洗一次過濾器，以確保最佳的過濾性能。","ar":"يُوصَى بتنظيف الفلتر على الأقل كل 200 ساعة لضمان أداء الفلتر الأمثل.","hu":"Ajánlott legalább 200 óránként tisztítani a szűrőt, hogy optimális szűrőteljesítményt biztosítsunk.","el":"Συνιστάται η καθαριότητα του φίλτρου τουλάχιστον κάθε 200 ώρες για να διασφαλιστεί η βέλτιστη απόδοση του φίλτρου.","nl":"Het wordt aanbevolen om het filter ten minste elke 200 uur schoon te maken om optimale filterprestaties te garanderen.","pl":"Zaleca się czyszczenie filtra co najmniej co 200 godzin, aby zapewnić optymalną wydajność filtra.","fi":"Suositellaan puhdistamaan suodatin vähintään joka 200. tunti, jotta suodattimen suorituskyky on optimaalinen.","sv":"Det rekommenderas att rengöra filtret minst var 200:e timme för att säkerställa optimal filterprestanda.","km":"វា ត្រូវ បាន ផ្តល់ អនុសាសន៍ ឲ្យ សម្អាត តម្រង យ៉ាង ហោច ណាស់ រៀង រាល់ 200 ម៉ោង ដើម្បី ធានា ការ អនុវត្ត តម្រង ដ៏ ប្រសើរ បំផុត ។"},"The filter should be cleaned at least every 2000 hours to ensure the correct functioning of the AC.":{"en":"The filter should be cleaned at least every 2000 hours to ensure the correct functioning of the AC.","zh-Hans":"过滤器应至少每2000小时清洁一次，以确保空调正常工作。","fr":"Le filtre doit être nettoyé au moins tous les 2000 heures pour assurer le bon fonctionnement de la climatisation.","ja":"エアコンの正しい動作を確保するために、少なくとも2000時間ごとにフィルターを清掃する必要があります。","it":"Il filtro deve essere pulito almeno ogni 2000 ore per garantire il corretto funzionamento del condizionatore d'aria.","es":"El filtro debe limpiarse al menos cada 2000 horas para garantizar el correcto funcionamiento del aire acondicionado.","pt":"O filtro deve ser limpo pelo menos a cada 2000 horas para garantir o funcionamento correto do ar-condicionado.","de":"Der Filter sollte mindestens alle 2000 Stunden gereinigt werden, um die korrekte Funktion der Klimaanlage zu gewährleisten.","ru":"Фильтр должен быть очищен не реже чем каждые 2000 часов, чтобы обеспечить правильную работу кондиционера.","vi":"Bộ lọc nên được vệ sinh ít nhất mỗi 2000 giờ để đảm bảo hoạt động chính xác của máy điều hòa.","th":"ต้องทำความสะอาดตัวกรองอย่างน้อยทุก 2000 ชั่วโมงเพื่อให้เครื่องปรับอากาศทำงานได้อย่างถูกต้อง","id":"Filter harus dibersihkan setidaknya setiap 2000 jam untuk memastikan fungsi AC yang benar.","zh-Hant":"為確保空調的正確運作，建議每2000小時至少清洗一次過濾器。","zh-TW":"為確保空調的正確運作，建議每2000小時至少清洗一次過濾器。","ar":"يجب تنظيف الفلتر على الأقل كل 2000 ساعة لضمان العمل الصحيح لمكيف الهواء.","hu":"A szűrőt legalább 2000 óránként kell tisztítani, hogy biztosítsuk az légkondicionáló megfelelő működését.","el":"Το φίλτρο πρέπει να καθαρίζεται τουλάχιστον κάθε 2000 ώρες για να διασφαλιστεί η σωστή λειτουργία του κλιματιστικού.","nl":"Het filter moet ten minste elke 2000 uur worden schoongemaakt om een correcte werking van de airconditioner te garanderen.","pl":"Filtr należy czyścić co najmniej co 2000 godzin, aby zapewnić prawidłowe działanie klimatyzacji.","fi":"Suodatin on puhdistettava vähintään joka 2000. tunti, jotta ilmastointilaite toimii oikein.","sv":"Filtret bör rengöras minst var 2000:e timme för att säkerställa korrekt funktion av luftkonditioneringen.","km":"តម្រង គួរ តែ ត្រូវ បាន សម្អាត យ៉ាង ហោច ណាស់ រៀង រាល់ 2000 ម៉ោង ដើម្បី ធានា នូវ មុខ ងារ ត្រឹម ត្រូវ របស់ AC ។"},"Confirm Filter Cleaning Date":{"en":"Confirm Filter Cleaning Date","zh-Hans":"确认滤网清洁日期","fr":"Confirmer la date de nettoyage du filtre","ja":"フィルター清掃日を確認する","it":"Conferma la data di pulizia del filtro","es":"Confirmar la fecha de limpieza del filtro","pt":"Confirmar a data de limpeza do filtro","de":"Bestätigen Sie das Datum der Filterreinigung","ru":"Подтвердите дату очистки фильтра","vi":"Xác nhận ngày vệ sinh bộ lọc","th":"ยืนยันวันที่ทำความสะอาดตัวกรอง","id":"Konfirmasi Tanggal Pembersihan Filter","zh-Hant":"確認過濾器清潔日期","zh-TW":"確認過濾器清潔日期","ar":"تأكيد تاريخ تنظيف الفلتر","hu":"Megerősítse a szűrő tisztításának dátumát","el":"Επιβεβαιώστε την ημερομηνία καθαρισμού του φίλτρου","nl":"Bevestig de datum van het reinigen van het filter","pl":"Potwierdź datę czyszczenia filtra","fi":"Vahvista suodattimen puhdistuspäivä","sv":"Bekräfta datumet för filterrengöring","km":"បញ្ជាក់ កាលបរិច្ឆេទ សម្អាត តម្រង"},"Cleaning Records":{"en":"Cleaning Records","zh-Hans":"清洗记录","fr":"Registres de nettoyage","ja":"清掃記録","it":"Registri di pulizia","es":"Registros de limpieza","pt":"Registros de limpeza","de":"Reinigungsprotokolle","ru":"Записи о чистке","vi":"Hồ sơ vệ sinh","th":"บันทึกการทำความสะอาด","id":"Catatan Pembersihan","zh-Hant":"清洗记录","zh-TW":"清洗記錄","ar":"سجلات التنظيف","hu":"Tisztítási nyilvántartások","el":"Καθαρισμός Εγγραφών","nl":"Reinigingsrecords","pl":"Rejestry czyszczenia","fi":"Puhdistusrekisterit","sv":"Rengöringsregister","km":"កំណត់ត្រាសំអាត"},"No fliter cleaning record":{"en":"No fliter cleaning record","zh-Hans":"无滤网清洗记录","fr":"Aucun enregistrement de nettoyage de filtre","ja":"フィルター清掃記録なし","it":"Nessun record di pulizia del filtro","es":"Sin registro de limpieza del filtro","pt":"Sem registro de limpeza do filtro","de":"Kein Filterreinigungsprotokoll","ru":"Нет записи о чистке фильтра","vi":"Không có hồ sơ vệ sinh bộ lọc","th":"ไม่มีบันทึกการทำความสะอาดตัวกรอง","id":"Tidak ada catatan pembersihan filter","zh-Hant":"没有过滤器清洗记录","zh-TW":"沒有過濾器清洗記錄","ar":"لا يوجد سجل تنظيف الفلتر","hu":"Nincs szűrőtisztítási nyilvántartás","el":"Καμία εγγραφή καθαρισμού φίλτρου","nl":"Geen reinigingsrecord voor filter","pl":"Brak rejestracji czyszczenia filtra","fi":"Ei suodattimen puhdistusrekisteriä","sv":"Ingen rengöringsregistrering för filter","km":"គ្មាន កំណត់ ត្រា សម្អាត ត្រជាក់ ទេ"},"Record":{"en":"Record","zh-Hans":"记录","fr":"Enregistrement","ja":"記録","it":"Registro","es":"Registro","pt":"Registro","de":"Aufzeichnung","ru":"Запись","vi":"Hồ sơ","th":"บันทึก","id":"Catatan","zh-Hant":"記錄","zh-TW":"記錄","ar":"سجل","hu":"Feljegyzés","el":"Εγγραφή","nl":"Record","pl":"Rekord","fi":"Tietue","sv":"Registrera","km":"កំណត់ត្រា"},"Update hourly":{"en":"Update hourly","zh-Hans":"每小时更新一次","fr":"Mise à jour horaire","ja":"毎時更新","it":"Aggiornamento orario","es":"Actualización horaria","pt":"Atualização por hora","de":"Stündliches Update","ru":"Обновление каждый час","vi":"Cập nhật hàng giờ","th":"อัปเดตทุกชั่วโมง","id":"Pembaruan setiap jam","zh-Hant":"每小时更新","zh-TW":"每小時更新","ar":"تحديث كل ساعة","hu":"Óránkénti frissítés","el":"Ενημέρωση κάθε ώρα","nl":"Uurlijkse update","pl":"Aktualizacja co godzinę","fi":"Päivitys tunnin välein","sv":"Uppdatera varje timme","km":"Update ១ម៉ោង"},"Fliter Reset":{"en":"Fliter Reset","zh-Hans":"重置滤网清洗记录","fr":"Réinitialisation du filtre","ja":"フィルターリセット","it":"Reset del filtro","es":"Reinicio del filtro","pt":"Reset do filtro","de":"Filter zurücksetzen","ru":"Сброс фильтра","vi":"Đặt lại bộ lọc","th":"รีเซ็ตตัวกรอง","id":"Reset filter","zh-Hant":"过滤器重置","zh-TW":"過濾器重置","ar":"إعادة تعيين الفلتر","hu":"Szűrő visszaállítása","el":"Επαναφορά φίλτρου","nl":"Filter resetten","pl":"Resetowanie filtra","fi":"Suodattimen nollaus","sv":"Återställ filter","km":"កំណត់ ត្រា សម្អាត តម្រង ឡើង វិញ"}}

/***/ }),

/***/ 2:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }(); /**
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      * Created by liujim on 2017/8/26.
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      */


var _nativeService = __webpack_require__(1);

var _nativeService2 = _interopRequireDefault(_nativeService);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Helper = function () {
    function Helper() {
        _classCallCheck(this, Helper);
    }

    _createClass(Helper, null, [{
        key: "showAlertViewCommon",
        value: function showAlertViewCommon(msg, _delay) {
            var delay = _delay !== undefined ? _delay : 10;
            // setTimeout(() => {
            //     nativeService.toast(msg);    
            // }, delay);
            clearTimeout(this.requestTimer);
            this.requestTimer = setTimeout(function () {
                _nativeService2.default.toast(msg);
            }, delay);
        }
    }, {
        key: "showLoadingView",
        value: function showLoadingView(isShow) {
            if (isShow) {
                _nativeService2.default.showLoading();
            } else {
                _nativeService2.default.hideLoading();
            }
        }
    }, {
        key: "log",
        value: function log(msg) {
            console.log("weex-console ---- " + JSON.stringify(msg, null, 2));
        }
    }, {
        key: "logByTag",
        value: function logByTag(msg, tag) {
            console.log(tag + "\t" + JSON.stringify(msg, null, 2));
        }
    }, {
        key: "decimalArrayToHexStrArray",
        value: function decimalArrayToHexStrArray(origin) {
            return origin.map(function (item) {
                return item.toString(16);
            });
        }
    }, {
        key: "decimalArrayToHexStrArrayFormat",
        value: function decimalArrayToHexStrArrayFormat(origin) {
            var item = "";
            return origin.map(function (_item) {
                item = _item.toString(16);
                return item.length == 1 ? "0" + item : item;
            });
        }
    }, {
        key: "decimalArrayToHexArray",
        value: function decimalArrayToHexArray(origin) {
            return origin.map(function (item) {
                return parseInt(item); //int compatible with hex
            });
        }
    }, {
        key: "hexArrayToHexStrArray",
        value: function hexArrayToHexStrArray(origin) {
            return origin.map(function (item) {
                return item.toString(16);
            });
        }
    }, {
        key: "hexArrayToDecimalArray",
        value: function hexArrayToDecimalArray(origin) {
            return origin.map(function (item) {
                return parseInt(item) & 0xff;
            });
        }
    }, {
        key: "hexStrArrayToDecimalArray",
        value: function hexStrArrayToDecimalArray(origin) {
            return origin.map(function (item) {
                return parseInt("0x" + item) & 0xff;
            });
        }
    }, {
        key: "strArrayToIntArray",
        value: function strArrayToIntArray(origin) {
            return origin.map(function (item) {
                return parseInt(item);
            });
        }
    }, {
        key: "merge",
        value: function merge(origin, addition) {
            for (var key in addition) {
                if (_typeof(addition[key]) !== "object" || addition[key] instanceof Array) {
                    origin[key] = addition[key];
                } else {
                    this.merge(origin[key], addition[key]);
                }
            }
        }
    }, {
        key: "arrayClone",
        value: function arrayClone(orginal) {
            var result = [];

            orginal.map(function (item) {
                result.push(item);
            });

            return result;
        }
    }, {
        key: "arrayConcat",
        value: function arrayConcat(origin, addition) {
            var _this = this;

            var result = this.arrayClone(origin);
            addition.map(function (item) {
                if (!_this.inArray(result, item)) {
                    result.push(item);
                }
            });

            return result;
        }
    }, {
        key: "hexStrAlignLeft",
        value: function hexStrAlignLeft(str) {
            if (str.length < 2) {
                return "0" + str;
            } else {
                return str;
            }
        }
    }, {
        key: "inArray",
        value: function inArray(container, search) {
            var isExist = false;
            container.map(function (item) {
                if (item == search) {
                    isExist = true;
                }
            });
            return isExist;
        }
    }, {
        key: "removeSingleValueFromArray",
        value: function removeSingleValueFromArray(container, value) {
            //return by ref
            var valueIndex = 0;
            container.map(function (item, index) {
                if (item == value) {
                    valueIndex = index;
                    return;
                }
            });
            container.splice(valueIndex, 1);
        }
    }, {
        key: "getJsonLength",
        value: function getJsonLength(json) {
            var counter = 0;
            for (var i in json) {
                counter++;
            }
            return counter;
        }
    }, {
        key: "dayNameMapping",
        value: function dayNameMapping(num) {
            var dayMap = [t.getText('week_Mon'), t.getText('week_Tue'), t.getText('week_Wed'), t.getText('week_Thu'), t.getText('week_Fri'), t.getText('week_Sat'), t.getText('week_Sun')];

            var dayName = dayMap[num - 1] != undefined ? dayMap[num - 1] : "";

            return dayName;
        }
    }, {
        key: "dayArrToStr",
        value: function dayArrToStr(week) {
            var repeatDays = "";
            if (week.length != 7) {
                week.map(function (item, index) {
                    repeatDays += Helper.dayNameMapping(item);
                    if (index != week.length - 1) {
                        repeatDays += ".";
                    }
                });
            } else {
                repeatDays = t.getText('week_everyday');
            }

            return repeatDays;
        }
    }, {
        key: "UTCToLocal",
        value: function UTCToLocal(utcTime) {
            var date = new Date();
            var y = date.getUTCFullYear();
            var m = date.getUTCMonth();
            var d = date.getUTCDate();
            var s = 0;
            var utc = Date.UTC(y, m, d, parseInt(utcTime.split(":")[0]), parseInt(utcTime.split(":")[1]), s);

            var local = new Date(utc);
            var hourLocal = local.getHours().toString().length < 2 ? "0" + local.getHours() : local.getHours().toString();
            var minuteLocal = local.getMinutes().toString().length < 2 ? "0" + local.getMinutes() : local.getMinutes().toString();

            return hourLocal + ":" + minuteLocal;
        }
    }, {
        key: "localToUTC",
        value: function localToUTC(localTime) {
            var date = new Date();
            var y = date.getFullYear();
            var m = date.getMonth();
            var d = date.getDate();
            var s = 0;
            var local = new Date(y, m, d, parseInt(localTime.split(":")[0]), parseInt(localTime.split(":")[1]), s);

            var hourUTC = local.getUTCHours().toString().length < 2 ? "0" + local.getUTCHours() : local.getUTCHours().toString();
            var minuteUTC = local.getUTCMinutes().toString().length < 2 ? "0" + local.getUTCMinutes() : local.getUTCMinutes().toString();

            return hourUTC + ":" + minuteUTC;
        }
    }, {
        key: "inputFilter",
        value: function inputFilter(value) {
            //todo
            return value.replace(/[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF][\u200D|\uFE0F]|[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF]|[0-9|*|#]\uFE0F\u20E3|[0-9|#]\u20E3|[\u203C-\u3299]\uFE0F\u200D|[\u203C-\u3299]\uFE0F|[\u2122-\u2B55]|\u303D|[\\A9|\\AE]\u3030|\\uA9|\\uAE|\u3030/ig, "");
            //return value;
        }
    }, {
        key: "getShortText",
        value: function getShortText(text, maxLength) {
            var _text = text + "";
            var result = _text;

            if (_text.length > maxLength) {
                result = _text.substring(0, maxLength) + "...";
            }

            return result;
        }
    }, {
        key: "isWeixinNavigator",
        value: function isWeixinNavigator() {
            var ua = window.navigator.userAgent.toLowerCase();
            if (ua.match(/MicroMessenger/i) == 'micromessenger') {
                return true;
            } else {
                return false;
            }
        }

        /**
         * 简单数组的并集
         * @param {Array} a
         * @param {Array} b
         */


        /**
         * 简单数组的交集
         * @param {Array} a
         * @param {Array} b
         */


        /**
         * 简单数组的差集
         * @param {Array} a
         * @param {Array} b
         */

    }]);

    return Helper;
}();

Helper.clone = function (original) {
    var clone = {};
    for (var i in original) {
        if (_typeof(original[i]) === 'object') {
            clone[i] = this.clone(original[i]);
        } else {
            clone[i] = original[i];
        }
    }
    return clone;
};

Helper.cloneDeep = function (original) {
    var clone = {};
    for (var i in original) {
        if (_typeof(original[i]) === 'object' && !(original[i] instanceof Array)) {
            clone[i] = this.cloneDeep(original[i]);
        } else {
            if (original[i] instanceof Array) {
                clone[i] = this.arrayClone(original[i]);
            } else {
                clone[i] = original[i];
            }
        }
    }
    return clone;
};

Helper.parseUnsignedInt = function (origin) {
    return parseInt(origin);
};

Helper.getUnion = function (a, b) {}
//todo
;

Helper.getIntersect = function (a, b) {}
//todo
;

Helper.getDifference = function (a, b) {
    var result = [];
    result = a.concat(b).filter(function (v) {
        return a.indexOf(v) === -1 || b.indexOf(v) === -1;
    });

    return result;
};

Helper.isRealNum = function (val) {
    // 先判定是否为number
    if (typeof val !== 'number') {
        return false;
    }
    if (!isNaN(val)) {
        return true;
    } else {
        return false;
    }
};

Helper.replaceAll = function (str, placeHolder, replaceStr) {
    return str.replace(RegExp(placeHolder, "g"), replaceStr);
};

Helper.getB5LocalVersion = function () {
    // 插件缓存B5数据的版本号
    return '2023051501';
};

exports.default = Helper;

/***/ }),

/***/ 28:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  extend: function extend(targetObj, fromObj) {
    fromObj = fromObj || {};
    targetObj = targetObj || {};
    for (var key in fromObj) {
      if (fromObj.hasOwnProperty(key) && !targetObj.hasOwnProperty(key)) {
        targetObj[key] = fromObj[key];
      }
    }
    return targetObj;
  }
};

/***/ }),

/***/ 29:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = {
  arrowIcon: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAWBAMAAAA2mnEIAAAAMFBMVEUAAAAgIyUgIyUgIyUgIyUgIyUgIyUgIyUgIyUgIyUgIyUgIyUgIyUgIyUgIyUgIyXxqNxkAAAAEHRSTlMATEYxFA4CPTgqCUMlIhsZEJGcAQAAAE5JREFUGNNjAIKLDxjgQFAewT4o6ABncwqKICQmIkkwC6oiJAyFArBKsDUKLYBzMgR3ISQKxTHZCDUIvQgzMe1CCCPchnAzwi+YfkT4HQA98hAFt122dQAAAABJRU5ErkJggg==",
  extendIcon: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAJCAMAAAA1k+1bAAAAM1BMVEUAAACYmJiXl5eZmZmampqYmJiYmJiXl5eZmZmYmJiYmJiZmZmZmZmYmJibm5ubm5uZmZlAoLvfAAAAEHRSTlMA9fZuSmhhUfhzVziEQ0IhhORZQgAAAEJJREFUCNdFyzkSwCAMQ1Ehg9my6P6nTeF4eI3mFwJsTjNrrbn7hS2NUX4CHipxAajM6sDpUhE6o9KieOPYil96Yz7ijwK/GAbG3wAAAABJRU5ErkJggg=="
};

/***/ }),

/***/ 32:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }(); /**
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      * Created by liujim on 2017/10/22.
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      */


var _SLKDecorator = __webpack_require__(33);

var _SLKDecorator2 = _interopRequireDefault(_SLKDecorator);

var _nativeService = __webpack_require__(1);

var _nativeService2 = _interopRequireDefault(_nativeService);

var _Helper = __webpack_require__(2);

var _Helper2 = _interopRequireDefault(_Helper);

var _web = __webpack_require__(35);

var _web2 = _interopRequireDefault(_web);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var bridgeModule = weex.requireModule('bridgeModule');

/*OEM*/
var ElectricityLimit = "/electricityLimit/queryLimit";
var StartLimit = "/electricityLimit/startLimit";
var StopLimit = "/electricityLimit/stopLimit";
var QueryRatio = "/electricityLimit/queryRatio";
var QueryElec = "/electricity/queryElec";
var AddApplianceAppoint = "/applianceappoint/addApplianceAppoint";
var UpdateApplianceAppoint = "/applianceappoint/updateApplianceAppoint";
var StartApplianceAppoint = "/applianceappoint/startApplianceAppoint";
var CloseApplianceAppoint = "/applianceappoint/closeApplianceAppoint";
var GetApplianceAppointList = "/applianceappoint/getApplianceAppointList";
var GetSleepCurveStatus = "/sleepcurve/getSleepCurveStatus";
var StartSleepCurve = "/sleepcurve/startSleepCurve";
var CloseSleepCurve = "/sleepcurve/closeSleepCurve";
var UpdateSleepCurve = "/sleepcurve/updateSleepCurve";
var _StartACCheck = "/acCheck/startACCheck";
var _AcCheckDetails = "/acCheck/acCheckDetails";
var _getACCheckScore = "/acCheck/getACCheckScore";

/*EMS*/
var _queryOptimizeScene = "/scene/ems/queryOptimizeScene"; //7.11 查询一键优化场景
var _initOptimizeScene = "/scene/ems/initOptimizeScene"; // 7.12 初始化一键优化场景
var _setOptimizeScene = "/scene/ems/setOptimizeScene"; //7.13 更新一键优化场景参数
var _queryTemplateScenes = "/scene/ems/queryTemplateScenes"; //7.14 查询空气机场景列表
var _uploadSceneLog = "/scene/ems/uploadSceneLog"; //7.15 上传场景开启日志
var _getFavoriteScenes = "/scene/ems/getFavoriteScenes"; //7.16 获取同城最喜欢的场景
var _getTimerList = "/timer/ems/getTimerList"; //36.1 获取闹钟列表
var _addTimer = "/timer/ems/updateTimer"; //36.2 添加闹钟
var _updateTimer = "/timer/ems/updateTimer"; //36.3 更新闹钟
var _deleteTimer = "/timer/ems/deleteTimer"; //36.4 删除闹钟
var _getTimerBroadcast = "/timer/ems/getTimerBroadcast"; //36.10 获取定时播报
var _setTimerBroadcast = "/timer/ems/setTimerBroadcast"; // 36.11 设置定时播报
var resetTimerBroadcast = "/timer/ems/resetTimerBroadcast"; //36.12 重置定时播报

var _getAreaWeatherDetail = "/weather/getAreaWeatherDetail"; //18.7 根据地址获取室外天气
var _getAreaWeather24h = "/weather/getAreaWeather24h"; // 18.8.	根据地址获取24小时室外天气
var _getAreaWeather7d = "/weather/getAreaWeather7d"; //18.9 根据地址获取七天室外天气
var _reverseGeocode = "/weather/ReverseGeocode"; //18.5 经纬度坐标转换为地区地址


var _newInformationSheet = "/css/add"; //新建售后信息单
var _getServiceItems = "/css/getServiceItems"; //获取故障类型

var _update = "/ems/config/update"; //37.1 app 更新EMS配置
var _list = "/ems/config/list"; //37.2 获取EMS配置
var _statuslist = "/ems/status/list"; //37.6 获取EMS配置


var _receivesMessage = "/message/ems/history/list"; //23.24 消息接收端列表接口
var _manual = "/ems/manual/list"; //37.4 获取EMS使用手册
var _messageList = "/emsPlugMsg/list"; //37.8 1.1.	获取EMS插件消息列表
var _messagedeLeteId = "/emsPlugMsg/deleteId"; //37.8 1.1.	1.1.	删除EMS插件消息ID
var _syncId = "/emsPlugMsg/syncId";
var _getOurterUrlInfo = "/appliance/getOurterUrlInfo";
var _deletePicture = "/emsPlugMsg/deletePicture";
var _addPicture = "/emsPlugMsg/addPicture";
var _addPictureList = "/emsPlugMsg/addPictureList";
var _getPictureList = "/emsPlugMsg/getPictureList";

/*OBM海外美居*/
var _addSchedule = "/schedule/add"; //添加预约
var _updateSchedule = "/schedule/update"; //修改预约
var _removeSchedule = "/schedule/remove"; //删除预约
var _openSchedule = "/schedule/open"; //开启预约
var _closeSchedule = "/schedule/close"; //关闭预约
var _getListSchedule = "/schedule/getList";
var _electricityLimitQuery = "/electricityLimit/queryRatio"; // 获取电量取值范围
var _electricityQueryLimit = "/electricityLimit/queryLimit"; // 获取电量限额
var _electricityStartLimit = "/electricityLimit/startLimit"; // 开启电量限额
var _electricityStopLimit = "/electricityLimit/stopLimit"; // 关闭电量限额
var _getSleepCurveStatus = "/sleepcurve/getSleepCurveStatus"; // 获取睡眠曲线及状态
var _startSleepCurve = "/sleepcurve/startSleepCurve"; // 开启舒睡曲线
var closeSleepCurve = "/sleepcurve/closeSleepCurve"; // 关闭舒睡功能
var _updateSleepCurve = "/sleepcurve/updateSleepCurve"; // 修改自定义曲线
var _queryElec = "/electricity/queryElec"; // 用电统计
var productDesc = "/appliance/aboutDeviceDescription"; //产品详细信息

var _queryOtaStaus = "/ota/queryOtaStaus"; //查询OTA的版本
var _upgradeWifi = "/ota/upgradeWifi"; //升级OTA
var _abandonUpgradeWifi = "/ota/abandonUpgradeWifi"; //取消升级OTA
var _setAutoUpgradeWifi = "/ota/setAutoUpgradeWifi"; //设置自动升级OTA
var unbindDevice = "/v1/appliance/user/unbind"; //删除设备
var sheareDevice = "/v1/appliance/user/share/cancel"; //分享设备
var _userListGet = '/v1/appliance/user/list/get'; // 获取用户家电列表
// const deviceBindGet='v1/appliance/info/bind/get'  // 家电信息及绑定关系查询
var _infoModify = '/v1/appliance/info/modify'; // 家电信息修改 
var activityList = '/activity/list'; // 活动列表
var activityToken = '/activity/getToken'; // 获取用户令牌
var stateListUrl = '/activity/USNWarr22/stateList'; // 获取state列表
var _bindDevice = "/v1/appliance/user/bind"; // 绑定设备

var favoriteListUrl = '/favorite/list'; // 查询Favorite
var addFavoriteUrl = '/favorite/add'; //  新增Favorite
var updateFavoriteUrl = '/favorite/modify'; //  修改Favorite
var deleteFavoriteUrl = '/favorite/del'; //  新增Favorite

var _iserviceGet = 'intl-appconfig/config/iservice/get';

var digiremoteUrl = '/digiremote'; // 密码锁

var ennoRange = '/orac-airapp/v1/enno/range'; //节能区间
var curveAdd = '/orac-airapp/sleep/curve/modify'; //新增睡眠曲线
var _curveModify = '/orac-airapp/sleep/curve/modify'; //修改睡眠曲线
var _curveRun = '/orac-airapp/sleep/curve/run'; //启动睡眠曲线
var _curveStop = '/orac-airapp/sleep/curve/stop'; //停止睡眠曲线
var _curveDetail = '/orac-airapp/sleep/curve/detail'; //查询曲线详情
var _curveRecommend = '/orac-airapp/sleep/curve/recommend'; //查询推荐ＡＩ睡眠曲线
var iecoUrl = '/ieco/updateFirmwareVersion';
var _otaRefreshId = '/refreshId/'; // 注意后面有 /
var _powerReport = '/orac-airapp/ieco/power/report';
var _targetGet = '/orac-airapp/v1/ieco/target/get';
var _targetSet = '/orac-airapp/v1/ieco/target/set';
var _powerBoast = '/orac-airapp/ieco/power/board';
var checkB5Version = '/orac-airapp/v1/ieco/checkB5VersionUpdate';

var _userPreferencesSet = '/settings/userPreferences/set';
var _userPreferencesGet = '/settings/userPreferences/get';
var deviceB5InfoSet = '/orac-airapp/ieco/power/saveb5'; //传设备B5数据
// iCheck*********
// 检测
var _checkByhand = '/orac-airapp/v1/icheck/check/hand'; //手动检测
var _taskExecution = '/orac-airapp/v1/icheck/check/task/execution'; //定时检测回调接口
var _byhandCancel = '/orac-airapp/v1/icheck/check/hand/cancel'; //取消手动检测
var _networkTime = '/orac-airapp/v1/icheck/network/time'; //网络情况反馈接口

//取消手动检测
// 检测历史
var _historyList = '/orac-airapp/v1/icheck/history/list'; // 设备检测历史分页查询
var _historyDetail = '/orac-airapp/v1/icheck/history/detail'; // 设备检测历史详情查询
var _historyLatestChecktime = '/orac-airapp/v1/icheck/history/latest/checktime'; // 最新检测时间查询

// iCheck接口-维护保养建议
var _supportSuggestion = '/orac-airapp/v1/icheck/support/suggestion'; // 随机维护保养建议

// 用户设置
var _settingNotification = '/orac-airapp/v1/icheck/user/setting/notification'; // 用户配置-通知设置
var _settingTiming = '/orac-airapp/v1/icheck/user/setting/timing'; // 用户配置-定时检测设置
var _getSetting = '/orac-airapp/v1/icheck/user/getSetting'; // 用户配置-查询所有设置
var _settingPowerOn = '/orac-airapp/v1/icheck/user/setting/powerOn'; // 用户配置-开机检测设置

// 智能可视化
var intelligentIndex = '/orac-airapp/intelligent/insight/index';
var firstTimeConnect = '/orac-airapp/v1/enno/connect/firstTime'; //首次配网时间
var checkB5Url = '/orac-airapp/intelligent/insight/query/switch/status';

var _getZoneId = '/v1/dst/area/time/zone/get'; // 获取设备地区ID ---冬夏令时
//电子说明书
var userGuideUrl = '/api/instruction/search';
// 联系我们
var contactUsUrl = 'api/serviceTelephone/query';
// 智能诊断
var troubleshootingUrl = '/api/knowledgeContent/list';
//新的check
var checkGroupListUrl = '/orac-airapp/check/group/list';
var checkGroupChecktUrl = '/orac-airapp/check/act/groupCheck';

var _queryCoolFlashStatus = "/orac-airapp/flashCool/query"; //coolflash查询
var _coolFlashEnabled = "/orac-airapp/flashCool/enabled"; //coolflash开关
var _setCoolFlashConfig = "/orac-airapp/flashCool/config"; //coolflash配置

var filterUrl = '/orac-airapp/filter'; //滤网

var langMap = {
    "ar": "arabic",
    "hr": "croatian",
    "en": "english",
    "fr": "french",
    "de": "Germany",
    "el": "greek",
    "hu": "hungary",
    "it": "italian",
    "ja": "japanese",
    "ko": "korean",
    "nl": "Netherlands",
    "pl": "Poland",
    "pt": "portuguese",
    "ro": "romanian",
    "ru": "russian",
    "es": "spanish",
    "se": "Sweden",
    "tr": "turkish",
    "zh": "zh-CHT"
};

var WebComDecorator = function () {
    function WebComDecorator(isViaServer, deviceId, deviceSn, familyId, mockMode) {
        _classCallCheck(this, WebComDecorator);

        this.isViaServer = isViaServer !== undefined ? isViaServer : false;
        this.deviceId = deviceId ? deviceId : "";
        this.deviceSn = deviceSn ? deviceSn : "";
        this.familyId = familyId ? familyId : "";

        this.mockMode = mockMode ? mockMode : false;

        this.runtimeTestData = {};
    }

    //获取EMS插件消息列表


    _createClass(WebComDecorator, [{
        key: 'messageList',
        value: function messageList(deviceId, success, error) {
            this.webserviceApdater(_messageList, {
                "deviceId": parseInt(this.deviceId)
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
        //删除EMS插件消息ID

    }, {
        key: 'messagedeLeteId',
        value: function messagedeLeteId(deviceId, messageID, success, error) {
            this.webserviceApdater(_messagedeLeteId, {
                "deviceId": parseInt(this.deviceId),
                "msgId": messageID
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'syncId',
        value: function syncId(deviceId, idList, success, error) {
            this.webserviceApdater(_syncId, {
                "deviceId": parseInt(this.deviceId),
                "idList": []
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        //新建售后信息单

    }, {
        key: 'newInformationSheet',
        value: function newInformationSheet(userId, customerName, phone, areaNum, areaCode, regionStr, address, serviceType, prodCode, serviceItem, serviceDesc, pubRemark, isFaultPush, success, error) {
            this.webserviceApdater(_newInformationSheet, {
                "userId": parseInt(userId),
                "customerName": customerName,
                "phone": parseInt(phone),
                "areaNum": areaNum,
                "areaCode": areaCode,
                "regionStr": regionStr + "",
                "address": address,
                "serviceType": serviceType,
                "prodCode": prodCode,
                "serviceItem": serviceItem,
                "serviceDesc": serviceDesc,
                "pubRemark": pubRemark,
                "isFaultPush": isFaultPush
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        //获取故障类型

    }, {
        key: 'getServiceItems',
        value: function getServiceItems(userId, prodCode, success, error) {
            this.webserviceApdater(_getServiceItems, {
                "userId": parseInt(userId),
                "prodCode": parseInt(prodCode)
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        //查询一键优化场景

    }, {
        key: 'queryOptimizeScene',
        value: function queryOptimizeScene(deviceId, success, error) {
            this.webserviceApdater(_queryOptimizeScene, {
                "deviceId": parseInt(this.deviceId),
                "deviceSn": this.deviceSn + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        //体检

    }, {
        key: 'StartACCheck',
        value: function StartACCheck(deviceId, success, error) {
            this.webserviceApdater(_StartACCheck, {
                "applianceId": parseInt(this.deviceId)
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
        //获取体检分数和时间

    }, {
        key: 'getACCheckScore',
        value: function getACCheckScore(deviceId, success, error) {
            this.webserviceApdater(_getACCheckScore, {
                "applianceId": parseInt(this.deviceId)
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
        //

    }, {
        key: 'AcCheckDetails',
        value: function AcCheckDetails(success, error) {
            this.webserviceApdater(_AcCheckDetails, {
                "applianceId": parseInt(this.deviceId)
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        //初始化一键优化场景

    }, {
        key: 'initOptimizeScene',
        value: function initOptimizeScene(deviceId, templateSceneId, success, error) {
            this.webserviceApdater(_initOptimizeScene, {
                "deviceId": parseInt(this.deviceId),
                "deviceSn": this.deviceSn + "",
                "templateSceneId": templateSceneId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        //更新一键优化场景参数

    }, {
        key: 'setOptimizeScene',
        value: function setOptimizeScene(deviceId, tempSet, humidity, clean, fresh, windSpeed, mode, ion, lrSwing, udSwing, templateSceneId, success, error) {
            this.webserviceApdater(_setOptimizeScene, {
                "deviceId": parseInt(this.deviceId),
                "deviceSn": this.deviceSn + "",
                "tempSet": tempSet,
                "humidity": parseInt(humidity),
                "clean": parseInt(clean),
                "fresh": parseInt(fresh),
                "windSpeed": parseInt(windSpeed),
                "mode": parseInt(mode),
                "ion": parseInt(ion),
                "lrSwing": parseInt(lrSwing),
                "udSwing": parseInt(udSwing),
                "templateSceneId": templateSceneId
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        //查询空气机场景列表

    }, {
        key: 'queryTemplateScenes',
        value: function queryTemplateScenes(success, error) {
            this.webserviceApdater(_queryTemplateScenes, {}, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        //上传场景开启日志

    }, {
        key: 'uploadSceneLog',
        value: function uploadSceneLog(deviceId, sceneId, sceneType, success, error) {
            this.webserviceApdater(_uploadSceneLog, {
                "deviceId": parseInt(this.deviceId),
                "deviceSn": this.deviceSn + "",
                "sceneId": parseInt(sceneId),
                "sceneType": sceneType + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        //获取同城最喜欢的场景

    }, {
        key: 'getFavoriteScenes',
        value: function getFavoriteScenes(deviceId, sceneNum, success, error) {
            this.webserviceApdater(_getFavoriteScenes, {
                "deviceId": parseInt(this.deviceId),
                "deviceSn": this.deviceSn + "",
                "sceneNum": parseInt(sceneNum)
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        //获取闹钟列表

    }, {
        key: 'getTimerList',
        value: function getTimerList(deviceId, success, error) {
            this.webserviceApdater(_getTimerList, {
                "deviceId": parseInt(this.deviceId)
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'addTimer',
        value: function addTimer(deviceId, timerName, valid, time, repeat, optimizeOnoff, tempSet, mode, humidityOnoff, cleanOnoff, freshOnoff, degermingOnoff, allClose, power, isNeedExec, success, error) {
            this.webserviceApdater(_addTimer, {
                "deviceId": parseInt(this.deviceId),
                "timerName": timerName + "",
                "valid": parseInt(valid),
                "time": time + "",
                "repeat": repeat instanceof Array ? repeat : [0, 1, 2, 3, 4, 5, 6],
                "optimizeOnoff": parseInt(optimizeOnoff),
                "tempSet": parseFloat(tempSet),
                "mode": parseInt(mode),
                "humidityOnoff": parseInt(humidityOnoff),
                "cleanOnoff": parseInt(cleanOnoff),
                "freshOnoff": parseInt(freshOnoff),
                "degermingOnoff": parseInt(degermingOnoff),
                "allClose": parseInt(allClose),
                "power": parseInt(power),
                "isNeedExec": isNeedExec
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'updateTimer',
        value: function updateTimer(deviceId, timerId, timerName, valid, time, repeat, optimizeOnoff, tempSet, mode, humidityOnoff, cleanOnoff, freshOnoff, degermingOnoff, allClose, power, isNeedExec, success, error) {
            this.webserviceApdater(_updateTimer, {
                "deviceId": parseInt(this.deviceId),
                "timerId": parseInt(timerId),
                "timerName": timerName + "",
                "valid": parseInt(valid),
                "time": time + "",
                "repeat": repeat instanceof Array ? repeat : [0, 1, 2, 3, 4, 5, 6],
                "optimizeOnoff": parseInt(optimizeOnoff),
                "tempSet": parseFloat(tempSet),
                "mode": parseInt(mode),
                "humidityOnoff": parseInt(humidityOnoff),
                "cleanOnoff": parseInt(cleanOnoff),
                "freshOnoff": parseInt(freshOnoff),
                "degermingOnoff": parseInt(degermingOnoff),
                "allClose": parseInt(allClose),
                "power": parseInt(power),
                "isNeedExec": isNeedExec
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'deleteTimer',
        value: function deleteTimer(deviceId, timerId, success, error) {
            this.webserviceApdater(_deleteTimer, {
                "deviceId": parseInt(this.deviceId),
                "timerId": parseInt(timerId)
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'getTimerBroadcast',
        value: function getTimerBroadcast(deviceSn, success, error) {
            this.webserviceApdater(_getTimerBroadcast, {
                "deviceSn": this.deviceSn + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'setTimerBroadcast',
        value: function setTimerBroadcast(deviceSn, status, time, repeats, success, error) {
            this.webserviceApdater(_setTimerBroadcast, {
                "deviceSn": this.deviceSn + "",
                "status": parseInt(status),
                "time": time + "",
                "repeats": repeats + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        // startACCheck(deviceId,success,error){
        //   this.webserviceApdater(deleteTimer,{
        //     "deviceId": parseInt(this.deviceId),
        //   }, function (data) {
        //     success && success(data);
        //   }, function (errorCode,errorMsg) {
        //     error && error(errorCode,errorMsg);
        //   });
        // }

    }, {
        key: 'getAreaWeatherDetail',
        value: function getAreaWeatherDetail(longitude, latitude, city, district, success, error) {
            this.webserviceApdater(_getAreaWeatherDetail, {
                "longitude": longitude + "",
                "latitude": latitude + "",
                "city": city + "",
                "district": district + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'getAreaWeather24h',
        value: function getAreaWeather24h(longitude, latitude, city, district, success, error) {
            this.webserviceApdater(_getAreaWeather24h, {
                "longitude": longitude + "",
                "latitude": latitude + "",
                "city": city + "",
                "district": district + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'getAreaWeather7d',
        value: function getAreaWeather7d(longitude, latitude, city, district, success, error) {
            this.webserviceApdater(_getAreaWeather7d, {
                "longitude": longitude + "",
                "latitude": latitude + "",
                "city": city + "",
                "district": district + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'reverseGeocode',
        value: function reverseGeocode(longitude, latitude, success, error) {
            this.webserviceApdater(_reverseGeocode, {
                "longitude": longitude + "",
                "latitude": latitude + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'update',
        value: function update(deviceId, isApp, config, success, error) {
            this.webserviceApdater(_update, {
                "deviceId": this.deviceId + "",
                "isApp": parseInt(isApp),
                "config": config
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'list',
        value: function list(deviceId, success, error) {
            this.webserviceApdater(_list, {
                "deviceId": this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'statuslist',
        value: function statuslist(deviceId, success, error) {
            this.webserviceApdater(_statuslist, {
                "deviceId": this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'receivesMessage',
        value: function receivesMessage(deviceId, success, error) {
            this.webserviceApdater(_receivesMessage, {
                "deviceId": this.deviceId + "",
                "type": "",
                "messageType": 800,
                "from": "",
                "size": "",
                "sort": 1
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'manual',
        value: function manual(deviceId, success, error) {
            this.webserviceApdater(_manual, {
                "deviceId": this.deviceId + "",
                "isApp": 1
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'deletePicture',
        value: function deletePicture(deviceId, success, error) {
            this.webserviceApdater(_deletePicture, {
                "deviceId": this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'addPicture',
        value: function addPicture(deviceId, picUrl, success, error) {
            this.webserviceApdater(_addPicture, {
                deviceId: this.deviceId + "",
                url: picUrl + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'addPictureList',
        value: function addPictureList(deviceId, urls, success, error) {
            this.webserviceApdater(_addPictureList, {
                deviceId: this.deviceId + "",
                urls: urls
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'getPictureList',
        value: function getPictureList(deviceId, success, error) {
            this.webserviceApdater(_getPictureList, {
                deviceId: this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'getOurterUrlInfo',
        value: function getOurterUrlInfo(success, error) {
            this.webserviceApdater(_getOurterUrlInfo, {}, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        // activityList

    }, {
        key: 'getActivityList',
        value: function getActivityList(userId, success, error) {
            // nativeService.alert(1)
            this.webserviceApdater(activityList, {
                appId: '1010',
                userId: userId
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'getActivityToken',
        value: function getActivityToken(param, success, error) {
            this.webserviceApdater(activityToken, {
                appId: '1010',
                userId: param.userId,
                activityUUID: param.uuid
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'getStateList',
        value: function getStateList(param, success, error) {
            this.webserviceApdater(stateListUrl, param, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }

        // const addSchedule = "/schedule/add"; //添加预约
        // const updateSchedule  = "/schedule/update"; //修改预约
        // const removeSchedule = "/schedule/remove"; // 删除预约
        // const openSchedule = "/schedule/open"; //开启预约
        // const getListSchedule = "/schedule/getList";

    }, {
        key: 'addSchedule',
        value: function addSchedule(switcher, time, week, repeat, status, temperature, wind, mode, label, timezone, userId, appId, timeType, success, error) {
            this.webserviceApdater(_addSchedule, {
                applianceId: this.deviceId + "",
                switcher: switcher,
                time: time,
                week: week,
                repeat: repeat,
                status: status,
                temperature: temperature,
                wind: wind,
                mode: mode,
                label: label,
                timezone: timezone,
                userId: userId,
                appId: appId,
                time_type: timeType
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'updateSchedule',
        value: function updateSchedule(scheduleId, switcher, time, week, repeat, status, temperature, wind, mode, label, timezone, userId, appId, timeType, success, error) {
            // let a = {
            //     scheduleId:scheduleId,
            //     switcher:switcher,
            //     time:time,
            //     week:week,
            //     repeat:repeat,
            //     status:status,
            //     temperature:temperature,
            //     wind:wind,
            //     mode:mode,
            //     label:label,
            //     timezone:timezone,
            //     userId:userId,
            //     appId:appId,
            //     time_type:timeType
            // }
            // nativeService.alert(JSON.stringify(a))
            this.webserviceApdater(_updateSchedule, {
                scheduleId: scheduleId,
                switcher: switcher,
                time: time,
                week: week,
                repeat: repeat,
                status: status,
                temperature: temperature,
                wind: wind,
                mode: mode,
                label: label,
                timezone: timezone,
                userId: userId,
                appId: appId,
                time_type: timeType
            }, function (data) {
                // nativeService.alert(data)
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(errorMsg)
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'removeSchedule',
        value: function removeSchedule(scheduleId, success, error) {
            this.webserviceApdater(_removeSchedule, {
                scheduleId: scheduleId
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'openSchedule',
        value: function openSchedule(scheduleId, success, error) {
            this.webserviceApdater(_openSchedule, {
                scheduleId: scheduleId
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'closeSchedule',
        value: function closeSchedule(scheduleId, success, error) {
            this.webserviceApdater(_closeSchedule, {
                scheduleId: scheduleId
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'getListSchedule',
        value: function getListSchedule(success, error) {
            this.webserviceApdater(_getListSchedule, {
                applianceId: this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 查询Favorite列表
         * @param success
         * @param error
         */

    }, {
        key: 'queryFavoriteList',
        value: function queryFavoriteList(userId, success, error) {
            // nativeService.alert(`${this.deviceId}--${userId}`)
            this.webserviceApdater(favoriteListUrl, {
                applianceId: this.deviceId + "",
                userId: userId + "",
                // applianceId : "24189255812049",
                // userId: "457300",
                appId: '1010',
                page: 1,
                pageSize: 1000
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'addFavorite',
        value: function addFavorite(param, success, error) {
            param.applianceId = this.deviceId + "";
            param.appId = '1010';
            this.webserviceApdater(addFavoriteUrl, param, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'updateFavorite',
        value: function updateFavorite(param, success, error) {
            param.applianceId = this.deviceId + "";
            param.appId = '1010';
            this.webserviceApdater(updateFavoriteUrl, param, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'deleteFavorite',
        value: function deleteFavorite(param, success, error) {
            param.applianceId = this.deviceId + "";
            param.appId = '1010';
            this.webserviceApdater(deleteFavoriteUrl, param, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 密码锁
         * @param success
         * @param error
         */

    }, {
        key: 'digiremoteQueryPwd',
        value: function digiremoteQueryPwd(userId, success, error) {
            this.webserviceApdater(digiremoteUrl + '/queryPwd', {
                applianceId: this.deviceId + "",
                userId: userId + "",
                appId: '1010'
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'digiremoteCreatePwd',
        value: function digiremoteCreatePwd(param, success, error) {
            this.webserviceApdater(digiremoteUrl + '/createPwd', {
                applianceId: this.deviceId + "",
                userId: param.userId,
                appId: '1010',
                deviceSn: this.initDsn(this.deviceSn) + "",
                deviceType: '0xAC',
                password: param.password,
                applianceBleMac: param.applianceBleMac,
                enable: param.enable || true
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'digiremoteResetPwd',
        value: function digiremoteResetPwd(param, success, error) {
            this.webserviceApdater(digiremoteUrl + '/resetPwd', {
                userId: param.userId,
                appId: '1010',
                deviceSn: param.deviceSn + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'digiremoteModifyPwd',
        value: function digiremoteModifyPwd(param, success, error) {
            this.webserviceApdater(digiremoteUrl + '/modifyPwd', {
                applianceId: this.deviceId + "",
                userId: param.userId,
                appId: '1010',
                password: param.password
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'digiremoteVerifyPwd',
        value: function digiremoteVerifyPwd(param, success, error) {
            this.webserviceApdater(digiremoteUrl + '/verifyPwd', {
                applianceId: this.deviceId + "",
                userId: param.userId,
                appId: '1010',
                password: param.password
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'digiremoteEnablePwd',
        value: function digiremoteEnablePwd(param, success, error) {
            // nativeService.alert(JSON.stringify(
            //     {
            //         applianceId : this.deviceId+"",
            //         userId: param.userId,
            //         appId: '1010',
            //         enable: param.enable,
            //     }
            // ))
            this.webserviceApdater(digiremoteUrl + '/enablePwd', {
                applianceId: this.deviceId + "",
                userId: param.userId,
                appId: '1010',
                enable: param.enable
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'initDsn',
        value: function initDsn(data) {
            return data.length == 32 ? data.slice(6, -4) : data.length == 28 ? data.slice(6) : data;
        }

        /**
         * 查询电量控制范围
         * @param success
         * @param error
         */

    }, {
        key: 'electricityLimitQuery',
        value: function electricityLimitQuery(success, error) {
            this.webserviceApdater(_electricityLimitQuery, {
                applianceId: this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 获取电量限额
         * @param success
         * @param error
         */

    }, {
        key: 'electricityQueryLimit',
        value: function electricityQueryLimit(success, error) {
            this.webserviceApdater(_electricityQueryLimit, {
                applianceId: this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 开启电量限额
         * @param limitValue
         * @param time
         * @param success
         * @param error
         */

    }, {
        key: 'electricityStartLimit',
        value: function electricityStartLimit(limitValue, time, success, error) {
            this.webserviceApdater(_electricityStartLimit, {
                applianceId: this.deviceId + "",
                limitValue: limitValue + "",
                time: time + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 关闭电量限额
         * @param success
         * @param error
         */

    }, {
        key: 'electricityStopLimit',
        value: function electricityStopLimit(success, error) {
            this.webserviceApdater(_electricityStopLimit, {
                applianceId: this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 获取睡眠曲线及状态
         * @param success
         * @param error
         */

    }, {
        key: 'getSleepCurveStatus',
        value: function getSleepCurveStatus(mode, temp, success, error) {
            this.webserviceApdater(_getSleepCurveStatus, {
                applianceId: this.deviceId + "",
                mode: mode
            }, function (data) {
                // nativeService.alert(JSON.stringify(data)+'raw');
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorCode)+'raw'+JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 开启舒睡曲线
         * @param type 曲线类型，1成人曲线，2儿童曲线，3老人曲线，4自定义曲线
         * @param mode 空调模式，2制冷模式，4制热模式
         * value: 自定义曲线的温度值，只有type为4自定义曲线时，value0到value9必填
         * @param value0
         * @param value1
         * @param value2
         * @param value3
         * @param value4
         * @param value5
         * @param value6
         * @param value7
         * @param value8
         * @param value9
         * @param success
         * @param error
         */

    }, {
        key: 'startSleepCurve',
        value: function startSleepCurve(type, mode, value0, value1, value2, value3, value4, value5, value6, value7, value8, value9, success, error) {
            this.webserviceApdater(_startSleepCurve, {
                applianceId: this.deviceId + "",
                type: type,
                value0: value0,
                value1: value1,
                value2: value2,
                value3: value3,
                value4: value4,
                value5: value5,
                value6: value6,
                value7: value7,
                value8: value8,
                value9: value9
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 关闭舒睡功能
         * @param success
         * @param error
         */

    }, {
        key: 'CloseSleepCurve',
        value: function CloseSleepCurve(success, error) {
            this.webserviceApdater(closeSleepCurve, {
                applianceId: this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 修改自定义曲线
         * 调用更新接口后默认打开睡眠曲线，协议接口中增加一个字段isStart用来表示更新后是否开启或关闭，APP默认发送打开
         * 自定义曲线服务器需要给一个默认值，制冷睡眠曲线给26度，制热睡眠曲线给20度，修改后默认开启，备注：睡眠曲线在APP界面呈现一条，但后台要区分制热睡眠曲线和制冷睡眠曲线
         * @param type
         * @param mode
         * @param value0
         * @param value1
         * @param value2
         * @param value3
         * @param value4
         * @param value5
         * @param value6
         * @param value7
         * @param value8
         * @param value9
         * @param isStart
         * @param success
         * @param error
         */

    }, {
        key: 'updateSleepCurve',
        value: function updateSleepCurve(type, mode, value0, value1, value2, value3, value4, value5, value6, value7, value8, value9, isStart, success, error) {
            this.webserviceApdater(_updateSleepCurve, {
                applianceId: this.deviceId + "",
                type: type,
                mode: mode,
                value0: value0,
                value1: value1,
                value2: value2,
                value3: value3,
                value4: value4,
                value5: value5,
                value6: value6,
                value7: value7,
                value8: value8,
                value9: value9,
                isStart: isStart
            }, function (data) {
                // nativeService.alert(data);
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(errorMsg);
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 查询用电
         * @param type 1表示获取某周每天电量，2表示获取某月每天电量，3表示获取某年每月电量，默认为2
         * @param date 当前日期 格式如”2014-10-09
         * @param success
         * @param error
         */

    }, {
        key: 'queryElec',
        value: function queryElec(type, date, success, error) {
            this.webserviceApdater(_queryElec, {
                applianceId: this.deviceId + "",
                type: type,
                date: date
            }, function (data) {
                // nativeService.alert(JSON.stringify(data));
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 获取产品说明
         * @param langCode 通用的国家语言码
         * @param success
         * @param error
         * */

    }, {
        key: 'getProductDesc',
        value: function getProductDesc(langCode, success, error) {
            var lang = langMap[langCode] !== undefined ? langMap[langCode] : 'english';

            this.webserviceApdater(productDesc, {
                type: "AC",
                appId: this.deviceId + "",
                lang: lang
            }, function (data) {
                success && success(JSON.parse(data.data));
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 查询OTA版本
         * @param success
         * @param error
         * */

    }, {
        key: 'queryOtaStaus',
        value: function queryOtaStaus(success, error, cacheCallback) {
            this.webserviceApdater(_queryOtaStaus, {
                applianceId: this.deviceId + "",
                userId: this.familyId + ""
            }, function (data) {
                // nativeService.alert(data)
                success && success(JSON.parse(data.data));
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            }, true, function (data) {
                cacheCallback && cacheCallback(JSON.parse(data.data));
            });

            if (this.mockMode) {
                var data = _web2.default['queryOtaStaus'];
                if (this.runtimeTestData.status == undefined) {
                    this.runtimeTestData.status = data.result.status;
                }
                data.result.status = this.runtimeTestData.status;
                this.runtimeTestData.status++;
                this.runtimeTestData.status > 3 && (this.runtimeTestData.status = -1);
                success && success(data);
            }
        }
        /**
         * 查询是否需要升级 Function页 Firmware Update 后面基于 needUpdate = 1 时显示需要升级的红点 
         * @param success
         * @param error
         * */

    }, {
        key: 'queryNeedUpdateStaus',
        value: function queryNeedUpdateStaus(success, error) {
            this.webserviceApdater(_queryOtaStaus, {
                applianceId: this.deviceId + "",
                userId: this.familyId + ""
            }, function (data) {
                // nativeService.alert(123)
                success && success(JSON.parse(data.data));
            }, function (errorCode, errorMsg) {
                // nativeService.alert(errorMsg)
                error && error(errorCode, errorMsg);
            });

            // let functionParamers = {
            //     queryStrings: {
            //         "serviceUrl": queryOtaStaus
            //     },
            //     transmitData: {
            //         applianceId : this.deviceId+"",
            //         userId: this.familyId+"",
            //     }
            // };
            // // nativeService.alert(functionParamers)
            // nativeService.requestDataTransmit(functionParamers).then((messageBack)=>{
            //     success && success(messageBack);
            // },(errorMsg)=>{
            //     error && error(errorMsg);
            // });
        }
        /**
        * 升级OTA
        * @param success
        * @param error
        * */

    }, {
        key: 'upgradeWifi',
        value: function upgradeWifi(success, error) {
            this.webserviceApdater(_upgradeWifi, {
                applianceId: this.deviceId + "",
                userId: this.familyId + ""
            }, function (data) {
                success && success(JSON.parse(data.data));
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 取消升级OTA
         * @param success
         * @param error
         * */

    }, {
        key: 'abandonUpgradeWifi',
        value: function abandonUpgradeWifi(success, error) {
            this.webserviceApdater(_abandonUpgradeWifi, {
                applianceId: this.deviceId + "",
                userId: this.familyId + ""
            }, function (data) {
                success && success(JSON.parse(data.data));
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        /**
         * 设置自动升级OTA
         * @param auto 自动升级：1； 手工升级：0.
         * @param success
         * @param error
         * */

    }, {
        key: 'setAutoUpgradeWifi',
        value: function setAutoUpgradeWifi(auto, success, error) {
            this.webserviceApdater(_setAutoUpgradeWifi, {
                applianceId: this.deviceId + "",
                userId: this.familyId + "",
                auto: auto ? 1 : 0
            }, function (data) {
                success && success(JSON.parse(data.data));
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'getVoiceCtrlDevicesList',
        value: function getVoiceCtrlDevicesList(sceneType, success, error) {
            // var applianceId = nativeService.getCurrentApplianceID();
            var functionParamers = {
                url: getVoiceCtrlDevicesListUrl,
                params: {
                    homegroupId: this.familyId + '',
                    sceneType: sceneType + '',
                    masterId: this.deviceId + '',
                    sceneId: 0 + '',
                    stamp: new Date().getTime(),
                    reqId: this.generateUUID()
                }
            };
            console.log('start');
            _nativeService2.default.sendCentralCloundRequest(getVoiceCtrlDevicesListUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json;charset=utf-8'
                },
                data: functionParamers.params
            }).then(function (data) {
                // nativeService.alert(JSON.stringify(data));
                console.log(JSON.stringify(data));
                success && success(data);
            }).catch(function (errorMsg) {
                error && error(-1, errorMsg);
            });
            console.log('end');
        }

        /**
         * 删除设备接口
         * @param {*} sceneType 
         * @param {*} success 
         * @param {*} error 
         */

    }, {
        key: 'deleteDevice',
        value: function deleteDevice(deviceId, success, error) {
            // var applianceId = nativeService.getCurrentApplianceID();
            var functionParamers = {
                url: unbindDevice,
                params: {
                    applianceId: this.deviceId + '',
                    src: "0",
                    stamp: new Date().getTime(),
                    reqId: this.generateUUID()
                }
                // nativeService.alert("!!!");
            };_nativeService2.default.sendCentralCloundRequest(functionParamers.url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json;charset=utf-8'
                },
                data: functionParamers.params
            }).then(function (data) {
                // nativeService.alert(JSON.stringify(data));
                console.log(JSON.stringify(data));
                success && success(data);
            }).catch(function (errorMsg) {
                error && error(-1, errorMsg);
            });
            console.log('end');
        }
        /**
             * 绑定设备接口
             * @param {*} sceneType 
             * @param {*} success 
             * @param {*} error 
             */

    }, {
        key: 'bindDevice',
        value: function bindDevice(param, success, error) {
            // var applianceId = nativeService.getCurrentApplianceID();
            var functionParamers = {
                url: _bindDevice,
                params: {
                    referSn: param.referSn || '',
                    applianceName: param.applianceName || '',
                    applianceType: param.applianceType || '',
                    modelNumber: param.modelNumber || '',
                    applianceDes: param.applianceDes || '',
                    mac: param.mac || '',
                    language: param.language || 'zh_CN',
                    timeZoneID: param.timeZoneID,
                    src: "0",
                    stamp: new Date().getTime(),
                    reqId: this.generateUUID()
                }
                // nativeService.alert(JSON.stringify(functionParamers));
            };_nativeService2.default.sendCentralCloundRequest(functionParamers.url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json;charset=utf-8'
                },
                data: functionParamers.params
            }).then(function (data) {
                // nativeService.alert(JSON.stringify(data));
                // nativeService.alert('suc==='+JSON.stringify(data))
                success && success(data);
            }).catch(function (errorMsg) {
                // nativeService.alert('err==='+JSON.stringify(errorMsg))
                error && error(errorMsg);
            });
        }

        /**
         * 获取用户家电列表 
         * @param {*} sceneType 
         * @param {*} success 
         * @param {*} error 
         */

    }, {
        key: 'userListGet',
        value: function userListGet(userid, success, error) {
            // nativeService.alert(444);
            var functionParamers = {
                url: _userListGet,
                params: {
                    applianceId: this.deviceId + '',
                    src: "0",
                    stamp: new Date().getTime(),
                    reqId: this.generateUUID()
                }
                // nativeService.alert("!!!");
            };_nativeService2.default.sendCentralCloundRequest(functionParamers.url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json;charset=utf-8'
                },
                data: functionParamers.params
            }, { isShowLoading: false }).then(function (data) {
                // nativeService.alert(JSON.stringify(data));
                console.log(JSON.stringify(data));
                success && success(data);
            }).catch(function (errorMsg) {
                error && error(-1, errorMsg);
            });
            console.log('end');
        }
        //

    }, {
        key: 'infoModify',
        value: function infoModify(applianceName, success, error) {

            // nativeService.alert("112233");
            // var applianceId = nativeService.getCurrentApplianceID();
            var functionParamers = {
                url: _infoModify,
                params: {
                    appId: '1010',
                    applianceId: this.deviceId + '',
                    applianceName: applianceName,
                    src: "0",
                    stamp: new Date().getTime(),
                    reqId: this.generateUUID()
                }
                //   nativeService.alert("!!!");
            };_nativeService2.default.sendCentralCloundRequest(functionParamers.url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json;charset=utf-8'
                },
                data: functionParamers.params
            }).then(function (data) {
                //   nativeService.alert(JSON.stringify(data));
                //   console.log(JSON.stringify(data))
                success && success(data);
            }).catch(function (errorMsg) {
                error && error(-1, errorMsg);
            });
            console.log('end');
        }

        /**
        * 一键报修
        * @param {*} sceneType 
        * @param {*} success 
        * @param {*} error 
        */

    }, {
        key: 'iserviceGet',
        value: function iserviceGet(userid, success, error) {
            // // nativeService.alert(weex.config.env.version);
            var functionParamers = {
                url: _iserviceGet,
                params: {}
                // nativeService.alert("!!!");
            };_nativeService2.default.sendCentralCloundRequest(functionParamers.url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json;charset=utf-8',
                    'version': weex.config.env.appVersion
                },
                data: functionParamers.params
            }).then(function (data) {
                // nativeService.alert(JSON.stringify(data));
                console.log(JSON.stringify(data));
                success && success(data);
            }).catch(function (errorMsg) {
                error && error(-1, errorMsg);
            });
            console.log('end');
        }

        /**
        * 电子说明书
        * @param {*} sceneType 
        * @param {*} success 
        * @param {*} error 
        */

    }, {
        key: 'getUserGuide',
        value: function getUserGuide(param, success, error) {
            // // nativeService.alert(weex.config.env.version);
            var functionParamers = {
                url: userGuideUrl,
                params: {
                    language: param.language,
                    countryCode: param.countryCode,
                    brand: 'Midea',
                    code: param.sn8
                }
            };
            _nativeService2.default.sendCentralCloundRequest(functionParamers.url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json;charset=utf-8',
                    'version': weex.config.env.appVersion
                },
                data: functionParamers.params
            }).then(function (data) {
                // nativeService.alert(JSON.stringify(data));
                console.log(JSON.stringify(data));
                success && success(data);
            }).catch(function (errorMsg) {
                error && error(-1, errorMsg);
            });
            console.log('end');
        }

        /**
         * 联系我们
         * @param {*} sceneType 
         * @param {*} success 
         * @param {*} error 
         */

    }, {
        key: 'getContactUs',
        value: function getContactUs(param, success, error) {
            // // nativeService.alert(weex.config.env.version);
            var functionParamers = {
                url: contactUsUrl,
                params: {
                    language: param.language,
                    region: param.countryCode,
                    platform: 'mjapp',
                    brand: 'Midea'
                }
            };
            _nativeService2.default.sendCentralCloundRequest(functionParamers.url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json;charset=utf-8',
                    'version': weex.config.env.appVersion
                },
                data: functionParamers.params
            }).then(function (data) {
                // nativeService.alert(JSON.stringify(data));
                console.log(JSON.stringify(data));
                success && success(data);
            }).catch(function (errorMsg) {
                error && error(-1, errorMsg);
            });
        }

        /**
        * 智能诊断
        * @param {*} sceneType 
        * @param {*} success 
        * @param {*} error 
        */

    }, {
        key: 'getTroubleshooting',
        value: function getTroubleshooting(param, success, error) {
            // // nativeService.alert(weex.config.env.version);
            var functionParamers = {
                url: troubleshootingUrl,
                params: param
            };
            _nativeService2.default.sendCentralCloundRequest(functionParamers.url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json;charset=utf-8',
                    'version': weex.config.env.appVersion
                },
                data: functionParamers.params
            }).then(function (data) {
                // nativeService.alert(JSON.stringify(data));
                console.log(JSON.stringify(data));
                success && success(data);
            }).catch(function (errorMsg) {
                error && error(-1, errorMsg);
            });
        }

        // 节能区间

    }, {
        key: 'queryEnnoRange',
        value: function queryEnnoRange(countryCode, success, error) {
            // nativeService.alert(`${this.deviceId}--${userId}`)
            this.webserviceApdater(ennoRange, {
                // applianceId : this.deviceId+"",
                countryCode: countryCode + ""
                // applianceId : "24189255812049",
                // userId: "457300",
                // appId: '1010',
                // page: 1,
                // pageSize: 1000
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }

        // 更新睡眠曲线

    }, {
        key: 'curveModify',
        value: function curveModify(curveId, applianceId, sn, userId, duration, tempCurve, fanSpeed, endClose, success, error) {
            // nativeService.alert(`${this.deviceId}--${userId}`)
            this.webserviceApdater(_curveModify, {
                curveId: curveId,
                applianceId: applianceId,
                sn: sn,
                userId: userId,
                duration: duration,
                tempCurve: tempCurve,
                fanSpeed: fanSpeed,
                endClose: endClose,
                appId: '1010'
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
        // 启动睡眠曲线

    }, {
        key: 'curveRun',
        value: function curveRun(curveId, userId, applianceId, sn, time, timezone, success, error) {
            this.webserviceApdater(_curveRun, {
                curveId: curveId,
                userId: userId,
                applianceId: applianceId,
                sn: sn,
                time: time,
                timezone: timezone,
                appId: '1010'
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
        // // 停止睡眠曲线
        // curveStop(curveId,userId,applianceId,sn,time,timezone, success,error) {
        //     this.webserviceApdater(curveStop,{
        //         curveId : curveId,
        //         userId: userId,
        //         applianceId: applianceId,
        //         sn : sn,
        //         time:time,
        //         timezone:timezone,
        //         appId:'1010'
        //     },(data)=>{
        //         success && success(data);
        //     },(errorCode,errorMsg)=>{
        //         error && error(errorCode,errorMsg);
        //     })
        // }
        // 停止睡眠曲线

    }, {
        key: 'curveStop',
        value: function curveStop(curveId, userId, applianceId, sn, success, error) {
            this.webserviceApdater(_curveStop, {
                curveId: curveId,
                userId: userId,
                applianceId: applianceId,
                sn: sn,
                appId: '1010'
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
        // 查询睡眠曲线

    }, {
        key: 'curveDetail',
        value: function curveDetail(curveId, applianceId, sn, duration, userId, mode, area, scale, success, error) {
            // nativeService.alert(33)
            this.webserviceApdater(_curveDetail, {
                curveId: curveId,
                applianceId: applianceId,
                sn: sn,
                duration: duration,
                userId: userId,
                mode: mode,
                area: area,
                scale: scale,
                appId: '1010'
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        // 查询推荐AI曲线

    }, {
        key: 'curveRecommend',
        value: function curveRecommend(curveId, applianceId, sn, duration, userId, mode, area, scale, success, error) {
            this.webserviceApdater(_curveRecommend, {
                curveId: curveId,
                applianceId: applianceId,
                sn: sn,
                duration: duration,
                userId: userId,
                mode: mode,
                area: area,
                scale: scale,
                appId: '1010'
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        // 节能区间

    }, {
        key: 'checkIeco',
        value: function checkIeco(success, error) {
            this.webserviceApdater(iecoUrl, {
                applianceId: this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'getIntelligent',
        value: function getIntelligent(params, success, error) {
            // nativeService.alert(JSON.stringify(
            //     {
            //         appId:'1010',
            //         applianceId : this.deviceId+"",
            //         sn: this.deviceSn+"",
            //         date: params.date,
            //         zoneId: params.zoneId,
            //         timezone: params.timezone,
            //         userId: params.userId,
            //         region: params.region,
            //         ieco: params.ieco,
            //         lat: params.lat,
            //         lng: params.lng
            //     }
            // ))
            this.webserviceApdater(intelligentIndex, {
                appId: '1010',
                applianceId: this.deviceId + "",
                sn: this.deviceSn + "",
                // applianceId : '178120883701863',
                // sn: '000000P0000000Q1D8341CEDB7380000',
                date: params.date,
                zoneId: params.zoneId,
                timezone: params.timezone,
                userId: params.userId,
                region: params.region,
                ieco: params.ieco,
                lat: params.lat,
                lng: params.lng
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'getFirstConnectTime',
        value: function getFirstConnectTime(success, error) {
            this.webserviceApdater(firstTimeConnect, {
                applianceCode: this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
        // 刷新wifi版本信息

    }, {
        key: 'otaRefreshId',
        value: function otaRefreshId(success, error) {
            this.webserviceApdater(_otaRefreshId, {
                applianceId: this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }

        // IECO Report

    }, {
        key: 'powerReport',
        value: function powerReport(sn, timezone, time, localDateTime, userId, zoneId, success, error) {
            this.webserviceApdater(_powerReport, {
                applianceId: this.deviceId + "",
                sn: sn,
                timezone: timezone,
                time: time,
                localDateTime: localDateTime,
                userId: userId,
                zoneId: zoneId
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }

        // 查询IECO target设置

    }, {
        key: 'targetGet',
        value: function targetGet(success, error) {
            this.webserviceApdater(_targetGet, {
                applianceId: this.deviceId + ""
            }, function (data) {
                // nativeService.alert(JSON.stringify(data));
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }

        // 查询IECO target设置

    }, {
        key: 'targetSet',
        value: function targetSet(status, target, period, notiPercentList, zoneId, success, error) {
            // let obj = {
            //     applianceId : this.deviceId+"",
            //     status:status,
            //     target:target,
            //     period:period,
            //     notiPercentList:notiPercentList,
            //     zoneId:zoneId
            // }
            // nativeService.alert(JSON.stringify(obj));
            this.webserviceApdater(_targetSet, {
                applianceId: this.deviceId + "",
                status: status,
                target: target,
                period: period,
                notiPercentList: notiPercentList,
                zoneId: zoneId
            }, function (data) {
                // nativeService.alert(JSON.stringify(data));
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }

        // 电量看板接口

    }, {
        key: 'powerBoast',
        value: function powerBoast(sn, timezone, time, localDateTime, userId, zoneId, powerGroupByType, startDay, endDay, success, error) {
            // let obj = {
            //     applianceId : this.deviceId+"",
            //     sn:sn,
            //     timezone:timezone,
            //     time:time,
            //     localDateTime:localDateTime,
            //     userId:userId,
            //     zoneId:zoneId,
            //     powerGroupByType:powerGroupByType,
            //     startDay:startDay,
            //     endDay:endDay,
            // }
            // nativeService.alert(JSON.stringify(obj));
            this.webserviceApdater(_powerBoast, {
                applianceId: this.deviceId + "",
                sn: sn,
                timezone: timezone,
                time: time,
                localDateTime: localDateTime,
                userId: userId,
                zoneId: zoneId,
                powerGroupByType: powerGroupByType,
                startDay: startDay,
                endDay: endDay
            }, function (data) {
                // nativeService.alert(JSON.stringify(data));
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }

        // 查询固件版本更新

    }, {
        key: 'checkB5VersionUpdate',
        value: function checkB5VersionUpdate(success, error) {
            this.webserviceApdater(checkB5Version, {
                applianceId: this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        // 用户设置

    }, {
        key: 'userPreferencesSet',
        value: function userPreferencesSet(temperatureUnit, timeFormat, appId, userId, success, error) {
            // nativeService.alert(JSON.stringify(11));
            this.webserviceApdater(_userPreferencesSet, {
                // applianceId : this.deviceId+"",
                temperatureUnit: temperatureUnit,
                timeFormat: timeFormat,
                userId: userId,
                appId: '1010'
            }, function (data) {
                // nativeService.alert(JSON.stringify(data));
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }
        // 用户设置查询

    }, {
        key: 'userPreferencesGet',
        value: function userPreferencesGet(userId, success, error) {
            this.webserviceApdater(_userPreferencesGet, {

                userId: userId
                // appId:'1010',
            }, function (data) {
                // nativeService.alert(JSON.stringify(data));
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert(JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'setDeviceB5Info',
        value: function setDeviceB5Info(param, success, error) {
            //传接口的B5数据给数据器
            // nativeService.alert(JSON.stringify(param));
            this.webserviceApdater(deviceB5InfoSet, {
                appId: '1010',
                applianceId: this.deviceId + "",
                // applianceType: 'AC',
                sn: this.deviceSn + "",
                rawB5: param
            }, function (data) {
                // nativeService.alert('suc==='+JSON.stringify(data));
                success && success(data);
            }, function (errorCode, errorMsg) {
                // nativeService.alert('err==='+JSON.stringify(errorMsg));
                error && error(errorCode, errorMsg);
            });
        }

        //iCheck ********************************************
        // 手动检测

    }, {
        key: 'checkByhand',
        value: function checkByhand(param, success, error) {
            this.webserviceApdater(_checkByhand, param, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'queryFilterCheck',
        value: function queryFilterCheck(success, error) {
            //滤网过期检测
            this.webserviceApdater(filterUrl + '/expire/check', {
                applianceId: this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'queryDeviceReportData',
        value: function queryDeviceReportData(success, error) {
            //滤网过期检测
            this.webserviceApdater('' + checkB5Url, {
                applianceId: this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'queryCoolFlashStatus',
        value: function queryCoolFlashStatus(success, error) {
            //查询coolflash
            this.webserviceApdater(_queryCoolFlashStatus, {
                applianceId: this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'setFilterRemind',
        value: function setFilterRemind(param, success, error) {
            //滤网过期提醒通知设置
            this.webserviceApdater(filterUrl + '/expire/setRemind', {
                applianceId: this.deviceId + "",
                allowExpireRemind: param.allowExpireRemind
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        // 手动取消检测

    }, {
        key: 'byhandCancel',
        value: function byhandCancel(param, success, error) {
            this.webserviceApdater(_byhandCancel, param, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'coolFlashEnabled',
        value: function coolFlashEnabled(param, success, error) {
            //coolflash 开关
            this.webserviceApdater(_coolFlashEnabled, {
                applianceId: this.deviceId + "",
                flag: param.flag
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'setFilterLife',
        value: function setFilterLife(param, success, error) {
            //设置滤网最大生命值
            this.webserviceApdater(filterUrl + '/setLife', {
                applianceId: this.deviceId + "",
                life: param.life
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        // 网络情况反馈接口

    }, {
        key: 'networkTime',
        value: function networkTime(param, success, error) {
            this.webserviceApdater(_networkTime, param, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'queryFilterDetail',
        value: function queryFilterDetail(success, error) {
            //滤网详情
            this.webserviceApdater(filterUrl + '/life/detail', {
                applianceId: this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'setCoolFlashConfig',
        value: function setCoolFlashConfig(param, success, error) {
            //coolflash 配置
            this.webserviceApdater(_setCoolFlashConfig, {
                applianceId: this.deviceId + "",
                duration: param.time,
                temperature: param.temp
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'setFilterReset',
        value: function setFilterReset(param, success, error) {
            //滤网重置
            this.webserviceApdater(filterUrl + '/reset', {
                applianceId: this.deviceId + "",
                date: param.date,
                zoneId: param.zoneId
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        // 定时检测回调接口

    }, {
        key: 'taskExecution',
        value: function taskExecution(param, success, error) {
            this.webserviceApdater(_taskExecution, param, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
        // 设备检测历史分页查询

    }, {
        key: 'historyList',
        value: function historyList(param, success, error) {
            this.webserviceApdater(_historyList, param, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
        // 设备检测历史详情查询

    }, {
        key: 'historyDetail',
        value: function historyDetail(param, success, error) {
            this.webserviceApdater(_historyDetail, param, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
        // 最新检测时间查询

    }, {
        key: 'historyLatestChecktime',
        value: function historyLatestChecktime(param, success, error) {
            this.webserviceApdater(_historyLatestChecktime, param, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
        // 随机维护保养建议

    }, {
        key: 'supportSuggestion',
        value: function supportSuggestion(param, success, error) {
            this.webserviceApdater(_supportSuggestion, param, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
        // 用户配置-通知设置

    }, {
        key: 'settingNotification',
        value: function settingNotification(param, success, error) {
            this.webserviceApdater(_settingNotification, param, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
        // 用户配置-定时检测

    }, {
        key: 'settingTiming',
        value: function settingTiming(param, success, error) {
            this.webserviceApdater(_settingTiming, param, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
        // 用户配置-查询所有设置

    }, {
        key: 'getSetting',
        value: function getSetting(param, success, error) {
            this.webserviceApdater(_getSetting, param, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
        // 用户配置-开机检测设置

    }, {
        key: 'settingPowerOn',
        value: function settingPowerOn(param, success, error) {
            this.webserviceApdater(_settingPowerOn, param, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
    }, {
        key: 'queryFilterNotify',
        value: function queryFilterNotify(success, error) {
            //滤网记录
            this.webserviceApdater(filterUrl + '/listMaintenance', {
                applianceId: this.deviceId + "",
                page: 1,
                pageSize: 1000
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }
        // check

    }, {
        key: 'getCheckGroupList',
        value: function getCheckGroupList(success, error) {
            this.webserviceApdater(checkGroupListUrl, {
                applianceId: this.deviceId + ""
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        // 获取设备地区id

    }, {
        key: 'getZoneId',
        value: function getZoneId(clientType, success, error) {
            var functionParamers = {
                url: _getZoneId,
                params: {
                    reqId: this.generateUUID(),
                    src: 0,
                    appId: '1010',
                    clientType: clientType,
                    stamp: new Date().getTime(),
                    type: 2,
                    mes: this.deviceId + ""
                }
            };

            _nativeService2.default.sendCentralCloundRequest(functionParamers.url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json;charset=utf-8'
                },
                data: functionParamers.params
            }).then(function (data) {
                // nativeService.alert(JSON.stringify(data));
                success && success(data);
            }).catch(function (errorMsg) {
                // nativeService.alert('err==='+JSON.stringify(errorMsg))
                error && error(errorMsg);
            });
        }
    }, {
        key: 'getCheckGroupCheck',
        value: function getCheckGroupCheck(param, success, error) {
            this.webserviceApdater(checkGroupChecktUrl, {
                applianceId: this.deviceId + "",
                groupId: param.groupId
            }, function (data) {
                success && success(data);
            }, function (errorCode, errorMsg) {
                error && error(errorCode, errorMsg);
            });
        }

        // end ************************************************************

    }, {
        key: 'generateUUID',
        value: function generateUUID() {
            var d = new Date().getTime();
            var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                var r = (d + Math.random() * 16) % 16 | 0;
                d = Math.floor(d / 16);
                return (c === 'x' ? r : r & 0x3 | 0x8).toString(16);
            });
            return uuid;
        }

        /***************************************base support func***************************************/

    }, {
        key: 'webserviceApdater',
        value: function webserviceApdater(url, parameters, success, error, _hasCache, cacheCallback) {
            console.log(url + "------url");
            _SLKDecorator2.default.MSmartUserDeviceManager.webserviceApdater(this.isViaServer, url, parameters, success, error, _hasCache, cacheCallback);
        }
    }]);

    return WebComDecorator;
}();

exports.default = WebComDecorator;

/***/ }),

/***/ 33:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }(); /**
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      * Created by liujim on 2017/9/25.
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      */


var _Helper = __webpack_require__(2);

var _Helper2 = _interopRequireDefault(_Helper);

var _nativeService = __webpack_require__(1);

var _nativeService2 = _interopRequireDefault(_nativeService);

var _WeexLayer = __webpack_require__(7);

var _WeexLayer2 = _interopRequireDefault(_WeexLayer);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var broadcastChannel = new BroadcastChannel('appPageData');

var MaxDelay = 3 * 1000;

var HasCache = false;

var MSmartUserManager = function () {
    function MSmartUserManager() {
        _classCallCheck(this, MSmartUserManager);
    }

    _createClass(MSmartUserManager, null, [{
        key: 'getUserInfo',
        value: function getUserInfo(success) {
            //todo
        }
    }]);

    return MSmartUserManager;
}();

var MSmartUserDeviceManager = function () {
    function MSmartUserDeviceManager() {
        _classCallCheck(this, MSmartUserDeviceManager);
    }

    _createClass(MSmartUserDeviceManager, null, [{
        key: 'getDeviceID',
        value: function getDeviceID(isWechat) {
            if (isWechat) {
                return localStorage.getItem('applianceId');
            } else {
                return bridge.getCurrentApplianceID();
            }
        }

        //getDeviceSN

        /***************************************************基础公用接口***************************************************/

    }, {
        key: 'getDeviceSN',
        value: function getDeviceSN(isWechat) {
            if (isWechat) {
                return localStorage.getItem('sn');
            } else {
                return bridge.getCurrentDevSN();
            }
        }

        /***************************************************设备通信接口***************************************************/

    }, {
        key: 'sendDeviceData',
        value: function sendDeviceData(deviceID, sendBitsDecimal, tag, context) {
            console.log("MSTransportNotification -- sending", sendBitsDecimal, tag);
            console.log("MSTransportNotification -- sending", _Helper2.default.decimalArrayToHexStrArray(sendBitsDecimal), tag);

            var _context = broadcastChannel;

            var requestToken = new Date().valueOf(); // OR CMD ID

            // Helper.decimalArrayToHexStrArray(sendBitsDecimal)

            return requestToken;
        }

        /***************************************************服务器通信接口***************************************************/

    }, {
        key: 'callWebService',
        value: function callWebService(queryString, _jsonData, success, error, _hasCache, cacheCallback) {
            //fault-tolerance
            var jsonData = {};
            for (var key in _jsonData) {
                if (_jsonData[key] != undefined && _jsonData[key] != null) {
                    jsonData[key] = _jsonData[key];
                }
            }
            // jsonData.type = '0xAC';

            var functionParamers = {
                type: '0xAC',
                queryStrings: {
                    "serviceUrl": queryString
                },
                transmitData: jsonData
            };

            //cache process A
            var hasCache = _hasCache === undefined ? HasCache : _hasCache;
            var uuid = jsonData.applianceId !== undefined ? jsonData.applianceId : "";
            uuid += queryString;
            hasCache && _WeexLayer2.default.getCache(uuid, function (data) {
                data !== null && cacheCallback && cacheCallback(data);
            });

            _nativeService2.default.requestDataTransmit(functionParamers).then(function (data) {
                _Helper2.default.logByTag(data, "======requestDataTransmit======data");

                // nativeService.toast(data);
                // nativeService.alert(JSON.stringify(data));

                //cache process B
                hasCache && _WeexLayer2.default.setCache(uuid, data);
                success && success(data);
            }).catch(function (errorMsg) {
                _Helper2.default.logByTag(errorMsg, "======requestDataTransmit======error");

                // nativeService.toast(errorMsg);

                error && error(-1, errorMsg);
            });
        }
    }, {
        key: 'errorFilter',
        value: function errorFilter(data) {
            if (data.status == 0) {
                if (data.returnData) {
                    var dataObj = JSON.parse(data.returnData);

                    if (dataObj.errCode == 0) {
                        return dataObj.result === undefined ? true : dataObj.result;
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }
    }, {
        key: 'webserviceApdater',
        value: function webserviceApdater(isViaServer, url, parameters, success, error, _hasCache, cacheCallback) {
            var _this = this;

            //todo
            //let cache = this.restoreServerData(url, parameters);
            var cache = false;

            var timerKey = this.generateUri(url, parameters);

            this.callWebService(url, parameters, function (data) {
                _this.resetRequestTimer(timerKey);
                // data && this.cacheServerData(url, parameters, data);
                success && success(data);
            }, function (errorCode, errorMsg) {
                _this.resetRequestTimer(timerKey);

                if (cache !== false) {
                    success && success(cache);
                } else {
                    error && error(errorCode, errorMsg);
                }
            }, _hasCache, cacheCallback);

            // this.resetRequestTimer();
            this.requestTimer[timerKey] = setTimeout(function () {
                if (cache !== false) {
                    success && success(cache);
                }
            }, MaxDelay);
        }
    }, {
        key: 'resetRequestTimer',
        value: function resetRequestTimer(timerKey) {
            this.requestTimer[timerKey] !== null && clearTimeout(this.requestTimer[timerKey]);
        }
    }, {
        key: 'cacheServerData',
        value: function cacheServerData(url, params, data) {
            //todo
            // localStorage.setItem(this.generateUri(url, params), JSON.stringify(data));
            // console.log(this.generateUri(url, params), JSON.stringify(data), "caching....");
        }
    }, {
        key: 'restoreServerData',
        value: function restoreServerData(url, params) {
            //todo
            // let store = localStorage.getItem(this.generateUri(url, params));
            // let result = store !== undefined ? JSON.parse(store) : false;
            // return result;
            return {};
        }
    }, {
        key: 'generateUri',
        value: function generateUri(url, params) {
            return url + JSON.stringify(params);
        }
    }]);

    return MSmartUserDeviceManager;
}();

MSmartUserDeviceManager.requestTimer = [];


var SLKDecorator = {
    MSmartUserManager: MSmartUserManager,
    MSmartUserDeviceManager: MSmartUserDeviceManager
};

exports.default = SLKDecorator;

/***/ }),

/***/ 35:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
var MockData = {
    queryOtaStaus: {
        "errCode": "0",
        "errMsg": "成功",
        "result": {
            "chipType": "6",
            "chipName": "QualComm - QCA4004B",
            "protocolType": "06",
            "protocolName": "mSmart+Homekit",
            "version": "4.0.2",
            "status": 0,
            "statusName": "升级中",
            "needUpdate": 1,
            "updateVersion": "4.0.2",
            "updateVersionDesc": "fix bugs",
            "auto": 0
        }
    },

    upgradeWifi: {
        "errCode": "0",
        "errMsg": "成功",
        "result": {
            "status": 0,
            "statusName": ""
        }
    },

    abandonUpgradeWifi: {
        "errCode": "0",
        "errMsg": "成功",
        "result": {
            "status": 0,
            "statusName": ""
        }
    },

    setAutoUpgradeWifi: {
        "errCode": "0",
        "errMsg": "成功"
    }

};

exports.default = MockData;

/***/ }),

/***/ 5:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }(); /**
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      * Created by liujim on 2017/8/19.
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      */

var _all = __webpack_require__(17);

var _all2 = _interopRequireDefault(_all);

var _nativeService = __webpack_require__(1);

var _nativeService2 = _interopRequireDefault(_nativeService);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Process = function () {
    function Process() {
        _classCallCheck(this, Process);
    }

    _createClass(Process, null, [{
        key: "initLangEnv",
        value: function initLangEnv(callback) {
            var _this = this;

            if (this.currentLanguageCode === null) {
                _nativeService2.default.getLanguage().then(function (data) {
                    //language:zh  country:CN
                    //en, US
                    //ru, RU
                    //it, IT
                    //fr, FR
                    //pt, PT
                    //es,  ES

                    if (data && data.language) {
                        _this.currentLanguageCode = data.language;
                        callback(_this.currentLanguageCode);
                    }
                });
            } else {
                callback(this.currentLanguageCode);
            }
        }
    }, {
        key: "getText",
        value: function getText(mark) {
            var currentLocate = this.currentLanguageCode;
            // nativeService.toast(currentLocate);
            // currentLocate = currentLocate === "es" ? "sp" : currentLocate; //fix  v7版本与IOT的接口对齐，不再作转换

            if (_all2.default[mark] !== undefined) {
                //console.log("translate success", mark, languageData[mark]);

                if (_all2.default[mark][currentLocate] !== undefined) {
                    return _all2.default[mark][currentLocate];
                } else {
                    return _all2.default[mark]["en"];
                }
            } else {
                //console.log("translate error", mark=="", mark, arguments);
                //console.trace();

                return mark;
            }
        }
    }]);

    return Process;
}();

Process.currentLanguageCode = null;
exports.default = Process;

/***/ }),

/***/ 50:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(51)
)

/* script */
__vue_exports__ = __webpack_require__(52)

/* template */
var __vue_template__ = __webpack_require__(53)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/chenhx113/Documents/project/meijuobmweexapp/code/AC/src/T0xAC/components/common/cell.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-7e416c00"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 51:
/***/ (function(module, exports) {

module.exports = {
  "theme-background": {
    "backgroundColor": "#F9F9F9"
  },
  "white-background": {
    "backgroundColor": "#ffffff"
  },
  "theme-background-full": {
    "backgroundColor": "#468EFF"
  },
  "theme-font-color": {
    "color": "#000000"
  },
  "theme-font-orange-color": {
    "color": "#C26033"
  },
  "theme-font-explain-color": {
    "color": "#D8D8DE",
    "opacity": 0.4
  },
  "theme-font-msg-gray-color": {
    "color": "#8A8A8F"
  },
  "theme-font-msg-gray-bg-color": {
    "backgroundColor": "#333333"
  },
  "theme-center-layout": {
    "display": "flex",
    "flexDirection": "row",
    "alignItems": "center"
  },
  "theme-center-layout-wrapper": {
    "display": "flex",
    "flexDirection": "row",
    "alignItems": "center",
    "flexWrap": "wrap"
  },
  "theme-cell-standard-style": {
    "backgroundColor": "#1a1a1a"
  },
  "spacing-line": {
    "width": 750,
    "height": 1,
    "backgroundColor": "#e2e2e2",
    "display": "flex",
    "alignSelf": "center"
  },
  "midea-cell-theme": {
    "height": 124,
    "position": "relative",
    "flexDirection": "row",
    "alignItems": "center",
    "paddingLeft": 32,
    "paddingRight": 32,
    "backgroundColor": "#1a1a1a"
  },
  "active-cell-theme": {
    "backgroundColor:active": "#cccccc"
  },
  "cell-label-text-theme": {
    "fontSize": 30,
    "color": "#666666",
    "width": 188,
    "marginRight": 10
  },
  "right-text-theme": {
    "fontSize": 25,
    "color": "#ffffff"
  },
  "cell-content-theme": {
    "color": "#ffffff",
    "fontSize": 30,
    "lineHeight": 40
  },
  "cell-desc-text-theme": {
    "color": "#999999",
    "fontSize": 24,
    "lineHeight": 30,
    "marginTop": 4
  },
  "cell-top-border-theme": {
    "borderTopColor": "#333333",
    "borderTopWidth": 1,
    "opacity": 0.8
  },
  "cell-bottom-border-theme": {
    "borderBottomWidth": 1,
    "borderBottomStyle": "solid",
    "borderBottomColor": "#333333",
    "opacity": 0.8
  },
  "wrap-theme": {
    "position": "relative",
    "flexDirection": "row",
    "backgroundColor": "#000000"
  },
  "selected-item-theme": {
    "opacity": 1,
    "color": "#ffffff",
    "fontSize": 48
  },
  "unselected-item-theme": {
    "opacity": 0.3,
    "color": "#ffffff"
  },
  "debug-util": {
    "borderWidth": 2,
    "borderColor": "#FF0000"
  },
  "ctrl-page-wrapper": {
    "backgroundColor": "#000000",
    "width": 750
  },
  "ctrl-page-scroller": {
    "flex": 1,
    "zIndex": 99999,
    "display": "flex",
    "backgroundColor": "#000000",
    "alignItems": "center",
    "marginBottom": 30
  },
  "ctrl-page-info-bg": {
    "width": 750,
    "position": "absolute"
  },
  "ctrl-page-info-panel": {
    "height": 600,
    "backgroundSize": "cover"
  },
  "ctrl-page-temp-control": {
    "display": "flex",
    "flexDirection": "row",
    "width": 750,
    "justifyContent": "center",
    "alignItems": "center",
    "position": "absolute",
    "top": 200
  },
  "ctrl-page-temperature-value": {
    "width": 380,
    "height": 400,
    "display": "flex",
    "justifyContent": "center",
    "alignItems": "center"
  },
  "ctrl-page-circleprogress": {
    "position": "absolute",
    "width": 750,
    "top": 90,
    "height": 630
  },
  "ctrl-page-circle-arc": {
    "width": 630,
    "height": 630,
    "alignSelf": "center"
  },
  "ctrl-page-temp-btn": {
    "display": "flex",
    "justifyContent": "center",
    "alignItems": "center",
    "flexDirection": "row",
    "position": "absolute",
    "width": 500,
    "left": 125,
    "top": 350
  },
  "ctrl-page-temperature-btn-img": {
    "height": 55,
    "width": 55
  },
  "ctrl-page-temperature-unit": {
    "color": "#ffffff",
    "position": "absolute",
    "top": 120,
    "right": 53,
    "fontSize": 30
  },
  "ctrl-page-more-info-wrap": {
    "width": 350,
    "paddingTop": 16,
    "paddingRight": 16,
    "paddingBottom": 16,
    "paddingLeft": 16,
    "borderRadius": 50,
    "marginTop": 30
  },
  "ctrl-page-control-btn-group": {
    "width": 700,
    "marginTop": 12,
    "marginRight": 25,
    "marginBottom": 20,
    "marginLeft": 25,
    "position": "relative",
    "top": 20
  },
  "ctrl-page-btn-img-style": {
    "height": 95,
    "width": 95
  },
  "ctrl-page-control-btn-cell": {
    "height": 152,
    "backgroundColor": "rgba(255,255,255,0.1)",
    "width": 686,
    "paddingTop": 15,
    "paddingRight": 32,
    "paddingBottom": 15,
    "paddingLeft": 32,
    "borderRadius": 20,
    "display": "flex",
    "flexDirection": "row",
    "alignItems": "center",
    "position": "relative"
  },
  "ctrl-page-control-btn-group-wrap": {
    "backgroundColor": "rgba(255,255,255,0.1)",
    "borderRadius": 20,
    "paddingTop": 30,
    "paddingRight": 0,
    "paddingBottom": 30,
    "paddingLeft": 0,
    "display": "flex",
    "flexDirection": "row",
    "flexWrap": "wrap"
  },
  "ctrl-page-single-btn": {
    "height": 145,
    "width": 135,
    "display": "flex",
    "marginTop": 10,
    "marginRight": 20,
    "marginBottom": 10,
    "marginLeft": 20,
    "flexDirection": "column",
    "justifyContent": "center",
    "alignItems": "center",
    "opacity": 1
  },
  "ctrl-page-cell-img": {
    "marginTop": 0,
    "marginRight": 30,
    "marginBottom": 0,
    "marginLeft": 0
  },
  "ctrl-page-cell-title": {
    "display": "flex",
    "alignItems": "center",
    "flexDirection": "row"
  },
  "ctrl-page-switch-btn": {
    "position": "absolute",
    "left": 550,
    "top": 50,
    "width": 100,
    "height": 60
  },
  "ctrl-page-btn-text": {
    "textAlign": "center",
    "fontSize": 24,
    "color": "#000000",
    "marginTop": 20
  },
  "silder-container": {
    "flex": 1,
    "marginLeft": 8,
    "marginRight": 8,
    "height": 64,
    "width": 550
  },
  "line-container": {
    "position": "absolute",
    "left": 20,
    "height": 64,
    "width": 550,
    "flexDirection": "row",
    "justifyContent": "space-around",
    "alignItems": "center"
  },
  "line": {
    "height": 6,
    "marginTop": 30,
    "marginRight": 3,
    "marginBottom": 30,
    "marginLeft": 3,
    "flex": 1,
    "backgroundColor": "#424546",
    "borderRadius": 2
  },
  "title": {
    "fontSize": 35,
    "textAlign": "center"
  },
  "custom-content": {
    "marginTop": 10,
    "textAlign": "center"
  },
  "content": {
    "width": 750,
    "alignItems": "center",
    "justifyContent": "center"
  },
  "info-wrapper": {
    "width": 750,
    "display": "flex",
    "justifyContent": "center",
    "alignItems": "center",
    "position": "absolute",
    "top": 300,
    "height": 600
  },
  "dialog-btn": {
    "width": 300,
    "height": 80,
    "marginTop": 0,
    "marginRight": 20,
    "marginBottom": 0,
    "marginLeft": 20,
    "display": "flex",
    "justifyContent": "center",
    "alignItems": "center",
    "backgroundColor": "#333333"
  },
  "theme-blk": {
    "position": "absolute",
    "top": 4.7,
    "left": 4,
    "zIndex": 100,
    "height": 35,
    "width": 35,
    "backgroundColor": "#808080",
    "borderRadius": 35
  },
  "theme-blk-android": {
    "position": "absolute",
    "top": 5,
    "left": 4,
    "zIndex": 100,
    "height": 35,
    "width": 35,
    "backgroundColor": "#808080",
    "borderRadius": 35
  },
  "theme-wx-switch-color": {
    "position": "absolute",
    "width": 96,
    "height": 48,
    "borderRadius": 62,
    "borderWidth": 2,
    "borderStyle": "solid"
  },
  "theme-border-show": {
    "opacity": 1,
    "borderColor": "#c06039"
  },
  "theme-border-none": {
    "opacity": 1,
    "borderColor": "#808080"
  },
  "right-text-custom": {
    "fontSize": 24,
    "color": "#999999"
  },
  "midea-cell-firmware": {
    "height": 168,
    "position": "relative",
    "flexDirection": "row",
    "alignItems": "center",
    "paddingLeft": 32,
    "paddingRight": 32,
    "backgroundColor": "#ffffff"
  },
  "midea-cell": {
    "height": 108,
    "position": "relative",
    "flexDirection": "row",
    "alignItems": "center",
    "paddingLeft": 32,
    "paddingRight": 32,
    "backgroundColor": "#ffffff"
  },
  "active-cell": {
    "backgroundColor:active": "#f5f5f5"
  },
  "cell-margin": {
    "marginBottom": 24
  },
  "cell-title": {
    "flex": 1
  },
  "cell-indent": {
    "paddingBottom": 30,
    "paddingTop": 30
  },
  "has-desc": {
    "paddingBottom": 18,
    "paddingTop": 18
  },
  "cell-top-border": {
    "borderTopColor": "#e2e2e2",
    "borderTopWidth": 1
  },
  "cell-bottom-border": {
    "borderBottomWidth": 1,
    "borderBottomStyle": "solid",
    "borderBottomColor": "#e2e2e2"
  },
  "cell-label-text": {
    "fontSize": 30,
    "color": "#666666",
    "width": 188,
    "marginRight": 10
  },
  "right-text": {
    "fontSize": 24,
    "color": "#999999"
  },
  "cell-arrow-icon": {
    "width": 12,
    "height": 24,
    "position": "absolute",
    "right": 24
  },
  "cell-content": {
    "color": "#333333",
    "fontSize": 30,
    "lineHeight": 40
  },
  "cell-desc-text": {
    "color": "#999999",
    "fontSize": 24,
    "lineHeight": 30,
    "marginTop": 4
  },
  "item-img": {
    "width": 30,
    "height": 30,
    "marginRight": 24
  }
}

/***/ }),

/***/ 52:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var _util = __webpack_require__(28);

var _util2 = _interopRequireDefault(_util);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var icon = __webpack_require__(29);

module.exports = {
    props: {
        height: {
            type: String,
            default: '100'
        },
        label: {
            type: String,
            default: ''
        },
        title: {
            type: String,
            default: ''
        },
        desc: {
            type: String,
            default: ''
        },
        rightText: {
            type: String,
            default: ''
        },
        clickActivied: {
            type: Boolean,
            default: false
        },
        hasTopBorder: {
            type: Boolean,
            default: false
        },
        hasMargin: {
            type: Boolean,
            default: false
        },
        hasBottomBorder: {
            type: Boolean,
            default: true
        },
        hasArrow: {
            type: Boolean,
            default: false
        },
        hasVerticalIndent: {
            type: Boolean,
            default: true
        },
        isOver: {
            type: Boolean,
            default: false
        },
        cellStyle: {
            type: Object,
            default: function _default() {
                return {};
            }
        },
        itemImg: {
            type: String,
            default: ''
        },
        itemImgWidth: {
            type: Number,
            default: 30
        },
        itemImgHeight: {
            type: Number,
            default: 30
        },
        mideaCellClass: {
            type: String,
            default: 'midea-cell'
        },
        activeCellClass: {
            type: String,
            default: 'active-cell'
        },
        cellLabelTextClass: {
            type: String,
            default: 'cell-label-text'
        },
        rightTextClass: {
            type: String,
            default: 'right-text'
        },
        cellContentClass: {
            type: String,
            default: 'cell-content'
        },
        cellDescText: {
            type: String,
            default: 'cell-desc-text'
        },
        cellTopBorderClass: {
            type: String,
            default: 'cell-top-border'
        },
        cellBottomBorderClass: {
            type: String,
            default: 'cell-bottom-border'
        }
    },
    computed: {
        outputCellStyle: function outputCellStyle() {
            var height = this.height,
                cellStyle = this.cellStyle;
            //return util.extend({"height":height+"px"},cellStyle);

            return _extends({ "height": height + "px" }, cellStyle);
        }
    },
    data: function data() {
        return {
            //arrowIcon: icon.arrowIcon
            arrowIcon: "./img/arrow_right.png"
        };
    },
    methods: {
        cellClicked: function cellClicked(e) {

            this.$emit('mideaCellClick', { e: e });
        }
    }
};

/***/ }),

/***/ 53:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    class: [_vm.mideaCellClass, _vm.clickActivied && _vm.activeCellClass, _vm.hasTopBorder && _vm.cellTopBorderClass, _vm.hasBottomBorder && _vm.cellBottomBorderClass, _vm.hasMargin && 'cell-margin', _vm.hasVerticalIndent && 'cell-indent', _vm.desc && 'has-desc'],
    style: {
      'display': 'flex',
      'flex-direction': _vm.isOver ? 'row-reverse' : 'row'
    },
    on: {
      "click": _vm.cellClicked
    }
  }, [_vm._t("itemImg", [(_vm.itemImg && _vm.itemImg != '') ? _c('image', {
    staticClass: ["item-img"],
    style: {
      width: _vm.itemImgWidth + 'px',
      height: _vm.itemImgHeight + 'px'
    },
    attrs: {
      "src": _vm.itemImg
    }
  }) : _vm._e()]), _vm._t("label", [(_vm.label) ? _c('div', [_c('text', {
    class: [_vm.cellLabelTextClass]
  }, [_vm._v(_vm._s(_vm.label))])]) : _vm._e()]), _c('div', {
    staticClass: ["cell-title"]
  }, [_vm._t("title", [_c('text', {
    class: [_vm.cellContentClass]
  }, [_vm._v(_vm._s(_vm.title))]), (_vm.desc) ? _c('text', {
    class: [_vm.cellDescText]
  }, [_vm._v(_vm._s(_vm.desc))]) : _vm._e()])], 2), _vm._t("value"), _vm._t("text"), _vm._t("rightText", [(_vm.rightText) ? _c('div', {
    style: {
      paddingRight: _vm.hasArrow ? '24px' : '0px'
    }
  }, [_c('text', {
    class: [_vm.rightTextClass]
  }, [_vm._v(_vm._s(_vm.rightText))])]) : _vm._e()]), (_vm.hasArrow) ? _c('image', {
    staticClass: ["cell-arrow-icon"],
    style: {
      top: ((_vm.height - 24) / 2) + 'px',
      left: _vm.isOver ? '24px' : 'auto',
      transform: _vm.isOver ? 'rotate(180deg)' : 'rotate(0deg)'
    },
    attrs: {
      "src": _vm.arrowIcon
    }
  }) : _vm._e()], 2)
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),

/***/ 7:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _nativeService = __webpack_require__(1);

var _nativeService2 = _interopRequireDefault(_nativeService);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var appPageDataChannel = new BroadcastChannel('appPageData');
var lottieModule = weex.requireModule('lottieModule');

var HasBurialPoint = true;

var WeexLayer = function () {
    function WeexLayer() {
        _classCallCheck(this, WeexLayer);
    }

    /*
    * 页面跳转
    * params 参数对象
    * fromPage 可选参数，从哪个页面跳转进来
    * */


    _createClass(WeexLayer, null, [{
        key: 'goToPages',
        value: function goToPages(link, params, fromPage, WebComDecorator) {
            var path = link + ".js";

            var _params = params === undefined ? {} : params;
            if (fromPage !== undefined) {
                _params['fromPage'] = fromPage;
            }

            var isCanSideBack = undefined;

            if (params && params.isCanSideBack !== undefined) {
                isCanSideBack = params.isCanSideBack;
            }
            // nativeService.alert('ww'+isCanSideBack)
            _nativeService2.default.goTo(path, { viewTag: link }, { param: JSON.stringify(params) }, isCanSideBack);

            //跳转埋点
            if (HasBurialPoint) {
                var routerItems = path.split("/");
                WebComDecorator && WebComDecorator.burialPointRequestCommon && WebComDecorator.burialPointRequestCommon(routerItems[routerItems.length - 1], fromPage, {}, {});
            }
        }

        /*
        * 页面返回：普通返回 + 跳页返回
        * */

    }, {
        key: 'goBack',
        value: function goBack(link, fromPage, toPage, WebComDecorator) {
            if (link !== undefined && link !== "") {
                _nativeService2.default.goBack({ viewTag: link });
            } else {
                _nativeService2.default.goBack();
            }

            //返回埋点
            HasBurialPoint && WebComDecorator && WebComDecorator.burialPointRequestCommon && WebComDecorator.burialPointRequestCommon(toPage, fromPage, {}, {});
        }

        /*
        * 快速返回:一键返回到最开始跳转的页面
        * */

    }, {
        key: 'goBackToRootView',
        value: function goBackToRootView() {
            _nativeService2.default.goBack({ viewTag: 'rootView' });
        }

        /*
        * 页面返回：退出插件
        * */

    }, {
        key: 'goBackToMeiju',
        value: function goBackToMeiju() {
            _nativeService2.default.backToNative();
        }

        /*
        * 获取页面导航参数
        * */

    }, {
        key: 'getParams',
        value: function getParams() {
            var params = _nativeService2.default.getParameters('param');

            if (WeexLayer.isEmptyObject(params)) {
                return null;
            } else {
                return JSON.parse(params);
            }
        }

        /*
        * 获得前一个页面
        * */

    }, {
        key: 'getPrePage',
        value: function getPrePage() {
            var params = WeexLayer.getParams();

            if (params !== null && params.fromPage !== undefined) {
                return params.fromPage;
            } else {
                return null;
            }
        }

        /*
        * 重置应用程序状态
        * */

    }, {
        key: 'resetAppRuntimeData',
        value: function resetAppRuntimeData(callback, _uuid) {
            var uuid = _uuid !== undefined ? _uuid : '';
            WeexLayer.resetCache(uuid + 'appRuntimeData', function () {
                callback && callback();
            });
        }

        /*
        * 设置应用程序状态
        * */

    }, {
        key: 'setAppRuntimeData',
        value: function setAppRuntimeData(dict, callback, _uuid) {
            var uuid = _uuid !== undefined ? _uuid : '';

            WeexLayer.getCache(uuid + 'appRuntimeData', function (result) {
                var data = dict;

                if (result !== null) {
                    data = result;
                    for (var key in dict) {
                        data[key] = dict[key];
                    }
                }

                WeexLayer.setCache(uuid + 'appRuntimeData', data, callback);
            });
        }

        /*
        * 获取应用程序状态
        * */

    }, {
        key: 'getAppRuntimeData',
        value: function getAppRuntimeData(callback, _uuid) {
            var uuid = _uuid !== undefined ? _uuid : '';

            WeexLayer.getCache(uuid + 'appRuntimeData', function (result) {
                callback && callback(result);
            });
        }

        /*
        * 删除应用程序中的某个状态
        * */

    }, {
        key: 'removeAppRuntimeData',
        value: function removeAppRuntimeData(key, callback, _uuid) {
            var uuid = _uuid !== undefined ? _uuid : '';

            WeexLayer.getCache(uuid + 'appRuntimeData', function (result) {
                if (result !== null) {
                    var data = result;

                    if (data[key] !== undefined) {
                        delete data[key];

                        WeexLayer.setCache(uuid + 'appRuntimeData', data, callback);
                    }
                }
            });
        }

        /*
        * 设置缓存
        * */

    }, {
        key: 'setCache',
        value: function setCache(key, dict, callback) {
            _nativeService2.default.setItem(key, JSON.stringify(dict), function () {
                callback && callback();
            });
        }

        /*
        * 获取缓存
        * */

    }, {
        key: 'getCache',
        value: function getCache(key, callback) {
            _nativeService2.default.getItem(key, function (result) {
                if (result.data !== "undefined" && callback) {
                    callback(JSON.parse(result.data));
                } else {
                    callback(null);
                }
            });
        }

        /*
        * 重置缓存
        * */

    }, {
        key: 'resetCache',
        value: function resetCache(key, callback) {
            _nativeService2.default.removeItem(key, function () {
                callback && callback();
            });
        }

        /*
        * 消息系统
        * 发送消息
        * */

    }, {
        key: 'postMessage',
        value: function postMessage(_name, _data) {
            appPageDataChannel.postMessage({ name: _name, data: _data });
        }

        /*
        * 消息系统
        * 接受消息
        * */

    }, {
        key: 'onMessage',
        value: function onMessage(_name, callback) {
            appPageDataChannel.onmessage = function (event) {
                if (event !== undefined && event.data !== undefined && event.data.name !== undefined) {
                    if (_name === event.data.name) {
                        callback && callback(event.data.data);
                    }
                }
            };
        }
    }, {
        key: 'isEmptyObject',
        value: function isEmptyObject(obj) {
            for (var key in obj) {
                return false;
            }
            return true;
        }
    }, {
        key: 'lottieControl',


        /*
        * lottie 通用控制
        * */
        value: function lottieControl(lottieRef, action, success, error) {
            var param = {
                api: action,
                params: {}
            };
            lottieModule.lottieInterface(lottieRef, param, function (data) {
                success && success(data);
            }, function (data) {
                error && error(data);
            });
        }

        /*
        * lottie 播放
        * */

    }, {
        key: 'lottiePlay',
        value: function lottiePlay(lottieRef, success, error) {
            this.lottieControl(lottieRef, 'play', success, error);
        }

        /*
        * lottie 暂停
        * */

    }, {
        key: 'lottiePause',
        value: function lottiePause(lottieRef, success, error) {
            this.lottieControl(lottieRef, 'pause', success, error);
        }

        /*
        * lottie 恢复
        * */

    }, {
        key: 'lottieResume',
        value: function lottieResume(lottieRef, success, error) {
            this.lottieControl(lottieRef, 'resume', success, error);
        }

        /*
        * lottie 停止
        * */

    }, {
        key: 'lottieStop',
        value: function lottieStop(lottieRef, success, error) {
            this.lottieControl(lottieRef, 'stop', success, error);
        }

        /*
        * Apng 通用控制
        * */

    }, {
        key: 'apngControl',
        value: function apngControl(apngRef, action, params, success, error) {
            apngRef[action](params, function (success) {
                success && success();
            }, function (error) {
                error && error();
            });
        }

        /*
        * 获取当前页面
        * */

    }, {
        key: 'getCurrentPage',
        value: function getCurrentPage() {
            var bundleUrl = weex.config.bundleUrl;
            return bundleUrl;
            // nativeService.alert(weex.config.bundleUrl)
            // return bundleUrl.substring(bundleUrl.lastIndexOf('/') + 1, bundleUrl.lastIndexOf('.js'))
        }
    }]);

    return WeexLayer;
}();

exports.default = WeexLayer;

/***/ }),

/***/ 8:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

// ************ debug 相关 *************
var storage = weex.requireModule('storage');
var mm = weex.requireModule('modal');
var debugInfoDataChannel = new BroadcastChannel('debugInfoDataChannel');
var debugUtil = {
    isEnableDebugInfo: false,
    debugInfoKey: 'debugInfo',
    debugInfoDataChannel: debugInfoDataChannel,
    debugInfoExist: '',
    debugInfo: '',
    debugLogSizeLmite: 80000,
    debugLog: function debugLog() {
        var _this = this;

        for (var _len = arguments.length, messages = Array(_len), _key = 0; _key < _len; _key++) {
            messages[_key] = arguments[_key];
        }

        if (!this.isEnableDebugInfo) return;

        if (!this.debugInfoExist) {
            this.getDebugLog().then(function (data) {
                _this.debugInfoExist = data || ' ***>>> ';
                _this.debugLog.apply(_this, messages);
            });
        } else {
            var debugInfoArray = [];
            for (var index = 0; index < messages.length; index++) {
                var message = messages[index];
                if ((typeof message === 'undefined' ? 'undefined' : _typeof(message)) == 'object') {
                    try {
                        message = JSON.stringify(message, null, 2);
                    } catch (error) {
                        debugInfoArray.push(error);
                    }
                } else if (typeof message == 'string') {
                    try {
                        message = JSON.stringify(JSON.parse(message), null, 2);
                    } catch (error) {}
                }
                debugInfoArray = debugInfoArray.concat(this.strCut2Arr(message, 2000));
            }
            var newDebugInfo = new Date() + '\n' + debugInfoArray.join(", ") + '\n\n';
            this.debugInfo += newDebugInfo;
            this.setItem(this.debugInfoKey, this.debugInfoExist + this.debugInfo);
        }
    },
    getDebugLog: function getDebugLog() {
        var _this2 = this;

        return new Promise(function (resolve, reject) {
            _this2.getItem(_this2.debugInfoKey, function (resp) {
                var result = resp.data || '';
                resolve(result.substr(-_this2.debugLogSizeLmite));
            });
        });
    },
    resetDebugLog: function resetDebugLog() {
        this.debugInfoExist = '';
        this.debugInfo = '';
    },
    cleanDebugLog: function cleanDebugLog() {
        var _this3 = this;

        this.debugInfoExist = '***';
        this.debugInfo = '';
        return new Promise(function (resolve, reject) {
            _this3.removeItem(_this3.debugInfoKey, function () {
                _this3.debugInfoExist = '***';
                _this3.debugInfo = '';
                resolve();
            });
        });
    },
    getItem: function getItem(key, callback) {
        storage.getItem(key, callback);
    },
    setItem: function setItem(key, value, callback) {
        if ((typeof value === 'undefined' ? 'undefined' : _typeof(value)) == 'object') {
            value = JSON.stringify(value);
        }
        value = value.substr(-this.debugLogSizeLmite);
        storage.setItem(key, value, callback);
    },
    removeItem: function removeItem(key, callback) {
        storage.removeItem(key, callback);
    },
    strCut2Arr: function strCut2Arr(str, n) {
        var arr = [];
        var len = Math.ceil(str.length / n);
        for (var i = 0; i < len; i++) {
            if (str.length >= n) {
                var strCut = str.substring(0, n);
                arr.push(strCut + '&*&');
                str = str.substring(n);
            } else {
                str = str;
                arr.push(str);
            }
        }
        return arr;
    }
};

debugInfoDataChannel.onmessage = function (event) {
    debugUtil.cleanDebugLog();
};

exports.default = debugUtil;

/***/ }),

/***/ 941:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _AddScheduleRepeat = __webpack_require__(942);

var _AddScheduleRepeat2 = _interopRequireDefault(_AddScheduleRepeat);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

new Vue({
  el: '#root',
  render: function render(h) {
    return h(_AddScheduleRepeat2.default);
  }
}); // 自动生成的入口文件

/***/ }),

/***/ 942:
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(943)
)

/* script */
__vue_exports__ = __webpack_require__(944)

/* template */
var __vue_template__ = __webpack_require__(945)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "/Users/chenhx113/Documents/project/meijuobmweexapp/code/AC/src/T0xAC/app/ac/common/AddScheduleRepeat.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-5f39bccb"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),

/***/ 943:
/***/ (function(module, exports) {

module.exports = {
  "theme-background": {
    "backgroundColor": "#F9F9F9"
  },
  "white-background": {
    "backgroundColor": "#ffffff"
  },
  "theme-background-full": {
    "backgroundColor": "#468EFF"
  },
  "theme-font-color": {
    "color": "#000000"
  },
  "theme-font-orange-color": {
    "color": "#C26033"
  },
  "theme-font-explain-color": {
    "color": "#D8D8DE",
    "opacity": 0.4
  },
  "theme-font-msg-gray-color": {
    "color": "#8A8A8F"
  },
  "theme-font-msg-gray-bg-color": {
    "backgroundColor": "#333333"
  },
  "theme-center-layout": {
    "display": "flex",
    "flexDirection": "row",
    "alignItems": "center"
  },
  "theme-center-layout-wrapper": {
    "display": "flex",
    "flexDirection": "row",
    "alignItems": "center",
    "flexWrap": "wrap"
  },
  "theme-cell-standard-style": {
    "backgroundColor": "#1a1a1a"
  },
  "spacing-line": {
    "width": 750,
    "height": 1,
    "backgroundColor": "#e2e2e2",
    "display": "flex",
    "alignSelf": "center"
  },
  "midea-cell-theme": {
    "height": 124,
    "position": "relative",
    "flexDirection": "row",
    "alignItems": "center",
    "paddingLeft": 32,
    "paddingRight": 32,
    "backgroundColor": "#1a1a1a"
  },
  "active-cell-theme": {
    "backgroundColor:active": "#cccccc"
  },
  "cell-label-text-theme": {
    "fontSize": 30,
    "color": "#666666",
    "width": 188,
    "marginRight": 10
  },
  "right-text-theme": {
    "fontSize": 25,
    "color": "#ffffff"
  },
  "cell-content-theme": {
    "color": "#ffffff",
    "fontSize": 30,
    "lineHeight": 40
  },
  "cell-desc-text-theme": {
    "color": "#999999",
    "fontSize": 24,
    "lineHeight": 30,
    "marginTop": 4
  },
  "cell-top-border-theme": {
    "borderTopColor": "#333333",
    "borderTopWidth": 1,
    "opacity": 0.8
  },
  "cell-bottom-border-theme": {
    "borderBottomWidth": 1,
    "borderBottomStyle": "solid",
    "borderBottomColor": "#333333",
    "opacity": 0.8
  },
  "wrap-theme": {
    "position": "relative",
    "flexDirection": "row",
    "backgroundColor": "#000000"
  },
  "selected-item-theme": {
    "opacity": 1,
    "color": "#ffffff",
    "fontSize": 48
  },
  "unselected-item-theme": {
    "opacity": 0.3,
    "color": "#ffffff"
  },
  "debug-util": {
    "borderWidth": 2,
    "borderColor": "#FF0000"
  },
  "ctrl-page-wrapper": {
    "backgroundColor": "#000000",
    "width": 750
  },
  "ctrl-page-scroller": {
    "flex": 1,
    "zIndex": 99999,
    "display": "flex",
    "backgroundColor": "#000000",
    "alignItems": "center",
    "marginBottom": 30
  },
  "ctrl-page-info-bg": {
    "width": 750,
    "position": "absolute"
  },
  "ctrl-page-info-panel": {
    "height": 600,
    "backgroundSize": "cover"
  },
  "ctrl-page-temp-control": {
    "display": "flex",
    "flexDirection": "row",
    "width": 750,
    "justifyContent": "center",
    "alignItems": "center",
    "position": "absolute",
    "top": 200
  },
  "ctrl-page-temperature-value": {
    "width": 380,
    "height": 400,
    "display": "flex",
    "justifyContent": "center",
    "alignItems": "center"
  },
  "ctrl-page-circleprogress": {
    "position": "absolute",
    "width": 750,
    "top": 90,
    "height": 630
  },
  "ctrl-page-circle-arc": {
    "width": 630,
    "height": 630,
    "alignSelf": "center"
  },
  "ctrl-page-temp-btn": {
    "display": "flex",
    "justifyContent": "center",
    "alignItems": "center",
    "flexDirection": "row",
    "position": "absolute",
    "width": 500,
    "left": 125,
    "top": 350
  },
  "ctrl-page-temperature-btn-img": {
    "height": 55,
    "width": 55
  },
  "ctrl-page-temperature-unit": {
    "color": "#ffffff",
    "position": "absolute",
    "top": 120,
    "right": 53,
    "fontSize": 30
  },
  "ctrl-page-more-info-wrap": {
    "width": 350,
    "paddingTop": 16,
    "paddingRight": 16,
    "paddingBottom": 16,
    "paddingLeft": 16,
    "borderRadius": 50,
    "marginTop": 30
  },
  "ctrl-page-control-btn-group": {
    "width": 700,
    "marginTop": 12,
    "marginRight": 25,
    "marginBottom": 20,
    "marginLeft": 25,
    "position": "relative",
    "top": 20
  },
  "ctrl-page-btn-img-style": {
    "height": 95,
    "width": 95
  },
  "ctrl-page-control-btn-cell": {
    "height": 152,
    "backgroundColor": "rgba(255,255,255,0.1)",
    "width": 686,
    "paddingTop": 15,
    "paddingRight": 32,
    "paddingBottom": 15,
    "paddingLeft": 32,
    "borderRadius": 20,
    "display": "flex",
    "flexDirection": "row",
    "alignItems": "center",
    "position": "relative"
  },
  "ctrl-page-control-btn-group-wrap": {
    "backgroundColor": "rgba(255,255,255,0.1)",
    "borderRadius": 20,
    "paddingTop": 30,
    "paddingRight": 0,
    "paddingBottom": 30,
    "paddingLeft": 0,
    "display": "flex",
    "flexDirection": "row",
    "flexWrap": "wrap"
  },
  "ctrl-page-single-btn": {
    "height": 145,
    "width": 135,
    "display": "flex",
    "marginTop": 10,
    "marginRight": 20,
    "marginBottom": 10,
    "marginLeft": 20,
    "flexDirection": "column",
    "justifyContent": "center",
    "alignItems": "center",
    "opacity": 1
  },
  "ctrl-page-cell-img": {
    "marginTop": 0,
    "marginRight": 30,
    "marginBottom": 0,
    "marginLeft": 0
  },
  "ctrl-page-cell-title": {
    "display": "flex",
    "alignItems": "center",
    "flexDirection": "row"
  },
  "ctrl-page-switch-btn": {
    "position": "absolute",
    "left": 550,
    "top": 50,
    "width": 100,
    "height": 60
  },
  "ctrl-page-btn-text": {
    "textAlign": "center",
    "fontSize": 24,
    "color": "#000000",
    "marginTop": 20
  },
  "silder-container": {
    "flex": 1,
    "marginLeft": 8,
    "marginRight": 8,
    "height": 64,
    "width": 550
  },
  "line-container": {
    "position": "absolute",
    "left": 20,
    "height": 64,
    "width": 550,
    "flexDirection": "row",
    "justifyContent": "space-around",
    "alignItems": "center"
  },
  "line": {
    "height": 6,
    "marginTop": 30,
    "marginRight": 3,
    "marginBottom": 30,
    "marginLeft": 3,
    "flex": 1,
    "backgroundColor": "#424546",
    "borderRadius": 2
  },
  "title": {
    "fontSize": 35,
    "textAlign": "center"
  },
  "custom-content": {
    "marginTop": 10,
    "textAlign": "center"
  },
  "content": {
    "width": 750,
    "alignItems": "center",
    "justifyContent": "center"
  },
  "info-wrapper": {
    "width": 750,
    "display": "flex",
    "justifyContent": "center",
    "alignItems": "center",
    "position": "absolute",
    "top": 300,
    "height": 600
  },
  "dialog-btn": {
    "width": 300,
    "height": 80,
    "marginTop": 0,
    "marginRight": 20,
    "marginBottom": 0,
    "marginLeft": 20,
    "display": "flex",
    "justifyContent": "center",
    "alignItems": "center",
    "backgroundColor": "#333333"
  },
  "theme-blk": {
    "position": "absolute",
    "top": 4.7,
    "left": 4,
    "zIndex": 100,
    "height": 35,
    "width": 35,
    "backgroundColor": "#808080",
    "borderRadius": 35
  },
  "theme-blk-android": {
    "position": "absolute",
    "top": 5,
    "left": 4,
    "zIndex": 100,
    "height": 35,
    "width": 35,
    "backgroundColor": "#808080",
    "borderRadius": 35
  },
  "theme-wx-switch-color": {
    "position": "absolute",
    "width": 96,
    "height": 48,
    "borderRadius": 62,
    "borderWidth": 2,
    "borderStyle": "solid"
  },
  "theme-border-show": {
    "opacity": 1,
    "borderColor": "#c06039"
  },
  "theme-border-none": {
    "opacity": 1,
    "borderColor": "#808080"
  },
  "right-text-custom": {
    "fontSize": 24,
    "color": "#999999"
  },
  "midea-cell-firmware": {
    "height": 168,
    "position": "relative",
    "flexDirection": "row",
    "alignItems": "center",
    "paddingLeft": 32,
    "paddingRight": 32,
    "backgroundColor": "#ffffff"
  }
}

/***/ }),

/***/ 944:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _base = __webpack_require__(12);

var _base2 = _interopRequireDefault(_base);

var _nativeService = __webpack_require__(1);

var _nativeService2 = _interopRequireDefault(_nativeService);

var _WeexLayer = __webpack_require__(7);

var _WeexLayer2 = _interopRequireDefault(_WeexLayer);

var _cell = __webpack_require__(50);

var _cell2 = _interopRequireDefault(_cell);

var _WebComDecorator = __webpack_require__(32);

var _WebComDecorator2 = _interopRequireDefault(_WebComDecorator);

var _Process = __webpack_require__(5);

var _Process2 = _interopRequireDefault(_Process);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var BroadcastChannel = weex.requireModule('BroadcastChannel');

exports.default = {
    name: 'AddScheduleRepeat',
    components: {
        mideaCell: _cell2.default
    },
    mixins: [_base2.default],
    data: function data() {
        return {
            t: _Process2.default,

            msg: 'AddScheduleRepeat',
            links: [],
            commonUse: [],
            customUse: [],

            week: [],
            repeat: 0,
            scheduleId: null,
            switcher: null,
            time: null,
            status: null,
            temperature: null,
            wind: null,
            mode: null,
            label: null,
            timezone: null,
            userId: null,
            appId: null,
            timeType: null,
            isUpdate: null,

            hasSet: false,

            morefuncListA: [{
                "name": "Every day",
                "rightText": "",
                "descText": "",
                "itemImg": "./../../../../assets/img/ac/clomo-ems/setting/timer-icon@2x.png",
                "selected": true
            }, {
                "name": "Weekdays",
                "rightText": "",
                "descText": "",
                "itemImg": "./../../../../assets/img/ac/clomo-ems/setting/auto-switch-icon@2x.png"
            }, {
                "name": "Only once",
                "rightText": "",
                "descText": "",
                "itemImg": "./../../../../assets/img/ac/clomo-ems/setting/auto-switch-icon@2x.png"
            }],

            morefuncListB: [{
                "name": "Monday",
                "rightText": "",
                "descText": "",
                "itemImg": "./../../../../assets/img/ac/clomo-ems/setting/timer-icon@2x.png"
            }, {
                "name": "Tuesday",
                "rightText": "",
                "descText": "",
                "itemImg": "./../../../../assets/img/ac/clomo-ems/setting/timer-icon@2x.png"
            }, {
                "name": "Wednesday",
                "rightText": "",
                "descText": "",
                "itemImg": "./../../../../assets/img/ac/clomo-ems/setting/timer-icon@2x.png"
            }, {
                "name": "Thursday",
                "rightText": "",
                "descText": "",
                "itemImg": "./../../../../assets/img/ac/clomo-ems/setting/timer-icon@2x.png"
            }, {
                "name": "Friday",
                "rightText": "",
                "descText": "",
                "itemImg": "./../../../../assets/img/ac/clomo-ems/setting/timer-icon@2x.png",
                "selected": true
            }, {
                "name": "Saturday",
                "rightText": "",
                "descText": "",
                "itemImg": "./../../../../assets/img/ac/clomo-ems/setting/timer-icon@2x.png"
            }, {
                "name": "Sunday",
                "rightText": "",
                "descText": "",
                "itemImg": "./../../../../assets/img/ac/clomo-ems/setting/timer-icon@2x.png"
            }]
        };
    },

    created: function created() {
        // globalEvent.addEventListener('receiveMessageFromApp', (data)=> {
        //     if (data.messageType == 'hardwareBackClick') {
        //         // this.selfBack();
        //     }
        // });
    },
    mounted: function mounted() {
        var _this = this;

        // this.broadcastChannel = new BroadcastChannel('scheduleRepeat');

        _nativeService2.default.getDeviceInfo().then(function (data) {
            // nativeService.alert(JSON.stringify(data))
            _this.deviceId = data.result.deviceId;
            _this.deviceSn = data.result.deviceSn;
            if (!_this.webComDecorator) {
                _this.webComDecorator = new _WebComDecorator2.default(false, _this.deviceId, _this.deviceSn, "");
            }
            // callback && callback()
        });
        this.isIos && this.viewappear();
    },
    methods: {
        viewappear: function viewappear() {
            var param = _WeexLayer2.default.getParams();

            this.week = param.week;
            this.repeat = param.repeat == null || param.repeat == undefined ? 1 : param.repeat;

            this.scheduleId = param.scheduleId;
            this.switcher = param.switcher;
            this.time = param.time;
            this.status = param.status;
            this.temperature = param.temperature;
            this.wind = param.wind;
            this.mode = param.mode;
            this.label = param.label, this.timezone = param.timezone, this.userId = param.userId;
            this.appId = param.appId, this.timeType = param.timeType;

            this.isUpdate = param.isUpdate;

            var that = this;
            setTimeout(function () {
                that.getCommonUse();
                that.getCustomUse();

                if (that.repeat == 1) {
                    that.setCustomSelected(that.commonUse, 2);
                } else if (that.testWeekDay([1, 2, 3, 4, 5], param.week) && param.week.length == 5) {
                    that.setCustomSelected(that.commonUse, 1);
                } else if (param.week.length == 7) {
                    that.setCustomSelected(that.commonUse, 0);
                } else {
                    for (var i = 0; i < param.week.length; i++) {
                        that.customUse[param.week[i] - 1].selected = true;
                    }
                }
            }, 200);

            // let param = this.$route.params;
            // if (param.repeat == 1) {
            //     this.setCustomSelected(this.commonUse, 2);
            // }
            // else if (this.testWeekDay([1, 2, 3, 4, 5], param.week) && param.week.length == 5) {
            //     this.setCustomSelected(this.commonUse, 1);
            // } else if (param.week.length == 7) {
            //     this.setCustomSelected(this.commonUse, 0);
            // } else {
            //     for (let i = 0; i < param.week.length; i++) {
            //         this.customUse[param.week[i] - 1].selected = true
            //     }
            // }
            // console.log('activated', this.$route.params);
        },

        init: function init() {},
        setCustomSelected: function setCustomSelected(arr, index) {
            for (var i = 0; i < arr.length; i++) {
                arr[i].selected = false;
            }
            arr[index].selected = true;
        },
        testWeekDay: function testWeekDay(container, search) {
            var arr = [1, 2, 3, 4, 5];
            // var testArr = [1,2,3,4];
            var flag = true;
            for (var i = 0; i < container.length; i++) {
                if (!this.checkWeekday(search[i], i)) {
                    flag = false;
                    console.log("!!");
                    return false;
                } else {}
                // console.log();
            }
            return flag;
        },
        checkWeekday: function checkWeekday(item, index) {
            var isExist = false;
            if (item == index + 1) {
                isExist = true;
            }
            return isExist;
        },

        // back() {
        //     this.confirmSchedule()
        //     this.popView();
        // },
        getCommonUse: function getCommonUse() {
            this.commonUse = [{
                title: this.t.getText("Every day"),
                selected: false
            }, {
                title: this.t.getText("Weekdays"),
                selected: false
            }, {
                title: this.t.getText("Only once"),
                selected: false
            }];
        },
        getCustomUse: function getCustomUse() {
            this.customUse = [{
                title: this.t.getText("Monday"),
                selected: false
            }, {
                title: this.t.getText("Tuesday"),
                selected: false
            }, {
                title: this.t.getText("Wednesday"),
                selected: false
            }, {
                title: this.t.getText("Thursday"),
                selected: false
            }, {
                title: this.t.getText("Friday"),
                selected: false
            }, {
                title: this.t.getText("Saturday"),
                selected: false
            }, {
                title: this.t.getText("Sunday"),
                selected: false
            }];
        },
        cellClick: function cellClick(item) {
            // nativeService.toast(JSON.stringify(item));
            this.resetCustomUse();
            // if (item.selected) {
            //     item.selected = false;
            // } else {
            this.resetCommonUse();
            item.selected = true;
            this.hasSet = true;
            // }

            // console.log(!item.selected);

            var repeatWeek = [];
            var repeat = 0; //0代表没选择 1代表不重复，2代表重复
            // ['每天','工作日','一次']
            for (var i = 0; i < this.commonUse.length; i++) {
                // console.log(this.commonUse[i]);
                if (this.commonUse[i].selected) {
                    // console.log(this.commonUse[i].title);
                    if (i == 0) {
                        repeatWeek = [1, 2, 3, 4, 5, 6, 7];
                        repeat = 2;
                    } else if (i == 1) {
                        repeatWeek = [1, 2, 3, 4, 5];
                        repeat = 2;
                    } else if (i == 2) {
                        repeatWeek = [];
                        repeat = 1;
                    }
                }
            }

            for (var j = 0; j < this.customUse.length; j++) {
                if (this.customUse[j].selected) {
                    repeatWeek.push(j + 1);
                    repeat = 2;
                }
            }
            // nativeService.alert("end confirm"+ repeatWeek + '---repeat:' +repeat);
            // 修改时才会立即保存(新增时因为无scheduleId,返回无法获取获取保存后的scheduleId)
            // nativeService.alert(this.isUpdate)
            if (this.isUpdate) {
                // nativeService.alert(JSON.stringify(this.timeType));
                this.webComDecorator.updateSchedule(this.scheduleId, this.switcher, this.time, repeatWeek, repeat, this.status, this.temperature, this.wind, this.mode, this.label, this.timezone, this.userId, this.appId, this.timeType, function (data) {
                    // nativeService.alert(JSON.stringify(data));
                    // nativeService.toast(t.getText('update success'));
                    // this.showLoading(false);
                    // this.back();
                }, function (errorCode, errorMsg) {
                    // nativeService.toast(t.getText('update fail'));
                });
            } else {
                // 保存至cache,返回后去获取该标识的缓存
                _WeexLayer2.default.setCache('weekAndRepeat', {
                    week: repeatWeek,
                    repeat: repeat
                }, function () {});
            }
        },
        customClick: function customClick(item) {

            if (this.checkAllSelected()) {
                item.selected = true;
                console.log("if");
            } else {
                console.log("else");
                item.selected = !item.selected;
            }
            this.checkAllSelected();
            this.resetCommonUse(); // 重置上面的
            this.hasSet = true;

            var repeatWeek = [];
            var repeat = 0; //0代表没选择 1代表不重复，2代表重复
            // ['每天','工作日','一次']
            for (var i = 0; i < this.commonUse.length; i++) {
                // console.log(this.commonUse[i]);
                if (this.commonUse[i].selected) {
                    // console.log(this.commonUse[i].title);
                    if (i == 0) {
                        repeatWeek = [1, 2, 3, 4, 5, 6, 7];
                        repeat = 2;
                    } else if (i == 1) {
                        repeatWeek = [1, 2, 3, 4, 5];
                        repeat = 2;
                    } else if (i == 2) {
                        repeatWeek = [];
                        repeat = 1;
                    }
                }
            }

            for (var j = 0; j < this.customUse.length; j++) {
                if (this.customUse[j].selected) {
                    repeatWeek.push(j + 1);
                    repeat = 2;
                }
            }
            // nativeService.alert(repeatWeek)
            // nativeService.alert("end confirm"+ repeatWeek + '---repeat:' +repeat);
            // 修改时才会立即保存(新增时因为无scheduleId,返回无法获取获取保存后的scheduleId)
            // nativeService.alert(this.isUpdate)
            if (this.isUpdate) {
                // nativeService.alert(JSON.stringify(this.timeType));
                this.webComDecorator.updateSchedule(this.scheduleId, this.switcher, this.time, repeatWeek, repeat, this.status, this.temperature, this.wind, this.mode, this.label, this.timezone, this.userId, this.appId, this.timeType, function (data) {
                    // nativeService.alert(JSON.stringify(data));
                    // nativeService.toast(t.getText('update success'));
                    // this.showLoading(false);
                    // this.back();
                }, function (errorCode, errorMsg) {
                    // nativeService.alert(errorMsg)
                    // nativeService.toast(t.getText('update fail'));
                });
            } else {
                // 保存至cache,返回后去获取该标识的缓存
                _WeexLayer2.default.setCache('weekAndRepeat', {
                    week: repeatWeek,
                    repeat: repeat
                }, function () {
                    //  nativeService.alert(JSON.stringify(333))
                    // this.back();
                });
            }
        },
        checkAllSelected: function checkAllSelected() {
            var j = 0;
            for (var i = 0; i < this.customUse.length; i++) {
                if (this.customUse[i].selected == false) {
                    j++;
                }
                // this.customUse[i].selected = false;
            }
            console.log(j, j == 6 ? true : false);
            return j == 6 ? true : false;
        },
        resetCommonUse: function resetCommonUse() {
            for (var i = 0; i < this.commonUse.length; i++) {
                this.commonUse[i].selected = false;
            }
        },
        resetCustomUse: function resetCustomUse() {
            for (var i = 0; i < this.customUse.length; i++) {
                this.customUse[i].selected = false;
            }
        },
        confirmSchedule: function confirmSchedule() {
            var _this2 = this;

            console.log("confirm");
            var repeatWeek = [];
            var repeat = 0; //0代表没选择 1代表不重复，2代表重复
            // ['每天','工作日','一次']
            for (var i = 0; i < this.commonUse.length; i++) {
                // console.log(this.commonUse[i]);
                if (this.commonUse[i].selected) {
                    // console.log(this.commonUse[i].title);
                    if (i == 0) {
                        repeatWeek = [1, 2, 3, 4, 5, 6, 7];
                        repeat = 2;
                    } else if (i == 1) {
                        repeatWeek = [1, 2, 3, 4, 5];
                        repeat = 2;
                    } else if (i == 2) {
                        repeatWeek = [];
                        repeat = 1;
                    }
                }
            }

            for (var j = 0; j < this.customUse.length; j++) {
                if (this.customUse[j].selected) {
                    repeatWeek.push(j + 1);
                    repeat = 2;
                }
            }
            // nativeService.alert("end confirm"+ repeatWeek + '---repeat:' +repeat);

            _WeexLayer2.default.postMessage('repeatBack', {
                repeatWeek: repeatWeek,
                repeat: repeat,
                hasSet: this.hasSet
            });

            _WeexLayer2.default.getCache('timerData', function (item) {
                _WeexLayer2.default.setCache('timerData', {
                    mode: item.mode,
                    wind: item.wind,
                    temperature: item.temperature,
                    label: item.label,
                    time: item.time,
                    switcher: item.switcher,
                    isUpdate: item.isUpdate, // 标志位区分是新增还是修改
                    scheduleId: item.scheduleId,
                    timeType: item.timeType,
                    week: repeatWeek,
                    repeat: repeat
                }, function () {
                    _this2.back();
                });
            });

            // let data = {
            //     timerData: {
            //         mode: item.mode,
            //         wind: item.wind,
            //         temperature: item.temperature,
            //         label: item.label,
            //         time: item.time,
            //         switcher: item.switcher,
            //         isUpdate: item.isUpdate, // 标志位区分是新增还是修改
            //         scheduleId: item.scheduleId,
            //         week: repeatWeek,
            //         repeat: repeat
            //     }};
            // nativeService.alert(JSON.stringify(data));
            // let item = this.getCache(this).timerData;
            // this.setCache(this, {
            //     timerData: {
            //         mode: item.mode,
            //         wind: item.wind,
            //         temperature: item.temperature,
            //         label: item.label,
            //         time: item.time,
            //         switcher: item.switcher,
            //         isUpdate: item.isUpdate, // 标志位区分是新增还是修改
            //         scheduleId: item.scheduleId,
            //         week: repeatWeek,
            //         repeat: repeat
            //     }
            // });
        },
        selfBack: function selfBack() {
            this.confirmSchedule();
        }
    }
};

/***/ }),

/***/ 945:
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    ref: "wrapper",
    staticClass: ["wrapper", "theme-background"],
    on: {
      "viewappear": _vm.viewappear,
      "viewdisappear": _vm.viewdisappear
    }
  }, [_c('div', {
    staticClass: ["accounted"],
    style: {
      'height': _vm.pageHeight
    }
  }, [_c('midea-header', {
    attrs: {
      "title": _vm.t.getText('Repeat'),
      "isImmersion": _vm.isImmersion,
      "showRightImg": true,
      "rightImg": "./../../../assets/img/smart_ic_reline@3x11.png"
    },
    on: {
      "leftImgClick": _vm.selfBack,
      "rightImgClick": _vm.reload
    }
  }), _c('div', {
    staticStyle: {
      marginTop: "24px"
    }
  }, [_vm._l((_vm.commonUse), function(item, i) {
    return _c('midea-cell', {
      attrs: {
        "itemImgWidth": "40",
        "itemImgHeight": "40",
        "title": item.title,
        "hasArrow": false,
        "height": "124",
        "hasTopBorder": true,
        "hasBottomBorder": false,
        "hasSubBottomBorder": false,
        "clickActivied": true,
        "rightText": item.rightText,
        "desc": item.descText
      },
      on: {
        "mideaCellClick": function($event) {
          _vm.cellClick(item)
        }
      }
    }, [_c('div', {
      staticClass: ["cell_content"],
      slot: "rightText"
    }, [(item.selected) ? _c('image', {
      staticStyle: {
        width: "40px",
        height: "40px"
      },
      attrs: {
        "src": "./../../../assets/img/ac/common/choose.png"
      }
    }) : _vm._e()])])
  }), _c('div', {
    staticClass: ["spacing-line"]
  })], 2), _c('div', {
    staticStyle: {
      marginTop: "24px"
    }
  }, [_vm._l((_vm.customUse), function(item, i) {
    return _c('midea-cell', {
      attrs: {
        "itemImgWidth": "40",
        "itemImgHeight": "40",
        "title": item.title,
        "hasArrow": false,
        "height": "124",
        "hasTopBorder": true,
        "hasBottomBorder": false,
        "hasSubBottomBorder": false,
        "clickActivied": true,
        "rightText": item.rightText,
        "desc": item.descText
      },
      on: {
        "mideaCellClick": function($event) {
          _vm.customClick(item)
        }
      }
    }, [_c('div', {
      staticClass: ["cell_content"],
      slot: "rightText"
    }, [(item.selected) ? _c('image', {
      staticStyle: {
        width: "40px",
        height: "40px"
      },
      attrs: {
        "src": "./../../../assets/img/ac/common/choose.png"
      }
    }) : _vm._e()])])
  }), _c('div', {
    staticClass: ["spacing-line"]
  })], 2)], 1)])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ })

/******/ });